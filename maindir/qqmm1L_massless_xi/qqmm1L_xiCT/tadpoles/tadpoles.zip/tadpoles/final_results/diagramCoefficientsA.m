{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, 
 {((-I)*4^(-1 - 2*d)*EL^6*gAl^3*gAu^3*
    ((2*Pi)^(3*d)*((-224 + 232*d - 74*d^2 + 7*d^3)*s^2 + 
       4*(144 - 76*d + 9*d^2)*s*t + 4*(176 - 80*d + 7*d^2)*t^2) - 
     2^(1 + 3*d)*(32 - 20*d + 3*d^2)*Pi^(3*d)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] - (-4 + d)^2*(2*Pi)^(3*d)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]^2))/((-4 + d)*Pi^(4*d)*s^2), 
  (I*(32 - 14*d + d^2)*EL^6*gAl^3*gAu^3*(s + 2*t))/((-4 + d)*(2*Pi)^d*s), 
  (I*2^(-1 - 2*d)*EL^6*gAl^3*gAu^3*t*(3*d*(2*Pi)^d*s^2 + 
     2^(3 + d)*Pi^d*(-s^2 + s*t + 2*t^2)))/(Pi^(2*d)*s), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, (I*4^(-1 - d)*EL^6*gAl^2*gAu^2*
    (gZlL*gZuL*(mz^2*(2^(1 + d)*(-12 - 14*d + 18*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(5 + d)*(2*Pi)^d) + 13*d^3*(2*Pi)^d*s - 
       2^(1 + d)*Pi^d*((-52 - 2*d + 26*d^2 - 3*d^3 + d^4)*s + 
         (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
     gZlR*gZuR*(mz^2*(2^(1 + d)*(-12 - 14*d + 18*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(5 + d)*(2*Pi)^d) + 13*d^3*(2*Pi)^d*s - 
       2^(1 + d)*Pi^d*((-52 - 2*d + 26*d^2 - 3*d^3 + d^4)*s + 
         (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
     gZlR*gZuL*(mz^2*(-(2^(1 + d)*(12 - 31*d + 21*d^2 - 3*d^3 + d^4)*Pi^d) + 
         d^3*(5 + d)*(2*Pi)^d) - 13*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-20 - 19*d + 28*d^2 - 3*d^3 + d^4)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t)) + 
     gZlL*gZuR*(mz^2*(-(2^(1 + d)*(12 - 31*d + 21*d^2 - 3*d^3 + d^4)*Pi^d) + 
         d^3*(5 + d)*(2*Pi)^d) - 13*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-20 - 19*d + 28*d^2 - 3*d^3 + d^4)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t))))/((-4 + d)*Pi^(2*d)*s), 
  0, (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(2 - d)*((8 + 12*d - 8*d^2 + d^3)*gZlL*gZuL - 
       (-8 + 18*d - 8*d^2 + d^3)*gZlR*gZuL - (-8 + 18*d - 8*d^2 + d^3)*gZlL*
        gZuR + (8 + 12*d - 8*d^2 + d^3)*gZlR*gZuR))/(mz^2*Pi^d) + 
    (2^(4 - d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*t)/
     ((-4 + d)*mz^2*Pi^d*s) + 
    (2^(2 - d)*((-4 + d)*gZlL*gZuR*((2 - 4*d + d^2)*s - 2*(14 - 8*d + d^2)*
          t) - gZlL*gZuL*((8 + 12*d - 8*d^2 + d^3)*s - 
         2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
       gZlR*(-((8 + 12*d - 8*d^2 + d^3)*gZuR*s) + 
         2*(-52 + 44*d - 12*d^2 + d^3)*gZuR*t + (-4 + d)*gZuL*
          ((2 - 4*d + d^2)*s - 2*(14 - 8*d + d^2)*t))))/(mz^2*Pi^d*s) - 
    (2^(1 - 2*d)*(2 - d)*(gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t)))))/((-4 + d)*mz^2*Pi^(2*d)*
      (mz^2 - s)*s) + (2^(1 - 2*d)*(2 - d)*
      (-(gZlR*(gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
              8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
          gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
              (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
            mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
                (-56 + 46*d - 12*d^2 + d^3)*t))))) + 
       gZlL*(gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 + 6*d - 4*d^2)*s^2 - 
             (-60 + 48*d - 12*d^2 + d^3)*s*t - 8*t^2) + 
           mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s + 
               (-52 + 44*d - 12*d^2 + d^3)*t))) - 
         gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
             (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
           mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
               (-56 + 46*d - 12*d^2 + d^3)*t))))))/((-4 + d)*mz^2*Pi^(2*d)*
      (mz^2 - s)*s) + (2^(1 - d)*d*(gZlL + gZlR)*(gZuL + gZuR)*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
    (2^(1 - d)*((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
       (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*t*(-1 + GaugeXi[Q]))/
     (mz^2*Pi^d*s) - (2^(1 - d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) - 
    ((-2 + d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
       gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) + 
    ((d*s + 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
       gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
       gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    ((-2 + d)*(gZlL*(gZuR*s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((2 + d)*s - t)) + gZuR*mz^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (-2*s + t)) + gZuL*mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            (s + t)) - gZuL*s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (s + d*s + t))) - 
       gZlR*(gZuL*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
         gZuR*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 2^(1 + d)*mz^2*Pi^d*
            (s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t))))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) - 
    (2*(-2 + d)*((((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
          (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*mz^2*t*(-1 + GaugeXi[Q]))/
        ((2*Pi)^d*s) - (3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*t^2*
         (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - (2^(2 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*t^2*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlR*gZuL*((-4 + d)*s + 2*t) + 
          gZlL*gZuR*((-4 + d)*s + 2*t) + gZlL*gZuL*(-((-2 + d)*s) + 2*t) + 
          gZlR*gZuR*(-((-2 + d)*s) + 2*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) - (t*(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2))/
        (mz^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 
  (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(3 - d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*
      (1 - (2*t)/((-4 + d)*s)))/Pi^d + 
    (4^(1 - d)*(gZlL*gZuL*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((56 - 38*d + 8*d^2)*s - 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((56 - 38*d + 8*d^2)*s - (-52 + 44*d - 12*d^2 + d^
                3)*t))) - gZlR*gZuL*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((52 - 37*d + 8*d^2)*s - 
             (-56 + 46*d - 12*d^2 + d^3)*t))) - 
       gZlL*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((52 - 37*d + 8*d^2)*s - (-56 + 46*d - 12*d^2 + d^
                3)*t)))))/(mz^2*Pi^(2*d)*s) - 
    (4^(1 - d)*(-3 + d)*(gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t)))))/((-4 + d)*Pi^(2*d)*(mz^2 - s)*
      s) + (4^(1 - d)*(-3 + d)*
      (-(gZlR*(gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
              8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
          gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
              (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
            mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
                (-56 + 46*d - 12*d^2 + d^3)*t))))) + 
       gZlL*(gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 + 6*d - 4*d^2)*s^2 - 
             (-60 + 48*d - 12*d^2 + d^3)*s*t - 8*t^2) + 
           mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s + 
               (-52 + 44*d - 12*d^2 + d^3)*t))) - 
         gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
             (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
           mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
               (-56 + 46*d - 12*d^2 + d^3)*t))))))/
     ((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) - 
    (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*((-4 + d)*mz^2 + d*s)*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
    (2^(1 - d)*(mz^2 - s)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    (((-4 + d)*mz^2 + (-2 + d)*s)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) - 
    ((gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
       gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
      (mz^2*((-4 + d)*s + 2*t) + s*(d*s + 2*t))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^d*s^2) + (((-4 + d)*mz^2 + (-2 + d)*s)*
      (gZlR*gZuL*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
       gZlL*gZuR*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
       gZlL*gZuL*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 
         2^(1 + d)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t)) + 
       gZlR*gZuR*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 
         2^(1 + d)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) + 
    (2^(2 - d)*(gZlL*gZuL*((-2 + d)*s*t + mz^2*((-2 + d)*s + (-4 + d)*t)) + 
       gZlR*gZuR*((-2 + d)*s*t + mz^2*((-2 + d)*s + (-4 + d)*t)) - 
       gZlR*gZuL*((-4 + d)*s*t + mz^2*((-4 + d)*s + (-2 + d)*t)) - 
       gZlL*gZuR*((-4 + d)*s*t + mz^2*((-4 + d)*s + (-2 + d)*t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    (2*(-3 + d)*(mz^2 + s)*((((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
          (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*mz^2*t*(-1 + GaugeXi[Q]))/
        ((2*Pi)^d*s) - (3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*t^2*
         (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - (2^(2 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*t^2*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlR*gZuL*((-4 + d)*s + 2*t) + 
          gZlL*gZuR*((-4 + d)*s + 2*t) + gZlL*gZuL*(-((-2 + d)*s) + 2*t) + 
          gZlR*gZuR*(-((-2 + d)*s) + 2*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) - (t*(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2))/
        (mz^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*t*
    (-(gZlR*gZuL*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*Pi^d + 
          d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
         ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t))) - 
     gZlL*gZuR*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t)) + 
     gZlL*gZuL*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t)) + 
     gZlR*gZuR*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t))))/(Pi^(2*d)*s), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*t*
    (gZlR*gZuL*(mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((-2 - 2*d + d^2)*s + 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
         4*(-4 + d)*s*t - 8*t^2)) + gZlL*gZuR*
      (mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((-2 - 2*d + d^2)*s + 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
         4*(-4 + d)*s*t - 8*t^2)) - gZlL*gZuL*
      (mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
         4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
         2*(-2 + d)*s*t + 4*t^2)) - gZlR*gZuR*
      (mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
         4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
         2*(-2 + d)*s*t + 4*t^2))))/(Pi^(2*d)*s), 
  ((-I)*EL^6*gAl^2*gAu^2*((2^(1 + d)*d*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*
       (-1 + GaugeXi[Q])^2)/mz^2 - 
     (2^(1 + d)*((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
        (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*Pi^d*t*(-1 + GaugeXi[Q])^2)/
      (mz^2*s) - (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/(mz^2*s) - 
     ((-2 + d)*(2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/(mz^2*s) + 
     ((2*Pi)^d*(d*s + 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
        gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
        gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/(mz^2*s^2) + 
     ((-2 + d)*(-1 + GaugeXi[Q])^2*
       (-(s*(gZlR*(3*d*gZuL*(2*Pi)^d*s - 3*d*gZuR*(2*Pi)^d*s + 
             2^(1 + d)*gZuR*Pi^d*(s + d*s + t) + 2^(1 + d)*gZuL*Pi^d*
              (-((2 + d)*s) + t)) + gZlL*(3*d*gZuR*(2*Pi)^d*s - 
             2^(1 + d)*gZuR*Pi^d*((2 + d)*s - t) + gZuL*(-3*d*(2*Pi)^d*s + 
               2^(1 + d)*Pi^d*(s + d*s + t))))) + 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (mz^2*s*(-s + mz^2*GaugeXi[Q])) + 
     (2*(-2 + d)*t*((3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*t*
          (-1 + GaugeXi[Q])^2)/mz^2 - (2^(1 + d)*Pi^d*
          (gZlR*gZuL*(-((-4 + d)*s) + 4*t) + gZlL*gZuR*(-((-4 + d)*s) + 
             4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + gZlR*gZuR*
            ((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q])^2)/mz^2 + 
        (2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*t*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q])/s + (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
           gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
           gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s - 
        (((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
           (-2 + d)*gZlR*gZuR)*mz^2*(2*Pi)^d*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/s + (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2)/
         mz^2))/(s - mz^2*GaugeXi[Q])^2))/(2^(2*(2 + d))*Pi^(2*d)*
    (-1 + GaugeXi[Q])), (I*EL^6*gAl^2*gAu^2*
    ((-4*(gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)) + gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
          d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - 
            (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuR*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/(mz^2*s) + 
     (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])*
       (-s + mz^2*GaugeXi[Q]))/(mz^2*s) - 
     ((2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
        gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q]))/(mz^2*s) + 
     (2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(-1 + GaugeXi[Q])*
       (d*s + (-4 + d)*mz^2*GaugeXi[Q]))/mz^2 + 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*(s*(d*s + 2*t) + mz^2*((-4 + d)*s + 2*t)*
         GaugeXi[Q]))/(mz^2*s^2) - (2^(2 + d)*Pi^d*(-1 + GaugeXi[Q])*
       (((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
          (-2 + d)*gZlR*gZuR)*s*t + 
        mz^2*(gZlL*gZuL*((-2 + d)*s + (-4 + d)*t) + 
          gZlR*gZuR*((-2 + d)*s + (-4 + d)*t) - gZlR*gZuL*
           ((-4 + d)*s + (-2 + d)*t) - gZlL*gZuR*((-4 + d)*s + (-2 + d)*t))*
         GaugeXi[Q]))/(mz^2*s) + ((-1 + GaugeXi[Q])*
       ((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q])*
       (s*(gZlR*(3*d*gZuL*(2*Pi)^d*s - 3*d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(s + d*s + t) + 2^(1 + d)*gZuL*Pi^d*
             (-((2 + d)*s) + t)) + gZlL*(3*d*gZuR*(2*Pi)^d*s - 
            2^(1 + d)*gZuR*Pi^d*((2 + d)*s - t) + gZuL*(-3*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(s + d*s + t)))) - 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (mz^2*s*(s - mz^2*GaugeXi[Q])) + (2*(-3 + d)*t*(s + mz^2*GaugeXi[Q])*
       ((3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*t*(-1 + GaugeXi[Q])^2)/
         mz^2 - (2^(1 + d)*Pi^d*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
           gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
           gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q])^2)/mz^2 + 
        (2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*t*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q])/s + (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
           gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
           gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s - 
        (((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
           (-2 + d)*gZlR*gZuR)*mz^2*(2*Pi)^d*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/s + (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2)/
         mz^2))/((-1 + GaugeXi[Q])*(s - mz^2*GaugeXi[Q])^2)))/
   (2^(2*(2 + d))*Pi^(2*d)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, ((-I)*2^(-2 - d)*EL^6*gAl^2*gAu^2*
    ((-4 + d)*gZlR*gZuL*((-6 + 14*d - 7*d^2 + d^3)*mz^2 - 
       (10 + 12*d - 11*d^2 + 2*d^3)*s - 2*(-32 + 26*d - 8*d^2 + d^3)*t) + 
     (-4 + d)*gZlL*gZuR*((-6 + 14*d - 7*d^2 + d^3)*mz^2 - 
       (10 + 12*d - 11*d^2 + 2*d^3)*s - 2*(-32 + 26*d - 8*d^2 + d^3)*t) + 
     gZlL*gZuL*((24 + 28*d - 36*d^2 + 11*d^3 - d^4)*mz^2 + 
       (-104 - 4*d + 52*d^2 - 19*d^3 + 2*d^4)*s + 
       2*(88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t) + 
     gZlR*gZuR*((24 + 28*d - 36*d^2 + 11*d^3 - d^4)*mz^2 + 
       (-104 - 4*d + 52*d^2 - 19*d^3 + 2*d^4)*s + 
       2*(88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)))/((-4 + d)*Pi^d*s), 0, 
  (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(2 - d)*((8 + 12*d - 8*d^2 + d^3)*gZlL*gZuL - 
       (-8 + 18*d - 8*d^2 + d^3)*gZlR*gZuL - (-8 + 18*d - 8*d^2 + d^3)*gZlL*
        gZuR + (8 + 12*d - 8*d^2 + d^3)*gZlR*gZuR))/(mz^2*Pi^d) + 
    (2^(4 - d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*t)/
     ((-4 + d)*mz^2*Pi^d*s) + 
    (2^(2 - d)*((-4 + d)*gZlL*gZuR*((2 - 4*d + d^2)*s - 2*(14 - 8*d + d^2)*
          t) - gZlL*gZuL*((8 + 12*d - 8*d^2 + d^3)*s - 
         2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
       gZlR*(-((8 + 12*d - 8*d^2 + d^3)*gZuR*s) + 
         2*(-52 + 44*d - 12*d^2 + d^3)*gZuR*t + (-4 + d)*gZuL*
          ((2 - 4*d + d^2)*s - 2*(14 - 8*d + d^2)*t))))/(mz^2*Pi^d*s) - 
    (2^(1 - 2*d)*(2 - d)*(gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t)))))/((-4 + d)*mz^2*Pi^(2*d)*
      (mz^2 - s)*s) - (2^(1 - 2*d)*(2 - d)*
      (2^(2 + d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
         (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
          gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*mz^2*Pi^d*s + 
       2^(2 + d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
         (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
          gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*Pi^d*s*t + 
       mz^2*(2*Pi)^d*((-4 + d)*gZlR*gZuL*((54 - 28*d + 3*d^2)*s + 
           2*(14 - 8*d + d^2)*t) + (-4 + d)*gZlL*gZuR*
          ((54 - 28*d + 3*d^2)*s + 2*(14 - 8*d + d^2)*t) + 
         gZlL*gZuL*((216 - 164*d + 40*d^2 - 3*d^3)*s - 
           2*(-52 + 44*d - 12*d^2 + d^3)*t) + gZlR*gZuR*
          ((216 - 164*d + 40*d^2 - 3*d^3)*s - 2*(-52 + 44*d - 12*d^2 + d^3)*
            t)) - gZlL*(d^3*gZuL*(2*Pi)^d*s^2 - d^3*gZuR*(2*Pi)^d*s^2 + 
         2^(1 + d)*gZuL*Pi^d*((4 + 6*d - 4*d^2)*s^2 + 
           (-44 + 40*d - 12*d^2 + d^3)*s*t - 8*t^2) + 2^(1 + d)*gZuR*Pi^d*
          ((4 - 9*d + 4*d^2)*s^2 - (-40 + 42*d - 12*d^2 + d^3)*s*t - 
           8*t^2)) - gZlR*(d^3*gZuR*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 - (-44 + 40*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + gZuL*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
            ((4 - 9*d + 4*d^2)*s^2 - (-40 + 42*d - 12*d^2 + d^3)*s*t - 
             8*t^2)))))/((-4 + d)*mz^2*Pi^(2*d)*(mz^2 - s)*s) + 
    (2^(1 - d)*d*(gZlL + gZlR)*(gZuL + gZuR)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
    (2^(1 - d)*((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
       (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*t*(-1 + GaugeXi[Q]))/
     (mz^2*Pi^d*s) - (2^(1 - d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) - 
    ((-2 + d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
       gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) + 
    ((d*s + 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
       gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
       gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    ((-2 + d)*(gZlL*(gZuR*s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((2 + d)*s - t)) + gZuR*mz^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (-2*s + t)) + gZuL*mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            (s + t)) - gZuL*s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (s + d*s + t))) - 
       gZlR*(gZuL*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
         gZuR*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 2^(1 + d)*mz^2*Pi^d*
            (s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t))))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) + 
    (2*(-2 + d)*((3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(mz^2 + t)^2*
         (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - d)*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*t*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*mz^2*(gZlL*((-8 + d)*gZuL*s - (2 + d)*gZuR*s - 2*gZuL*t - 
            2*gZuR*t) - gZlR*((2 + d)*gZuL*s - (-8 + d)*gZuR*s + 2*gZuL*t + 
            2*gZuR*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlL*((-8 + d)*gZuL*s - (2 + d)*gZuR*s - 2*gZuL*t - 
            2*gZuR*t) - gZlR*((2 + d)*gZuL*s - (-8 + d)*gZuR*s + 2*gZuL*t + 
            2*gZuR*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (mz^2*(gZlR*(2*(-1 + d)*gZuL*s - 2*(-5 + d)*gZuR*s + d*gZuL*t - 
            (-6 + d)*gZuR*t) + gZlL*(-2*(-5 + d)*gZuL*s + 2*(-1 + d)*gZuR*s - 
            (-6 + d)*gZuL*t + d*gZuR*t))*(-1 + GaugeXi[Q]))/((2*Pi)^d*s) + 
       (2^(1 - d)*(gZlR*gZuL*(-((-4 + d)*s^2) + 4*s*t + 2*t^2) + 
          gZlL*gZuR*(-((-4 + d)*s^2) + 4*s*t + 2*t^2) + 
          gZlL*gZuL*((-2 + d)*s^2 + 4*s*t + 2*t^2) + 
          gZlR*gZuR*((-2 + d)*s^2 + 4*s*t + 2*t^2))*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
            d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2) + 2^(1 + d)*gZuL*Pi^d*
             (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) + (t*(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2))/
        (mz^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 
  (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(3 - d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - (-56 + 46*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuR)*
      (1 - (2*t)/((-4 + d)*s)))/Pi^d + 
    (4^(1 - d)*(gZlL*gZuL*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((56 - 38*d + 8*d^2)*s - 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((56 - 38*d + 8*d^2)*s - (-52 + 44*d - 12*d^2 + d^
                3)*t))) - gZlR*gZuL*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((52 - 37*d + 8*d^2)*s - 
             (-56 + 46*d - 12*d^2 + d^3)*t))) - 
       gZlL*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((52 - 37*d + 8*d^2)*s - (-56 + 46*d - 12*d^2 + d^
                3)*t)))))/(mz^2*Pi^(2*d)*s) - 
    (4^(1 - d)*(-3 + d)*(gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 + (-60 + 48*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + mz^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((4 + 6*d - 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 9*d - 4*d^2)*s^2 - 
           (-72 + 50*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s + 
             (-56 + 46*d - 12*d^2 + d^3)*t)))))/((-4 + d)*Pi^(2*d)*(mz^2 - s)*
      s) - (4^(1 - d)*(-3 + d)*(2^(2 + d)*((-52 + 44*d - 12*d^2 + d^3)*gZlL*
          gZuL - (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - 
         (-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*
          gZlR*gZuR)*mz^2*Pi^d*s + 2^(2 + d)*((-52 + 44*d - 12*d^2 + d^3)*
          gZlL*gZuL - (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuL - 
         (-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuR + (-52 + 44*d - 12*d^2 + d^3)*
          gZlR*gZuR)*Pi^d*s*t + mz^2*(2*Pi)^d*
        ((-4 + d)*gZlR*gZuL*((54 - 28*d + 3*d^2)*s + 2*(14 - 8*d + d^2)*t) + 
         (-4 + d)*gZlL*gZuR*((54 - 28*d + 3*d^2)*s + 2*(14 - 8*d + d^2)*t) + 
         gZlL*gZuL*((216 - 164*d + 40*d^2 - 3*d^3)*s - 
           2*(-52 + 44*d - 12*d^2 + d^3)*t) + gZlR*gZuR*
          ((216 - 164*d + 40*d^2 - 3*d^3)*s - 2*(-52 + 44*d - 12*d^2 + d^3)*
            t)) - gZlL*(d^3*gZuL*(2*Pi)^d*s^2 - d^3*gZuR*(2*Pi)^d*s^2 + 
         2^(1 + d)*gZuL*Pi^d*((4 + 6*d - 4*d^2)*s^2 + 
           (-44 + 40*d - 12*d^2 + d^3)*s*t - 8*t^2) + 2^(1 + d)*gZuR*Pi^d*
          ((4 - 9*d + 4*d^2)*s^2 - (-40 + 42*d - 12*d^2 + d^3)*s*t - 
           8*t^2)) - gZlR*(d^3*gZuR*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*Pi^d*
          ((-4 - 6*d + 4*d^2)*s^2 - (-44 + 40*d - 12*d^2 + d^3)*s*t + 
           8*t^2) + gZuL*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
            ((4 - 9*d + 4*d^2)*s^2 - (-40 + 42*d - 12*d^2 + d^3)*s*t - 
             8*t^2)))))/((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) - 
    (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*((-4 + d)*mz^2 + d*s)*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
    (2^(1 - d)*(mz^2 - s)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    (((-4 + d)*mz^2 + (-2 + d)*s)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
       gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
       gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) - 
    ((gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
       gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
      (mz^2*((-4 + d)*s + 2*t) + s*(d*s + 2*t))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^d*s^2) + (((-4 + d)*mz^2 + (-2 + d)*s)*
      (gZlR*gZuL*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
       gZlL*gZuR*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
       gZlL*gZuL*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 
         2^(1 + d)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t)) + 
       gZlR*gZuR*(d*mz^2*(2*Pi)^d*s - 3*d*(2*Pi)^d*s^2 - 
         2^(1 + d)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*s*(s + d*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) + 
    (2^(2 - d)*(gZlL*gZuL*((-2 + d)*s*t + mz^2*((-2 + d)*s + (-4 + d)*t)) + 
       gZlR*gZuR*((-2 + d)*s*t + mz^2*((-2 + d)*s + (-4 + d)*t)) - 
       gZlR*gZuL*((-4 + d)*s*t + mz^2*((-4 + d)*s + (-2 + d)*t)) - 
       gZlL*gZuR*((-4 + d)*s*t + mz^2*((-4 + d)*s + (-2 + d)*t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) - 
    (2*(-3 + d)*(mz^2 + s)*((3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*
         (mz^2 + t)^2*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - d)*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*t*(gZlR*gZuL*(-((-4 + d)*s) + 4*t) + 
          gZlL*gZuR*(-((-4 + d)*s) + 4*t) + gZlL*gZuL*((-2 + d)*s + 4*t) + 
          gZlR*gZuR*((-2 + d)*s + 4*t))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*mz^2*(gZlL*((-8 + d)*gZuL*s - (2 + d)*gZuR*s - 2*gZuL*t - 
            2*gZuR*t) - gZlR*((2 + d)*gZuL*s - (-8 + d)*gZuR*s + 2*gZuL*t + 
            2*gZuR*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(gZlL*((-8 + d)*gZuL*s - (2 + d)*gZuR*s - 2*gZuL*t - 
            2*gZuR*t) - gZlR*((2 + d)*gZuL*s - (-8 + d)*gZuR*s + 2*gZuL*t + 
            2*gZuR*t))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (mz^2*(gZlR*(2*(-1 + d)*gZuL*s - 2*(-5 + d)*gZuR*s + d*gZuL*t - 
            (-6 + d)*gZuR*t) + gZlL*(-2*(-5 + d)*gZuL*s + 2*(-1 + d)*gZuR*s - 
            (-6 + d)*gZuL*t + d*gZuR*t))*(-1 + GaugeXi[Q]))/((2*Pi)^d*s) + 
       (2^(1 - d)*(gZlR*gZuL*(-((-4 + d)*s^2) + 4*s*t + 2*t^2) + 
          gZlL*gZuR*(-((-4 + d)*s^2) + 4*s*t + 2*t^2) + 
          gZlL*gZuL*((-2 + d)*s^2 + 4*s*t + 2*t^2) + 
          gZlR*gZuR*((-2 + d)*s^2 + 4*s*t + 2*t^2))*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
            d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2) + 2^(1 + d)*gZuL*Pi^d*
             (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) + (t*(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
          gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)) - 
          2^(1 + d)*Pi^d*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s + 
              2*gZuL*t + 2*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + 
              (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))*GaugeXi[Q] + 
          (gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*Pi^
                d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t)) + 
            gZlL*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^
                d*(-s + t) + 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*GaugeXi[Q]^2))/
        (mz^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*t*
    (-(gZlR*gZuL*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*Pi^d + 
          d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
         ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t))) - 
     gZlL*gZuR*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t)) + 
     gZlL*gZuL*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t)) + 
     gZlR*gZuR*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
         d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
        ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t))))/(Pi^(2*d)*s), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*t*
    (gZlR*gZuL*(mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((-2 - 2*d + d^2)*s + 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
         4*(-4 + d)*s*t - 8*t^2)) + gZlL*gZuR*
      (mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((-2 - 2*d + d^2)*s + 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
         4*(-4 + d)*s*t - 8*t^2)) - gZlL*gZuL*
      (mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
         4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
         2*(-2 + d)*s*t + 4*t^2)) - gZlR*gZuR*
      (mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
         4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
         2*(-2 + d)*s*t + 4*t^2))))/(Pi^(2*d)*s), 
  ((-I)*EL^6*gAl^2*gAu^2*(2^(1 + d)*d*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*
      (-1 + GaugeXi[Q])^2 - (2^(1 + d)*((-2 + d)*gZlL*gZuL - 
        (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*Pi^d*t*
       (-1 + GaugeXi[Q])^2)/s - 
     (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/s - 
     ((-2 + d)*(2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/s + 
     ((2*Pi)^d*(d*s + 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
        gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
        gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2)/s^2 + 
     ((-2 + d)*(-1 + GaugeXi[Q])^2*
       (s*(gZlR*(3*d*gZuL*(2*Pi)^d*s - 3*d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(s + d*s + t) + 2^(1 + d)*gZuL*Pi^d*
             (-((2 + d)*s) + t)) + gZlL*(3*d*gZuR*(2*Pi)^d*s - 
            2^(1 + d)*gZuR*Pi^d*((2 + d)*s - t) + gZuL*(-3*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(s + d*s + t)))) - 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (s*(s - mz^2*GaugeXi[Q])) - 
     (2*(-2 + d)*t*((gZlL*(2^(1 + d)*(-1 + d)*gZuL*Pi^d - 2^(1 + d)*(-2 + d)*
             gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d) - 
          gZlR*(2^(1 + d)*(-2 + d)*gZuL*Pi^d - 2^(1 + d)*(-1 + d)*gZuR*Pi^d - 
            d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*s + 
        (gZlL*(gZuL*mz^2*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
            gZuR*mz^2*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d) - 2^(1 + d)*(-2 + d)*
             gZuL*Pi^d*s + 2^(1 + d)*(-4 + d)*gZuR*Pi^d*s) - 
          gZlR*(gZuL*mz^2*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
            gZuR*mz^2*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d) - 2^(1 + d)*(-4 + d)*
             gZuL*Pi^d*s + 2^(1 + d)*(-2 + d)*gZuR*Pi^d*s))*GaugeXi[Q] + 
        (gZlL*(gZuL*(2^(1 + d)*(-2 + d)*mz^2*Pi^d + 2^(1 + d)*(-1 + d)*Pi^
                d*s - d*(2*Pi)^d*s) + gZuR*(-(2^(1 + d)*(-4 + d)*mz^2*Pi^d) - 
              2^(1 + d)*(-2 + d)*Pi^d*s + d*(2*Pi)^d*s)) - 
          gZlR*(gZuL*(2^(1 + d)*(-4 + d)*mz^2*Pi^d + 2^(1 + d)*(-2 + d)*Pi^
                d*s - d*(2*Pi)^d*s) + gZuR*(-(2^(1 + d)*(-2 + d)*mz^2*Pi^d) - 
              2^(1 + d)*(-1 + d)*Pi^d*s + d*(2*Pi)^d*s)))*GaugeXi[Q]^2 + 
        mz^2*(gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 2^(1 + d)*gZuR*Pi^d + 
            d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + gZlL*(2^(1 + d)*gZuL*Pi^d - 
            2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*
         GaugeXi[Q]^3))/(s*(s - mz^2*GaugeXi[Q]))))/
   (2^(2*(2 + d))*mz^2*Pi^(2*d)*(-1 + GaugeXi[Q])), 
  (I*EL^6*gAl^2*gAu^2*
    ((-4*(gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)) + gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
          d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - 
            (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuR*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/s + 
     (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])*
       (-s + mz^2*GaugeXi[Q]))/s - 
     ((2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
        gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q]))/s + 
     2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(-1 + GaugeXi[Q])*
      (d*s + (-4 + d)*mz^2*GaugeXi[Q]) + 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*(s*(d*s + 2*t) + mz^2*((-4 + d)*s + 2*t)*
         GaugeXi[Q]))/s^2 - (2^(2 + d)*Pi^d*(-1 + GaugeXi[Q])*
       (((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
          (-2 + d)*gZlR*gZuR)*s*t + 
        mz^2*(gZlL*gZuL*((-2 + d)*s + (-4 + d)*t) + 
          gZlR*gZuR*((-2 + d)*s + (-4 + d)*t) - gZlR*gZuL*
           ((-4 + d)*s + (-2 + d)*t) - gZlL*gZuR*((-4 + d)*s + (-2 + d)*t))*
         GaugeXi[Q]))/s + ((-1 + GaugeXi[Q])*((-2 + d)*s + 
        (-4 + d)*mz^2*GaugeXi[Q])*
       (s*(gZlR*(3*d*gZuL*(2*Pi)^d*s - 3*d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(s + d*s + t) + 2^(1 + d)*gZuL*Pi^d*
             (-((2 + d)*s) + t)) + gZlL*(3*d*gZuR*(2*Pi)^d*s - 
            2^(1 + d)*gZuR*Pi^d*((2 + d)*s - t) + gZuL*(-3*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(s + d*s + t)))) - 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (s*(s - mz^2*GaugeXi[Q])) - (2*(-3 + d)*t*(s + mz^2*GaugeXi[Q])*
       ((gZlL*(2^(1 + d)*(-1 + d)*gZuL*Pi^d - 2^(1 + d)*(-2 + d)*gZuR*Pi^d - 
            d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d) - 
          gZlR*(2^(1 + d)*(-2 + d)*gZuL*Pi^d - 2^(1 + d)*(-1 + d)*gZuR*Pi^d - 
            d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*s + 
        (gZlL*(gZuL*mz^2*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
            gZuR*mz^2*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d) - 2^(1 + d)*(-2 + d)*
             gZuL*Pi^d*s + 2^(1 + d)*(-4 + d)*gZuR*Pi^d*s) - 
          gZlR*(gZuL*mz^2*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
            gZuR*mz^2*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d) - 2^(1 + d)*(-4 + d)*
             gZuL*Pi^d*s + 2^(1 + d)*(-2 + d)*gZuR*Pi^d*s))*GaugeXi[Q] + 
        (gZlL*(gZuL*(2^(1 + d)*(-2 + d)*mz^2*Pi^d + 2^(1 + d)*(-1 + d)*Pi^
                d*s - d*(2*Pi)^d*s) + gZuR*(-(2^(1 + d)*(-4 + d)*mz^2*Pi^d) - 
              2^(1 + d)*(-2 + d)*Pi^d*s + d*(2*Pi)^d*s)) - 
          gZlR*(gZuL*(2^(1 + d)*(-4 + d)*mz^2*Pi^d + 2^(1 + d)*(-2 + d)*Pi^
                d*s - d*(2*Pi)^d*s) + gZuR*(-(2^(1 + d)*(-2 + d)*mz^2*Pi^d) - 
              2^(1 + d)*(-1 + d)*Pi^d*s + d*(2*Pi)^d*s)))*GaugeXi[Q]^2 + 
        mz^2*(gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 2^(1 + d)*gZuR*Pi^d + 
            d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + gZlL*(2^(1 + d)*gZuL*Pi^d - 
            2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*
         GaugeXi[Q]^3))/(s*(-1 + GaugeXi[Q])*(s - mz^2*GaugeXi[Q]))))/
   (2^(2*(2 + d))*mz^2*Pi^(2*d)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, 
 {0, ((-I)*EL^6*gAl*gAu*
    (gZlR^2*(-(gZuR^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((-4 - 6*d + 4*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZuL^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s - 
           (-56 + 46*d - 12*d^2 + d^3)*t))) + 
     gZlL^2*(gZuL^2*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((4 + 6*d - 4*d^2)*s + 
           (-52 + 44*d - 12*d^2 + d^3)*t)) + 
       gZuR^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s - 
           (-56 + 46*d - 12*d^2 + d^3)*t)))))/(2^(2*(1 + d))*Pi^(2*d)*s), 0, 
  ((-I)*2^(-4 - d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) + gZuL^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2)) + gZlR^2*(-(gZuL^2*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuR^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
    (-mz^2 + s + mz^2*GaugeXi[Q]))/((-1 + d)*mz^4*Pi^d*s^2), 0, 
  (I*2^(-2 - d)*EL^6*gAl*gAu*t*
    (gZlL^2*((-4 + d)*gZuR^2*(4*(14 - 8*d + d^2)*mz^2 - (-6 + d^2)*s - 
         8*(-2 + d)*t) + gZuL^2*(-4*(-52 + 44*d - 12*d^2 + d^3)*mz^2 + 
         (24 - 4*d - 4*d^2 + d^3)*s + 8*(10 - 6*d + d^2)*t)) + 
     gZlR^2*((-4 + d)*gZuL^2*(4*(14 - 8*d + d^2)*mz^2 - (-6 + d^2)*s - 
         8*(-2 + d)*t) + gZuR^2*(-4*(-52 + 44*d - 12*d^2 + d^3)*mz^2 + 
         (24 - 4*d - 4*d^2 + d^3)*s + 8*(10 - 6*d + d^2)*t))))/(Pi^d*s), 0, 
  (I*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
          ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2))) + 
       gZuL^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((-2 + 2*d + d^2)*s^2 - 
           (8 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-(d^2*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)))) - 
     gZlR^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
     (gZlL^2*(-(gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 
              2*(4 - 5*d + d^2)*s*t - 4*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 
              2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
                2*t^2)))) + gZuL^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 
             2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*
                t^2)))) + gZlR^2*
        (-(gZuL^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*
               s*t - 4*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(
                (4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)))) + 
         gZuR^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
              ((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))))*
      GaugeXi[Q] - 
     (gZlL^2*(-(gZuR^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
             ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
            mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((12 - 9*d + d^2)*s^2 + 
                3*(4 - 5*d + d^2)*s*t - 6*t^2)))) + 
         gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 3*
                (8 - 5*d + d^2)*s*t + 6*t^2)))) + 
       gZlR^2*(-(gZuL^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
             ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
            mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((12 - 9*d + d^2)*s^2 + 
                3*(4 - 5*d + d^2)*s*t - 6*t^2)))) + 
         gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 3*
                (8 - 5*d + d^2)*s*t + 6*t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(gZlL^2*(-(gZuR^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d + 6*d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuL^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((2 - 2*d + 6*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZlR^2*(-(gZuL^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d + 6*d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuR^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((2 - 2*d + 6*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))*
      GaugeXi[Q]^3))/((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 0, 
  ((-I)*EL^6*gAl*gAu*(((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
       (4*(-1 + d)*mz^4 - 4*d*mz^2*s + d*s^2))/((-1 + d)*mz^4) + 
     (2^(2 + 3*d)*(gZlR^2*((-56 + 46*d - 12*d^2 + d^3)*gZuL^2 - 
          (-52 + 44*d - 12*d^2 + d^3)*gZuR^2) + 
        gZlL^2*(-((-52 + 44*d - 12*d^2 + d^3)*gZuL^2) + 
          (-56 + 46*d - 12*d^2 + d^3)*gZuR^2))*Pi^(3*d)*(s + 2*t))/s - 
     4^(1 + d)*Pi^(2*d)*
      (gZlR^2*(-(gZuR^2*(2^(2 + d)*(13 - 11*d + 3*d^2)*Pi^d - 
            d^3*(2*Pi)^d)) + gZuL^2*(2^(1 + d)*(28 - 23*d + 6*d^2)*Pi^d - 
           d^3*(2*Pi)^d)) + gZlL^2*(gZuR^2*(2^(1 + d)*(28 - 23*d + 6*d^2)*
            Pi^d - d^3*(2*Pi)^d) + gZuL^2*(2^(2 + d)*(-13 + 11*d - 3*d^2)*
            Pi^d + d^3*(2*Pi)^d)))*(1 + (2*t)/s) - 
     (2*(gZlL^2*(gZuR^2*(-((-4 + d)*(2*Pi)^(3*d)*s^2*t) + 2^(1 + 3*d)*mz^4*
             Pi^(3*d)*((-108 + 75*d - 16*d^2 + d^3)*s + 2*(-55 + 46*d - 
                12*d^2 + d^3)*t) - 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZuL^2*((-2 + d)*(2*Pi)^(3*d)*s^2*t - 2^(1 + 3*d)*mz^4*Pi^(3*d)*
             ((-114 + 77*d - 16*d^2 + d^3)*s + 2*(-53 + 44*d - 12*d^2 + d^3)*
               t) + 2^(2 + 3*d)*mz^2*Pi^(3*d)*((-2 + d)^2*s^2 + 
              (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        gZlR^2*(gZuL^2*(-((-4 + d)*(2*Pi)^(3*d)*s^2*t) + 2^(1 + 3*d)*mz^4*
             Pi^(3*d)*((-108 + 75*d - 16*d^2 + d^3)*s + 2*(-55 + 46*d - 
                12*d^2 + d^3)*t) - 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZuR^2*((-2 + d)*(2*Pi)^(3*d)*s^2*t - 2^(1 + 3*d)*mz^4*Pi^(3*d)*
             ((-114 + 77*d - 16*d^2 + d^3)*s + 2*(-53 + 44*d - 12*d^2 + d^3)*
               t) + 2^(2 + 3*d)*mz^2*Pi^(3*d)*((-2 + d)^2*s^2 + 
              (18 - 11*d + 2*d^2)*s*t + 4*t^2)))))/(mz^4*s) + 
     ((2*Pi)^(2*d)*(2*mz^2 - s)*
       (gZlL^2*(gZuR^2*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
            2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t)) + 
          gZuL^2*(-(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t)) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)))) + 
        gZlR^2*(gZuL^2*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
            2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t)) - 
          gZuR^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
            s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))))/(mz^4*s) + 
     ((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*
       (4*(-1 + d)*mz^4 - 4*d*mz^2*s + d*s^2)*((2*Pi)^d - 
        2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2))/
      ((-1 + d)*mz^4*(-1 + GaugeXi[Q])^2) - 
     ((2*Pi)^(2*d)*(4*(-1 + d)*mz^4 - 4*mz^2*(d*s + 2*t) + s*(d*s + 2*t))*
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
          gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
        gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
          gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
        2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
             gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*
           (gZuL^2*((-4 + d)*s - 2*t) - gZuR^2*((-2 + d)*s + 2*t)))*
         GaugeXi[Q] + (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (s - t))) + gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 
                t))) - gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - 
                t)) - gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
         GaugeXi[Q]^2))/((-1 + d)*mz^4*s*(-1 + GaugeXi[Q])^2) - 
     (2^(1 + 2*d)*Pi^(2*d)*(mz^2 - s/2)*
       (gZlL^2*(-(gZuR^2*(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                 t)) + 2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t))) + 
          gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
            s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) - 
        gZlR^2*(gZuL^2*(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                t)) + 2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t)) - 
          gZuR^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
            s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) - 
        2*(gZlL^2*(-(gZuR^2*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
               2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t))) + 
            gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
              s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) - 
          gZlR^2*(gZuL^2*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
              2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t)) - 
            gZuR^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
              s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*GaugeXi[Q] + 
        (gZlL^2*(-(gZuR^2*(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                   t)) + 2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t))) + 
            gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
              s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) - 
          gZlR^2*(gZuL^2*(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                  t)) + 2^(1 + d)*mz^2*Pi^d*((-4 + d)*s + 2*t)) - 
            gZuR^2*(2^(1 + d)*mz^2*Pi^d*((-2 + d)*s - 2*t) + 
              s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))))*
         GaugeXi[Q]^2))/(mz^4*s*(-1 + GaugeXi[Q])^2)))/
   (2^(4*(1 + d))*Pi^(4*d)), ((-I)*2^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(-2*(-8 + 18*d - 8*d^2 + d^3)*mz^2*s + 
         (-8 + 18*d - 8*d^2 + d^3)*s^2 - 8*(-4 + d)*s*t + 16*t^2) + 
       gZuL^2*(2*(8 + 12*d - 8*d^2 + d^3)*mz^2*s - (8 + 12*d - 8*d^2 + d^3)*
          s^2 + 8*(-2 + d)*s*t + 16*t^2)) + 
     gZlR^2*(gZuL^2*(-2*(-8 + 18*d - 8*d^2 + d^3)*mz^2*s + 
         (-8 + 18*d - 8*d^2 + d^3)*s^2 - 8*(-4 + d)*s*t + 16*t^2) + 
       gZuR^2*(2*(8 + 12*d - 8*d^2 + d^3)*mz^2*s - (8 + 12*d - 8*d^2 + d^3)*
          s^2 + 8*(-2 + d)*s*t + 16*t^2))))/(Pi^d*s), 
  (I*2^(-3 - 2*d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*(2^(2 + d)*(-4 + d)*mz^2*Pi^d*t*((-2 - 2*d + d^2)*s + 
            4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*((2 - 4*d + d^2)*s - 
            2*(14 - 8*d + d^2)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
            2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 4*(-4 + d)*s*t - 
              8*t^2)))) + gZuL^2*(2^(2 + d)*mz^2*Pi^d*t*
          ((16 + 4*d - 6*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t) + 
         2^(1 + d)*mz^4*Pi^d*((8 + 12*d - 8*d^2 + d^3)*s - 
           2*(-52 + 44*d - 12*d^2 + d^3)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
           2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 2*(-2 + d)*s*t + 
             4*t^2)))) + gZlR^2*
      (-(gZuL^2*(2^(2 + d)*(-4 + d)*mz^2*Pi^d*t*((-2 - 2*d + d^2)*s + 
            4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*((2 - 4*d + d^2)*s - 
            2*(14 - 8*d + d^2)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
            2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 4*(-4 + d)*s*t - 
              8*t^2)))) + gZuR^2*(2^(2 + d)*mz^2*Pi^d*t*
          ((16 + 4*d - 6*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t) + 
         2^(1 + d)*mz^4*Pi^d*((8 + 12*d - 8*d^2 + d^3)*s - 
           2*(-52 + 44*d - 12*d^2 + d^3)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
           2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 2*(-2 + d)*s*t + 
             4*t^2))))))/(Pi^(2*d)*s), 
  ((-I)*4^(-2 - d)*EL^6*gAl*gAu*
    (s*(-(gZlR^2*(-(gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
     2*(gZlL^2*(-(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*mz^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
            2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2))) + gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))) + gZlR^2*(-(gZuL^2*(d^2*(2*Pi)^d*s^3 + 
            2^(1 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
               t - 4*t^2) + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2))) + gZuR^2*(d^2*(2*Pi)^d*s^3 + 
           2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))))*GaugeXi[Q] - 
     (gZlL^2*(-(gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(3 + d)*mz^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
            2^(1 + d)*Pi^d*s*((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2))) + gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(3 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))) + gZlR^2*(-(gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 
            2^(3 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
               t - 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 3*d + d^2)*s^2 - 
              (4 - 5*d + d^2)*s*t + 2*t^2))) + gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 
           2^(1 + d)*Pi^d*s*(-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 
             2*t^2) + 2^(3 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
              s*t + 4*t^2))))*GaugeXi[Q]^2 + 
     4*mz^2*(gZlR^2*(-(gZuR^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuL^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZlL^2*(gZuR^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
            ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
         gZuL^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2))))*GaugeXi[Q]^3))/
   ((-1 + d)*mz^4*Pi^(2*d)*s*(-1 + GaugeXi[Q])^2), 
  (I*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d - 2*d^2)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2))) + 
       gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(2*(-1 + d + d^2)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2)))) + 
     gZlR^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d - 2*d^2)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2))) + 
       gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(2*(-1 + d + d^2)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2)))) + 
     (gZlL^2*(gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2) + mz^2*(7*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-12 + 9*d - 5*d^2)*s^2 - 3*(4 - 5*d + d^2)*s*
                t + 6*t^2))) + gZuL^2*(-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
              2*(8 - 5*d + d^2)*s*t + 4*t^2)) + mz^2*(-7*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((6 - 6*d + 5*d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
               6*t^2)))) + gZlR^2*
        (gZuL^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
              t - 4*t^2) + mz^2*(7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-12 + 9*d - 5*d^2)*s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2))) + 
         gZuR^2*(-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
              4*t^2)) + mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((6 - 6*d + 5*d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 6*t^2)))))*
      GaugeXi[Q] + 
     (gZlR^2*(gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-6 + 6*d + d^2)*s^2 - 
               3*(8 - 5*d + d^2)*s*t - 6*t^2))) - 
         gZuL^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d + d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2)))) + 
       gZlL^2*(gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-6 + 6*d + d^2)*s^2 - 
               3*(8 - 5*d + d^2)*s*t - 6*t^2))) - 
         gZuR^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d + d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(gZlL^2*(-(gZuR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d + 4*d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((2 - 2*d + 4*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZlR^2*(-(gZuL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d + 4*d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((2 - 2*d + 4*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))*
      GaugeXi[Q]^3))/((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  (I*EL^6*gAl*gAu*(-((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
       (s - s*GaugeXi[Q])^2*(d*(mz^2 - s)^2 + 2*((-2 + d)*mz^4 - d*mz^2*s)*
         GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)) - (gZlL^2 + gZlR^2)*
      (gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*s^2*(d*(mz^2 - s)^2 + 
       2*((-2 + d)*mz^4 - d*mz^2*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)*
      ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
     (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])^2*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
       2^(1 + d)*Pi^d*(gZlL^2*(gZuL^2*((-2 + d)*s - 2*t) - 
           gZuR^2*((-4 + d)*s + 2*t)) - gZlR^2*(gZuL^2*((-4 + d)*s + 2*t) + 
           gZuR^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
        GaugeXi[Q]^2) + (2*Pi)^(2*d)*((mz^2 - s)^2*(d*s + 2*t) + 
       2*(mz^4*((-2 + d)*s - 2*t) - mz^2*s*(d*s + 2*t))*GaugeXi[Q] + 
       mz^4*(d*s + 2*t)*GaugeXi[Q]^2)*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
            gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*(gZuL^2*((-4 + d)*s - 2*t) - 
           gZuR^2*((-2 + d)*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        GaugeXi[Q]^2) + (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])*
      (gZlL^2*(-(gZuR^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                2*(1 + d)*s - t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (2 + d)*s - t)))) + gZuL^2*
          (-(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t))) + 
           mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t)))) + 
       gZlR^2*(gZuR^2*(-(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + 
                t))) + mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
              (s + 2*d*s + t))) + gZuL^2*
          (s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t)) + 
           mz^2*(5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*(1 + d)*s + t)))) + 
       (-(gZlR^2*(-(gZuR^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                  ((-1 + d)*s - t)) - 2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t))) + 
            gZuL^2*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
              mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t))))) + 
         gZlL^2*(gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - 
                 t)) - 2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t)) - 
           gZuR^2*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
             mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t)))))*
        GaugeXi[Q] + 
       (-(gZlR^2*(-(gZuR^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                  (-s + 3*d*s - t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                  (s + d*s + t)))) + gZuL^2*(-(s*(-3*d*(2*Pi)^d*s + 
                 2^(1 + d)*Pi^d*((2 + d)*s - t))) + mz^2*(-5*d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + 3*d*s + t))))) + 
         gZlL^2*(gZuL^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + 3*d*s - 
                 t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t))) - 
           gZuR^2*(-(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) + 
             mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + t)))))*
        GaugeXi[Q]^2 + 
       mz^2*(gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
        GaugeXi[Q]^3) + 2*(1 - d)*s*
      ((2*Pi)^(3*d)*(gZlL^2*(gZuR^2*((-4 + d)*mz^4*t + (-4 + d)*s^2*t + 
             2*mz^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*
                t^2)) - gZuL^2*((-2 + d)*mz^4*t + (-2 + d)*s^2*t + 
             2*mz^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) - 
         gZlR^2*(-(gZuL^2*((-4 + d)*mz^4*t + (-4 + d)*s^2*t + 
              2*mz^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 
                4*t^2))) + gZuR^2*((-2 + d)*mz^4*t + (-2 + d)*s^2*t + 
             2*mz^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)))) + 
       2^(1 + 3*d)*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s^2*t + mz^4*((-4 + d)*s + 2*(-3 + d)*
                 t) + mz^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 
                8*t^2))) + gZuL^2*((-2 + d)*s^2*t + mz^4*((-2 + d)*s + 2*
                (-3 + d)*t) + mz^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*
                t + 8*t^2))) + gZlR^2*
          (-(gZuL^2*((-4 + d)*s^2*t + mz^4*((-4 + d)*s + 2*(-3 + d)*t) + 
              mz^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 
                8*t^2))) + gZuR^2*((-2 + d)*s^2*t + mz^4*((-2 + d)*s + 2*
                (-3 + d)*t) + mz^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*
                t + 8*t^2))))*GaugeXi[Q] - (2*Pi)^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s^2*t + 2*mz^4*(2*(-4 + d)*s + 
                (-8 + 3*d)*t) + 2*mz^2*((8 - 6*d + d^2)*s^2 + 
                (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuL^2*((-2 + d)*s^2*t + mz^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
             2*mz^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))) + 
         gZlR^2*(-(gZuL^2*((-4 + d)*s^2*t + 2*mz^4*(2*(-4 + d)*s + 
                (-8 + 3*d)*t) + 2*mz^2*((8 - 6*d + d^2)*s^2 + 
                (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuR^2*((-2 + d)*s^2*t + mz^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
             2*mz^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))))*
        GaugeXi[Q]^2 + 2^(1 + 3*d)*mz^2*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s*t + mz^2*((-4 + d)*s + 2*(-3 + d)*
                 t))) + gZuL^2*((-2 + d)*s*t + mz^2*((-2 + d)*s + 2*(-3 + d)*
                t))) + gZlR^2*(-(gZuL^2*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
                2*(-3 + d)*t))) + gZuR^2*((-2 + d)*s*t + 
             mz^2*((-2 + d)*s + 2*(-3 + d)*t))))*GaugeXi[Q]^3 - 
       (gZlL^2*((-2 + d)*gZuL^2 - (-4 + d)*gZuR^2) + 
         gZlR^2*(-((-4 + d)*gZuL^2) + (-2 + d)*gZuR^2))*mz^4*(2*Pi)^(3*d)*t*
        GaugeXi[Q]^4)))/(2^(4*(1 + d))*(1 - d)*mz^4*Pi^(4*d)*
    (s - s*GaugeXi[Q])^2), (I*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
           ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
          mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d + 4*d^2)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2)))) + 
       gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 4*d^2)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
     gZlR^2*(-(gZuL^2*(3*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
           ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
          mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d + 4*d^2)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2)))) + 
       gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 4*d^2)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
     (gZlL^2*(gZuL^2*(-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
               s*t + 4*t^2)) + mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-6 + 6*d + d^2)*s^2 - 3*(8 - 5*d + d^2)*s*t - 6*t^2))) + 
         gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
              t - 4*t^2) + mz^2*(5*d^2*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
              ((-12 + 9*d + d^2)*s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2)))) - 
       gZlR^2*(gZuL^2*(-(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 
              2*(4 - 5*d + d^2)*s*t - 4*t^2)) + mz^2*(-5*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-12 + 9*d + d^2)*s^2 - 3*(4 - 5*d + d^2)*s*t + 
               6*t^2))) + gZuR^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2) + mz^2*(5*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*(-((-6 + 6*d + d^2)*s^2) + 3*(8 - 5*d + d^2)*s*
                t + 6*t^2)))))*GaugeXi[Q] + 
     (gZlL^2*(gZuR^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d - 5*d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2))) + 
         gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + 5*d^2)*
                s^2 + 3*(8 - 5*d + d^2)*s*t + 6*t^2)))) + 
       gZlR^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d - 5*d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2))) + 
         gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + 5*d^2)*
                s^2 + 3*(8 - 5*d + d^2)*s*t + 6*t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(-(gZlR^2*(-(gZuR^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              (2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + 2*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            (2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 3*d + 2*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2))))*
      GaugeXi[Q]^3))/((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  (I*EL^6*gAl*gAu*(-((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
       (s - s*GaugeXi[Q])^2*(d*(mz^2 - s)^2 + 2*((-2 + d)*mz^4 - d*mz^2*s)*
         GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)) - (gZlL^2 + gZlR^2)*
      (gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*s^2*(d*(mz^2 - s)^2 + 
       2*((-2 + d)*mz^4 - d*mz^2*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)*
      ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
     (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])^2*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
       2^(1 + d)*Pi^d*(gZlL^2*(gZuL^2*((-2 + d)*s - 2*t) - 
           gZuR^2*((-4 + d)*s + 2*t)) - gZlR^2*(gZuL^2*((-4 + d)*s + 2*t) + 
           gZuR^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
        GaugeXi[Q]^2) + (2*Pi)^(2*d)*((mz^2 - s)^2*(d*s + 2*t) + 
       2*(mz^4*((-2 + d)*s - 2*t) - mz^2*s*(d*s + 2*t))*GaugeXi[Q] + 
       mz^4*(d*s + 2*t)*GaugeXi[Q]^2)*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
            gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*(gZuL^2*((-4 + d)*s - 2*t) - 
           gZuR^2*((-2 + d)*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        GaugeXi[Q]^2) + (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])*
      (gZlL^2*(-(gZuR^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
            s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t)))) + 
         gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) - 
       gZlR^2*(gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t))) - 
         gZuR^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
       (-(gZlR^2*(-(gZuR^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                  (-s + 3*d*s - t)) - 2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t))) + 
            gZuL^2*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
              mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + t))))) + 
         gZlL^2*(gZuL^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + 3*d*s - 
                 t)) - 2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t)) - 
           gZuR^2*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
             mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + t)))))*
        GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                   t))) + mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 ((-2 + d)*s + t)))) + gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 
               2^(1 + d)*Pi^d*((-1 + d)*s - t)) - s*(-3*d*(2*Pi)^d*s + 
               2^(1 + d)*Pi^d*(s + d*s + t)))) - 
         gZlR^2*(gZuL^2*(-(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                  t))) + mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + 
                 t))) - gZuR^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                ((-1 + d)*s - t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (s + d*s + t)))))*GaugeXi[Q]^2 + 
       mz^2*(gZlL^2*(-(gZuR^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                2*(1 + d)*s - t))) + gZuL^2*(-5*d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*(s + 2*d*s + t))) - 
         gZlR^2*(gZuL^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(1 + d)*s - 
               t)) - gZuR^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
              (s + 2*d*s + t))))*GaugeXi[Q]^3) + 
     2*(1 - d)*s*((2*Pi)^(3*d)*
        (gZlL^2*(gZuR^2*((-4 + d)*mz^4*t + (-4 + d)*s^2*t + 
             2*mz^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*
                t^2)) - gZuL^2*((-2 + d)*mz^4*t + (-2 + d)*s^2*t + 
             2*mz^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) - 
         gZlR^2*(-(gZuL^2*((-4 + d)*mz^4*t + (-4 + d)*s^2*t + 
              2*mz^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 
                4*t^2))) + gZuR^2*((-2 + d)*mz^4*t + (-2 + d)*s^2*t + 
             2*mz^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)))) + 
       2^(1 + 3*d)*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s^2*t + mz^4*((-4 + d)*s + 2*(-3 + d)*
                 t) + mz^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 
                8*t^2))) + gZuL^2*((-2 + d)*s^2*t + mz^4*((-2 + d)*s + 2*
                (-3 + d)*t) + mz^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*
                t + 8*t^2))) + gZlR^2*
          (-(gZuL^2*((-4 + d)*s^2*t + mz^4*((-4 + d)*s + 2*(-3 + d)*t) + 
              mz^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 
                8*t^2))) + gZuR^2*((-2 + d)*s^2*t + mz^4*((-2 + d)*s + 2*
                (-3 + d)*t) + mz^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*
                t + 8*t^2))))*GaugeXi[Q] - (2*Pi)^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s^2*t + 2*mz^4*(2*(-4 + d)*s + 
                (-8 + 3*d)*t) + 2*mz^2*((8 - 6*d + d^2)*s^2 + 
                (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuL^2*((-2 + d)*s^2*t + mz^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
             2*mz^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))) + 
         gZlR^2*(-(gZuL^2*((-4 + d)*s^2*t + 2*mz^4*(2*(-4 + d)*s + 
                (-8 + 3*d)*t) + 2*mz^2*((8 - 6*d + d^2)*s^2 + 
                (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuR^2*((-2 + d)*s^2*t + mz^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
             2*mz^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))))*
        GaugeXi[Q]^2 + 2^(1 + 3*d)*mz^2*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-4 + d)*s*t + mz^2*((-4 + d)*s + 2*(-3 + d)*
                 t))) + gZuL^2*((-2 + d)*s*t + mz^2*((-2 + d)*s + 2*(-3 + d)*
                t))) + gZlR^2*(-(gZuL^2*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
                2*(-3 + d)*t))) + gZuR^2*((-2 + d)*s*t + 
             mz^2*((-2 + d)*s + 2*(-3 + d)*t))))*GaugeXi[Q]^3 - 
       (gZlL^2*((-2 + d)*gZuL^2 - (-4 + d)*gZuR^2) + 
         gZlR^2*(-((-4 + d)*gZuL^2) + (-2 + d)*gZuR^2))*mz^4*(2*Pi)^(3*d)*t*
        GaugeXi[Q]^4)))/(2^(4*(1 + d))*(1 - d)*mz^4*Pi^(4*d)*
    (s - s*GaugeXi[Q])^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*4^(-1 - 2*d)*EL^6*gAl^3*gAu^3*
    ((2*Pi)^(3*d)*((-96 + 216*d - 82*d^2 + 7*d^3)*s^2 + 
       4*(208 - 84*d + 5*d^2)*s*t + 4*(176 - 80*d + 7*d^2)*t^2) - 
     2^(1 + 3*d)*(32 - 20*d + 3*d^2)*Pi^(3*d)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] - (-4 + d)^2*(2*Pi)^(3*d)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]^2))/((-4 + d)*Pi^(4*d)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, (I*(32 - 14*d + d^2)*EL^6*gAl^3*gAu^3*(s + 2*t))/
   ((-4 + d)*(2*Pi)^d*s), (I*2^(-1 - 2*d)*EL^6*gAl^3*gAu^3*
    (2^(3 + d)*Pi^d*t*(3*s^2 + 5*s*t + 2*t^2) + 
     d*s^2*(2^(1 + d)*Pi^d*s + (2*Pi)^d*(s + 3*t))))/(Pi^(2*d)*s), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0}, {0, 0, 0, (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(2 - d)*((-128 + 88*d - 18*d^2 + d^3)*gZlL*gZuL - 
       (-112 + 82*d - 18*d^2 + d^3)*gZlR*gZuL - (-112 + 82*d - 18*d^2 + d^3)*
        gZlL*gZuR + (-128 + 88*d - 18*d^2 + d^3)*gZlR*gZuR))/(mz^2*Pi^d) - 
    (2^(4 - d)*((-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuL - (-52 + 44*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuR)*(s + t))/
     ((-4 + d)*mz^2*Pi^d*s) - 
    (2^(2 - d)*((-4 + d)*gZlL*gZuL*(3*(20 - 10*d + d^2)*s + 
         2*(14 - 8*d + d^2)*t) + (-4 + d)*gZlR*gZuR*(3*(20 - 10*d + d^2)*s + 
         2*(14 - 8*d + d^2)*t) + gZlR*gZuL*((216 - 170*d + 42*d^2 - 3*d^3)*
          s - 2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
       gZlL*gZuR*((216 - 170*d + 42*d^2 - 3*d^3)*s - 
         2*(-52 + 44*d - 12*d^2 + d^3)*t)))/(mz^2*Pi^d*s) + 
    (2^(1 - 2*d)*(2 - d)*(gZlR*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*(-((-124 + 89*d - 21*d^2 + d^3)*s^2) - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (-((-124 + 89*d - 21*d^2 + d^3)*s^2) - (-76 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*mz^2*Pi^(2*d)*(mz^2 - s)*s) - 
    (2^(1 - 2*d)*(2 - d)*
      (-(gZlR*(gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*
               s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                (-108 + 85*d - 21*d^2 + 2*d^3)*s + (-52 + 44*d - 12*d^2 + 
                  d^3)*t))) + gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + 
                d^3)*s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(
                (-120 + 90*d - 21*d^2 + 2*d^3)*s + (-56 + 46*d - 12*d^2 + 
                  d^3)*t))))) + 
       gZlL*(-(gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*
               s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                (-108 + 85*d - 21*d^2 + 2*d^3)*s + (-52 + 44*d - 12*d^2 + 
                  d^3)*t)))) + gZuL*(d^3*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
            ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*
              s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
              ((-120 + 90*d - 21*d^2 + 2*d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*
                t))))))/((-4 + d)*mz^2*Pi^(2*d)*(mz^2 - s)*s) - 
    (2^(1 - d)*d*(gZlL + gZlR)*(gZuL + gZuR)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
    (2^(1 - d)*((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
       (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*(s + t)*(-1 + GaugeXi[Q]))/
     (mz^2*Pi^d*s) + (((-2 + d)*s - 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
       gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
       gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    (2^(1 - d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
         d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    ((-2 + d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
         d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) + 
    ((-2 + d)*(gZlL*(d*gZuR*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*
            s) + gZuL*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
         2^(1 + d)*gZuR*Pi^d*(mz^2 - s)*t + gZuL*mz^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(3*s + t))) + 
       gZlR*(d*gZuL*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*s) + 
         gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
         2^(1 + d)*gZuL*Pi^d*(mz^2 - s)*t + gZuR*mz^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(3*s + t))))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) - 
    (2*(-2 + d)*((3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(mz^2 - s)^2*
         (-1 + GaugeXi[Q]))/(mz^2*Pi^d) - (3*2^(2 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*(mz^2 - s)*t*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*t^2*(-1 + GaugeXi[Q]))/
        (mz^2*Pi^d) + (2^(1 - d)*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*
           (gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 
          4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*s*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - d)*t*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (mz^2*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - d*gZuL*t + 
            (-6 + d)*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + (-2 + d)*gZuR*s + 
            (-6 + d)*gZuL*t - d*gZuR*t))*(-1 + GaugeXi[Q]))/((2*Pi)^d*s) - 
       (2^(1 - d)*(gZlL*gZuL*((-2 + d)*s^2 - 2*t^2) + 
          gZlR*gZuR*((-2 + d)*s^2 - 2*t^2) - gZlR*gZuL*((-4 + d)*s^2 + 
            2*t^2) - gZlL*gZuR*((-4 + d)*s^2 + 2*t^2))*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - d)*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*mz^2*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
           d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
            ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
             (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
           2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
           gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
               (3 + d)*s*t - t^2))) + 2*(s + t)*
          (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + 
                t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
             2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
          GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
             d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
              ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
               (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
             2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
             gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                 (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/(mz^2*(2*Pi)^(2*d)*
         (-1 + GaugeXi[Q]))))/(mz^2 - s)^2), (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(3 - d)*((-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuL - (-52 + 44*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuR)*
      ((-2 + d)*s + 2*t))/((-4 + d)*Pi^d*s) + 
    (4^(1 - d)*(-3 + d)*(gZlR*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*(-((-124 + 89*d - 21*d^2 + d^3)*s^2) - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (-((-124 + 89*d - 21*d^2 + d^3)*s^2) - (-76 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) - 
    (4^(1 - d)*(-(gZlR*gZuL*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
          mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((56 - 41*d + 9*d^2)*s - 
              (-52 + 44*d - 12*d^2 + d^3)*t)))) - 
       gZlL*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((56 - 41*d + 9*d^2)*s - (-52 + 44*d - 12*d^2 + d^
                3)*t))) + gZlL*gZuL*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((64 - 44*d + 9*d^2)*s - 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((64 - 44*d + 9*d^2)*s - (-56 + 46*d - 12*d^2 + d^
                3)*t)))))/(mz^2*Pi^(2*d)*s) - 
    (4^(1 - d)*(-3 + d)*
      (-(gZlR*(gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*
               s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                (-108 + 85*d - 21*d^2 + 2*d^3)*s + (-52 + 44*d - 12*d^2 + 
                  d^3)*t))) + gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + 
                d^3)*s*t + 8*t^2) + mz^2*(d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(
                (-120 + 90*d - 21*d^2 + 2*d^3)*s + (-56 + 46*d - 12*d^2 + 
                  d^3)*t))))) + 
       gZlL*(-(gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*
               s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                (-108 + 85*d - 21*d^2 + 2*d^3)*s + (-52 + 44*d - 12*d^2 + 
                  d^3)*t)))) + gZuL*(d^3*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
            ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*
              s*t + 8*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
              ((-120 + 90*d - 21*d^2 + 2*d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*
                t))))))/((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) + 
    (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*((-4 + d)*mz^2 + d*s)*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
    ((mz^2*(-((-6 + d)*s) + 2*t) + s*(-((-2 + d)*s) + 2*t))*
      (gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
       gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    (2^(1 - d)*(mz^2 - s)*(d*gZlR*(gZuL - gZuR)*s + 
       gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
       2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) - 
    (((-4 + d)*mz^2 + (-2 + d)*s)*(d*gZlR*(gZuL - gZuR)*s + 
       gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
       2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^d*s) - 
    (2^(2 - d)*(gZlL*((-4 + d)*gZuL*s*(s + t) - (-2 + d)*gZuR*s*(s + t) + 
         gZuR*mz^2*(2*s - (-4 + d)*t) + gZuL*mz^2*(2*s + (-2 + d)*t)) + 
       gZlR*(-((-2 + d)*gZuL*s*(s + t)) + (-4 + d)*gZuR*s*(s + t) + 
         gZuL*mz^2*(2*s - (-4 + d)*t) + gZuR*mz^2*(2*s + (-2 + d)*t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    (((-4 + d)*mz^2 + (-2 + d)*s)*
      (-(gZlR*(d*gZuL*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*s) + 
          gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
          2^(1 + d)*gZuL*Pi^d*(mz^2 - s)*t + gZuR*mz^2*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(3*s + t)))) + 
       gZlL*(-(gZuR*(d*s*(mz^2*(2*Pi)^d - 2^(1 + d)*Pi^d*s + (2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(mz^2 - s)*t)) + 
         gZuL*(mz^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)) + 
           s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)))))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) + 
    (2*(-3 + d)*(mz^2 + s)*((3*2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*
         (mz^2 - s)^2*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (3*2^(2 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(mz^2 - s)*t*
         (-1 + GaugeXi[Q]))/(mz^2*Pi^d) + (3*2^(1 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*t^2*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*s*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(1 - d)*t*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (mz^2*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - d*gZuL*t + 
            (-6 + d)*gZuR*t) + gZlR*(-((-4 + d)*gZuL*s) + (-2 + d)*gZuR*s + 
            (-6 + d)*gZuL*t - d*gZuR*t))*(-1 + GaugeXi[Q]))/((2*Pi)^d*s) - 
       (2^(1 - d)*(gZlL*gZuL*((-2 + d)*s^2 - 2*t^2) + 
          gZlR*gZuR*((-2 + d)*s^2 - 2*t^2) - gZlR*gZuL*((-4 + d)*s^2 + 
            2*t^2) - gZlL*gZuR*((-4 + d)*s^2 + 2*t^2))*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - d)*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/Pi^d - 
       (2^(1 - d)*mz^2*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - d)*t*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) + 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
           d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
            ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
             (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
           2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
           gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
               (3 + d)*s*t - t^2))) + 2*(s + t)*
          (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + 
                t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
             2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
          GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
             d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
              ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
               (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
             2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
             gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                 (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/(mz^2*(2*Pi)^(2*d)*
         (-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 0, 0, 
  (I*EL^6*gAl^2*gAu^2*((2^(1 + d)*d*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*
       (-1 + GaugeXi[Q])^2)/mz^2 - 
     (2^(1 + d)*((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
        (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*Pi^d*(s + t)*
       (-1 + GaugeXi[Q])^2)/(mz^2*s) - ((2*Pi)^d*((-2 + d)*s - 2*t)*
       (gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])^2)/(mz^2*s^2) - 
     (2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2)/(mz^2*s) - 
     ((-2 + d)*(2*Pi)^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2)/(mz^2*s) + 
     ((-2 + d)*(-1 + GaugeXi[Q])^2*
       (s*(gZlL*(d*gZuL*(2*Pi)^d*s + d*gZuR*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*gZuR*Pi^d*t + 2^(1 + d)*gZuL*Pi^d*(-((-3 + d)*s) + 
              t)) + gZlR*(d*(gZuL - gZuR)*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*Pi^d*(3*gZuR*s + gZuL*t + gZuR*t))) - 
        mz^2*(gZlR*(-(d*gZuR*(2*Pi)^d*s) + 2^(1 + d)*gZuR*Pi^d*(3*s + t) + 
            gZuL*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
          gZlL*(-(d*gZuL*(2*Pi)^d*s) + 2^(1 + d)*gZuL*Pi^d*(3*s + t) + 
            gZuR*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*GaugeXi[Q]))/
      (mz^2*s*(-s + mz^2*GaugeXi[Q])) - 
     (2*(-2 + d)*((-3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(s + t)^2*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*s*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*t*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + 3*2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*
         Pi^d*(s + t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q] - 
        2^(1 + d)*Pi^d*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q] + 
        (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s^2 - 2*t^2) + 
           gZlR*gZuR*((-2 + d)*s^2 - 2*t^2) - gZlR*gZuL*((-4 + d)*s^2 + 
             2*t^2) - gZlL*gZuR*((-4 + d)*s^2 + 2*t^2))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q])/s - 2^(1 + d)*Pi^d*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q] - 
        (2^(1 + d)*Pi^d*t*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
           2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
             gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s - 
        3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*mz^2*Pi^d*(-1 + GaugeXi[Q])^2*
         GaugeXi[Q]^2 - (mz^2*(2*Pi)^d*(gZlL*((-2 + d)*gZuL*s - 
             (-4 + d)*gZuR*s - d*gZuL*t + (-6 + d)*gZuR*t) + 
           gZlR*(-((-4 + d)*gZuL*s) + (-2 + d)*gZuR*s + (-6 + d)*gZuL*t - 
             d*gZuR*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/s + 
        (2^(1 + d)*mz^2*Pi^d*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
           2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
             gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/s - 
        (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + d*gZuR*(2*Pi)^d*s*(s - 3*t) + 
            2^(1 + d)*gZuL*Pi^d*(s - t)*((-1 + d)*s - t) + 
            2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + (3 + d)*s*t + t^2)) - 
          gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 2^(1 + d)*gZuR*Pi^d*(s - t)*
             ((-1 + d)*s - t) + gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 
              2^(1 + d)*Pi^d*((-2 + d)*s^2 - (3 + d)*s*t - t^2))) + 
          2*(s + t)*(-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
               2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*
                (2*s + t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^
                d*s + 2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(
                2*s + t)))*GaugeXi[Q] + 
          (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + d*gZuR*(2*Pi)^d*s*(s - 
                3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*((-1 + d)*s - t) + 
              2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + (3 + d)*s*t + t^2)) - 
            gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 2^(1 + d)*gZuR*Pi^d*(s - t)*(
                (-1 + d)*s - t) + gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 
                2^(1 + d)*Pi^d*((-2 + d)*s^2 - (3 + d)*s*t - t^2))))*
           GaugeXi[Q]^2)/mz^2))/(s - mz^2*GaugeXi[Q])^2))/
   (2^(2*(2 + d))*Pi^(2*d)*(-1 + GaugeXi[Q])), 
  ((-I)*EL^6*gAl^2*gAu^2*
    ((-4*(gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)) + gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
          d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - 
            (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuR*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/(mz^2*s) + 
     (2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])*
       (-s + mz^2*GaugeXi[Q]))/(mz^2*s) - 
     ((2*Pi)^d*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
          d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
       (-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q]))/(mz^2*s) + 
     (2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(-1 + GaugeXi[Q])*
       (d*s + (-4 + d)*mz^2*GaugeXi[Q]))/mz^2 + 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*(s*(-((-2 + d)*s) + 2*t) + 
        mz^2*(-((-6 + d)*s) + 2*t)*GaugeXi[Q]))/(mz^2*s^2) - 
     (2^(2 + d)*Pi^d*(-1 + GaugeXi[Q])*
       (((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - (-2 + d)*gZlL*gZuR + 
          (-4 + d)*gZlR*gZuR)*s*(s + t) + 
        mz^2*(gZlL*(2*gZuL*s + 2*gZuR*s + (-2 + d)*gZuL*t - 
            (-4 + d)*gZuR*t) + gZlR*(2*gZuL*s + 2*gZuR*s - (-4 + d)*gZuL*t + 
            (-2 + d)*gZuR*t))*GaugeXi[Q]))/(mz^2*s) + 
     ((-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q])*
       (s*(gZlL*(d*gZuL*(2*Pi)^d*s + d*gZuR*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*gZuR*Pi^d*t + 2^(1 + d)*gZuL*Pi^d*(-((-3 + d)*s) + 
              t)) + gZlR*(d*(gZuL - gZuR)*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*Pi^d*(3*gZuR*s + gZuL*t + gZuR*t))) - 
        mz^2*(gZlR*(-(d*gZuR*(2*Pi)^d*s) + 2^(1 + d)*gZuR*Pi^d*(3*s + t) + 
            gZuL*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
          gZlL*(-(d*gZuL*(2*Pi)^d*s) + 2^(1 + d)*gZuL*Pi^d*(3*s + t) + 
            gZuR*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*GaugeXi[Q]))/
      (mz^2*s*(-s + mz^2*GaugeXi[Q])) - (2*(-3 + d)*(s + mz^2*GaugeXi[Q])*
       ((-3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(s + t)^2*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*s*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*t*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + 3*2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*
         Pi^d*(s + t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q] - 
        2^(1 + d)*Pi^d*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q] + 
        (2^(1 + d)*Pi^d*(gZlL*gZuL*((-2 + d)*s^2 - 2*t^2) + 
           gZlR*gZuR*((-2 + d)*s^2 - 2*t^2) - gZlR*gZuL*((-4 + d)*s^2 + 
             2*t^2) - gZlL*gZuR*((-4 + d)*s^2 + 2*t^2))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q])/s - 2^(1 + d)*Pi^d*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
          2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
            gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q] - 
        (2^(1 + d)*Pi^d*t*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
           2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
             gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s - 
        3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*mz^2*Pi^d*(-1 + GaugeXi[Q])^2*
         GaugeXi[Q]^2 - (mz^2*(2*Pi)^d*(gZlL*((-2 + d)*gZuL*s - 
             (-4 + d)*gZuR*s - d*gZuL*t + (-6 + d)*gZuR*t) + 
           gZlR*(-((-4 + d)*gZuL*s) + (-2 + d)*gZuR*s + (-6 + d)*gZuL*t - 
             d*gZuR*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/s + 
        (2^(1 + d)*mz^2*Pi^d*(d*(gZlL - gZlR)*(gZuL - gZuR)*s - 
           2*(gZlL*gZuL*t + gZlR*gZuR*t + gZlR*gZuL*(-3*s + t) + 
             gZlL*gZuR*(-3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/s - 
        (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + d*gZuR*(2*Pi)^d*s*(s - 3*t) + 
            2^(1 + d)*gZuL*Pi^d*(s - t)*((-1 + d)*s - t) + 
            2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + (3 + d)*s*t + t^2)) - 
          gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 2^(1 + d)*gZuR*Pi^d*(s - t)*
             ((-1 + d)*s - t) + gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 
              2^(1 + d)*Pi^d*((-2 + d)*s^2 - (3 + d)*s*t - t^2))) + 
          2*(s + t)*(-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
               2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*
                (2*s + t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^
                d*s + 2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(
                2*s + t)))*GaugeXi[Q] + 
          (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + d*gZuR*(2*Pi)^d*s*(s - 
                3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*((-1 + d)*s - t) + 
              2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + (3 + d)*s*t + t^2)) - 
            gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 2^(1 + d)*gZuR*Pi^d*(s - t)*(
                (-1 + d)*s - t) + gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 
                2^(1 + d)*Pi^d*((-2 + d)*s^2 - (3 + d)*s*t - t^2))))*
           GaugeXi[Q]^2)/mz^2))/((-1 + GaugeXi[Q])*(s - mz^2*GaugeXi[Q])^2)))/
   (2^(2*(2 + d))*Pi^(2*d)), 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*4^(-1 - d)*EL^6*gAl^2*gAu^2*
    (-(gZlR*gZuL*(mz^2*(2^(1 + d)*(168 - 179*d + 68*d^2 - 3*d^3 + d^4)*Pi^d - 
          d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
        2^(1 + d)*Pi^d*((-280 + 251*d - 75*d^2 + 3*d^3)*s + 
          (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t))) - 
     gZlL*gZuR*(mz^2*(2^(1 + d)*(168 - 179*d + 68*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-280 + 251*d - 75*d^2 + 3*d^3)*s + 
         (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
     gZlL*gZuL*(mz^2*(2^(1 + d)*(192 - 196*d + 71*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-272 + 248*d - 75*d^2 + 3*d^3)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t)) + 
     gZlR*gZuR*(mz^2*(2^(1 + d)*(192 - 196*d + 71*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-272 + 248*d - 75*d^2 + 3*d^3)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t))))/((-4 + d)*Pi^(2*d)*s), 
  0, (I*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*
    (((-128 + 88*d - 18*d^2 + d^3)*gZlL*gZuL - (-112 + 82*d - 18*d^2 + d^3)*
        gZlR*gZuL - (-112 + 82*d - 18*d^2 + d^3)*gZlL*gZuR + 
       (-128 + 88*d - 18*d^2 + d^3)*gZlR*gZuR)*(2*Pi)^d*
      (mz^2*(-s + t) + s*(s + t)) + 
     2*(gZlL*gZuL*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-56 + 46*d - 12*d^2 + d^3)*s + (8 + 2*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*s + 
             (8 - 6*d + d^2)*t))) + gZlR*gZuR*
        (mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*((-56 + 46*d - 12*d^2 + d^3)*
              s + (8 + 2*d - 3*d^2)*t)) + (s + t)*(-(d^3*(2*Pi)^d*s) + 
           2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*s + (8 - 6*d + d^2)*t))) - 
       gZlR*gZuL*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-52 + 44*d - 12*d^2 + d^3)*s + (4 + 3*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            ((72 - 49*d + 10*d^2)*s + 2*(10 - 6*d + d^2)*t))) - 
       gZlL*gZuR*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-52 + 44*d - 12*d^2 + d^3)*s + (4 + 3*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            ((72 - 49*d + 10*d^2)*s + 2*(10 - 6*d + d^2)*t))))))/
   (Pi^(2*d)*s), (I*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*(s + t)*
    (gZlR*gZuL*(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d) + 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*
          s - 4*(10 - 6*d + d^2)*t) + 2^(1 + d)*Pi^d*
        (-((-72 + 45*d - 9*d^2 + d^3)*s^2) - 4*(-6 + d)*s*t + 8*t^2)) + 
     gZlL*gZuR*(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d) + 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*
          s - 4*(10 - 6*d + d^2)*t) + 2^(1 + d)*Pi^d*
        (-((-72 + 45*d - 9*d^2 + d^3)*s^2) - 4*(-6 + d)*s*t + 8*t^2)) + 
     gZlL*gZuL*(mz^4*(2^(1 + d)*(-64 + 44*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 - 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((36 - 16*d + d^2)*s - 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^2 + 
         4*d*s*t + 8*t^2)) + gZlR*gZuR*
      (mz^4*(2^(1 + d)*(-64 + 44*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 - 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((36 - 16*d + d^2)*s - 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^2 + 
         4*d*s*t + 8*t^2))))/(Pi^(2*d)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(2 - d)*((-128 + 88*d - 18*d^2 + d^3)*gZlL*gZuL - 
       (-112 + 82*d - 18*d^2 + d^3)*gZlR*gZuL - (-112 + 82*d - 18*d^2 + d^3)*
        gZlL*gZuR + (-128 + 88*d - 18*d^2 + d^3)*gZlR*gZuR))/(mz^2*Pi^d) - 
    (2^(4 - d)*((-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuL - (-52 + 44*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuR)*(s + t))/
     ((-4 + d)*mz^2*Pi^d*s) - 
    (2^(2 - d)*((-4 + d)*gZlL*gZuL*(3*(20 - 10*d + d^2)*s + 
         2*(14 - 8*d + d^2)*t) + (-4 + d)*gZlR*gZuR*(3*(20 - 10*d + d^2)*s + 
         2*(14 - 8*d + d^2)*t) + gZlR*gZuL*((216 - 170*d + 42*d^2 - 3*d^3)*
          s - 2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
       gZlL*gZuR*((216 - 170*d + 42*d^2 - 3*d^3)*s - 
         2*(-52 + 44*d - 12*d^2 + d^3)*t)))/(mz^2*Pi^d*s) + 
    (2^(1 - 2*d)*(2 - d)*(gZlR*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*(-((-124 + 89*d - 21*d^2 + d^3)*s^2) - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (-((-124 + 89*d - 21*d^2 + d^3)*s^2) - (-76 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*mz^2*Pi^(2*d)*(mz^2 - s)*s) + 
    (2^(1 - 2*d)*(2 - d)*(gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*mz^2*Pi^(2*d)*(mz^2 - s)*s) - 
    (2^(1 - d)*d*(gZlL + gZlR)*(gZuL + gZuR)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
    (2^(1 - d)*((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
       (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*(s + t)*(-1 + GaugeXi[Q]))/
     (mz^2*Pi^d*s) + (((-2 + d)*s - 2*t)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
       gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
       gZlL*gZuR*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    (2^(1 - d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
         d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    ((-2 + d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
         d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s) + 
    ((-2 + d)*(gZlL*(d*gZuR*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*
            s) + gZuL*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
         2^(1 + d)*gZuR*Pi^d*(mz^2 - s)*t + gZuL*mz^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(3*s + t))) + 
       gZlR*(d*gZuL*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*s) + 
         gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
         2^(1 + d)*gZuL*Pi^d*(mz^2 - s)*t + gZuR*mz^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(3*s + t))))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) + 
    (2*(-2 + d)*((((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
          (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*mz^2*(s + t)*
         (-1 + GaugeXi[Q]))/((2*Pi)^d*s) - (3*2^(1 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*(s + t)^2*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(2 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(s + t)^2*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - d)*s*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*
           (gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 
          4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*t*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/Pi^d + 
       (2^(1 - d)*t*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) - 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) - (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
           d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
            ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
             (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
           2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
           gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
               (3 + d)*s*t - t^2))) + 2*(s + t)*
          (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + 
                t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
             2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
          GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
             d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
              ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
               (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
             2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
             gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                 (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/(mz^2*(2*Pi)^(2*d)*
         (-1 + GaugeXi[Q]))))/(mz^2 - s)^2), (I/16)*EL^6*gAl^2*gAu^2*
   ((2^(3 - d)*((-56 + 46*d - 12*d^2 + d^3)*gZlL*gZuL - 
       (-52 + 44*d - 12*d^2 + d^3)*gZlR*gZuL - (-52 + 44*d - 12*d^2 + d^3)*
        gZlL*gZuR + (-56 + 46*d - 12*d^2 + d^3)*gZlR*gZuR)*
      ((-2 + d)*s + 2*t))/((-4 + d)*Pi^d*s) + 
    (4^(1 - d)*(-3 + d)*(gZlR*gZuL*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*(-((-124 + 89*d - 21*d^2 + d^3)*s^2) - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (-((-124 + 89*d - 21*d^2 + d^3)*s^2) - (-76 + 48*d - 12*d^2 + d^3)*
            s*t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) + 
    (4^(1 - d)*(-3 + d)*(gZlR*gZuL*(d^3*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - 
           (-76 + 48*d - 12*d^2 + d^3)*s*t + 8*t^2) + 
         mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-108 + 85*d - 21*d^2)*s + 
             (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuR*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
          ((124 - 89*d + 21*d^2 - 2*d^3)*s^2 - (-76 + 48*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            ((-108 + 85*d - 21*d^2)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZlL*gZuL*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          ((-128 + 94*d - 21*d^2 + 2*d^3)*s^2 + (-56 + 50*d - 12*d^2 + d^3)*s*
            t + 8*t^2) + mz^2*(-3*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
            (3*(40 - 30*d + 7*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t)))))/
     ((-4 + d)*Pi^(2*d)*(mz^2 - s)*s) - 
    (4^(1 - d)*(-(gZlR*gZuL*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
          mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((56 - 41*d + 9*d^2)*s - 
              (-52 + 44*d - 12*d^2 + d^3)*t)))) - 
       gZlL*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((56 - 41*d + 9*d^2)*s - (-52 + 44*d - 12*d^2 + d^
                3)*t))) + gZlL*gZuL*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((64 - 44*d + 9*d^2)*s - 
             (-56 + 46*d - 12*d^2 + d^3)*t))) + 
       gZlR*gZuR*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-(d^3*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*((64 - 44*d + 9*d^2)*s - (-56 + 46*d - 12*d^2 + d^
                3)*t)))))/(mz^2*Pi^(2*d)*s) + 
    (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*((-4 + d)*mz^2 + d*s)*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
    ((mz^2*(-((-6 + d)*s) + 2*t) + s*(-((-2 + d)*s) + 2*t))*
      (gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
       gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^d*s^2) + 
    (2^(1 - d)*(mz^2 - s)*(d*gZlR*(gZuL - gZuR)*s + 
       gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
       2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) - 
    (((-4 + d)*mz^2 + (-2 + d)*s)*(d*gZlR*(gZuL - gZuR)*s + 
       gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
       2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/
     (mz^2*(2*Pi)^d*s) - 
    (2^(2 - d)*(gZlL*((-4 + d)*gZuL*s*(s + t) - (-2 + d)*gZuR*s*(s + t) + 
         gZuR*mz^2*(2*s - (-4 + d)*t) + gZuL*mz^2*(2*s + (-2 + d)*t)) + 
       gZlR*(-((-2 + d)*gZuL*s*(s + t)) + (-4 + d)*gZuR*s*(s + t) + 
         gZuL*mz^2*(2*s - (-4 + d)*t) + gZuR*mz^2*(2*s + (-2 + d)*t)))*
      (-1 + GaugeXi[Q]))/(mz^2*Pi^d*s) + 
    (((-4 + d)*mz^2 + (-2 + d)*s)*
      (-(gZlR*(d*gZuL*s*(mz^2*(2*Pi)^d + (-(2^(1 + d)*Pi^d) + (2*Pi)^d)*s) + 
          gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
          2^(1 + d)*gZuL*Pi^d*(mz^2 - s)*t + gZuR*mz^2*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(3*s + t)))) + 
       gZlL*(-(gZuR*(d*s*(mz^2*(2*Pi)^d - 2^(1 + d)*Pi^d*s + (2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(mz^2 - s)*t)) + 
         gZuL*(mz^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)) + 
           s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)))))*
      (-1 + GaugeXi[Q]))/(mz^2*(2*Pi)^(2*d)*(mz^2 - s)*s) - 
    (2*(-3 + d)*(mz^2 + s)*((((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
          (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*mz^2*(s + t)*
         (-1 + GaugeXi[Q]))/((2*Pi)^d*s) - (3*2^(1 - d)*(gZlL + gZlR)*
         (gZuL + gZuR)*(s + t)^2*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) - 
       (2^(2 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(s + t)^2*(-1 + GaugeXi[Q]))/
        (Pi^d*s) + (2^(1 - d)*s*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*
           (gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 
          4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*t*(6*gZlR*gZuL*s + d*(gZlL - gZlR)*(gZuL - gZuR)*s + 
          6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 
          4*gZlR*gZuR*t)*(-1 + GaugeXi[Q]))/(mz^2*Pi^d) + 
       (2^(1 - d)*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/Pi^d + 
       (2^(1 - d)*t*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q]))/(Pi^d*s) - 
       (2^(1 - 2*d)*(gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2) + 2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)) - 
          gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))*(-1 + GaugeXi[Q]))/
        (Pi^(2*d)*s) - (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
           d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
            ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
             (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
           2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
           gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
               (3 + d)*s*t - t^2))) + 2*(s + t)*
          (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuR*Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + 
                t))) + gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
             2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
          GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
             d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
              ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
               (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
             2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
             gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                 (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/(mz^2*(2*Pi)^(2*d)*
         (-1 + GaugeXi[Q]))))/(mz^2 - s)^2), 0, 0, 
  (I*EL^6*gAl^2*gAu^2*((2^(1 + d)*d*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*
       (-1 + GaugeXi[Q])^2)/mz^2 - 
     (2^(1 + d)*((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - 
        (-2 + d)*gZlL*gZuR + (-4 + d)*gZlR*gZuR)*Pi^d*(s + t)*
       (-1 + GaugeXi[Q])^2)/(mz^2*s) - ((2*Pi)^d*((-2 + d)*s - 2*t)*
       (gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])^2)/(mz^2*s^2) - 
     (2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2)/(mz^2*s) - 
     ((-2 + d)*(2*Pi)^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2)/(mz^2*s) + 
     ((-2 + d)*(-1 + GaugeXi[Q])^2*
       (s*(gZlL*(d*gZuL*(2*Pi)^d*s + d*gZuR*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*gZuR*Pi^d*t + 2^(1 + d)*gZuL*Pi^d*(-((-3 + d)*s) + 
              t)) + gZlR*(d*(gZuL - gZuR)*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*Pi^d*(3*gZuR*s + gZuL*t + gZuR*t))) - 
        mz^2*(gZlR*(-(d*gZuR*(2*Pi)^d*s) + 2^(1 + d)*gZuR*Pi^d*(3*s + t) + 
            gZuL*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
          gZlL*(-(d*gZuL*(2*Pi)^d*s) + 2^(1 + d)*gZuL*Pi^d*(3*s + t) + 
            gZuR*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*GaugeXi[Q]))/
      (mz^2*s*(-s + mz^2*GaugeXi[Q])) - 
     (2*(-2 + d)*((-3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(s + t)^2*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*s*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*t*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 - (2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*
          Pi^d*(s + t)^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s + 
        2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q] + 
        (2^(1 + d)*Pi^d*t*(d*gZlR*(gZuL - gZuR)*s + 
           gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
           2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/
         s + (((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - (-2 + d)*gZlL*gZuR + 
           (-4 + d)*gZlR*gZuR)*mz^2*(2*Pi)^d*(s + t)*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/s - (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
            d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
             ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
              (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
            2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
            gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                (3 + d)*s*t - t^2))) + 2*(s + t)*
           (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*
                Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t))) + 
            gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
           GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
              d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*(
                (-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
                (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
              2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
              gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*
                 ((-2 + d)*s^2 - (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/mz^2))/
      (s - mz^2*GaugeXi[Q])^2))/(2^(2*(2 + d))*Pi^(2*d)*(-1 + GaugeXi[Q])), 
  ((-I)*EL^6*gAl^2*gAu^2*
    ((-4*(gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)) + gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + 
          d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - 
            (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuR*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/(mz^2*s) + 
     (2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + 
        gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
        2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])*
       (-s + mz^2*GaugeXi[Q]))/(mz^2*s) - 
     ((2*Pi)^d*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
          d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 2*gZlR*(gZuL*t + gZuR*(3*s + t)))*
       (-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q]))/(mz^2*s) + 
     (2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(-1 + GaugeXi[Q])*
       (d*s + (-4 + d)*mz^2*GaugeXi[Q]))/mz^2 + 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])*(s*(-((-2 + d)*s) + 2*t) + 
        mz^2*(-((-6 + d)*s) + 2*t)*GaugeXi[Q]))/(mz^2*s^2) - 
     (2^(2 + d)*Pi^d*(-1 + GaugeXi[Q])*
       (((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - (-2 + d)*gZlL*gZuR + 
          (-4 + d)*gZlR*gZuR)*s*(s + t) + 
        mz^2*(gZlL*(2*gZuL*s + 2*gZuR*s + (-2 + d)*gZuL*t - 
            (-4 + d)*gZuR*t) + gZlR*(2*gZuL*s + 2*gZuR*s - (-4 + d)*gZuL*t + 
            (-2 + d)*gZuR*t))*GaugeXi[Q]))/(mz^2*s) + 
     ((-1 + GaugeXi[Q])*((-2 + d)*s + (-4 + d)*mz^2*GaugeXi[Q])*
       (s*(gZlL*(d*gZuL*(2*Pi)^d*s + d*gZuR*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*gZuR*Pi^d*t + 2^(1 + d)*gZuL*Pi^d*(-((-3 + d)*s) + 
              t)) + gZlR*(d*(gZuL - gZuR)*(2^(1 + d)*Pi^d - (2*Pi)^d)*s + 
            2^(1 + d)*Pi^d*(3*gZuR*s + gZuL*t + gZuR*t))) - 
        mz^2*(gZlR*(-(d*gZuR*(2*Pi)^d*s) + 2^(1 + d)*gZuR*Pi^d*(3*s + t) + 
            gZuL*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
          gZlL*(-(d*gZuL*(2*Pi)^d*s) + 2^(1 + d)*gZuL*Pi^d*(3*s + t) + 
            gZuR*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*GaugeXi[Q]))/
      (mz^2*s*(-s + mz^2*GaugeXi[Q])) - (2*(-3 + d)*(s + mz^2*GaugeXi[Q])*
       ((-3*2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(s + t)^2*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*s*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 + (2^(1 + d)*Pi^d*t*(6*gZlR*gZuL*s + 
           d*(gZlL - gZlR)*(gZuL - gZuR)*s + 6*gZlL*gZuR*s + 4*gZlL*gZuL*t + 
           4*gZlR*gZuL*t + 4*gZlL*gZuR*t + 4*gZlR*gZuR*t)*
          (-1 + GaugeXi[Q])^2)/mz^2 - (2^(2 + d)*(gZlL + gZlR)*(gZuL + gZuR)*
          Pi^d*(s + t)^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/s + 
        2^(1 + d)*Pi^d*(d*gZlR*(gZuL - gZuR)*s + gZlL*(6*gZuL*s - d*gZuL*s + 
            d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
          2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q] + 
        (2^(1 + d)*Pi^d*t*(d*gZlR*(gZuL - gZuR)*s + 
           gZlL*(6*gZuL*s - d*gZuL*s + d*gZuR*s + 2*gZuL*t + 2*gZuR*t) + 
           2*gZlR*(gZuL*t + gZuR*(3*s + t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/
         s + (((-4 + d)*gZlL*gZuL - (-2 + d)*gZlR*gZuL - (-2 + d)*gZlL*gZuR + 
           (-4 + d)*gZlR*gZuR)*mz^2*(2*Pi)^d*(s + t)*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/s - (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
            d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*
             ((-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
              (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
            2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
            gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*((-2 + d)*s^2 - 
                (3 + d)*s*t - t^2))) + 2*(s + t)*
           (-(gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuR*
                Pi^d*(-s + t) + 2^(1 + d)*gZuL*Pi^d*(2*s + t))) + 
            gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
              2^(1 + d)*gZuL*Pi^d*(s - t) - 2^(1 + d)*gZuR*Pi^d*(2*s + t)))*
           GaugeXi[Q] + (gZlL*(-(d*gZuL*(2*Pi)^d*s*(s - 3*t)) + 
              d*gZuR*(2*Pi)^d*s*(s - 3*t) + 2^(1 + d)*gZuL*Pi^d*(s - t)*(
                (-1 + d)*s - t) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + d)*s^2) + 
                (3 + d)*s*t + t^2)) - gZlR*(d*gZuR*(2*Pi)^d*s*(s - 3*t) - 
              2^(1 + d)*gZuR*Pi^d*(s - t)*((-1 + d)*s - t) + 
              gZuL*(-(d*(2*Pi)^d*s*(s - 3*t)) + 2^(1 + d)*Pi^d*
                 ((-2 + d)*s^2 - (3 + d)*s*t - t^2))))*GaugeXi[Q]^2)/mz^2))/
      ((-1 + GaugeXi[Q])*(s - mz^2*GaugeXi[Q])^2)))/(2^(2*(2 + d))*Pi^(2*d)), 
  0, 0, 0, 0, 0, 0, 0, 0, (I*4^(-1 - d)*EL^6*gAl^2*gAu^2*
    (-(gZlR*gZuL*(mz^2*(2^(1 + d)*(168 - 179*d + 68*d^2 - 3*d^3 + d^4)*Pi^d - 
          d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
        2^(1 + d)*Pi^d*((-280 + 251*d - 75*d^2 + 3*d^3)*s + 
          (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t))) - 
     gZlL*gZuR*(mz^2*(2^(1 + d)*(168 - 179*d + 68*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-280 + 251*d - 75*d^2 + 3*d^3)*s + 
         (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
     gZlL*gZuL*(mz^2*(2^(1 + d)*(192 - 196*d + 71*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-272 + 248*d - 75*d^2 + 3*d^3)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t)) + 
     gZlR*gZuR*(mz^2*(2^(1 + d)*(192 - 196*d + 71*d^2 - 3*d^3 + d^4)*Pi^d - 
         d^3*(15 + d)*(2*Pi)^d) + 9*d^3*(2*Pi)^d*s + 
       2^(1 + d)*Pi^d*((-272 + 248*d - 75*d^2 + 3*d^3)*s + 
         (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t))))/((-4 + d)*Pi^(2*d)*s), 
  0, (I*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*
    (((-128 + 88*d - 18*d^2 + d^3)*gZlL*gZuL - (-112 + 82*d - 18*d^2 + d^3)*
        gZlR*gZuL - (-112 + 82*d - 18*d^2 + d^3)*gZlL*gZuR + 
       (-128 + 88*d - 18*d^2 + d^3)*gZlR*gZuR)*(2*Pi)^d*
      (mz^2*(-s + t) + s*(s + t)) + 
     2*(gZlL*gZuL*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-56 + 46*d - 12*d^2 + d^3)*s + (8 + 2*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*s + 
             (8 - 6*d + d^2)*t))) + gZlR*gZuR*
        (mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*((-56 + 46*d - 12*d^2 + d^3)*
              s + (8 + 2*d - 3*d^2)*t)) + (s + t)*(-(d^3*(2*Pi)^d*s) + 
           2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*s + (8 - 6*d + d^2)*t))) - 
       gZlR*gZuL*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-52 + 44*d - 12*d^2 + d^3)*s + (4 + 3*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            ((72 - 49*d + 10*d^2)*s + 2*(10 - 6*d + d^2)*t))) - 
       gZlL*gZuR*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*
            ((-52 + 44*d - 12*d^2 + d^3)*s + (4 + 3*d - 3*d^2)*t)) + 
         (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            ((72 - 49*d + 10*d^2)*s + 2*(10 - 6*d + d^2)*t))))))/
   (Pi^(2*d)*s), (I*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*(s + t)*
    (gZlR*gZuL*(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d) + 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*
          s - 4*(10 - 6*d + d^2)*t) + 2^(1 + d)*Pi^d*
        (-((-72 + 45*d - 9*d^2 + d^3)*s^2) - 4*(-6 + d)*s*t + 8*t^2)) + 
     gZlL*gZuR*(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d) + 
       d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*
          s - 4*(10 - 6*d + d^2)*t) + 2^(1 + d)*Pi^d*
        (-((-72 + 45*d - 9*d^2 + d^3)*s^2) - 4*(-6 + d)*s*t + 8*t^2)) + 
     gZlL*gZuL*(mz^4*(2^(1 + d)*(-64 + 44*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 - 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((36 - 16*d + d^2)*s - 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^2 + 
         4*d*s*t + 8*t^2)) + gZlR*gZuR*
      (mz^4*(2^(1 + d)*(-64 + 44*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d) - 
       d^3*(2*Pi)^d*s^2 - 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((36 - 16*d + d^2)*s - 
         4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^2 + 
         4*d*s*t + 8*t^2))))/(Pi^(2*d)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, (I*2^(-4 - d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) + gZuL^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2)) + gZlR^2*(-(gZuL^2*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuR^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
    (-mz^2 + s + mz^2*GaugeXi[Q]))/((-1 + d)*mz^4*Pi^d*s^2), 0, 0, 0, 
  (I*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
           ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
          mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d + 4*d^2)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2)))) + 
       gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-7*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((2 - 2*d + 4*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
             2*t^2)))) + gZlR^2*
      (-(gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
            (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-7*d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((4 - 3*d + 4*d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2)))) + gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 4*d^2)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
     (gZlL^2*(gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2) + mz^2*(17*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((12 - 9*d - 7*d^2)*s^2 + 3*(4 - 5*d + d^2)*s*
                t - 6*t^2))) + gZuL^2*(-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
              2*(8 - 5*d + d^2)*s*t + 4*t^2)) + mz^2*(-17*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-6 + 6*d + 7*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*
                t - 6*t^2)))) - gZlR^2*
        (gZuL^2*(-(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*
               s*t - 4*t^2)) + mz^2*(-17*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-12 + 9*d + 7*d^2)*s^2 - 3*(4 - 5*d + d^2)*s*
                t + 6*t^2))) + gZuR^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2) + mz^2*(17*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((6 - 6*d - 7*d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
               6*t^2)))))*GaugeXi[Q] + 
     (gZlL^2*(-(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 
              2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
                2*t^2)))) + gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((2 - 2*d + d^2)*
                s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlR^2*(-(gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
            3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((4 - 3*d + d^2)*
                 s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)))) + 
         gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2) + 3*mz^2*(-(d^2*(2*Pi)^d*s^2) + 
             2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*
                t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(-(gZlR^2*(-(gZuR^2*(-21*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              (2*(-1 + d + 5*d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-21*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + 10*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-21*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            (2*(-1 + d + 5*d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-21*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 3*d + 10*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2))))*
      GaugeXi[Q]^3))/((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 0, 
  (I*EL^6*gAl*gAu*(((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
       (4*(-1 + d)*mz^4 - 4*d*mz^2*s + d*s^2))/((-1 + d)*mz^4) + 
     2^(2 + 3*d)*(gZlL^2*((-56 + 46*d - 12*d^2 + d^3)*gZuL^2 - 
         (-52 + 44*d - 12*d^2 + d^3)*gZuR^2) + 
       gZlR^2*(-((-52 + 44*d - 12*d^2 + d^3)*gZuL^2) + 
         (-56 + 46*d - 12*d^2 + d^3)*gZuR^2))*Pi^(3*d)*(-1 - (2*t)/s) + 
     4^(1 + d)*Pi^(2*d)*(gZlR^2*(gZuL^2*(2^(2 + d)*(13 - 11*d + 3*d^2)*Pi^d - 
           d^3*(2*Pi)^d) - gZuR^2*(2^(1 + d)*(28 - 23*d + 6*d^2)*Pi^d - 
           d^3*(2*Pi)^d)) + gZlL^2*(gZuR^2*(2^(2 + d)*(13 - 11*d + 3*d^2)*
            Pi^d - d^3*(2*Pi)^d) + gZuL^2*(2^(1 + d)*(-28 + 23*d - 6*d^2)*
            Pi^d + d^3*(2*Pi)^d)))*(-1 - (2*t)/s) - 
     (2*(gZlL^2*(gZuR^2*(-((-2 + d)*(2*Pi)^(3*d)*s^2*(s + t)) + 
            2^(1 + 3*d)*mz^4*Pi^(3*d)*((-112 + 81*d - 18*d^2 + d^3)*s + 
              2*(-53 + 44*d - 12*d^2 + d^3)*t) - 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((10 - 7*d + d^2)*s^2 + (10 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZuL^2*((-4 + d)*(2*Pi)^(3*d)*s^2*(s + t) - 2^(1 + 3*d)*mz^4*
             Pi^(3*d)*((-122 + 87*d - 18*d^2 + d^3)*s + 2*(-55 + 46*d - 
                12*d^2 + d^3)*t) + 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        gZlR^2*(gZuL^2*(-((-2 + d)*(2*Pi)^(3*d)*s^2*(s + t)) + 
            2^(1 + 3*d)*mz^4*Pi^(3*d)*((-112 + 81*d - 18*d^2 + d^3)*s + 
              2*(-53 + 44*d - 12*d^2 + d^3)*t) - 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((10 - 7*d + d^2)*s^2 + (10 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZuR^2*((-4 + d)*(2*Pi)^(3*d)*s^2*(s + t) - 2^(1 + 3*d)*mz^4*
             Pi^(3*d)*((-122 + 87*d - 18*d^2 + d^3)*s + 2*(-55 + 46*d - 
                12*d^2 + d^3)*t) + 2^(2 + 3*d)*mz^2*Pi^(3*d)*
             ((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*t^2)))))/
      (mz^4*s) - ((2*Pi)^(2*d)*(2*mz^2 - s)*
       (gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(2^(1 + d)*mz^2*Pi^d - (2*Pi)^d*s) + 
          2^(1 + d)*Pi^d*(2*mz^2 - s)*(gZuL^2*t + gZuR^2*(3*s + t))) + 
        gZlL^2*(gZuR^2*(d*s*(2^(1 + d)*mz^2*Pi^d - (2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(2*mz^2 - s)*t) + 
          gZuL^2*(-(2^(1 + d)*mz^2*Pi^d*((-6 + d)*s - 2*t)) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t))))))/(mz^4*s) + 
     ((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*
       (4*(-1 + d)*mz^4 - 4*d*mz^2*s + d*s^2)*((2*Pi)^d - 
        2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2))/
      ((-1 + d)*mz^4*(-1 + GaugeXi[Q])^2) + 
     ((2*Pi)^(2*d)*(4*(-1 + d)*mz^4 + s*((-2 + d)*s - 2*t) + 
        mz^2*(-4*(-2 + d)*s + 8*t))*
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
          gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
        gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
          gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
        2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
             gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*
           (gZuL^2*((-4 + d)*s - 2*t) - gZuR^2*((-2 + d)*s + 2*t)))*
         GaugeXi[Q] + (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (s - t))) + gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 
                t))) - gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - 
                t)) - gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
         GaugeXi[Q]^2))/((-1 + d)*mz^4*s*(-1 + GaugeXi[Q])^2) + 
     (2^(1 + 2*d)*Pi^(2*d)*(mz^2 - s/2)*
       (-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(2^(1 + d)*mz^2*Pi^d + 
             2^(1 + d)*Pi^d*s - 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*
            (gZuL^2*t + gZuR^2*(3*s + t)))) + 
        gZlL^2*(-(gZuR^2*(d*s*(2^(1 + d)*mz^2*Pi^d + 2^(1 + d)*Pi^d*s - 3*
                (2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*t)) + 
          gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-6 + d)*s - 2*t) + 
            s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t)))) - 
        2*(-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(2^(1 + d)*mz^2*Pi^d - (2*Pi)^d*
                s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*(gZuL^2*t + gZuR^2*
                (3*s + t)))) + gZlL^2*(-(gZuR^2*(d*s*(2^(1 + d)*mz^2*Pi^d - 
                 (2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*t)) + 
            gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-6 + d)*s - 2*t) + 
              s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))))*GaugeXi[Q] + 
        (-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(2^(1 + d)*mz^2*Pi^d + 2^(1 + d)*
                Pi^d*s - 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*
              (gZuL^2*t + gZuR^2*(3*s + t)))) + 
          gZlL^2*(-(gZuR^2*(d*s*(2^(1 + d)*mz^2*Pi^d + 2^(1 + d)*Pi^d*s - 
                 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*mz^2 - s)*t)) + 
            gZuL^2*(2^(1 + d)*mz^2*Pi^d*((-6 + d)*s - 2*t) + 
              s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t)))))*
         GaugeXi[Q]^2))/(mz^4*s*(-1 + GaugeXi[Q])^2)))/
   (2^(4*(1 + d))*Pi^(4*d)), (I*2^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(2*(-112 + 82*d - 18*d^2 + d^3)*mz^2*s - 
         (-144 + 90*d - 18*d^2 + d^3)*s^2 - 8*(-6 + d)*s*t + 16*t^2) + 
       gZuL^2*(-2*(-128 + 88*d - 18*d^2 + d^3)*mz^2*s + 
         (-144 + 96*d - 18*d^2 + d^3)*s^2 + 8*d*s*t + 16*t^2)) + 
     gZlR^2*(gZuL^2*(2*(-112 + 82*d - 18*d^2 + d^3)*mz^2*s - 
         (-144 + 90*d - 18*d^2 + d^3)*s^2 - 8*(-6 + d)*s*t + 16*t^2) + 
       gZuR^2*(-2*(-128 + 88*d - 18*d^2 + d^3)*mz^2*s + 
         (-144 + 96*d - 18*d^2 + d^3)*s^2 + 8*d*s*t + 16*t^2))))/(Pi^d*s), 0, 
  (I*4^(-2 - d)*EL^6*gAl*gAu*
    (s*(-(gZlR^2*(-(gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
     2*(gZlL^2*(-(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*mz^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
            2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
              2*t^2))) + gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))) + gZlR^2*(-(gZuL^2*(d^2*(2*Pi)^d*s^3 + 
            2^(1 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
               t - 4*t^2) + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
              (4 - 5*d + d^2)*s*t - 2*t^2))) + gZuR^2*(d^2*(2*Pi)^d*s^3 + 
           2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))))*GaugeXi[Q] - 
     (gZlL^2*(-(gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 2^(3 + d)*mz^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
            2^(1 + d)*Pi^d*s*((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 
              2*t^2))) + gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2) + 
           2^(3 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))) + gZlR^2*(-(gZuL^2*(3*d^2*(2*Pi)^d*s^3 + 
            2^(3 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
               t - 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 3*d + d^2)*s^2 - 
              (4 - 5*d + d^2)*s*t + 2*t^2))) + gZuR^2*(3*d^2*(2*Pi)^d*s^3 + 
           2^(1 + d)*Pi^d*s*(-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 
             2*t^2) + 2^(3 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
              s*t + 4*t^2))))*GaugeXi[Q]^2 + 
     4*mz^2*(gZlR^2*(-(gZuR^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
         gZuL^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZlL^2*(gZuR^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
            ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
         gZuL^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2))))*GaugeXi[Q]^3))/
   ((-1 + d)*mz^4*Pi^(2*d)*s*(-1 + GaugeXi[Q])^2), 
  (I*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlR^2*(-(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
          mz^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + d^2)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2)))) + 
       gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-3*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 
             2*t^2)))) + gZlL^2*
      (-(gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-3*d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 
              2*t^2)))) + gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
          ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
         mz^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
     (gZlR^2*(gZuR^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
              t + 4*t^2) + 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              (2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) - 
         gZuL^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
              t - 4*t^2) + 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-4 + 3*d + 2*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
              t + 4*t^2) + 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              (2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) - 
         gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
              t - 4*t^2) + 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-4 + 3*d + 2*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))))*
      GaugeXi[Q] - 
     (gZlR^2*(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-6 + 6*d + 4*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*
                t - 6*t^2))) - gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
           mz^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d + 4*d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2)))) + 
       gZlL^2*(gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(-11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-6 + 6*d + 4*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*
                t - 6*t^2))) - gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
           mz^2*(-11*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-12 + 9*d + 4*d^2)*
                s^2 - 3*(4 - 5*d + d^2)*s*t + 6*t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(-(gZlR^2*(-(gZuR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-2 + 2*d + 3*d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + 3*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-2 + 2*d + 3*d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 3*d + 3*d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2))))*
      GaugeXi[Q]^3))/((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  (I*EL^6*gAl*gAu*((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
      (s - s*GaugeXi[Q])^2*(d*(mz^2 - s)^2 + 2*((-2 + d)*mz^4 - d*mz^2*s)*
        GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2) + (gZlL^2 + gZlR^2)*
      (gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*s^2*(d*(mz^2 - s)^2 + 
       2*((-2 + d)*mz^4 - d*mz^2*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)*
      ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
     (2*Pi)^(2*d)*((mz^2 - s)^2*((-2 + d)*s - 2*t) + 
       2*mz^2*(d*(mz^2 - s)*s + 2*(s^2 + mz^2*t + s*t))*GaugeXi[Q] + 
       mz^4*((-2 + d)*s - 2*t)*GaugeXi[Q]^2)*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
            gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*(gZuL^2*((-4 + d)*s - 2*t) - 
           gZuR^2*((-2 + d)*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        GaugeXi[Q]^2) + (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])^2*
      (gZlL^2*(gZuR^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
       gZlR^2*(gZuL^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s + 2*gZuL^2*t + 
            2*gZuR^2*(3*s + t))) + gZlL^2*(gZuL^2*((-6 + d)*s - 2*t) - 
           gZuR^2*(d*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(gZuR^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         gZlR^2*(gZuL^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
        GaugeXi[Q]^2) + (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])*
      (gZlL^2*(gZuR^2*(d*s*(mz^2*(2*Pi)^d + 2^(1 + d)*Pi^d*s - 
             3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(mz^2 - s)*t) + 
         gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t)))) + 
       gZlR^2*(gZuL^2*(d*s*(mz^2*(2*Pi)^d + 2^(1 + d)*Pi^d*s - 
             3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(mz^2 - s)*t) + 
         gZuR^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) - 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t)))) + 
       (gZlL^2*(gZuL^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (3*(-1 + d)*s - t)) - 2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t)) - 
           gZuR^2*(-(d*s*(mz^2*(-3*2^(1 + d)*Pi^d + 5*(2*Pi)^d) + 
                2^(1 + d)*Pi^d*s)) + 2^(1 + d)*Pi^d*(mz^2 - 2*s)*t)) - 
         gZlR^2*(-(d*(gZuL^2 - gZuR^2)*s*(mz^2*(-3*2^(1 + d)*Pi^d + 
                5*(2*Pi)^d) + 2^(1 + d)*Pi^d*s)) + 2^(1 + d)*Pi^d*
            (mz^2 - 2*s)*(gZuL^2*t + gZuR^2*(3*s + t))))*GaugeXi[Q] + 
       (-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(mz^2*(2^(1 + d)*Pi^d - (2*Pi)^d) - 
              2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(mz^2 + s)*
             (gZuL^2*t + gZuR^2*(3*s + t)))) + 
         gZlL^2*(-(gZuR^2*(d*s*(mz^2*(2^(1 + d)*Pi^d - (2*Pi)^d) - 
                2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(mz^2 + 
                s)*t)) + gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                ((-3 + d)*s - t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((3 + d)*s + t)))))*GaugeXi[Q]^2 + 
       mz^2*(-(gZlR^2*(d*(gZuL^2 - gZuR^2)*(2^(2 + d)*Pi^d - 5*(2*Pi)^d)*s - 
            2^(1 + d)*Pi^d*(gZuL^2*t + gZuR^2*(3*s + t)))) + 
         gZlL^2*(-(gZuR^2*(d*(2^(2 + d)*Pi^d - 5*(2*Pi)^d)*s - 
              2^(1 + d)*Pi^d*t)) + gZuL^2*(-5*d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*(3*s + 2*d*s + t))))*GaugeXi[Q]^3) + 
     2*(1 - d)*s*((2*Pi)^(3*d)*
        (gZlL^2*(-(gZuR^2*((-2 + d)*mz^4*(s + t) + (-2 + d)*s^2*(s + t) + 
              2*mz^2*((10 - 7*d + d^2)*s^2 + (10 - 11*d + 2*d^2)*s*t - 
                4*t^2))) + gZuL^2*((-4 + d)*mz^4*(s + t) + (-4 + d)*s^2*
              (s + t) + 2*mz^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*
                t + 4*t^2))) + gZlR^2*(-(gZuL^2*((-2 + d)*mz^4*(s + t) + 
              (-2 + d)*s^2*(s + t) + 2*mz^2*((10 - 7*d + d^2)*s^2 + 
                (10 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuR^2*((-4 + d)*mz^4*(s + t) + (-4 + d)*s^2*(s + t) + 
             2*mz^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*
                t^2)))) - 2^(1 + 3*d)*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-2 + d)*s^2*(s + t) + mz^4*((-4 + d)*s + 
                2*(-3 + d)*t) + mz^2*((18 - 13*d + 2*d^2)*s^2 + 
                (18 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
           gZuL^2*((-4 + d)*s^2*(s + t) + mz^4*((-2 + d)*s + 2*(-3 + d)*t) + 
             mz^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*
                t^2))) + gZlR^2*(-(gZuL^2*((-2 + d)*s^2*(s + t) + 
              mz^4*((-4 + d)*s + 2*(-3 + d)*t) + mz^2*((18 - 13*d + 2*d^2)*
                 s^2 + (18 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
           gZuR^2*((-4 + d)*s^2*(s + t) + mz^4*((-2 + d)*s + 2*(-3 + d)*t) + 
             mz^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*
                t^2))))*GaugeXi[Q] + (2^(1 + 3*d)*d^2*(gZlL^2 - gZlR^2)*
          (gZuL^2 - gZuR^2)*mz^2*Pi^(3*d)*s*(s + 2*t) + 
         d*(2*Pi)^(3*d)*(gZlR^2*(gZuR^2*(s^2*(s + t) + 2*mz^4*(s + 3*t) - 6*
                mz^2*s*(s + 3*t)) - gZuL^2*(s^2*(s + t) + 2*mz^4*(s + 3*t) - 
               2*mz^2*s*(5*s + 9*t))) + gZlL^2*(gZuL^2*(s^2*(s + t) + 2*mz^4*
                (s + 3*t) - 6*mz^2*s*(s + 3*t)) - gZuR^2*(s^2*(s + t) + 2*
                mz^4*(s + 3*t) - 2*mz^2*s*(5*s + 9*t)))) + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlR^2*(-2*gZuR^2*(s^3 + 4*mz^4*t - 6*mz^2*s*
                t + s^2*t - 2*mz^2*t^2) + gZuL^2*(s^2*(s + t) + 2*mz^4*
                (3*s + 5*t) + mz^2*(-6*s^2 - 6*s*t + 4*t^2))) + 
           gZlL^2*(-2*gZuL^2*(s^3 + 4*mz^4*t - 6*mz^2*s*t + s^2*t - 2*mz^2*
                t^2) + gZuR^2*(s^2*(s + t) + 2*mz^4*(3*s + 5*t) + mz^2*
                (-6*s^2 - 6*s*t + 4*t^2)))))*GaugeXi[Q]^2 + 
       2^(1 + 3*d)*mz^2*Pi^(3*d)*
        (gZlL^2*(gZuR^2*((-2 + d)*s*(s + t) + mz^2*((-4 + d)*s + 2*(-3 + d)*
                t)) - gZuL^2*((-4 + d)*s*(s + t) + mz^2*((-2 + d)*s + 2*
                (-3 + d)*t))) + gZlR^2*(gZuL^2*((-2 + d)*s*(s + t) + 
             mz^2*((-4 + d)*s + 2*(-3 + d)*t)) - gZuR^2*((-4 + d)*s*(s + t) + 
             mz^2*((-2 + d)*s + 2*(-3 + d)*t))))*GaugeXi[Q]^3 + 
       (gZlR^2*(-((-2 + d)*gZuL^2) + (-4 + d)*gZuR^2) + 
         gZlL^2*((-4 + d)*gZuL^2 - (-2 + d)*gZuR^2))*mz^4*(2*Pi)^(3*d)*
        (s + t)*GaugeXi[Q]^4)))/(2^(4*(1 + d))*(1 - d)*mz^4*Pi^(4*d)*
    (s - s*GaugeXi[Q])^2), ((-I)*4^(-2 - d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
          ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + 3*d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(7*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((2 - 2*d - 3*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
             2*t^2)))) + gZlR^2*(gZuL^2*(-(d^2*(2*Pi)^d*s^3) + 
         2^(1 + d)*Pi^d*s*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
         mz^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + 3*d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) + mz^2*(7*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((2 - 2*d - 3*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
             2*t^2)))) + 
     (gZlL^2*(gZuR^2*(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2) + mz^2*(11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((12 - 9*d - 4*d^2)*s^2 + 3*(4 - 5*d + d^2)*s*
                t - 6*t^2))) + gZuL^2*(-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
              2*(8 - 5*d + d^2)*s*t + 4*t^2)) + mz^2*(-11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-6 + 6*d + 4*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*
                t - 6*t^2)))) - gZlR^2*
        (gZuL^2*(-(2^(1 + d)*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*
               s*t - 4*t^2)) + mz^2*(-11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((-12 + 9*d + 4*d^2)*s^2 - 3*(4 - 5*d + d^2)*s*
                t + 6*t^2))) + gZuR^2*(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2) + mz^2*(11*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((6 - 6*d - 4*d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
               6*t^2)))))*GaugeXi[Q] + 
     (gZlR^2*(gZuR^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2) - 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*(2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*
                t^2))) + gZuL^2*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + 2*d^2)*
                s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2) - 3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*(2*(-1 + d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*
                t^2))) + gZuR^2*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
            ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
           3*mz^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + 2*d^2)*
                s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))))*GaugeXi[Q]^2 + 
     mz^2*(-(gZlR^2*(-(gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
          gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))) + 
       gZlL^2*(gZuL^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
         gZuR^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 3*d + d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))))*GaugeXi[Q]^3))/
   ((-1 + d)*mz^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  (I*EL^6*gAl*gAu*((gZlL^2 + gZlR^2)*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
      (s - s*GaugeXi[Q])^2*(d*(mz^2 - s)^2 + 2*((-2 + d)*mz^4 - d*mz^2*s)*
        GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2) + (gZlL^2 + gZlR^2)*
      (gZuL^2 + gZuR^2)*(2*Pi)^(2*d)*s^2*(d*(mz^2 - s)^2 + 
       2*((-2 + d)*mz^4 - d*mz^2*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2)*
      ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
     (2*Pi)^(2*d)*((mz^2 - s)^2*((-2 + d)*s - 2*t) + 
       2*mz^2*(d*(mz^2 - s)*s + 2*(s^2 + mz^2*t + s*t))*GaugeXi[Q] + 
       mz^4*((-2 + d)*s - 2*t)*GaugeXi[Q]^2)*
      (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
       gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(gZuR^2*(-((-4 + d)*s) + 2*t) + 
            gZuL^2*((-2 + d)*s + 2*t))) + gZlL^2*(gZuL^2*((-4 + d)*s - 2*t) - 
           gZuR^2*((-2 + d)*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(-(gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t))) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) - 
         gZlR^2*(gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        GaugeXi[Q]^2) + (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])^2*
      (gZlL^2*(gZuR^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
         gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
       gZlR^2*(gZuL^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
         gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
       2^(1 + d)*Pi^d*(-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s + 2*gZuL^2*t + 
            2*gZuR^2*(3*s + t))) + gZlL^2*(gZuL^2*((-6 + d)*s - 2*t) - 
           gZuR^2*(d*s + 2*t)))*GaugeXi[Q] + 
       (gZlL^2*(gZuR^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         gZlR^2*(gZuL^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
        GaugeXi[Q]^2) - (1 - d)*(2*Pi)^(2*d)*s*(mz^2 - s + mz^2*GaugeXi[Q])*
      (gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(mz^2*(2^(2 + d)*Pi^d - 5*(2*Pi)^d) - 
           2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) - 2^(1 + d)*Pi^d*(mz^2 - s)*
          (gZuL^2*t + gZuR^2*(3*s + t))) - 
       gZlL^2*(-(gZuR^2*(d*s*(mz^2*(2^(2 + d)*Pi^d - 5*(2*Pi)^d) - 
              2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) - 2^(1 + d)*Pi^d*(mz^2 - s)*
             t)) + gZuL^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
              (3*s + 2*d*s + t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
              ((3 + d)*s + t)))) + 
       (-(gZlL^2*(gZuL^2*(mz^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 ((-3 + d)*s - t)) - 2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t)) - 
            gZuR^2*(-(d*s*(mz^2*(-(2^(1 + d)*Pi^d) + (2*Pi)^d) + 2^(1 + d)*
                  Pi^d*s)) + 2^(1 + d)*Pi^d*(mz^2 - 2*s)*t))) + 
         gZlR^2*(-(d*(gZuL^2 - gZuR^2)*s*(mz^2*(-(2^(1 + d)*Pi^d) + 
                (2*Pi)^d) + 2^(1 + d)*Pi^d*s)) + 2^(1 + d)*Pi^d*(mz^2 - 2*s)*
            (gZuL^2*t + gZuR^2*(3*s + t))))*GaugeXi[Q] - 
       (-(gZlR^2*(d*(gZuL^2 - gZuR^2)*s*(mz^2*(3*2^(1 + d)*Pi^d - 
                5*(2*Pi)^d) - 2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(mz^2 + s)*(gZuL^2*t + gZuR^2*(3*s + t)))) + 
         gZlL^2*(-(gZuR^2*(d*s*(mz^2*(3*2^(1 + d)*Pi^d - 5*(2*Pi)^d) - 
                2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(mz^2 + 
                s)*t)) + gZuL^2*(mz^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (3*(-1 + d)*s - t)) - s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((3 + d)*s + t)))))*GaugeXi[Q]^2 - 
       mz^2*(gZlL^2*(gZuR^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuL^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         gZlR^2*(gZuL^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuR^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
        GaugeXi[Q]^3) - 2*(1 - d)*s*
      ((2*Pi)^(3*d)*(gZlL^2*(gZuR^2*((-2 + d)*mz^4*(s + t) + 
             (-2 + d)*s^2*(s + t) + 2*mz^2*((10 - 7*d + d^2)*s^2 + 
               (10 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
           gZuL^2*((-4 + d)*mz^4*(s + t) + (-4 + d)*s^2*(s + t) + 
             2*mz^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*
                t^2))) - gZlR^2*(-(gZuL^2*((-2 + d)*mz^4*(s + t) + 
              (-2 + d)*s^2*(s + t) + 2*mz^2*((10 - 7*d + d^2)*s^2 + 
                (10 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
           gZuR^2*((-4 + d)*mz^4*(s + t) + (-4 + d)*s^2*(s + t) + 
             2*mz^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*
                t^2)))) + 2^(1 + 3*d)*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-2 + d)*s^2*(s + t) + mz^4*((-4 + d)*s + 
                2*(-3 + d)*t) + mz^2*((18 - 13*d + 2*d^2)*s^2 + 
                (18 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
           gZuL^2*((-4 + d)*s^2*(s + t) + mz^4*((-2 + d)*s + 2*(-3 + d)*t) + 
             mz^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*
                t^2))) + gZlR^2*(-(gZuL^2*((-2 + d)*s^2*(s + t) + 
              mz^4*((-4 + d)*s + 2*(-3 + d)*t) + mz^2*((18 - 13*d + 2*d^2)*
                 s^2 + (18 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
           gZuR^2*((-4 + d)*s^2*(s + t) + mz^4*((-2 + d)*s + 2*(-3 + d)*t) + 
             mz^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*
                t^2))))*GaugeXi[Q] - (2^(1 + 3*d)*d^2*(gZlL^2 - gZlR^2)*
          (gZuL^2 - gZuR^2)*mz^2*Pi^(3*d)*s*(s + 2*t) + 
         d*(2*Pi)^(3*d)*(gZlR^2*(gZuR^2*(s^2*(s + t) + 2*mz^4*(s + 3*t) - 6*
                mz^2*s*(s + 3*t)) - gZuL^2*(s^2*(s + t) + 2*mz^4*(s + 3*t) - 
               2*mz^2*s*(5*s + 9*t))) + gZlL^2*(gZuL^2*(s^2*(s + t) + 2*mz^4*
                (s + 3*t) - 6*mz^2*s*(s + 3*t)) - gZuR^2*(s^2*(s + t) + 2*
                mz^4*(s + 3*t) - 2*mz^2*s*(5*s + 9*t)))) + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlR^2*(-2*gZuR^2*(s^3 + 4*mz^4*t - 6*mz^2*s*
                t + s^2*t - 2*mz^2*t^2) + gZuL^2*(s^2*(s + t) + 2*mz^4*
                (3*s + 5*t) + mz^2*(-6*s^2 - 6*s*t + 4*t^2))) + 
           gZlL^2*(-2*gZuL^2*(s^3 + 4*mz^4*t - 6*mz^2*s*t + s^2*t - 2*mz^2*
                t^2) + gZuR^2*(s^2*(s + t) + 2*mz^4*(3*s + 5*t) + mz^2*
                (-6*s^2 - 6*s*t + 4*t^2)))))*GaugeXi[Q]^2 + 
       2^(1 + 3*d)*mz^2*Pi^(3*d)*
        (gZlL^2*(-(gZuR^2*((-2 + d)*s*(s + t) + mz^2*((-4 + d)*s + 
                2*(-3 + d)*t))) + gZuL^2*((-4 + d)*s*(s + t) + 
             mz^2*((-2 + d)*s + 2*(-3 + d)*t))) + 
         gZlR^2*(-(gZuL^2*((-2 + d)*s*(s + t) + mz^2*((-4 + d)*s + 
                2*(-3 + d)*t))) + gZuR^2*((-4 + d)*s*(s + t) + 
             mz^2*((-2 + d)*s + 2*(-3 + d)*t))))*GaugeXi[Q]^3 - 
       (gZlR^2*(-((-2 + d)*gZuL^2) + (-4 + d)*gZuR^2) + 
         gZlL^2*((-4 + d)*gZuL^2 - (-2 + d)*gZuR^2))*mz^4*(2*Pi)^(3*d)*
        (s + t)*GaugeXi[Q]^4)))/(2^(4*(1 + d))*(1 - d)*mz^4*Pi^(4*d)*
    (s - s*GaugeXi[Q])^2), (I*4^(-1 - d)*EL^6*gAl*gAu*
    (gZlL^2*(-(gZuR^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((4 + 3*d - 3*d^2 + d^3)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZuL^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
          ((8 + 2*d - 3*d^2 + d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*t))) + 
     gZlR^2*(-(gZuL^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((4 + 3*d - 3*d^2 + d^3)*s + (-52 + 44*d - 12*d^2 + d^3)*t))) + 
       gZuR^2*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
          ((8 + 2*d - 3*d^2 + d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*t)))))/
   (Pi^(2*d)*s), 0, (I*4^(-1 - d)*EL^6*gAl*gAu*
    (gZlR^2*(gZuR^2*(-(d^3*(2*Pi)^d*s*(s - t)) + 2^(2 + d)*
          (-56 + 46*d - 12*d^2 + d^3)*mz^2*Pi^d*(s + t) + 
         2^(1 + d)*Pi^d*((80 - 56*d + 11*d^2)*s^2 - 
           (-112 + 80*d - 15*d^2 + d^3)*s*t + 4*(8 - 6*d + d^2)*t^2)) - 
       gZuL^2*(-(d^3*(2*Pi)^d*s*(s - t)) + 2^(2 + d)*(-52 + 44*d - 12*d^2 + 
           d^3)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*
          ((88 - 57*d + 11*d^2)*s^2 - (-128 + 81*d - 15*d^2 + d^3)*s*t + 
           4*(10 - 6*d + d^2)*t^2))) + 
     gZlL^2*(gZuL^2*(-(d^3*(2*Pi)^d*s*(s - t)) + 2^(2 + d)*
          (-56 + 46*d - 12*d^2 + d^3)*mz^2*Pi^d*(s + t) + 
         2^(1 + d)*Pi^d*((80 - 56*d + 11*d^2)*s^2 - 
           (-112 + 80*d - 15*d^2 + d^3)*s*t + 4*(8 - 6*d + d^2)*t^2)) - 
       gZuR^2*(-(d^3*(2*Pi)^d*s*(s - t)) + 2^(2 + d)*(-52 + 44*d - 12*d^2 + 
           d^3)*mz^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*
          ((88 - 57*d + 11*d^2)*s^2 - (-128 + 81*d - 15*d^2 + d^3)*s*t + 
           4*(10 - 6*d + d^2)*t^2)))))/(Pi^(2*d)*s), 0, 
  (I*2^(-3 - 2*d)*EL^6*gAl*gAu*
    (gZlL^2*(gZuR^2*(-(d^3*(2*Pi)^d*s^2*(s + 3*t)) - 2^(1 + d)*mz^4*Pi^d*
          ((-216 + 170*d - 42*d^2 + 3*d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^3)*
            t) + 2^(2 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*s^2 + 
           (-184 + 122*d - 24*d^2 + d^3)*s*t - 4*(10 - 6*d + d^2)*t^2) + 
         2^(1 + d)*Pi^d*(9*(8 - 5*d + d^2)*s^3 + (96 - 49*d + 9*d^2 + d^3)*
            s^2*t - 4*(-8 + d)*s*t^2 + 8*t^3)) + 
       gZuL^2*(d^3*(2*Pi)^d*s^2*(s + 3*t) - 2^(2 + d)*(-4 + d)*mz^2*Pi^d*
          (s + t)*((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 
         2^(1 + d)*(-4 + d)*mz^4*Pi^d*(3*(20 - 10*d + d^2)*s + 
           2*(14 - 8*d + d^2)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2)*s^3 - 
           (72 - 52*d + 9*d^2 + d^3)*s^2*t + 4*(2 + d)*s*t^2 + 8*t^3))) + 
     gZlR^2*(gZuL^2*(-(d^3*(2*Pi)^d*s^2*(s + 3*t)) - 2^(1 + d)*mz^4*Pi^d*
          ((-216 + 170*d - 42*d^2 + 3*d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^3)*
            t) + 2^(2 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*s^2 + 
           (-184 + 122*d - 24*d^2 + d^3)*s*t - 4*(10 - 6*d + d^2)*t^2) + 
         2^(1 + d)*Pi^d*(9*(8 - 5*d + d^2)*s^3 + (96 - 49*d + 9*d^2 + d^3)*
            s^2*t - 4*(-8 + d)*s*t^2 + 8*t^3)) + 
       gZuR^2*(d^3*(2*Pi)^d*s^2*(s + 3*t) - 2^(2 + d)*(-4 + d)*mz^2*Pi^d*
          (s + t)*((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 
         2^(1 + d)*(-4 + d)*mz^4*Pi^d*(3*(20 - 10*d + d^2)*s + 
           2*(14 - 8*d + d^2)*t) + 2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2)*s^3 - 
           (72 - 52*d + 9*d^2 + d^3)*s^2*t + 4*(2 + d)*s*t^2 + 8*t^3)))))/
   (Pi^(2*d)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*2^(-2 - d)*(-4 + d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*
    ((-4 - 2*d + d^2)*s + 2*(14 - 8*d + d^2)*t)*CKM[1, 1]*CKMC[1, 1])/
   (Pi^d*s), 0, 0, 0, 0, (I*2^(-4 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*
    ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1]*
    (-mw^2 + s + mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*Pi^d*s^2), 
  (I*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    ((2^(1 + 3*d)*Pi^(3*d)*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2))/
      ((-1 + d)*mw^4) + ((2*Pi)^(3*d)*(-2*mw^2 + s)^2*((-6 + d)*s - 2*t))/
      (mw^4*s) - (8^(1 + d)*(-56 + 46*d - 12*d^2 + d^3)*Pi^(3*d)*(s + 2*t))/
      s - ((2*Pi)^(3*d)*((-4 + d)*s - 2*t)*(4*(-1 + d)*mw^4 + 
        s*((-2 + d)*s - 2*t) + mw^2*(-4*(-2 + d)*s + 8*t)))/
      ((-1 + d)*mw^4*s) - (2*((-4 + d)*(2*Pi)^(3*d)*s^2*(s + t) - 
        2^(1 + 3*d)*mw^4*Pi^(3*d)*((-122 + 87*d - 18*d^2 + d^3)*s + 
          2*(-55 + 46*d - 12*d^2 + d^3)*t) + 2^(2 + 3*d)*mw^2*Pi^(3*d)*
         ((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*t^2)))/(mw^4*s) + 
     ((2*Pi)^(2*d)*(2*mw^2 - s)*(2^(1 + d)*mw^2*Pi^d*((-6 + d)*s - 2*t) + 
        s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-((-3 + d)*s) + t)) - 
        2^(1 + d)*Pi^d*(2*mw^2 - s)*((-6 + d)*s - 2*t)*GaugeXi[Q] + 
        (2^(1 + d)*mw^2*Pi^d*((-6 + d)*s - 2*t) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)))*GaugeXi[Q]^2))/
      (mw^4*s*(-1 + GaugeXi[Q])^2)))/(2^(4*(1 + d))*Pi^(4*d)), 
  ((-I)*4^(-1 - 2*d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*
    (2*(-128 + 88*d - 18*d^2 + d^3)*mw^2*s - (-144 + 96*d - 18*d^2 + d^3)*
      s^2 - 8*d*s*t - 16*t^2)*CKM[1, 1]*CKMC[1, 1]*
    ((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
     (2*Pi)^(3*d)*GaugeXi[Q]^2))/(Pi^(4*d)*s*(-1 + GaugeXi[Q])^2), 
  (I*4^(-1 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*(s + t)*
    (2^(2 + d)*(-56 + 46*d - 12*d^2 + d^3)*mw^2*Pi^d - d^3*(2*Pi)^d*s + 
     2^(1 + d)*Pi^d*((80 - 56*d + 11*d^2)*s + 4*(8 - 6*d + d^2)*t))*CKM[1, 1]*
    CKMC[1, 1])/(Pi^(2*d)*s), (I*2^(-3 - 2*d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*
    gWud*(-(2^(2 + d)*(-4 + d)*mw^2*Pi^d*(s + t)*((36 - 16*d + d^2)*s - 
        4*(-2 + d)*t)) + 2^(1 + d)*(-4 + d)*mw^4*Pi^d*
      (3*(20 - 10*d + d^2)*s + 2*(14 - 8*d + d^2)*t) + 
     (s + t)*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
        ((-72 + 48*d - 9*d^2 + d^3)*s^2 + 4*d*s*t + 8*t^2)))*CKM[1, 1]*
    CKMC[1, 1])/(Pi^(2*d)*s), (I*4^(-2 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*
    CKM[1, 1]*CKMC[1, 1]*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
      (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
     mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + 
         (8 - 5*d + d^2)*s*t + 2*t^2)) - 
     (2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(3 - 3*d + d^2)*s^2 + 
           3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q] + 
     (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
         (8 - 5*d + d^2)*s*t + 2*t^2) + mw^2*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
           6*t^2)))*GaugeXi[Q]^2 + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
       2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))*
      GaugeXi[Q]^3))/((-1 + d)*mw^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  ((-I)*4^(-2 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    (-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(2*(1 - d + d^2)*s^2 + 
       (8 - 5*d + d^2)*s*t + 2*t^2) - 2^(1 + d)*Pi^d*(2*mw^2 + s)*
      ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)*GaugeXi[Q] + 
     (-3*d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(2*(1 - d + d^2)*s^2 + 
         (8 - 5*d + d^2)*s*t + 2*t^2) + 2^(3 + d)*mw^2*Pi^d*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^2 - 
     2^(2 + d)*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)*
      GaugeXi[Q]^3))/((-1 + d)*mw^4*Pi^(2*d)*s*(-1 + GaugeXi[Q])^2), 
  (I*4^(-2 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    (-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*(2*(-1 + d)*s^2 - 
       (8 - 5*d + d^2)*s*t - 2*t^2) + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
       2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     (2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
       mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(3 - 3*d + d^2)*s^2 + 
           3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q] + 
     (-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*(2*(-1 + d)*s^2 - 
         (8 - 5*d + d^2)*s*t - 2*t^2) + mw^2*(d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
           6*t^2)))*GaugeXi[Q]^2 + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
       2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))*
      GaugeXi[Q]^3))/((-1 + d)*mw^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  ((-I)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    (((2*Pi)^(3*d)*((-6 + d)*s - 2*t)*(mw^2 - s + mw^2*GaugeXi[Q])^2)/s + 
     (2^(1 + 3*d)*Pi^(3*d)*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
         GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/(-1 + d) - 
     ((2*Pi)^(3*d)*((-4 + d)*s - 2*t)*((mw^2 - s)^2*((-2 + d)*s - 2*t) + 
        2*mw^2*(d*(mw^2 - s)*s + 2*(s^2 + mw^2*t + s*t))*GaugeXi[Q] + 
        mw^4*((-2 + d)*s - 2*t)*GaugeXi[Q]^2))/((-1 + d)*s^2) + 
     ((2*Pi)^(2*d)*(mw^2 - s + mw^2*GaugeXi[Q])*
       (mw^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)) + 
        s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)) + 
        (2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t) + mw^2*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(3*s + t)))*GaugeXi[Q] + 
        (mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)))*GaugeXi[Q]^2 - 
        mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))*GaugeXi[Q]^3))/
      (s*(-1 + GaugeXi[Q])^2) + 
     (2*(-((2*Pi)^(3*d)*((-4 + d)*mw^4*(s + t) + (-4 + d)*s^2*(s + t) + 
           2*mw^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        2^(1 + 3*d)*Pi^(3*d)*((-4 + d)*s^2*(s + t) + 
          mw^4*((-2 + d)*s + 2*(-3 + d)*t) + mw^2*((12 - 9*d + 2*d^2)*s^2 + 
            (36 - 21*d + 4*d^2)*s*t + 8*t^2))*GaugeXi[Q] - 
        (2*Pi)^(3*d)*(2*d^2*mw^2*s*(s + 2*t) - 4*(s^3 + 4*mw^4*t - 
            6*mw^2*s*t + s^2*t - 2*mw^2*t^2) + 
          d*(s^2*(s + t) + 2*mw^4*(s + 3*t) - 6*mw^2*s*(s + 3*t)))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*((-4 + d)*s*(s + t) + 
          mw^2*((-2 + d)*s + 2*(-3 + d)*t))*GaugeXi[Q]^3 - 
        (-4 + d)*mw^4*(2*Pi)^(3*d)*(s + t)*GaugeXi[Q]^4))/
      (s*(-1 + GaugeXi[Q])^2)))/(2^(4*(1 + d))*mw^4*Pi^(4*d)), 
  (I*4^(-2 - d)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    ((mw^2 + s)*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
         (8 - 5*d + d^2)*s*t - 2*t^2)) + 
     (2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       mw^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 
           3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q] - 
     (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
         (8 - 5*d + d^2)*s*t + 2*t^2) + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*(2*(3 - 3*d + d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
           6*t^2)))*GaugeXi[Q]^2 + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
       2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))*
      GaugeXi[Q]^3))/((-1 + d)*mw^4*Pi^(2*d)*s^2*(-1 + GaugeXi[Q])^2), 
  ((-I)*EL^6*gAl*gAu*gWdu*gWlN*gWNl*gWud*CKM[1, 1]*CKMC[1, 1]*
    (((2*Pi)^(3*d)*((-6 + d)*s - 2*t)*(mw^2 - s + mw^2*GaugeXi[Q])^2)/s + 
     (2^(1 + 3*d)*Pi^(3*d)*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
         GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/(-1 + d) - 
     ((2*Pi)^(3*d)*((-4 + d)*s - 2*t)*((mw^2 - s)^2*((-2 + d)*s - 2*t) + 
        2*mw^2*(d*(mw^2 - s)*s + 2*(s^2 + mw^2*t + s*t))*GaugeXi[Q] + 
        mw^4*((-2 + d)*s - 2*t)*GaugeXi[Q]^2))/((-1 + d)*s^2) + 
     ((2*Pi)^(2*d)*(mw^2 - s + mw^2*GaugeXi[Q])*
       (mw^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)) + 
        s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)) + 
        (2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t) + mw^2*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(3*s + t)))*GaugeXi[Q] + 
        (mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(3*s - d*s + t)))*GaugeXi[Q]^2 - 
        mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))*GaugeXi[Q]^3))/
      (s*(-1 + GaugeXi[Q])^2) + 
     (2*(-((2*Pi)^(3*d)*((-4 + d)*mw^4*(s + t) + (-4 + d)*s^2*(s + t) + 
           2*mw^2*((8 - 5*d + d^2)*s^2 + (20 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        2^(1 + 3*d)*Pi^(3*d)*((-4 + d)*s^2*(s + t) + 
          mw^4*((-2 + d)*s + 2*(-3 + d)*t) + mw^2*((12 - 9*d + 2*d^2)*s^2 + 
            (36 - 21*d + 4*d^2)*s*t + 8*t^2))*GaugeXi[Q] - 
        (2*Pi)^(3*d)*(2*d^2*mw^2*s*(s + 2*t) - 4*(s^3 + 4*mw^4*t - 
            6*mw^2*s*t + s^2*t - 2*mw^2*t^2) + 
          d*(s^2*(s + t) + 2*mw^4*(s + 3*t) - 6*mw^2*s*(s + 3*t)))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*((-4 + d)*s*(s + t) + 
          mw^2*((-2 + d)*s + 2*(-3 + d)*t))*GaugeXi[Q]^3 - 
        (-4 + d)*mw^4*(2*Pi)^(3*d)*(s + t)*GaugeXi[Q]^4))/
      (s*(-1 + GaugeXi[Q])^2)))/(2^(4*(1 + d))*mw^4*Pi^(4*d)), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((-I)*(16 - 7*d + d^2)*EL^6*gAl^4*gAu^2*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-4 + d)*(2*Pi)^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZlL^2 + gZlR^2)*(2*mz^2 - (-7 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(Pi^d*s^3), 0, 0, 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZlL^2 + gZlR^2)*(2*mz^2 + 3*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(mz^2*Pi^d*s^3), 0, 0, 0, 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZlL^2 + gZlR^2)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(mz^2*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*(gZlL^2 + gZlR^2)*
    (2^(1 + d)*mz^4*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     2^(1 + d)*Pi^d*s^2*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mz^2*s*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-8 + 5*d)*s^2 - 
         2*(-8 + d)*s*t - 2*(-8 + d)*t^2))))/(Pi^(2*d)*s^3), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*4^(-1 - d)*EL^6*gAl^3*gAu*
    (-(gZlR*gZuL*((-17 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         ((64 - 76*d + 33*d^2 + 2*d^3)*s^2 + (64 - 108*d + 55*d^2 - 12*d^3 + 
            d^4)*s*t - 2*(16 - 7*d + d^2)*t^2))) - 
     gZlL*gZuR*((-17 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
        ((64 - 76*d + 33*d^2 + 2*d^3)*s^2 + (64 - 108*d + 55*d^2 - 12*d^3 + 
           d^4)*s*t - 2*(16 - 7*d + d^2)*t^2)) + 
     gZlL*gZuL*((-15 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
        (2*(16 - 23*d + 12*d^2 + d^3)*s^2 + (128 - 136*d + 59*d^2 - 12*d^3 + 
           d^4)*s*t + 2*(16 - 7*d + d^2)*t^2)) + 
     gZlR*gZuR*((-15 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
        (2*(16 - 23*d + 12*d^2 + d^3)*s^2 + (128 - 136*d + 59*d^2 - 12*d^3 + 
           d^4)*s*t + 2*(16 - 7*d + d^2)*t^2))))/
   ((-4 + d)*Pi^(2*d)*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((-I)*2^(-2 - d)*EL^6*gAl*gAu*(2*mz^2 - (-7 + d)*s)*
    (gZlL^3*(-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
     gZlR^3*(-(gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
   (Pi^d*(mz^2 - s)*s^2), 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu*(2*mz^2 + 3*s)*
    (gZlL^3*(-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
     gZlR^3*(-(gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
   (mz^2*Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 
  (I*EL^6*gAl*gAu*(gZlL^3*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR^3*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   (2^(2*(1 + d))*mz^2*Pi^(2*d)*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*2^(-2 - d)*EL^6*gAl*gAu*(2*mz^4 - (-8 + d)*mz^2*s + 2*s^2)*
    (gZlL^3*(-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
     gZlR^3*(-(gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
   (Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {((-I)*2^(-2 - d)*EL^6*gAl*gAu*gWlN*gWNl*gZNL*(2*mw^2 - (-7 + d)*s)*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu*gWlN*gWNl*gZNL*(2*mw^2 + 3*s)*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (mw^2*Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 
  ((-I)*EL^6*gAl*gAu*gWlN*gWNl*gZNL*(d^2*gZuL*(2*Pi)^d*s^2 - 
     d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - 
       (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuL*Pi^d*
      (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))/
   (2^(2*(1 + d))*mw^2*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 
  (I*2^(-2 - d)*EL^6*gAl*gAu*gWlN*gWNl*gZNL*(2*mw^4 - (-8 + d)*mw^2*s + 
     2*s^2)*(-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(-4*(-1 + d)*mw^2 + s - 4*d*s + 
     s*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^d*s^3), 
  (I*2^(-3 - d)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*(2*mw^2 - s)*
    (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*mw^4*Pi^d*s^3), 
  ((-I)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*mw^2*
    (2^(1 + d)*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mw^2*(d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-s^2 + 2*s*t + 2*t^2))))/
   ((2*Pi)^(2*d)*s^3), 0, 0, (I*4^(-1 - d)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*
    (2^(1 + d)*(-2 + 3*d)*mw^2*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     d*s*(d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-s^2 + 2*s*t + 2*t^2))))/
   ((-1 + d)*d*mw^4*Pi^(2*d)*s^2), (I*2^(-3 - 2*d)*EL^6*gAl*gAu^2*gWlN*gWNl*
    gWWA*(-(s*(d*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-s^2 + 2*s*t + 2*t^2) + 
        2^(1 + d)*mw^2*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2))) + 
     2^(2 + d)*mw^2*Pi^d*(2*mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]))/((-1 + d)*mw^4*Pi^(2*d)*s^2), 
  ((-I)*2^(-2 - d)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*((-2 + d)*s^2 + 4*s*t + 
     4*t^2)*((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*s^2), (I*2^(-2 - d)*EL^6*gAl*gAu^2*gWlN*gWNl*gWWA*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(mw^4 + 2*(-3 + 2*d)*mw^2*s + s^2 - 
     2*mw^2*(mw^2 + s)*GaugeXi[Q] + mw^4*GaugeXi[Q]^2))/
   ((-1 + d)*mw^4*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*2^(-3 - d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (4*(-1 + d)*mw^2 + (-1 + 4*d)*s - s*GaugeXi[Q]))/
   ((-1 + d)*mw^2*Pi^d*s^2*(-mz^2 + s)), 
  (I*2^(-4 - d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*(2*mw^2 - s)*
    (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*mw^4*Pi^d*(mz^2 - s)*s^2), 
  ((-I)*2^(-1 - d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*mw^2*(mw^2 + 2*s)*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*(mz^2 - s)*s^2), 0, 0, (I*8^(-1 - 2*d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*
    ((-4 + 6*d)*mw^2 + d*s)*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    ((2*Pi)^(5*d) - 2^(1 + 5*d)*Pi^(5*d)*GaugeXi[Q] + 
     (2*Pi)^(5*d)*GaugeXi[Q]^2))/((-1 + d)*d*mw^4*Pi^(6*d)*(mz^2 - s)*s*
    (-1 + GaugeXi[Q])^2), ((-I)*4^(-2 - 3*d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*
    ((2^(1 + 5*d)*Pi^(5*d)*(2*mw^2 + s)*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - 
        2*gZuL*t - 2*gZuR*t)*(s - 2*mw^2*GaugeXi[Q])^2)/((mz^2 - s)*s) - 
     (2^(1 + 5*d)*(gZuL + gZuR)*Pi^(5*d)*(2*mw^2 + s)*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2))/
      ((-1 + d)*(mz^2 - s)) + 
     ((2*Pi)^(4*d)*(-(2^(1 + d)*gZuL*mw^2*Pi^d*((-4 + d)*s - 2*t)) + 
        2^(1 + d)*gZuR*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
        gZuR*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
        gZuL*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))*
       (s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2))/((-1 + d)*(mz^2 - s)*s) + 
     (2*(2*mw^2 + s)*(-(((-2 + d)*gZuL - (-4 + d)*gZuR)*(2*Pi)^(5*d)*s^2*t) + 
        2^(1 + 5*d)*((-2 + d)*gZuL - (-4 + d)*gZuR)*Pi^(5*d)*s*(2*mw^2 + s)*t*
         GaugeXi[Q] + (2*Pi)^(5*d)*(gZuL*(2*mw^4*((-2 + d)*s - 2*t) - 
            8*(-2 + d)*mw^2*s*t - (-2 + d)*s^2*t) + 
          gZuR*(8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 
            2*mw^4*((-4 + d)*s + 2*t)))*GaugeXi[Q]^2 - 
        2^(2 + 5*d)*mw^2*Pi^(5*d)*((-4 + d)*gZuR*s*t - 
          gZuR*mw^2*((-4 + d)*s + 2*t) + gZuL*(mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*s*t))*GaugeXi[Q]^3 + 2^(1 + 5*d)*mw^4*Pi^(5*d)*
         ((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - 2*gZuL*t - 2*gZuR*t)*
         GaugeXi[Q]^4))/(s*(-mz^2 + s)*(-1 + GaugeXi[Q])^2)))/
   (mw^4*Pi^(6*d)), ((-I)*2^(-3 - d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    ((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s), 
  (I*2^(-3 - d)*EL^6*gAl*gAu*gWlN*gWNl*gWWZ*
    (-(gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (mw^4 + 2*(-3 + 2*d)*mw^2*s + s^2 - 2*mw^2*(mw^2 + s)*GaugeXi[Q] + 
     mw^4*GaugeXi[Q]^2))/((-1 + d)*mw^4*Pi^d*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, 
 {((-I)*(16 - 7*d + d^2)*EL^6*gAl^2*gAu^4*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-4 + d)*(2*Pi)^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*(gZuL^2 + gZuR^2)*
    (-(d*(1 + d)*(2*Pi)^d*s^3) + 2^(1 + d)*mz^2*Pi^d*
      ((-2 + d)*s^2 + 4*s*t + 4*t^2) + 2^(1 + d)*Pi^d*s*
      ((-7 + 5*d)*s^2 - 2*(-7 + d)*s*t - 2*(-7 + d)*t^2)))/(Pi^(2*d)*s^3), 0, 
  0, ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZuL^2 + gZuR^2)*(2*mz^2 + 3*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(mz^2*Pi^d*s^3), 0, 0, 0, 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZuL^2 + gZuR^2)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(mz^2*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*(gZuL^2 + gZuR^2)*
    (2^(1 + d)*mz^4*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     2^(1 + d)*Pi^d*s^2*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mz^2*s*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-8 + 5*d)*s^2 - 
         2*(-8 + d)*s*t - 2*(-8 + d)*t^2))))/(Pi^(2*d)*s^3), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*gWdu*gWud*(2*mw^2 - (-7 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1])/(Pi^d*s^3), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*gWdu*gWud*(2*mw^2 + 3*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1])/(mw^2*Pi^d*s^3), 0, 
  0, 0, 0, ((-I)*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*gWdu*gWud*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1])/(mw^2*Pi^d*s^2), 0, 
  0, 0, 0, 0, 0, (I*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*gWdu*gWud*
    (2*mw^4 - (-8 + d)*mw^2*s + 2*s^2)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    CKM[1, 1]*CKMC[1, 1])/(Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {((-I)*2^(-2 - d)*(16 - 7*d + d^2)*EL^6*gAl*gAu^3*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-4 + d)*Pi^d*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*4^(-1 - d)*EL^6*gAl*gAu*(gZlR*gZuL^3*(-(d^2*(1 + d)*(2*Pi)^d*s^3) + 
       2^(1 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
         4*t^2) + 2^(1 + d)*Pi^d*s*((28 - 25*d + 7*d^2)*s^2 - 
         (-28 + 39*d - 12*d^2 + d^3)*s*t + 2*(-7 + d)*t^2)) + 
     gZlL*gZuR^3*(-(d^2*(1 + d)*(2*Pi)^d*s^3) + 2^(1 + d)*mz^2*Pi^d*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       2^(1 + d)*Pi^d*s*((28 - 25*d + 7*d^2)*s^2 - 
         (-28 + 39*d - 12*d^2 + d^3)*s*t + 2*(-7 + d)*t^2)) + 
     gZlL*gZuL^3*(d^2*(1 + d)*(2*Pi)^d*s^3 - 2^(1 + d)*mz^2*Pi^d*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       2^(1 + d)*Pi^d*s*(-2*(7 - 8*d + 3*d^2)*s^2 + 
         (-56 + 43*d - 12*d^2 + d^3)*s*t + 2*(-7 + d)*t^2)) + 
     gZlR*gZuR^3*(d^2*(1 + d)*(2*Pi)^d*s^3 - 2^(1 + d)*mz^2*Pi^d*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       2^(1 + d)*Pi^d*s*(-2*(7 - 8*d + 3*d^2)*s^2 + 
         (-56 + 43*d - 12*d^2 + d^3)*s*t + 2*(-7 + d)*t^2))))/
   (Pi^(2*d)*(mz^2 - s)*s^2), 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu*(2*mz^2 + 3*s)*
    (-(gZlR*gZuL^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (mz^2*Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 
  (I*2^(-2 - d)*EL^6*gAl*gAu*
    (-(gZlR*gZuL^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (mz^2*Pi^d*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-2 - d)*EL^6*gAl*gAu*
    (2*mz^4 - (-8 + d)*mz^2*s + 2*s^2)*
    (-(gZlR*gZuL^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR^3*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR^3*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*4^(-1 - d)*EL^6*gAl*gAu*gWdu*gWud*gZdL*
    (-(2^(1 + d)*gZlL*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
        4*t^2)) + gZlL*s*((-11 + d)*d^2*(2*Pi)^d*s^2 + 
       2^(1 + d)*Pi^d*(2*(-7 + 8*d)*s^2 + (-56 + 43*d - 12*d^2 + d^3)*s*t + 
         2*(-7 + d)*t^2)) + gZlR*(2^(1 + d)*mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) - s*((-13 + d)*d^2*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((-28 + 25*d)*s^2 + (-28 + 39*d - 12*d^2 + d^3)*s*t - 
           2*(-7 + d)*t^2))))*CKM[1, 1]*CKMC[1, 1])/
   (Pi^(2*d)*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu*gWdu*gWud*gZdL*(2*mw^2 + 3*s)*
    (-(gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
    CKMC[1, 1])/(mw^2*Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 
  ((-I)*2^(-2 - d)*EL^6*gAl*gAu*gWdu*gWud*gZdL*
    (-(gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
    CKMC[1, 1])/(mw^2*Pi^d*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 
  ((-I)*4^(-1 - d)*EL^6*gAl*gAu*gWdu*gWud*gZdL*
    (gZlL*(2^(1 + d)*mw^4*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2) + 2^(1 + d)*Pi^d*s^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
          t + 4*t^2) + mw^2*s*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (2*(8 - 9*d + 3*d^2)*s^2 - (-64 + 48*d - 13*d^2 + d^3)*s*t - 
           2*(-8 + d)*t^2))) - 
     gZlR*(2^(1 + d)*mw^4*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
         4*t^2) + 2^(1 + d)*Pi^d*s^2*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + mw^2*s*(-(d^3*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((32 - 28*d + 7*d^2)*s^2 - 
           (-32 + 44*d - 13*d^2 + d^3)*s*t + 2*(-8 + d)*t^2))))*CKM[1, 1]*
    CKMC[1, 1])/(Pi^(2*d)*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-3 - d)*EL^6*gAl^2*gAu*gWdu*gWud*
    gWWA*((-2 + d)*s^2 + 4*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1]*
    (-4*(-1 + d)^2*mw^2*s + d*(-8*(-1 + d)*mw^4 + (3 - 8*d)*mw^2*s + s^2)*
      GaugeXi[Q] + d*mw^2*s*GaugeXi[Q]^2))/((-1 + d)*d*mw^4*Pi^d*s^3*
    GaugeXi[Q]), ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*
    (d*(2*Pi)^d*s^5 - 2^(1 + d)*Pi^d*s^3*((-1 + d)*s^2 + 2*s*t + 2*t^2) + 
     2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     2^(2 + d)*(-5 + 3*d)*mw^4*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2) - 
     2^(1 + d)*(-7 + 4*d)*mw^2*Pi^d*s^2*((-2 + d)*s^2 + 4*s*t + 4*t^2))*
    CKM[1, 1]*CKMC[1, 1])/((-1 + d)*mw^4*Pi^(2*d)*s^3), 
  (I*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*mw^2*(mw^2 + 2*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*CKM[1, 1]*CKMC[1, 1])/((2*Pi)^d*s^3), 0, 
  0, (I*2^(-3 - d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*((-2 + d)*s^2 + 4*s*t + 
     4*t^2)*CKM[1, 1]*CKMC[1, 1]*((4 - 13*d + 4*d^2)*mw^2 - d*s + 
     d*mw^2*GaugeXi[Q]))/((-1 + d)*d*mw^4*Pi^d*s^2), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*CKM[1, 1]*CKMC[1, 1]*
    (-(s*(d*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-s^2 + 2*s*t + 2*t^2) + 
        2^(1 + d)*mw^2*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2))) + 
     2^(2 + d)*mw^2*Pi^d*(2*mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]))/((-1 + d)*mw^4*Pi^(2*d)*s^2), 
  (I*2^(-3 - d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    CKM[1, 1]*CKMC[1, 1]*((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*s^2), (I*2^(-3 - 2*d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*
    CKM[1, 1]*CKMC[1, 1]*(-(d*(2*Pi)^d*s^4) + 2^(1 + d)*Pi^d*s^2*
      (s^2 - 2*s*t - 2*t^2) - 2^(1 + d)*(-3 + 2*d)*mw^2*Pi^d*s*
      ((-2 + d)*s^2 + 4*s*t + 4*t^2) - mw^4*(-3*d*(2*Pi)^d*s^2 + 
       2^(1 + d)*Pi^d*((-1 + 2*d)*s^2 + 2*s*t + 2*t^2)) + 
     2^(1 + d)*mw^2*Pi^d*(mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] + mw^4*(-(d*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
        (s^2 - 2*s*t - 2*t^2))*GaugeXi[Q]^2))/((-1 + d)*mw^4*Pi^(2*d)*s^2), 
  ((-I)*2^(-3 - d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*((-2 + d)*s^2 + 4*s*t + 
     4*t^2)*CKM[1, 1]*CKMC[1, 1]*(4*(-1 + d)^2*mw^2 - 
     d*(mw^2 + s)*GaugeXi[Q] + d*mw^2*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^4*Pi^d*s^2*GaugeXi[Q]), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu*gWdu*gWud*gWWA*CKM[1, 1]*CKMC[1, 1]*
    (d*(2*Pi)^d*s^4 + 2^(1 + d)*Pi^d*s^2*(-s^2 + 2*s*t + 2*t^2) + 
     2^(1 + d)*(-3 + 2*d)*mw^2*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mw^4*(d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-s^2 + 2*s*t + 2*t^2)) - 
     2^(1 + d)*mw^2*Pi^d*(mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] + mw^4*(-3*d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
        ((-1 + 2*d)*s^2 + 2*s*t + 2*t^2))*GaugeXi[Q]^2))/
   ((-1 + d)*mw^4*Pi^(2*d)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, ((-I)*4^(-2 - 3*d)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*CKM[1, 1]*CKMC[1, 1]*
    (2^(2 + 5*d)*(-1 + d)^2*mw^2*Pi^(5*d)*s*
      (-(gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
     (2^(3 + 5*d)*d^4*(gZlL - gZlR)*mw^4*Pi^(5*d)*s*(s + 2*t) - 
       32^(1 + d)*mw^2*Pi^(5*d)*s*(gZlR*(-2*s^2 - 2*s*t + t^2) + 
         gZlL*(s^2 + 4*s*t + t^2)) - d^3*(2*Pi)^(5*d)*s*
        (gZlL*(-13*mw^2*s*(s + 2*t) + s^2*(s + 2*t) + 8*mw^4*(5*s + 12*t)) - 
         gZlR*(-13*mw^2*s*(s + 2*t) + s^2*(s + 2*t) + 8*mw^4*(7*s + 12*t))) + 
       2^(1 + 5*d)*d^2*Pi^(5*d)*(gZlR*(-(s^3*(3*s + 5*t)) + 
           mw^2*s^2*(43*s + 73*t) - 8*mw^4*(7*s^2 + 9*s*t - 2*t^2)) + 
         gZlL*(s^3*(2*s + 5*t) - mw^2*s^2*(30*s + 73*t) + 
           8*mw^4*(4*s^2 + 13*s*t + 2*t^2))) - 2^(2 + 5*d)*d*Pi^(5*d)*
        (gZlR*(mw^2*s*(38*s^2 + 46*s*t - 13*t^2) - 
           8*mw^4*(2*s^2 + 2*s*t - t^2) + s^2*(-2*s^2 - 2*s*t + t^2)) + 
         gZlL*(8*mw^4*(s^2 + 4*s*t + t^2) + s^2*(s^2 + 4*s*t + t^2) - 
           mw^2*s*(21*s^2 + 72*s*t + 13*t^2))))*GaugeXi[Q] + 
     (-(2^(2 + 5*d)*d^4*(gZlL - gZlR)*mw^2*Pi^(5*d)*s*(4*mw^2 + 3*s)*
         (s + 2*t)) + 2^(4 + 5*d)*mw^2*Pi^(5*d)*s*
        (gZlR*(-2*s^2 - 2*s*t + t^2) + gZlL*(s^2 + 4*s*t + t^2)) + 
       d^3*(2*Pi)^(5*d)*s*(gZlL*(2*s^2*(s + 2*t) + 16*mw^4*(5*s + 12*t) + 
           3*mw^2*s*(15*s + 38*t)) - gZlR*(2*s^2*(s + 2*t) + 
           16*mw^4*(7*s + 12*t) + 3*mw^2*s*(23*s + 38*t))) + 
       2^(2 + 5*d)*d*Pi^(5*d)*(gZlR*(mw^2*s*(12*s^2 + 16*s*t - 3*t^2) - 
           16*mw^4*(2*s^2 + 2*s*t - t^2) + 2*s^2*(-2*s^2 - 2*s*t + t^2)) + 
         gZlL*(16*mw^4*(s^2 + 4*s*t + t^2) + 2*s^2*(s^2 + 4*s*t + t^2) - 
           mw^2*s*(7*s^2 + 22*s*t + 3*t^2))) - 2^(1 + 5*d)*d^2*Pi^(5*d)*
        (-(gZlR*(2*s^3*(3*s + 5*t) + mw^2*s*(37*s^2 + 29*s*t - 24*t^2) + 
            16*mw^4*(7*s^2 + 9*s*t - 2*t^2))) + 
         gZlL*(2*s^3*(2*s + 5*t) + 16*mw^4*(4*s^2 + 13*s*t + 2*t^2) + 
           mw^2*s*(16*s^2 + 77*s*t + 24*t^2))))*GaugeXi[Q]^2 + 
     d*(2*Pi)^(5*d)*(gZlR*(-8*(-1 + d)*mw^4 + s^2 + mw^2*(s - 8*d*s))*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlL*(8*(-1 + d)*mw^4 + (-1 + 8*d)*mw^2*s - s^2)*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^3 - 
     d*mw^2*(2*Pi)^(5*d)*s*(-(gZlR*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^4))/
   ((-1 + d)*d*mw^4*Pi^(6*d)*s^2*(-mz^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]), 
  ((I/16)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*CKM[1, 1]*CKMC[1, 1]*
    ((2^(1 - d)*(gZlL + gZlR)*(2*mw^2 - s)*s^2*(4*(-1 + d)*mw^4 - 
        4*d*mw^2*s + d*s^2)*(-1 + GaugeXi[Q])^2)/Pi^d + 
     (2^(2 - d)*(-1 + d)*(gZlL + gZlR)*mw^4*(2*mw^2 - s)*
       ((-2 + d)*s^2 - 4*s*t - 4*(-1 + d)*t^2)*(-1 + GaugeXi[Q])^2)/Pi^d + 
     ((2*mw^2 - s)*s*((-4 + d)*gZlL*s - (-2 + d)*gZlR*s - 2*gZlL*t - 
        2*gZlR*t)*(4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
       (-1 + GaugeXi[Q])^2)/(2*Pi)^d - 4*(1 - d)*mw^4*(s + 2*t)*
      (-((2^(2 - d)*(-2 + d)*(gZlL + gZlR)*mw^2*s)/Pi^d) - 
       (2^(2 - d)*(-2 + d)*(gZlL + gZlR)*s*t)/Pi^d + 
       ((2 - d)*mw^2*((-2 + d)*gZlL*s - (-4 + d)*gZlR*s - 2*gZlL*t - 
          2*gZlR*t))/(2*Pi)^d + ((-6 + d)*s*((-2 + d)*gZlL*s - 
          (-4 + d)*gZlR*s + 2*gZlL*t + 2*gZlR*t))/(2*Pi)^d + 
       ((2 - d)*mw^2*((-6 + d)*gZlL*s - 2*gZlL*t - gZlR*(d*s + 2*t)))/
        (2*Pi)^d)*(-1 + GaugeXi[Q])^2 - 
     (2^(1 - 4*d)*(1 - d)*s*(gZlR*(-((-4 + d)*(2*Pi)^(3*d)*s^3*t) + 
          2^(2 + 3*d)*(-3 + d)*mw^6*Pi^(3*d)*((-4 + d)*s + 2*t) + 
          2^(1 + 3*d)*mw^4*Pi^(3*d)*s*(3*(12 - 7*d + d^2)*s + 
            2*(47 - 27*d + 4*d^2)*t) - 2^(1 + 3*d)*mw^2*Pi^(3*d)*s*
           (2*(8 - 6*d + d^2)*s^2 + (28 - 23*d + 4*d^2)*s*t - 8*t^2)) - 
        gZlL*(2^(2 + 3*d)*(-3 + d)*mw^6*Pi^(3*d)*((-2 + d)*s - 2*t) - 
          (-2 + d)*(2*Pi)^(3*d)*s^3*t + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*
           (3*(6 - 5*d + d^2)*s + 2*(37 - 25*d + 4*d^2)*t) - 
          2^(1 + 3*d)*mw^2*Pi^(3*d)*s*(2*(-2 + d)^2*s^2 + (38 - 23*d + 4*d^2)*
             s*t + 8*t^2)))*(-1 + GaugeXi[Q])^2)/Pi^(4*d) + 
     ((-1 + d)*(2*mw^2 - s)*s*(gZlR*(8*mw^4*((-3 + d)*s + t) - 
          4*mw^2*s*((-4 + d)*s + 2*t) + s^2*((-4 + d)*s + 2*t)) + 
        gZlL*(4*mw^2*s*((-2 + d)*s - 2*t) + 8*mw^4*t + 
          s^2*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*
         GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2))/(2*Pi)^(4*d) + 
     ((-1 + d)*(2*mw^2 - s)*s*(gZlL*(4*mw^2*s*((-2 + d)*s - 2*t) + 
          s^2*(-((-2 + d)*s) + 2*t) + 4*mw^4*((10 - 7*d + d^2)*s - 
            2*(-3 + d)*t)) + gZlR*(-4*mw^2*s*((-4 + d)*s + 2*t) + 
          s^2*((-4 + d)*s + 2*t) - 4*mw^4*((8 - 5*d + d^2)*s + 
            2*(-3 + d)*t)))*((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
        (2*Pi)^(3*d)*GaugeXi[Q]^2))/(2*Pi)^(4*d)))/
   ((-1 + d)*mw^4*(mz^2 - s)*(s - s*GaugeXi[Q])^2), 
  (I*2^(-1 - 2*d)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*mw^2*
    (-(2^(1 + d)*gZlR*Pi^d*s*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2)) + 2^(1 + d)*gZlL*Pi^d*s*((-2 + d)^2*s^2 + 
       2*(8 - 5*d + d^2)*s*t + 4*t^2) + gZlR*mw^2*(-(d^2*(2*Pi)^d*s^2) + 
       2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlL*mw^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
         (8 - 5*d + d^2)*s*t + 2*t^2)))*CKM[1, 1]*CKMC[1, 1])/
   (Pi^(2*d)*(mz^2 - s)*s^2), 0, 0, ((-I)*2^(-4 - d)*EL^6*gAl*gAu*gWdu*gWud*
    gWWZ*(-(gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
    CKMC[1, 1]*((-4 + 13*d - 4*d^2)*mw^2 + d*s - d*mw^2*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s), 
  ((I/16)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*CKM[1, 1]*CKMC[1, 1]*
    (-((2^(1 - d)*(gZlL + gZlR)*s*(2*mw^2 + s)*(-1 + GaugeXi[Q])^2*
        (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2))/
       Pi^d) - ((2*mw^2 + s)*((-4 + d)*gZlL*s - (-2 + d)*gZlR*s - 2*gZlL*t - 
        2*gZlR*t)*(-1 + GaugeXi[Q])^2*(s*(d*s + 2*t) - 
        4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2))/
      (2*Pi)^d + ((1 - d)*(s - 2*mw^2*GaugeXi[Q])*
       (s*(-(2^(1 + d)*gZlL*mw^2*Pi^d*((-2 + d)*s - 2*t)) + 
          2^(1 + d)*gZlR*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
          gZlR*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZlL*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        2*(-(gZlR*(-3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
             2^(1 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZlL*(2^(1 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) - 
            3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
         GaugeXi[Q] + (gZlR*(2^(3 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
          gZlL*(-(2^(3 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
            3*2^(1 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^2 + 
        2^(1 + d)*mw^2*Pi^d*(2*mw^2 + s)*((-2 + d)*gZlL*s - (-4 + d)*gZlR*s - 
          2*gZlL*t - 2*gZlR*t)*GaugeXi[Q]^3))/(2*Pi)^(2*d) - 
     (2^(1 - 3*d)*(1 - d)*(2*mw^2 + s)*(((-2 + d)*gZlL - (-4 + d)*gZlR)*
         (2*Pi)^(2*d)*s^2*t - 2^(1 + 2*d)*((-2 + d)*gZlL - (-4 + d)*gZlR)*
         Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] - (2*Pi)^(2*d)*
         (gZlL*(2*mw^4*((-2 + d)*s - 2*t) - 8*(-2 + d)*mw^2*s*t - 
            (-2 + d)*s^2*t) + gZlR*(8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 
            2*mw^4*((-4 + d)*s + 2*t)))*GaugeXi[Q]^2 + 
        4^(1 + d)*mw^2*Pi^(2*d)*((-4 + d)*gZlR*s*t - 
          gZlR*mw^2*((-4 + d)*s + 2*t) + gZlL*(mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*s*t))*GaugeXi[Q]^3 - 2^(1 + 2*d)*mw^4*Pi^(2*d)*
         ((-2 + d)*gZlL*s - (-4 + d)*gZlR*s - 2*gZlL*t - 2*gZlR*t)*
         GaugeXi[Q]^4))/Pi^(3*d) + (1 - d)*(s - 2*mw^2*GaugeXi[Q])*
      ((2^(3 - d)*(gZlL + gZlR)*mw^2*s*t*(-1 + GaugeXi[Q])^2)/Pi^d + 
       (2^(2 - d)*(gZlL + gZlR)*s^2*t*(-1 + GaugeXi[Q])^2)/Pi^d + 
       (2^(3 - d)*(gZlL + gZlR)*mw^4*s*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
       (2^(2 - d)*(gZlL + gZlR)*mw^2*s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/
        Pi^d + (mw^4*((-2 + d)*gZlL*s - (-4 + d)*gZlR*s - 2*gZlL*t - 
          2*gZlR*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/(2*Pi)^d + 
       (2^(1 - d)*mw^4*((-4 + d)*gZlL*s - (-2 + d)*gZlR*s - 2*gZlL*t - 
          2*gZlR*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
       (mw^4*((-6 + d)*gZlL*s - 2*gZlL*t - gZlR*(d*s + 2*t))*
         (-1 + GaugeXi[Q])^2*GaugeXi[Q])/(2*Pi)^d - 
       (mw^2*s*(-1 + GaugeXi[Q])^2*(gZlR*(-((-4 + d)*s) + 2*t) + 
          gZlL*((-2 + d)*s + 2*t) + (-((-2 + d)*gZlL*s) + (-4 + d)*gZlR*s + 
            2*gZlL*t + 2*gZlR*t)*GaugeXi[Q]))/(2*Pi)^d - 
       (s*(mw - mw*GaugeXi[Q])^2*((-2 + d)*gZlL*s - (-4 + d)*gZlR*s + 
          2*gZlL*t + 2*gZlR*t + (6*gZlL*s - d*gZlL*s + d*gZlR*s + 2*gZlL*t + 
            2*gZlR*t)*GaugeXi[Q]))/(2*Pi)^d - 
       (s^2*(gZlL*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
          gZlR*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)) + 
          2^(1 + d)*Pi^d*(-((-2 + d)*gZlL*s) + (-4 + d)*gZlR*s - 2*gZlL*t - 
            2*gZlR*t)*GaugeXi[Q] + (d*gZlL*(2*Pi)^d*s - d*gZlR*(2*Pi)^d*s + 
            2^(1 + d)*gZlL*Pi^d*(-s + t) + 2^(1 + d)*gZlR*Pi^d*(2*s + t))*
           GaugeXi[Q]^2))/(2*Pi)^(2*d))))/((-1 + d)*mw^4*(mz^2 - s)*s*
    (-1 + GaugeXi[Q])^2), (I*2^(-4 - d)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*
    (-(gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
     gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
    CKMC[1, 1]*((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s), 
  ((-I)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*CKM[1, 1]*CKMC[1, 1]*
    (-(2^(1 + d)*(gZlL + gZlR)*Pi^d*(s - s*GaugeXi[Q])^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2)) - (2*Pi)^d*((-4 + d)*gZlL*s - (-2 + d)*gZlR*s - 
       2*gZlL*t - 2*gZlR*t)*(-1 + GaugeXi[Q])^2*((mw^2 - s)^2*(d*s + 2*t) + 
       2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
       mw^4*(d*s + 2*t)*GaugeXi[Q]^2) - 
     (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
      (gZlL*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - t)) + 
       gZlR*mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t)) + 
       gZlR*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
       gZlL*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
       (2^(1 + d)*gZlL*Pi^d*s*((-2 + d)*s - 2*t) - 2^(1 + d)*gZlR*Pi^d*s*
          ((-4 + d)*s + 2*t) + gZlL*mw^2*(11*d*(2*Pi)^d*s + 
           2^(1 + d)*Pi^d*(s - 6*d*s + t)) + gZlR*mw^2*(-11*d*(2*Pi)^d*s + 
           2^(1 + d)*Pi^d*((-2 + 6*d)*s + t)))*GaugeXi[Q] + 
       (-(gZlR*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
            mw^2*(-11*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*s + 5*d*s - t)))) + 
         gZlL*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
           mw^2*(-11*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 5*d*s + t))))*
        GaugeXi[Q]^2 - mw^2*(-(d*gZlL*(2*Pi)^d*s) + d*gZlR*(2*Pi)^d*s + 
         2^(1 + d)*gZlR*Pi^d*(-2*s + t) + 2^(1 + d)*gZlL*Pi^d*(s + t))*
        GaugeXi[Q]^3) + (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
      (gZlR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
       gZlL*s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
       gZlR*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t)) + 
       gZlL*mw^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - d*s + t)) + 
       (gZlR*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         2^(1 + d)*gZlL*Pi^d*s*((-2 + d)*s - 2*t) + 2^(1 + d)*gZlR*Pi^d*s*
          ((-4 + d)*s + 2*t) - gZlL*mw^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(s + t)))*GaugeXi[Q] + 
       (gZlL*(mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - t)) + 
           s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))) - 
         gZlR*(s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t))))*
        GaugeXi[Q]^2 + mw^2*(-(d*gZlL*(2*Pi)^d*s) + d*gZlR*(2*Pi)^d*s + 
         2^(1 + d)*gZlR*Pi^d*(-2*s + t) + 2^(1 + d)*gZlL*Pi^d*(s + t))*
        GaugeXi[Q]^3) - 2*(1 - d)*s*
      (gZlR*(mw^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*t + 
         (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
          ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
       gZlL*(mw^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*t + 
         (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
          ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
       2*(gZlR*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
           mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
           mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 2*
                (5 + d^2)*s*t - 4*t^2))) + 
         gZlL*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
           mw^4*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + (-3 + d)*t)) + 
           mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + 
               (17 + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q] + 
       (-(gZlR*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^d*
             (2*(-4 + d)*s + (-8 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
         gZlL*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^d*
            (2*(-2 + d)*s + (-10 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
            ((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
        GaugeXi[Q]^2 - 2^(1 + d)*mw^2*Pi^d*
        (-(gZlR*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
         gZlL*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
        GaugeXi[Q]^3 - mw^4*(2^(1 + d)*gZlL*Pi^d - 2^(2 + d)*gZlR*Pi^d - 
         d*gZlL*(2*Pi)^d + d*gZlR*(2*Pi)^d)*t*GaugeXi[Q]^4)))/
   (2^(2*(2 + d))*(-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s*(-1 + GaugeXi[Q])^2), 
  (I*2^(-4 - d)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*
    (gZlR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
    CKMC[1, 1]*(4*(-1 + d)^2*mw^2 - d*(mw^2 + s)*GaugeXi[Q] + 
     d*mw^2*GaugeXi[Q]^2))/((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s*GaugeXi[Q]), 
  ((-I)*EL^6*gAl*gAu*gWdu*gWud*gWWZ*CKM[1, 1]*CKMC[1, 1]*
    (-(2^(1 + d)*(gZlL + gZlR)*Pi^d*(s - s*GaugeXi[Q])^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2)) - (2*Pi)^d*((-4 + d)*gZlL*s - (-2 + d)*gZlR*s - 
       2*gZlL*t - 2*gZlR*t)*(-1 + GaugeXi[Q])^2*((mw^2 - s)^2*(d*s + 2*t) + 
       2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
       mw^4*(d*s + 2*t)*GaugeXi[Q]^2) - 
     (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
      (gZlL*(mw^2*(-15*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + 8*d*s - t)) + 
         s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
       gZlR*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
         mw^2*(-13*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 7*d*s + t))) + 
       (2^(1 + d)*gZlL*Pi^d*s*((-2 + d)*s - 2*t) - 2^(1 + d)*gZlR*Pi^d*s*
          ((-4 + d)*s + 2*t) + gZlR*mw^2*(-3*d*(2*Pi)^d*s + 
           2^(1 + d)*Pi^d*(2*(-1 + d)*s + t)) + gZlL*mw^2*
          (9*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 5*d*s + t)))*GaugeXi[Q] + 
       (-(gZlR*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
            mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - t)))) + 
         gZlL*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
           mw^2*(-9*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 4*d*s + t))))*
        GaugeXi[Q]^2 - mw^2*(-(d*gZlL*(2*Pi)^d*s) + d*gZlR*(2*Pi)^d*s + 
         2^(1 + d)*gZlR*Pi^d*(-2*s + t) + 2^(1 + d)*gZlL*Pi^d*(s + t))*
        GaugeXi[Q]^3) + (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
      (gZlR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
       gZlL*s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
       gZlR*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t)) + 
       gZlL*mw^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - d*s + t)) + 
       (gZlR*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
         2^(1 + d)*gZlL*Pi^d*s*((-2 + d)*s - 2*t) + 2^(1 + d)*gZlR*Pi^d*s*
          ((-4 + d)*s + 2*t) - gZlL*mw^2*(-(d*(2*Pi)^d*s) + 
           2^(1 + d)*Pi^d*(s + t)))*GaugeXi[Q] + 
       (gZlL*(mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - t)) + 
           s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))) - 
         gZlR*(s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t))))*
        GaugeXi[Q]^2 + mw^2*(-(d*gZlL*(2*Pi)^d*s) + d*gZlR*(2*Pi)^d*s + 
         2^(1 + d)*gZlR*Pi^d*(-2*s + t) + 2^(1 + d)*gZlL*Pi^d*(s + t))*
        GaugeXi[Q]^3) - 2*(1 - d)*s*
      (gZlR*(mw^4*(2^(1 + d)*(2 + 3*d)*Pi^d - 7*d*(2*Pi)^d)*t + 
         (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
          ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
       gZlL*(mw^4*(2^(1 + d)*(1 + 3*d)*Pi^d - 7*d*(2*Pi)^d)*t + 
         (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
          ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
       2*(gZlR*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
           mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
           mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 2*
                (5 + d^2)*s*t - 4*t^2))) + 
         gZlL*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
           mw^4*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + (-3 + d)*t)) + 
           mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + 
               (17 + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q] + 
       (-(gZlR*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^d*
             (2*(-4 + d)*s + (-8 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
             ((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
         gZlL*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^d*
            (2*(-2 + d)*s + (-10 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
            ((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
        GaugeXi[Q]^2 - 2^(1 + d)*mw^2*Pi^d*
        (-(gZlR*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
         gZlL*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
        GaugeXi[Q]^3 - mw^4*(2^(1 + d)*gZlL*Pi^d - 2^(2 + d)*gZlR*Pi^d - 
         d*gZlL*(2*Pi)^d + d*gZlR*(2*Pi)^d)*t*GaugeXi[Q]^4)))/
   (2^(2*(2 + d))*(-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s*(-1 + GaugeXi[Q])^2), 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*EL^6*gAl^2*gAu^2*gFFAA*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((2*Pi)^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-1 - d)*EL^6*gAl*gAu^2*gFFAZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu*gFFAZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(Pi^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-3 - 2*d)*EL^6*gAl*gAu*gHHZZ*
    (gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   (Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-3 - 2*d)*EL^6*gAl*gAu*gXXZZ*
    (gZlL*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   (Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, (I*EL^6*gAl*gAu*gFFZZ*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   (2^(2*(1 + d))*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*2^(1 - d)*EL^6*gAl^2*gAu^2*ggmgmAA*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   (Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, ((-I)*2^(1 - d)*EL^6*gAl^2*gAu^2*ggpgpAA*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/(Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*EL^6*gAl*gAu^2*ggmgmAZ*(gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((2*Pi)^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (I*EL^6*gAl^2*gAu*ggmgmAZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((2*Pi)^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*EL^6*gAl*gAu^2*ggpgpAZ*(gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((2*Pi)^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*EL^6*gAl^2*gAu*ggpgpAZ*(gZuL + gZuR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((2*Pi)^d*(mz^2 - s)*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-1 - d)*EL^6*gAl*gAu*ggmgmZZ*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-1 - d)*EL^6*gAl*gAu*ggpgpZZ*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   (Pi^d*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, ((-I)*2^(1 - d)*(-1 + d)*EL^6*gAl^2*gAu^2*gWWAA*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(1 + (-1 + d)*GaugeXi[Q]))/
   (d*Pi^d*s^3*GaugeXi[Q]), 0, 0, 0, 0, 
  ((-I)*2^(1 - d)*EL^6*gAl^2*gAu^2*gWWAA*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    (1 + (-1 + d)*GaugeXi[Q]))/(d*Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*(-1 + d)*EL^6*gAl*gAu^2*gWWAZ*
    (gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*(1 + (-1 + d)*GaugeXi[Q]))/
   (d*(2*Pi)^d*s^2*(-mz^2 + s)*GaugeXi[Q]), 0, 0, 0, 0, 
  ((-I)*EL^6*gAl*gAu^2*gWWAZ*(gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    (1 + (-1 + d)*GaugeXi[Q]))/(d*(2*Pi)^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*(-1 + d)*EL^6*gAl^2*gAu*gWWAZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(1 + (-1 + d)*GaugeXi[Q]))/
   (d*(2*Pi)^d*s^2*(-mz^2 + s)*GaugeXi[Q]), 0, 0, 0, 0, 
  ((-I)*EL^6*gAl^2*gAu*gWWAZ*(gZuL + gZuR)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    (1 + (-1 + d)*GaugeXi[Q]))/(d*(2*Pi)^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*2^(-1 - d)*(-1 + d)*EL^6*gAl*gAu*gWWZZ*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (1 + (-1 + d)*GaugeXi[Q]))/(d*Pi^d*(mz^2 - s)^2*s*GaugeXi[Q]), 0, 0, 0, 
  0, ((-I)*2^(-1 - d)*EL^6*gAl*gAu*gWWZZ*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (1 + (-1 + d)*GaugeXi[Q]))/(d*Pi^d*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {(I*2^(1 - d)*(-2 + d)*EL^6*gAl^4*gAu^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(1 - d)*(-2 + d)*EL^6*gAl^4*gAu^2*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*2^(2 - d)*(-2 + d)*EL^6*gAl^4*gAu^2*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^3), (I*2^(1 - d)*EL^6*gAl^4*gAu^2*(4*ml^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {((3*I)*2^(1 - d)*(-2 + d)*EL^6*gAl^2*gAu^4*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*2^(2 - d)*(-2 + d)*EL^6*gAl^2*gAu^4*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^3), ((3*I)*2^(1 - d)*EL^6*gAl^2*gAu^4*
    (4*mc^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*2^(2 - d)*(-2 + d)*EL^6*gAl^2*gAu^4*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^3), ((3*I)*2^(1 - d)*EL^6*gAl^2*gAu^4*
    (4*mt^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^3), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((3*I)*2^(1 - d)*(-2 + d)*EL^6*gAd^2*gAl^2*gAu^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*2^(2 - d)*(-2 + d)*EL^6*gAd^2*gAl^2*gAu^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 
  ((3*I)*2^(1 - d)*EL^6*gAd^2*gAl^2*gAu^2*(4*ms^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*2^(2 - d)*(-2 + d)*EL^6*gAd^2*gAl^2*gAu^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 
  ((3*I)*2^(1 - d)*EL^6*gAd^2*gAl^2*gAu^2*(4*mb^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 0, 0, 0, 0}, 
 {((-I)*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*
    (-(2^(1 + d)*(-2 + d)*gZlL*gZlR*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2)) + 
     gZlL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2)) + 
     gZlR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2))))/((-1 + d)*Pi^(2*d)*s*
    (-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {((-I)*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*
    (-(2^(1 + d)*(-2 + d)*gZlL*gZlR*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2)) + 
     gZlL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2)) + 
     gZlR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2))))/((-1 + d)*Pi^(2*d)*s*
    (-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*(-2 + d)*EL^6*gAl^2*gAu^2*(gZlL + gZlR)^2*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZlL + gZlR)^2*(4*ml^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-1 - 2*d)*EL^6*gAl^3*gAu*
    (gZlL*(7*d^2*gZuL*(2*Pi)^d*s^2 - 5*d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((2 - 2*d - 3*d^2)*s^2 + 2*(-2 + d)*s*t + 
         2*(-2 + d)*t^2) + 2^(1 + d)*gZuR*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
         2*(-2 + d)*s*t + 2*(-2 + d)*t^2)) + 
     gZlR*(7*d^2*gZuR*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*Pi^d*
        ((-2 + 2*d + 3*d^2)*s^2 - 2*(-2 + d)*s*t - 2*(-2 + d)*t^2) + 
       gZuL*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
           2*(-2 + d)*s*t + 2*(-2 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-1 - 2*d)*EL^6*gAl^3*gAu*
    (gZlL*(7*d^2*gZuL*(2*Pi)^d*s^2 - 5*d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((2 - 2*d - 3*d^2)*s^2 + 2*(-2 + d)*s*t + 
         2*(-2 + d)*t^2) + 2^(1 + d)*gZuR*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
         2*(-2 + d)*s*t + 2*(-2 + d)*t^2)) + 
     gZlR*(7*d^2*gZuR*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*Pi^d*
        ((-2 + 2*d + 3*d^2)*s^2 - 2*(-2 + d)*s*t - 2*(-2 + d)*t^2) + 
       gZuL*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
           2*(-2 + d)*s*t + 2*(-2 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-I)*(-2 + d)*EL^6*gAl^3*gAu*(gZlL + gZlR)*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl^3*gAu*(gZlL + gZlR)*(gZuL + gZuR)*
    (4*ml^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((-3*I)*2^(-1 - 2*d)*EL^6*gAl*gAu^3*(gZlL + gZlR)*(gZuL + gZuR)*
    (-(d^2*(2*Pi)^d*s^2) + 2^(2 + d)*Pi^d*((-1 + d)*s^2 - (-2 + d)*s*t - 
       (-2 + d)*t^2)))/((-1 + d)*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAl*gAu^3*(gZlL + gZlR)*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAl*gAu^3*(gZlL + gZlR)*(gZuL + gZuR)*
    (4*mc^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAl*gAu^3*(gZlL + gZlR)*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAl*gAu^3*(gZlL + gZlR)*(gZuL + gZuR)*
    (4*mt^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((-3*I)*2^(-1 - 2*d)*EL^6*gAl^2*gAu^2*
    (-(2^(1 + d)*(-2 + d)*gZuL*gZuR*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2)) + 
     gZuL^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2)) + 
     gZuR^2*(-7*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + 3*d^2)*s^2 - 
         2*(-2 + d)*s*t - 2*(-2 + d)*t^2))))/((-1 + d)*Pi^(2*d)*s*
    (-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAl^2*gAu^2*(gZuL + gZuR)^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZuL + gZuR)^2*(4*mc^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAl^2*gAu^2*(gZuL + gZuR)^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*(gZuL + gZuR)^2*(4*mt^2 + (-2 + d)*s)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 
  0, 0, 0, 0, 0}, {((-3*I)*2^(-1 - 2*d)*EL^6*gAd*gAl*gAu^2*(gZdL + gZdR)*
    (gZlL + gZlR)*(-(d^2*(2*Pi)^d*s^2) + 2^(2 + d)*Pi^d*
      ((-1 + d)*s^2 - (-2 + d)*s*t - (-2 + d)*t^2)))/
   ((-1 + d)*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, ((-3*I)*(-2 + d)*EL^6*gAd*gAl*gAu^2*(gZdL + gZdR)*
    (gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAd*gAl*gAu^2*(gZdL + gZdR)*(gZlL + gZlR)*
    (4*ms^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAd*gAl*gAu^2*(gZdL + gZdR)*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAd*gAl*gAu^2*(gZdL + gZdR)*(gZlL + gZlR)*
    (4*mb^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0}, 
 {((3*I)*2^(-1 - 2*d)*EL^6*gAd*gAl^2*gAu*
    (gZdL*(7*d^2*gZuL*(2*Pi)^d*s^2 - 5*d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((2 - 2*d - 3*d^2)*s^2 + 2*(-2 + d)*s*t + 
         2*(-2 + d)*t^2) + 2^(1 + d)*gZuR*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
         2*(-2 + d)*s*t + 2*(-2 + d)*t^2)) + 
     gZdR*(7*d^2*gZuR*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*Pi^d*
        ((-2 + 2*d + 3*d^2)*s^2 - 2*(-2 + d)*s*t - 2*(-2 + d)*t^2) + 
       gZuL*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((2 - 2*d + 3*d^2)*s^2 + 
           2*(-2 + d)*s*t + 2*(-2 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*s*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, ((-3*I)*(-2 + d)*EL^6*gAd*gAl^2*gAu*(gZdL + gZdR)*
    (gZuL + gZuR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*(gZdL + gZdR)*(gZuL + gZuR)*
    (4*ms^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((-3*I)*(-2 + d)*EL^6*gAd*gAl^2*gAu*(gZdL + gZdR)*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((3*I)*2^(-1 - d)*EL^6*gAd*gAl^2*gAu*(gZdL + gZdR)*(gZuL + gZuR)*
    (4*mb^2 + (-2 + d)*s)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0}, 
 {(I*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*gZNL^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*gZNL^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*gZNL^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*(gZlL^2 + gZlR^2)*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(I*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*(gZlL^2 + gZlR^2)*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*2^(-1 - d)*(-2 + d)*EL^6*gAl*gAu*(gZlL^2 + gZlR^2)*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), 
  ((-I)*4^(-1 - d)*EL^6*gAl*gAu*
    (gZlL^3*(-(gZuR*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*ml^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZuL*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*ml^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2))) + 
     gZlR^3*(-(gZuL*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*ml^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*ml^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2))) - gZlL^2*gZlR*
      (gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
          ((-4 + 6*d - 3*d^2 + d^3)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2) - 2^(1 + d)*ml^2*Pi^d*
          ((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 2*(-32 + 41*d - 20*d^2 + 
             3*d^3)*s*t - 4*(1 + d)*t^2)) + gZuL*(-(d^3*(2*Pi)^d*s^3) + 
         2^(1 + d)*Pi^d*s*(2*(4 - 5*d + 2*d^2)*s^2 - 
           (-8 + 14*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2) + 
         2^(1 + d)*ml^2*Pi^d*((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 
           2*(-28 + 45*d - 20*d^2 + 3*d^3)*s*t + 4*(1 + d)*t^2))) + 
     gZlL*gZlR^2*(gZuL*(d^3*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
          ((-4 + 6*d - 3*d^2 + d^3)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2) + 2^(1 + d)*ml^2*Pi^d*
          ((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 2*(-32 + 41*d - 20*d^2 + 
             3*d^3)*s*t - 4*(1 + d)*t^2)) - gZuR*(-(d^3*(2*Pi)^d*s^3) + 
         2^(1 + d)*Pi^d*s*(2*(4 - 5*d + 2*d^2)*s^2 - 
           (-8 + 14*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2) + 
         2^(1 + d)*ml^2*Pi^d*((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 
           2*(-28 + 45*d - 20*d^2 + 3*d^3)*s*t + 4*(1 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((3*I)*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*(gZuL^2 + gZuR^2)*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((3*I)*2^(-1 - d)*(-2 + d)*EL^6*gAl*gAu*(gZuL^2 + gZuR^2)*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), 
  ((-3*I)*4^(-1 - d)*EL^6*gAl*gAu*
    (gZlL*(gZuL^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mc^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZuR^3*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*mc^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZuL*gZuR^2*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2) + 
         2^(1 + d)*mc^2*Pi^d*((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 
           2*(-32 + 41*d - 20*d^2 + 3*d^3)*s*t - 4*(1 + d)*t^2)) - 
       gZuL^2*gZuR*(d^3*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
          ((-8 + 10*d - 4*d^2 + d^3)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
           2*(-2 + d)*t^2) + 2^(1 + d)*mc^2*Pi^d*
          ((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 2*(-28 + 45*d - 20*d^2 + 
             3*d^3)*s*t + 4*(1 + d)*t^2))) - 
     gZlR*(-(gZuR^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mc^2*Pi^d*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
          2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - 
            (-16 + 18*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZuL^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mc^2*Pi^d*
          ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
         2^(1 + d)*Pi^d*s*(2*(4 - 5*d + 2*d^2)*s^2 - 
           (-8 + 14*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2)) + 
       gZuL^2*gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
          ((-4 + 6*d - 3*d^2 + d^3)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2) - 2^(1 + d)*mc^2*Pi^d*
          ((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 2*(-32 + 41*d - 20*d^2 + 
             3*d^3)*s*t - 4*(1 + d)*t^2)) + gZuL*gZuR^2*
        (d^3*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
           (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2) + 
         2^(1 + d)*mc^2*Pi^d*((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 
           2*(-28 + 45*d - 20*d^2 + 3*d^3)*s*t + 4*(1 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((3*I)*2^(-1 - d)*(-2 + d)*EL^6*gAl*gAu*(gZuL^2 + gZuR^2)*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), 
  ((-3*I)*4^(-1 - d)*EL^6*gAl*gAu*
    (gZlL*(gZuL^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mt^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZuR^3*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*mt^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZuL*gZuR^2*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2) + 
         2^(1 + d)*mt^2*Pi^d*((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 
           2*(-32 + 41*d - 20*d^2 + 3*d^3)*s*t - 4*(1 + d)*t^2)) - 
       gZuL^2*gZuR*(d^3*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*
          ((-8 + 10*d - 4*d^2 + d^3)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
           2*(-2 + d)*t^2) + 2^(1 + d)*mt^2*Pi^d*
          ((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 2*(-28 + 45*d - 20*d^2 + 
             3*d^3)*s*t + 4*(1 + d)*t^2))) - 
     gZlR*(-(gZuR^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mt^2*Pi^d*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
          2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - 
            (-16 + 18*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZuL^3*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mt^2*Pi^d*
          ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
         2^(1 + d)*Pi^d*s*(2*(4 - 5*d + 2*d^2)*s^2 - 
           (-8 + 14*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2)) + 
       gZuL^2*gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
          ((-4 + 6*d - 3*d^2 + d^3)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2) - 2^(1 + d)*mt^2*Pi^d*
          ((-28 + 44*d - 21*d^2 + 3*d^3)*s^2 + 2*(-32 + 41*d - 20*d^2 + 
             3*d^3)*s*t - 4*(1 + d)*t^2)) + gZuL*gZuR^2*
        (d^3*(2*Pi)^d*s^3 - 2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
           (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2) + 
         2^(1 + d)*mt^2*Pi^d*((-32 + 42*d - 19*d^2 + 3*d^3)*s^2 + 
           2*(-28 + 45*d - 20*d^2 + 3*d^3)*s*t + 4*(1 + d)*t^2)))))/
   ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {((3*I)*2^(-2 - d)*(-2 + d)*EL^6*gAl*gAu*(gZdL^2 + gZdR^2)*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, ((3*I)*2^(-1 - d)*(-2 + d)*EL^6*gAl*gAu*(gZdL^2 + gZdR^2)*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), 
  ((-3*I)*4^(-1 - d)*EL^6*gAl*gAu*
    (gZdR^2*(-(gZlR*gZuL*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*ms^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*ms^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZlL*gZuR*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*ms^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZlL*gZuL*(d^3*(2*Pi)^d*s^3 + 
         2^(1 + d)*(-3 + d)*ms^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2))) + 
     gZdL^2*(-(gZlL*gZuR*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*ms^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZlL*gZuL*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*ms^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZlR*gZuL*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*ms^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZlR*gZuR*(d^3*(2*Pi)^d*s^3 + 
         2^(1 + d)*(-3 + d)*ms^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2))) - 
     4*gZdL*gZdR*ms^2*(gZlR*(-((-7 + d)*d^2*gZuL*(2*Pi)^d*s^2) + 
         (-5 + d)*d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*
          ((4 - 7*d)*s^2 - (-4 + d)*(-1 + d)^2*s*t + 2*(-1 + d)*t^2) + 
         2^(1 + d)*gZuR*Pi^d*((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*
            t + 2*(-1 + d)*t^2)) + 
       gZlL*(-(gZuR*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) + 
         gZuL*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + 
             (-8 + 13*d - 6*d^2 + d^3)*s*t + 2*(-1 + d)*t^2))))))/
   ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((3*I)*2^(-1 - d)*(-2 + d)*EL^6*gAl*gAu*(gZdL^2 + gZdR^2)*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), 
  ((-3*I)*4^(-1 - d)*EL^6*gAl*gAu*
    (gZdR^2*(-(gZlR*gZuL*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*mb^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZlR*gZuR*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mb^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZlL*gZuR*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*mb^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZlL*gZuL*(d^3*(2*Pi)^d*s^3 + 
         2^(1 + d)*(-3 + d)*mb^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2))) + 
     gZdL^2*(-(gZlL*gZuR*(d^3*(2*Pi)^d*s^3 + 2^(1 + d)*(-3 + d)*mb^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
          2^(1 + d)*Pi^d*s*((-8 + 10*d - 4*d^2 + d^3)*s^2 + 
            (-8 + 14*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2))) + 
       gZlL*gZuL*(-(d^3*(2*Pi)^d*s^3) + 2^(1 + d)*(-3 + d)*mb^2*Pi^d*
          ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         2^(1 + d)*Pi^d*s*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
            s*t - 2*(-2 + d)*t^2)) + gZlR*gZuL*(d^3*(2*Pi)^d*s^3 - 
         2^(1 + d)*(-3 + d)*mb^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
          (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
           2*(-2 + d)*t^2)) + gZlR*gZuR*(d^3*(2*Pi)^d*s^3 + 
         2^(1 + d)*(-3 + d)*mb^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2) - 2^(1 + d)*Pi^d*s*((-4 + 6*d - 3*d^2 + d^3)*s^2 + 
           (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2))) - 
     4*gZdL*gZdR*mb^2*(gZlR*(-((-7 + d)*d^2*gZuL*(2*Pi)^d*s^2) + 
         (-5 + d)*d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*
          ((4 - 7*d)*s^2 - (-4 + d)*(-1 + d)^2*s*t + 2*(-1 + d)*t^2) + 
         2^(1 + d)*gZuR*Pi^d*((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*
            t + 2*(-1 + d)*t^2)) + 
       gZlL*(-(gZuR*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) + 
         gZuL*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + 
             (-8 + 13*d - 6*d^2 + d^3)*s*t + 2*(-1 + d)*t^2))))))/
   ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, ((-I)*2^(1 - d)*EL^6*gAl^2*gAu^2*gFFA^2*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*Pi^d*s^3), 
  (I*EL^6*gAl^2*gAu^2*gFFA^2*(d*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
      (-s^2 + 2*s*t + 2*t^2) - 2^(2 + d)*mw^2*Pi^d*((-2 + d)*s^2 + 4*s*t + 
       4*t^2)*GaugeXi[Q]))/((-1 + d)*(2*Pi)^(2*d)*s^3), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*EL^6*gAl*gAu^2*gFFA*gFFZ*(gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((-I)*2^(-1 - d)*EL^6*gAl*gAu^2*gFFA*gFFZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (I*EL^6*gAl^2*gAu*gFFA*gFFZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu*gFFA*gFFZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (I*2^(-2 - d)*EL^6*gAl*gAu*gHXZ^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (mh^2 + s - mz^2*GaugeXi[Q]))/((-1 + d)*Pi^d*(mz^2 - s)^2*s^2), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, (I*2^(-2 - d)*EL^6*gAl*gAu*gHXZ^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (-mh^2 + s + mz^2*GaugeXi[Q]))/((-1 + d)*Pi^d*(mz^2 - s)^2*s^2), 
  (I*EL^6*gAl*gAu*gHXZ^2*(((2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(mh^2 - s + mz^2*GaugeXi[Q])^2)/s - 
     ((mh^2 - s + mz^2*GaugeXi[Q])*
       (-(gZlR*gZuL*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
               t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
        gZlR*gZuR*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
          mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t))) + 
        gZlL*(-(gZuR*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                 t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZuL*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
            mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/s - 
     (2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(d*(mh^2 - s)^2 + 
        2*mz^2*((-2 + d)*mh^2 - d*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2))/
      (-1 + d) - 
     (2*((gZlR*gZuR*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-2 + d)*
             mh^2*Pi^d*s + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2) - 
          gZlR*gZuL*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*
             mh^2*Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2) + 
          gZlL*(gZuL*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-2 + 
                d)*mh^2*Pi^d*s + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2) - 
            gZuR*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*mh^
                2*Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2)))*t + 
        2*mz^2*(gZlL*(gZuR*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
            gZuL*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
            gZuR*mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t)) + 
            gZuL*mh^2*(d*(2*Pi)^d*(s + t) - 2^(1 + d)*Pi^d*(s + 2*t))) + 
          gZlR*(gZuL*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
              mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t))) - 
            gZuR*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
              mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))))*
         GaugeXi[Q] + mz^4*(gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 
            2^(1 + d)*gZuR*Pi^d + d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + 
          gZlL*(2^(1 + d)*gZuL*Pi^d - 2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + 
            d*gZuR*(2*Pi)^d))*t*GaugeXi[Q]^2))/s - 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       ((mh^2 - s)^2*(d*s + 2*t) + 2*mz^2*(mh^2*((-2 + d)*s - 2*t) - 
          s*(d*s + 2*t))*GaugeXi[Q] + mz^4*(d*s + 2*t)*GaugeXi[Q]^2))/
      ((-1 + d)*s^2)))/(2^(2*(1 + d))*Pi^(2*d)*(mz^2 - s)^2), 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, ((-I)*2^(-1 - d)*EL^6*gAl*gAu*gFFZ^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), (I*4^(-1 - d)*EL^6*gAl*gAu*gFFZ^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (s - 4*mw^2*GaugeXi[Q]))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*2^(1 - d)*EL^6*gAl^2*gAu^2*ggmgmA^2*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*Pi^d*s^3), 
  (I*EL^6*gAl^2*gAu^2*ggmgmA^2*(-(d*(2*Pi)^d*s^3) + 
     2^(1 + d)*Pi^d*s*(s^2 - 2*s*t - 2*t^2) + 2^(2 + d)*mw^2*Pi^d*
      ((-2 + d)*s^2 + 4*s*t + 4*t^2)*GaugeXi[Q]))/
   ((-1 + d)*(2*Pi)^(2*d)*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (I*2^(1 - d)*EL^6*gAl^2*gAu^2*ggpgpA^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2))/((-1 + d)*Pi^d*s^3), 
  (I*EL^6*gAl^2*gAu^2*ggpgpA^2*(-(d*(2*Pi)^d*s^3) + 
     2^(1 + d)*Pi^d*s*(s^2 - 2*s*t - 2*t^2) + 2^(2 + d)*mw^2*Pi^d*
      ((-2 + d)*s^2 + 4*s*t + 4*t^2)*GaugeXi[Q]))/
   ((-1 + d)*(2*Pi)^(2*d)*s^3), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*EL^6*gAl*gAu^2*ggmgmA*ggmgmZ*
    (gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl*gAu^2*ggmgmA*ggmgmZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*EL^6*gAl^2*gAu*ggmgmA*ggmgmZ*
    (gZuL + gZuR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl^2*gAu*ggmgmA*ggmgmZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*EL^6*gAl*gAu^2*ggpgpA*ggpgpZ*
    (gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl*gAu^2*ggpgpA*ggpgpZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*EL^6*gAl^2*gAu*ggpgpA*ggpgpZ*
    (gZuL + gZuR)*((-2 + d)*s^2 + 4*s*t + 4*t^2))/
   ((-1 + d)*(2*Pi)^d*s^2*(-mz^2 + s)), 
  (I*2^(-1 - d)*EL^6*gAl^2*gAu*ggpgpA*ggpgpZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (I*2^(-1 - d)*EL^6*gAl*gAu*ggmgmZ^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), ((-I)*4^(-1 - d)*EL^6*gAl*gAu*ggmgmZ^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (s - 4*mw^2*GaugeXi[Q]))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (I*2^(-1 - d)*EL^6*gAl*gAu*ggpgpZ^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
   ((-1 + d)*Pi^d*(mz^2 - s)^2*s), ((-I)*4^(-1 - d)*EL^6*gAl*gAu*ggpgpZ^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (s - 4*mw^2*GaugeXi[Q]))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s), 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*4^(-2 - d)*EL^6*gAl*gAu*gHZZ^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (-1 + GaugeXi[Q]))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*s^2), 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, ((-I)*4^(-2 - d)*EL^6*gAl*gAu*gHZZ^2*
    (gZlR*gZuL*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
         (4 - 5*d + d^2)*s*t - 2*t^2) - mh^2*(-(d^2*(2*Pi)^d*s^2) + 
         2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
           2*t^2))) + gZlL*gZuR*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
        ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) - 
       mh^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2))) + 
     gZlL*gZuL*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
        (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2) + 
       mh^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2))) + 
     gZlR*gZuR*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
        (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2) + 
       mh^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2))) + 
     mz^2*(-(gZlR*(-3*d^2*gZuL*(2*Pi)^d*s^2 + 3*d^2*gZuR*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuL*Pi^d*((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuR*Pi^d*(-((-2 + 2*d + d^2)*s^2) + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + gZlL*(3*d^2*gZuR*(2*Pi)^d*s^2 - 
         2^(1 + d)*gZuR*Pi^d*((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 
           2*t^2) + gZuL*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))))*
      GaugeXi[Q]))/((-1 + d)*mz^2*Pi^(2*d)*(mz^2 - s)^2*s^2), 
  ((-I)*EL^6*gAl*gAu*gHZZ^2*
    (((2*Pi)^d*(gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
        gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
       (mh^2 - s + mz^2*GaugeXi[Q])^2)/s - 
     ((mh^2 - s + mz^2*GaugeXi[Q])*
       (gZlL*(gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
          gZuL*s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
          gZuR*mh^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t)) + 
          gZuL*mh^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - d*s + t))) + 
        gZlR*(-(gZuR*(mh^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - 
                 t)) + s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) + 
          gZuL*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
            mh^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t)))) + 
        mz^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/s - 
     (2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*(d*(mh^2 - s)^2 + 
        2*mz^2*((-2 + d)*mh^2 - d*s)*GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2))/
      (-1 + d) - 
     (2*((gZlR*gZuR*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-2 + d)*
             mh^2*Pi^d*s + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2) - 
          gZlR*gZuL*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*
             mh^2*Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2) + 
          gZlL*(gZuL*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-2 + 
                d)*mh^2*Pi^d*s + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2) - 
            gZuR*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*mh^
                2*Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2)))*t + 
        2*mz^2*(gZlL*(gZuR*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
            gZuL*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
            gZuR*mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t)) + 
            gZuL*mh^2*(d*(2*Pi)^d*(s + t) - 2^(1 + d)*Pi^d*(s + 2*t))) + 
          gZlR*(gZuL*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
              mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t))) - 
            gZuR*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
              mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))))*
         GaugeXi[Q] + mz^4*(gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 
            2^(1 + d)*gZuR*Pi^d + d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + 
          gZlL*(2^(1 + d)*gZuL*Pi^d - 2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + 
            d*gZuR*(2*Pi)^d))*t*GaugeXi[Q]^2))/s - 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       ((mh^2 - s)^2*(d*s + 2*t) + 2*mz^2*(mh^2*((-2 + d)*s - 2*t) - 
          s*(d*s + 2*t))*GaugeXi[Q] + mz^4*(d*s + 2*t)*GaugeXi[Q]^2))/
      ((-1 + d)*s^2)))/(2^(2*(2 + d))*Pi^(2*d)*(mz^3 - mz*s)^2), 
  (I*4^(-2 - d)*EL^6*gAl*gAu*gHZZ^2*
    (gZlL*(gZuR*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) - mh^2*(-(d^2*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
             2*t^2)) + mz^2*(3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            (-((-4 + 3*d + d^2)*s^2) + (4 - 5*d + d^2)*s*t - 2*t^2))) + 
       gZuL*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*(2*(-1 + d)*s^2 - 
           (8 - 5*d + d^2)*s*t - 2*t^2) + mz^2*(-3*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 
             2*t^2)) + mh^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
            ((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))) - 
     gZlR*(gZuL*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*((-4 + 3*d)*s^2 - 
           (4 - 5*d + d^2)*s*t + 2*t^2) + mh^2*(-(d^2*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
             2*t^2)) + mz^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2))) + 
       gZuR*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
           (8 - 5*d + d^2)*s*t + 2*t^2) - mh^2*(-(d^2*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
             2*t^2)) + mz^2*(3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            (-((-2 + 2*d + d^2)*s^2) + (8 - 5*d + d^2)*s*t + 2*t^2))))))/
   ((-1 + d)*mz^2*Pi^(2*d)*(mz^2 - s)^2*s^2), 
  ((-I)*EL^6*gAl*gAu*gHZZ^2*((2^(1 + d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^d*
       (-4*mh^2*mz^2 + d*(mh^2 + mz^2 - s)^2))/(-1 + d) - 
     ((2*Pi)^d*(mh^2 + mz^2 - s)^2*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t)))/s + 
     ((2*Pi)^d*(gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       (d*(mh^2 + mz^2 - s)^2*s + 2*mh^4*t + 2*(mz^2 - s)^2*t - 
        4*mh^2*(s*t + mz^2*(s + t))))/((-1 + d)*s^2) - 
     (2*(gZlL*gZuL*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
          mh^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 
          mz^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 2^(1 + d)*mz^2*Pi^d*
           ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2) - 
          2^(1 + d)*mh^2*Pi^d*((-2 + d)*s*t + mz^2*((-2 + d)*s + 
              (-4 + d)*t))) + gZlR*gZuR*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*
            t) + mh^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 
          mz^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 2^(1 + d)*mz^2*Pi^d*
           ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2) - 
          2^(1 + d)*mh^2*Pi^d*((-2 + d)*s*t + mz^2*((-2 + d)*s + 
              (-4 + d)*t))) + gZlR*gZuL*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*
           t + mz^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*t + 
          (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mz^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2) + 
          2^(1 + d)*mh^2*Pi^d*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
              (-2 + d)*t))) + gZlL*gZuR*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*
           t + mz^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*t + 
          (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mz^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2) + 
          2^(1 + d)*mh^2*Pi^d*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
              (-2 + d)*t)))))/s + 
     ((mh^2 + mz^2 - s)*(gZlL*(-(gZuR*(mz^2 - s)*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s - t))) + gZuL*(mz^2 - s)*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(s + t)) + gZuR*mh^2*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*((-2 + d)*s + t)) + gZuL*mh^2*(d*(2*Pi)^d*s + 
            2^(1 + d)*Pi^d*(s - d*s + t))) + 
        gZlR*(-(gZuR*mh^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-1 + d)*s - 
               t))) + gZuR*(mz^2 - s)*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (s + t)) + gZuL*(-((mz^2 - s)*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t))) + mh^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                (-2 + d)*s + t))))))/s))/(2^(2*(2 + d))*Pi^(2*d)*
    (mz^3 - mz*s)^2)}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, (I*2^(-4 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (mw^2 + s - mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^d*(mz^2 - s)^2*s^2*sw^2), 
  0, 0, 0, 0, (I*2^(-3 - 2*d)*EL^6*gAl*gAu*gFZW^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   ((-1 + d)*mw^2*Pi^(2*d)*(mz^2 - s)^2*s*sw^2), 
  ((-I)*4^(-2 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (s - 4*mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^(2*d)*(mz^2 - s)^2*s*sw^2), 
  (I*2^(-4 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (-mw^2 + s + mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^d*(mz^2 - s)^2*s^2*
    sw^2), ((-I/16)*EL^6*gAl*gAu*gFZW^2*
    (((-1 + d)*s*(-(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
           2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t))) + 
        gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
           (2*s - t) - 2^(1 + d)*gZuR*Pi^d*(s + t)))*
       (mw^2 - s + mw^2*GaugeXi[Q])^2)/(2*Pi)^(2*d) - 
     ((1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       ((mw^2 - s)*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuL*Pi^d*((-1 + d)*s - t) - 2^(1 + d)*gZuR*Pi^d*
             ((-2 + d)*s + t)) - gZlR*(-(d*gZuL*(2*Pi)^d*s) + 
            d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*((-2 + d)*s + t) + 
            2^(1 + d)*gZuR*Pi^d*(s - d*s + t))) - 
        mw^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (2*Pi)^(2*d) - (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*s^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2))/Pi^d + (2^(1 - 3*d)*(1 - d)*s*
       ((2*Pi)^(2*d)*(gZlR*gZuL*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlL*gZuR*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
          gZlL*gZuL*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
          gZlR*gZuR*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        2^(1 + 2*d)*mw^2*Pi^(2*d)*(gZlL*gZuL*((-2 + d)*s*t + 
            mw^2*((-2 + d)*s + (-4 + d)*t)) + gZlR*gZuR*((-2 + d)*s*t + 
            mw^2*((-2 + d)*s + (-4 + d)*t)) - gZlR*gZuL*((-4 + d)*s*t + 
            mw^2*((-4 + d)*s + (-2 + d)*t)) - gZlL*gZuR*((-4 + d)*s*t + 
            mw^2*((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q] + 
        (-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + (-4 + d)*gZlL*gZuR - 
          (-2 + d)*gZlR*gZuR)*mw^4*(2*Pi)^(2*d)*t*GaugeXi[Q]^2))/Pi^(3*d) - 
     ((gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       ((mw^2 - s)^2*(d*s + 2*t) + 2*(mw^4*((-2 + d)*s - 2*t) - 
          mw^2*s*(d*s + 2*t))*GaugeXi[Q] + mw^4*(d*s + 2*t)*GaugeXi[Q]^2))/
      (2*Pi)^d))/((1 - d)*mw^2*(mz^2 - s)^2*s^2*sw^2), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (I*2^(-4 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (mw^2 + s - mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^d*(mz^2 - s)^2*s^2*sw^2), 
  0, 0, 0, 0, (I*2^(-3 - 2*d)*EL^6*gAl*gAu*gFZW^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
   ((-1 + d)*mw^2*Pi^(2*d)*(mz^2 - s)^2*s*sw^2), 
  ((-I)*4^(-2 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlL*(d^2*gZuL*(2*Pi)^d*s^2 - d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuR*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuL*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
     gZlR*(-(d^2*gZuL*(2*Pi)^d*s^2) + d^2*gZuR*(2*Pi)^d*s^2 + 
       2^(1 + d)*gZuL*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
       2^(1 + d)*gZuR*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
    (s - 4*mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^(2*d)*(mz^2 - s)^2*s*sw^2), 
  (I*2^(-4 - d)*EL^6*gAl*gAu*gFZW^2*
    (gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (-mw^2 + s + mw^2*GaugeXi[Q]))/((-1 + d)*mw^2*Pi^d*(mz^2 - s)^2*s^2*
    sw^2), ((-I/16)*EL^6*gAl*gAu*gFZW^2*
    (((-1 + d)*s*(-(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
           2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t))) + 
        gZlR*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
           (2*s - t) - 2^(1 + d)*gZuR*Pi^d*(s + t)))*
       (mw^2 - s + mw^2*GaugeXi[Q])^2)/(2*Pi)^(2*d) - 
     ((1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       ((mw^2 - s)*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuL*Pi^d*((-1 + d)*s - t) - 2^(1 + d)*gZuR*Pi^d*
             ((-2 + d)*s + t)) - gZlR*(-(d*gZuL*(2*Pi)^d*s) + 
            d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*((-2 + d)*s + t) + 
            2^(1 + d)*gZuR*Pi^d*(s - d*s + t))) - 
        mw^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
            2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
          gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
             (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]))/
      (2*Pi)^(2*d) - (2^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*s^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2))/Pi^d + (2^(1 - 3*d)*(1 - d)*s*
       ((2*Pi)^(2*d)*(gZlR*gZuL*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlL*gZuR*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
          gZlL*gZuL*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
          gZlR*gZuR*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        2^(1 + 2*d)*mw^2*Pi^(2*d)*(gZlL*gZuL*((-2 + d)*s*t + 
            mw^2*((-2 + d)*s + (-4 + d)*t)) + gZlR*gZuR*((-2 + d)*s*t + 
            mw^2*((-2 + d)*s + (-4 + d)*t)) - gZlR*gZuL*((-4 + d)*s*t + 
            mw^2*((-4 + d)*s + (-2 + d)*t)) - gZlL*gZuR*((-4 + d)*s*t + 
            mw^2*((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q] + 
        (-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + (-4 + d)*gZlL*gZuR - 
          (-2 + d)*gZlR*gZuR)*mw^4*(2*Pi)^(2*d)*t*GaugeXi[Q]^2))/Pi^(3*d) - 
     ((gZlL*gZuL*((-4 + d)*s - 2*t) + gZlR*gZuR*((-4 + d)*s - 2*t) - 
        gZlR*gZuL*((-2 + d)*s + 2*t) - gZlL*gZuR*((-2 + d)*s + 2*t))*
       ((mw^2 - s)^2*(d*s + 2*t) + 2*(mw^4*((-2 + d)*s - 2*t) - 
          mw^2*s*(d*s + 2*t))*GaugeXi[Q] + mw^4*(d*s + 2*t)*GaugeXi[Q]^2))/
      (2*Pi)^d))/((1 - d)*mw^2*(mz^2 - s)^2*s^2*sw^2), 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*gWWA^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)^2*mw^2 + 
     (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^2*Pi^d*s^3*GaugeXi[Q]), 
  ((-I)*2^(-2 - d)*EL^6*gAl^2*gAu^2*gWWA^2*(4*mw^2 - s)*
    (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*mw^4*Pi^d*s^3), 0, 0, 0, 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*gWWA^2*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    (4*(-1 + d)*mw^2*s + (2*mw^2 + s)*(2*(-4 + 5*d)*mw^2 + d*s)*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*s^3*GaugeXi[Q]), 
  (I*2^(-2 - d)*EL^6*gAl^2*gAu^2*gWWA^2*(2*mw^2 + s)^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(s - 4*mw^2*GaugeXi[Q]))/
   ((-1 + d)*mw^4*Pi^d*s^3), (I*2^(-1 - d)*EL^6*gAl^2*gAu^2*gWWA^2*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)*mw^2*s + 
     (4*(-3 + 2*d + d^2)*mw^4 + (-8 + 3*d + 4*d^2)*mw^2*s + d*s^2)*
      GaugeXi[Q] + (-4*(-1 + d)^2*mw^4 + d*mw^2*s)*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^4*Pi^d*s^3*GaugeXi[Q]), 
  ((-I)*2^(-1 - d)*EL^6*gAl^2*gAu^2*gWWA^2*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
    (mw^4 + 2*(-3 + 2*d)*mw^2*s + s^2 - 2*mw^2*(mw^2 + s)*GaugeXi[Q] + 
     mw^4*GaugeXi[Q]^2))/((-1 + d)*mw^4*Pi^d*s^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, ((-I)*2^(-2 - d)*EL^6*gAl*gAu^2*gWWA*gWWZ*
    (gZlL + gZlR)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)^2*mw^2 + 
     (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^2*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  (I*2^(-3 - d)*EL^6*gAl*gAu^2*gWWA*gWWZ*(gZlL + gZlR)*(4*mw^2 - s)*
    (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*mw^4*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 
  ((-I)*2^(-2 - d)*EL^6*gAl*gAu^2*gWWA*gWWZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)*mw^2*s + 
     (2*mw^2 + s)*(2*(-4 + 5*d)*mw^2 + d*s)*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl*gAu^2*gWWA*gWWZ*(gZlL + gZlR)*
    (-(s*(d*(2*Pi)^d*s^4 + 2^(1 + d)*Pi^d*s^2*(-s^2 + 2*s*t + 2*t^2) + 
        2^(2 + d)*mw^4*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
        2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2))) + 
     2^(2 + d)*mw^2*Pi^d*(2*mw^2 + s)^2*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]))/((-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s^2), 
  (I*2^(-2 - d)*EL^6*gAl*gAu^2*gWWA*gWWZ*(gZlL + gZlR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)*mw^2*s + 
     (4*(-3 + 2*d + d^2)*mw^4 + (-8 + 3*d + 4*d^2)*mw^2*s + d*s^2)*
      GaugeXi[Q] + (-4*(-1 + d)^2*mw^4 + d*mw^2*s)*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  ((-I)*4^(-1 - d)*EL^6*gAl*gAu^2*gWWA*gWWZ*(gZlL + gZlR)*
    (-(d*(2*Pi)^d*s^4) + 2^(1 + d)*Pi^d*s^2*((-1 + d)*s^2 + 2*s*t + 2*t^2) + 
     2^(1 + d)*(-3 + 2*d)*mw^2*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mw^4*(d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-s^2 + 2*s*t + 2*t^2)) - 
     2^(1 + d)*mw^2*Pi^d*(mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] + mw^4*(-(d*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
        ((-1 + d)*s^2 + 2*s*t + 2*t^2))*GaugeXi[Q]^2))/
   ((-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, ((-I)*2^(-2 - d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)^2*mw^2 + 
     (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^2*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  (I*2^(-3 - d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*(4*mw^2 - s)*
    (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*((-2 + d)*s^2 + 4*s*t + 
     4*t^2))/((-1 + d)*mw^4*Pi^d*s^2*(-mz^2 + s)), 0, 0, 0, 
  ((-I)*2^(-2 - d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)*mw^2*s + 
     (2*mw^2 + s)*(2*(-4 + 5*d)*mw^2 + d*s)*GaugeXi[Q]))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*
    (-(s*(d*(2*Pi)^d*s^4 + 2^(1 + d)*Pi^d*s^2*(-s^2 + 2*s*t + 2*t^2) + 
        2^(2 + d)*mw^4*Pi^d*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
        2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2))) + 
     2^(2 + d)*mw^2*Pi^d*(2*mw^2 + s)^2*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q]))/((-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s^2), 
  (I*2^(-2 - d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*
    ((-2 + d)*s^2 + 4*s*t + 4*t^2)*(4*(-1 + d)*mw^2*s + 
     (4*(-3 + 2*d + d^2)*mw^4 + (-8 + 3*d + 4*d^2)*mw^2*s + d*s^2)*
      GaugeXi[Q] + (-4*(-1 + d)^2*mw^4 + d*mw^2*s)*GaugeXi[Q]^2))/
   ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*s^2*GaugeXi[Q]), 
  ((-I)*4^(-1 - d)*EL^6*gAl^2*gAu*gWWA*gWWZ*(gZuL + gZuR)*
    (-(d*(2*Pi)^d*s^4) + 2^(1 + d)*Pi^d*s^2*((-1 + d)*s^2 + 2*s*t + 2*t^2) + 
     2^(1 + d)*(-3 + 2*d)*mw^2*Pi^d*s*((-2 + d)*s^2 + 4*s*t + 4*t^2) + 
     mw^4*(d*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-s^2 + 2*s*t + 2*t^2)) - 
     2^(1 + d)*mw^2*Pi^d*(mw^2 + s)*((-2 + d)*s^2 + 4*s*t + 4*t^2)*
      GaugeXi[Q] + mw^4*(-(d*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
        ((-1 + d)*s^2 + 2*s*t + 2*t^2))*GaugeXi[Q]^2))/
   ((-1 + d)*mw^4*Pi^(2*d)*(mz^2 - s)*s), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, ((-I)*2^(-3 - d)*EL^6*gAl*gAu*gWWZ^2*
    (-(gZlR*gZuL*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
     gZlL*gZuR*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
     gZlL*gZuL*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
     gZlR*gZuR*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
    (4*(-1 + d)^2*mw^2 + (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + 
     d*s*GaugeXi[Q]^2))/((-1 + d)*d*mw^2*Pi^d*(mz^2 - s)^2*s*GaugeXi[Q]), 
  ((-I)*EL^6*gAl*gAu*gWWZ^2*(((gZlL + gZlR)*(gZuL + gZuR)*(2*Pi)^(3*d)*
       (4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + 
        d*s^2))/(-1 + d) + ((gZlL + gZlR)*(gZuL + gZuR)*(2*Pi)^(2*d)*
       (4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*(2^(2 + d)*(-1 + d)*mw^4*Pi^d - 
        2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2))/(-1 + d) - 
     (2^(1 + 2*d)*Pi^(2*d)*(mw^2 - s/2)*
       (gZlR*gZuL*(-(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-4 + d)*s + 2*t)) + 
          2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-4 + d)*s + 2*t) - 
          3*2^(1 + d)*mw^2*Pi^d*s^2*((-4 + d)*s + 2*t) + 
          s^3*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuR*(-(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-4 + d)*s + 2*t)) + 
          2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-4 + d)*s + 2*t) - 
          3*2^(1 + d)*mw^2*Pi^d*s^2*((-4 + d)*s + 2*t) + 
          s^3*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuL*(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-2 + d)*s - 2*t) - 
          2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-2 + d)*s - 2*t) + 
          3*2^(1 + d)*mw^2*Pi^d*s^2*((-2 + d)*s - 2*t) + 
          s^3*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        gZlR*gZuR*(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-2 + d)*s - 2*t) - 
          2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-2 + d)*s - 2*t) + 
          3*2^(1 + d)*mw^2*Pi^d*s^2*((-2 + d)*s - 2*t) + 
          s^3*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))/s + 
     ((2*Pi)^(2*d)*(4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
       (-(gZlR*gZuL*(2^(2 + d)*(-1 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) - 
           2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
           s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) - 
        gZlL*gZuR*(2^(2 + d)*(-1 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) - 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlL*gZuL*(2^(2 + d)*(-1 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))) + 
        gZlR*gZuR*(2^(2 + d)*(-1 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))))/((-1 + d)*s) + 
     (2*(gZlL*((-4 + d)*gZuR*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*(-1 + d)*gZuR*
           mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) + 8^(1 + d)*gZuR*mw^6*Pi^(3*d)*s*
           ((-4 + d)*s - 2*(3 - 5*d + d^2)*t) - 2^(1 + 3*d)*gZuR*mw^4*
           Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 
            32*t^2) + 2^(2 + 3*d)*gZuR*mw^2*Pi^(3*d)*s^2*
           ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2) + 
          gZuL*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
            (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
             ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
             s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
            2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 
              2*(69 - 41*d + 7*d^2)*s*t + 32*t^2))) + 
        gZlR*((-4 + d)*gZuL*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*(-1 + d)*gZuL*mw^8*
           Pi^(3*d)*((-4 + d)*s + 2*t) + 8^(1 + d)*gZuL*mw^6*Pi^(3*d)*s*
           ((-4 + d)*s - 2*(3 - 5*d + d^2)*t) - 2^(1 + 3*d)*gZuL*mw^4*
           Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 
            32*t^2) + 2^(2 + 3*d)*gZuL*mw^2*Pi^(3*d)*s^2*
           ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2) + 
          gZuR*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
            (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
             ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
             s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
            2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 
              2*(69 - 41*d + 7*d^2)*s*t + 32*t^2)))))/s - 
     ((-2*mw^2 + s)^2*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
       (gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
        gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
       ((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
        (2*Pi)^(3*d)*GaugeXi[Q]^2))/(s*(-1 + GaugeXi[Q])^2)))/
   (2^(4*(1 + d))*mw^4*Pi^(4*d)*(mz^2 - s)^2), 0, 0, 0, 
  ((-I/8)*EL^6*gAl*gAu*gWWZ^2*((3*2^(1 - d)*(4 + d)*(gZlL + gZlR)*
       (gZuL + gZuR)*s)/(d*Pi^d) + (2^(1 - 2*d)*(4 + d)*
       (gZlR*(3*2^(3 + d)*gZuR*Pi^d + gZuL*(2*Pi)^d - 23*gZuR*(2*Pi)^d) + 
        gZlL*(3*2^(3 + d)*gZuL*Pi^d - 23*gZuL*(2*Pi)^d + gZuR*(2*Pi)^d))*s)/
      (d*Pi^(2*d)) + (2^(2 - d)*(gZlL + gZlR)*(gZuL + gZuR)*(2*mw^2 + s)*
       GaugeXi[Q])/Pi^d + (3*4^(1 - d)*(gZlL + gZlR)*(gZuL + gZuR)*
       (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q])/Pi^(2*d) + 
     ((2*mw^2 + s)^2*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(s - 2*mw^2*GaugeXi[Q]))/
      (mw^4*(2*Pi)^d*s) + 
     (2^(3 - 2*d)*(-(gZlR*(-(2^(1 + d)*gZuR*mw^2*Pi^d*((-4 + d)*s - 2*t)) + 
           2^(1 + d)*gZuL*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
           gZuL*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
           gZuR*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))) + 
        gZlL*(-(gZuR*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
             s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
          gZuL*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))))*
       ((-2*t)/d + mw^2*GaugeXi[Q]))/(mw^2*Pi^(2*d)*s) + 
     ((gZlR*gZuL*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuR*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuL*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        gZlR*gZuR*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
       (-s + 2*mw^2*GaugeXi[Q]))/(mw^4*(2*Pi)^(2*d)*s) - 
     (2^(2 - d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*((4 + d)*s + 4*mw^2*GaugeXi[Q]))/
      (d*mw^2*Pi^d*GaugeXi[Q]) + 
     ((gZlR*gZuL*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlL*gZuR*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlL*gZuL*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
        gZlR*gZuR*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
       (d*s + 2*t - 4*(-1 + d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^(2*d)*
       s) + ((gZlL + gZlR)*(gZuL + gZuR)*(2*mw^2 + s)^2*
       (-(d*s) + 4*(-1 + d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^d) + 
     ((gZlL + gZlR)*(gZuL + gZuR)*(2^(2 + d)*mw^4*Pi^d + 
        2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
       (-(d*s) + 4*(-1 + d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^(2*d)) - 
     (2^(1 - d)*((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
        (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*s*t*
       (s + (12*mw^2*GaugeXi[Q])/d))/(mw^4*Pi^d*GaugeXi[Q]^2) + 
     (2^(2 - d)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
        gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
        gZlL*gZuR*((-2 + d)*s + 2*t))*(-2*t + (4 + d)*mw^2*GaugeXi[Q]))/
      (d*mw^2*Pi^d*GaugeXi[Q]) - 
     ((2 + d)*(gZlL*(-((-2 + d)*gZuL*s) + (-4 + d)*gZuR*s + 2*gZuL*t + 
          2*gZuR*t) + gZlR*((-4 + d)*gZuL*s - (-2 + d)*gZuR*s + 2*gZuL*t + 
          2*gZuR*t))*(s - 2*(3*mw^2 + s)*GaugeXi[Q]))/
      (d*mw^2*(2*Pi)^d*GaugeXi[Q]) - 
     ((2 + d)*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
          2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
        gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
           (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*
       (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*(2*Pi)^(2*d)*GaugeXi[Q]) - 
     (2^(1 - d)*(2 + d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
        gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
        gZlL*gZuR*((-4 + d)*s + 2*t))*(-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/
      (d*mw^2*Pi^d*GaugeXi[Q]) - (2^(1 - d)*(2*mw^2 + s)*
       (gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
        gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
       (-2*s + (6*mw^2 + s)*GaugeXi[Q]))/(mw^2*Pi^d*s) - 
     (2^(1 - d)*(s + (4*mw^2*GaugeXi[Q])/d)*
       ((-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + (-4 + d)*gZlL*gZuR - 
          (-2 + d)*gZlR*gZuR)*s*t + 
        (gZlL*((-2 + d)*gZuL*s*t - (-4 + d)*gZuR*s*t + gZuR*mw^2*
             ((-4 + d)*s - 2*(-5 + d)*t) + gZuL*mw^2*(-((-2 + d)*s) + 
              2*(-1 + d)*t)) + gZlR*(-((-4 + d)*gZuL*s*t) + 
            (-2 + d)*gZuR*s*t + gZuL*mw^2*((-4 + d)*s - 2*(-5 + d)*t) + 
            gZuR*mw^2*(-((-2 + d)*s) + 2*(-1 + d)*t)))*GaugeXi[Q]))/
      (mw^4*Pi^d*GaugeXi[Q]^2) - 
     (2^(1 - 2*d)*(-(2^(1 + d)*Pi^d*s*(2*mw^2 + s)*
          (gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - 2*gZuL*t - 2*gZuR*t) - 
           gZlR*((-4 + d)*gZuL*s - (-2 + d)*gZuR*s + 2*gZuL*t + 2*gZuR*t))) + 
        (gZlL*(-(gZuR*(3*2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 2^(3 + d)*
                mw^2*Pi^d*s*((-4 + d)*s + 2*t) + s^2*(d*(2*Pi)^d*s + 
                 2^(1 + d)*Pi^d*(-2*s + t)))) + 
            gZuL*(3*2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 2^(3 + d)*mw^
                2*Pi^d*s*((-2 + d)*s - 2*t) + s^2*(d*(2*Pi)^d*s - 
                2^(1 + d)*Pi^d*(s + t)))) - 
          gZlR*(gZuL*(3*2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
              2^(3 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + s^2*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + t))) + gZuR*(-3*2^(2 + d)*mw^4*Pi^d*(
                (-2 + d)*s - 2*t) - 2^(3 + d)*mw^2*Pi^d*s*((-2 + d)*s - 
                2*t) + s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*
         GaugeXi[Q]))/(mw^2*Pi^(2*d)*s) + 
     (2^(1 - 2*d)*(s + (4*mw^2*GaugeXi[Q])/d)*
       ((gZlL*(-(2^(1 + d)*gZuL*Pi^d) + 2^(2 + d)*gZuR*Pi^d + 
            d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + gZlR*(2^(2 + d)*gZuL*Pi^d - 
            2^(1 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*s*t + 
        (gZlL*(gZuL*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
            gZuR*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
            gZuR*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + (-5 + d)*t)) + 
            gZuL*mw^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + (-1 + d)*t))) + 
          gZlR*(gZuL*((-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
              mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + (-5 + d)*t))) - 
            gZuR*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
              mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + (-1 + d)*t)))))*
         GaugeXi[Q]))/(mw^4*Pi^(2*d)*GaugeXi[Q]^2) + 
     (2^(2 - d)*(2*mw^2 + s)*((-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + 
          (-4 + d)*gZlL*gZuR - (-2 + d)*gZlR*gZuR)*s^2*t + 
        ((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
          (-2 + d)*gZlR*gZuR)*s*(6*mw^2 + s)*t*GaugeXi[Q] + 
        mw^2*(4*mw^2 + s)*(gZlL*((-2 + d)*gZuL*s - (-4 + d)*gZuR*s - 
            2*gZuL*t - 2*gZuR*t) - gZlR*((-4 + d)*gZuL*s - (-2 + d)*gZuR*s + 
            2*gZuL*t + 2*gZuR*t))*GaugeXi[Q]^2))/(mw^4*Pi^d*s*GaugeXi[Q]) + 
     (s*(2^(1 + d)*Pi^d*(gZlL*gZuL*(-10 - (4*s)/mw^2 - (6*t)/s + 
            d*(5 + (2*(s - t))/mw^2 - (2*t)/s + (s*t)/(mw^4*(-1 + GaugeXi[Q])^
                 2)) - (2*s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) + 
          gZlR*gZuR*(-10 - (4*s)/mw^2 - (6*t)/s + d*(5 + (2*(s - t))/mw^2 - 
              (2*t)/s + (s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) - 
            (2*s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) + gZlR*gZuL*
           (20 + (8*s - 12*t)/mw^2 - (18*t)/s + d*(-5 - (2*(s - t))/mw^2 + 
              (2*t)/s - (s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) + 
            (4*s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) + gZlL*gZuR*
           (20 + (8*s - 12*t)/mw^2 - (18*t)/s + d*(-5 - (2*(s - t))/mw^2 + 
              (2*t)/s - (s*t)/(mw^4*(-1 + GaugeXi[Q])^2)) + 
            (4*s*t)/(mw^4*(-1 + GaugeXi[Q])^2))) + 
        ((gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 2^(1 + d)*gZuR*Pi^d + 
             d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + gZlL*(2^(1 + d)*gZuL*Pi^d - 
             2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*s*t)/
         (mw^4*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) + 
        (6*(-(gZlR*(2^(1 + d)*(-4 + d)*gZuL*mw^2*Pi^d - 2^(1 + d)*(-2 + d)*
               gZuR*mw^2*Pi^d - 2^(2 + d)*gZuL*Pi^d*s + d*gZuL*(2*Pi)^d*s + 
              gZuR*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*s)) + 
           gZlL*(2^(1 + d)*(-2 + d)*gZuL*mw^2*Pi^d - 2^(1 + d)*(-4 + d)*gZuR*
              mw^2*Pi^d - 2^(1 + d)*gZuL*Pi^d*s + d*gZuL*(2*Pi)^d*s + 
             gZuR*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*s))*t)/(mw^4*GaugeXi[Q]) + 
        ((gZlR*(-(2^(2 + d)*gZuL*Pi^d) + 2^(1 + d)*gZuR*Pi^d + 
             d*gZuL*(2*Pi)^d - d*gZuR*(2*Pi)^d) + gZlL*(2^(1 + d)*gZuL*Pi^d - 
             2^(2 + d)*gZuR*Pi^d - d*gZuL*(2*Pi)^d + d*gZuR*(2*Pi)^d))*s*t*
          GaugeXi[Q]^2)/(mw^4*(-1 + GaugeXi[Q])^2)))/(2*Pi)^(2*d) + 
     ((-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + (-4 + d)*gZlL*gZuR - 
         (-2 + d)*gZlR*gZuR)*(2*Pi)^(2*d)*s^2*t + 3*2^(1 + 2*d)*
        ((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - (-4 + d)*gZlL*gZuR + 
         (-2 + d)*gZlR*gZuR)*Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] - 
       2^(1 + 2*d)*Pi^(2*d)*(gZlR*gZuL*(-5*(-4 + d)*s^2*t + 
           2*mw^2*s*((-4 + d)*s + (30 - 7*d)*t) + 
           mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + gZlL*gZuR*
          (-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + (30 - 7*d)*t) + 
           mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + gZlL*gZuL*
          (5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + 
           mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t)) + gZlR*gZuR*
          (5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + 
           mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t)))*GaugeXi[Q]^2 - 
       2^(1 + 2*d)*Pi^(2*d)*(gZlL*(gZuR*(3*(-4 + d)*s^2*t - 
             2*mw^2*s*(2*(-4 + d)*s + (24 - 5*d)*t) + 
             mw^4*(-10*(-4 + d)*s + 4*(-9 + d)*t)) + 
           gZuL*(-3*(-2 + d)*s^2*t + 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*t) + 
             2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
         gZlR*(gZuL*(-3*(-4 + d)*s^2*t + 2*mw^2*s*(2*(-4 + d)*s + (24 - 5*d)*
                t) + 2*mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
           gZuR*(3*(-2 + d)*s^2*t - 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*t) + 
             mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^3 + 
       (2*Pi)^(2*d)*(gZlL*(gZuR*((-4 + d)*s^2*t + mw^4*(-10*(-4 + d)*s + 4*
                (-9 + d)*t) - 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
           gZuL*(-((-2 + d)*s^2*t) + 4*mw^2*s*((-2 + d)*s - d*t) + 
             2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
         gZlR*(gZuL*(-((-4 + d)*s^2*t) + 2*mw^4*(5*(-4 + d)*s - 2*(-9 + d)*
                t) + 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
           gZuR*((-2 + d)*s^2*t + 4*mw^2*s*(-((-2 + d)*s) + d*t) + 
             mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^4)/
      (mw^4*(2*Pi)^(3*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)))/(mz^2 - s)^2, 
  ((-I)*2^(-4 - 3*d)*EL^6*gAl*gAu*gWWZ^2*
    (-(((2*Pi)^(2*d)*(2*mw^2 + s)^2*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
         gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
         gZlL*gZuR*((-4 + d)*s + 2*t))*(s - 2*mw^2*GaugeXi[Q])^2)/s) + 
     ((2*Pi)^d*(gZlR*gZuL*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuR*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
        gZlL*gZuL*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        gZlR*gZuR*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
       (s - 2*mw^2*GaugeXi[Q])^2)/s + ((gZlL + gZlR)*(gZuL + gZuR)*
       (2*Pi)^(2*d)*(2*mw^2 + s)^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2))/(-1 + d) + 
     ((gZlL + gZlR)*(gZuL + gZuR)*(2*Pi)^d*(2^(2 + d)*mw^4*Pi^d + 
        2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2))/
      (-1 + d) - ((2*Pi)^d*(gZlR*gZuL*(2^(2 + d)*mw^4*Pi^d*
           ((-2 + d)*s + 2*t) + 2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlL*gZuR*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlL*gZuL*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
        gZlR*gZuR*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
       (s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2))/((-1 + d)*s) + 
     (2*(2*mw^2 + s)^2*((-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + 
          (-4 + d)*gZlL*gZuR - (-2 + d)*gZlR*gZuR)*(2*Pi)^(2*d)*s^2*t + 
        2^(1 + 2*d)*((-2 + d)*gZlL*gZuL - (-4 + d)*gZlR*gZuL - 
          (-4 + d)*gZlL*gZuR + (-2 + d)*gZlR*gZuR)*Pi^(2*d)*s*(2*mw^2 + s)*t*
         GaugeXi[Q] + (2*Pi)^(2*d)*
         (gZlL*(gZuL*(2*mw^4*((-2 + d)*s - 2*t) - 8*(-2 + d)*mw^2*s*t - 
              (-2 + d)*s^2*t) + gZuR*(8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 
              2*mw^4*((-4 + d)*s + 2*t))) - 
          gZlR*(gZuL*(-8*(-4 + d)*mw^2*s*t - (-4 + d)*s^2*t + 
              2*mw^4*((-4 + d)*s + 2*t)) + gZuR*(8*(-2 + d)*mw^2*s*t + 
              (-2 + d)*s^2*t + mw^4*(4*s - 2*d*s + 4*t))))*GaugeXi[Q]^2 - 
        4^(1 + d)*mw^2*Pi^(2*d)*(gZlL*(gZuL*mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*gZuL*s*t + (-4 + d)*gZuR*s*t - gZuR*mw^2*
             ((-4 + d)*s + 2*t)) - gZlR*(-((-4 + d)*gZuL*s*t) + 
            (-2 + d)*gZuR*s*t + gZuL*mw^2*((-4 + d)*s + 2*t) + 
            gZuR*mw^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^3 + 
        2^(1 + 2*d)*mw^4*Pi^(2*d)*(gZlL*gZuL*((-2 + d)*s - 2*t) + 
          gZlR*gZuR*((-2 + d)*s - 2*t) - gZlR*gZuL*((-4 + d)*s + 2*t) - 
          gZlL*gZuR*((-4 + d)*s + 2*t))*GaugeXi[Q]^4))/
      (s*(-1 + GaugeXi[Q])^2)))/(mw^4*Pi^(3*d)*(mz^2 - s)^2), 
  (I*2^(-3 - 2*d)*EL^6*gAl*gAu*gWWZ^2*
    (4*mw^2*s*(gZlR*(-((-7 + d)*d^2*gZuL*(2*Pi)^d*s^2) + 
         (-5 + d)*d^2*gZuR*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*Pi^d*
          ((4 - 7*d)*s^2 - (-4 + d)*(-1 + d)^2*s*t + 2*(-1 + d)*t^2) + 
         2^(1 + d)*gZuR*Pi^d*((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*
            t + 2*(-1 + d)*t^2)) + 
       gZlL*(-(gZuR*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) + 
         gZuL*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + 
             (-8 + 13*d - 6*d^2 + d^3)*s*t + 2*(-1 + d)*t^2)))) + 
     (gZlR*gZuL*(-(2^(2 + d)*(-3 + 2*d + d^2)*mw^4*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
         d*s^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2)) - mw^2*s*(-3*d^3*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-32 + 36*d + 3*d^2 - 9*d^3 + 2*d^4)*s^2 + 
             (-32 + 52*d - 7*d^2 - 17*d^3 + 4*d^4)*s*t - 2*(-8 + 3*d + 4*d^2)*
              t^2))) + gZlL*gZuR*(-(2^(2 + d)*(-3 + 2*d + d^2)*mw^4*Pi^d*
           ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
         d*s^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2)) - mw^2*s*(-3*d^3*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-32 + 36*d + 3*d^2 - 9*d^3 + 2*d^4)*s^2 + 
             (-32 + 52*d - 7*d^2 - 17*d^3 + 4*d^4)*s*t - 2*(-8 + 3*d + 4*d^2)*
              t^2))) + gZlL*gZuL*(d^3*(2*Pi)^d*s^4 + 2^(1 + d)*d*Pi^d*s^2*
          (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         2^(2 + d)*(-3 + 2*d + d^2)*mw^4*Pi^d*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2) + mw^2*s*(-3*d^3*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-16 + 22*d - 2*d^2 - 5*d^3 + 2*d^4)*s^2 + 
             (-64 + 64*d + 9*d^2 - 17*d^3 + 4*d^4)*s*t + 2*(-8 + 3*d + 4*d^2)*
              t^2))) + gZlR*gZuR*(d^3*(2*Pi)^d*s^4 + 2^(1 + d)*d*Pi^d*s^2*
          (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         2^(2 + d)*(-3 + 2*d + d^2)*mw^4*Pi^d*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2) + mw^2*s*(-3*d^3*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-16 + 22*d - 2*d^2 - 5*d^3 + 2*d^4)*s^2 + 
             (-64 + 64*d + 9*d^2 - 17*d^3 + 4*d^4)*s*t + 2*(-8 + 3*d + 4*d^2)*
              t^2))))*GaugeXi[Q] - 
     mw^2*(gZlR*gZuL*(-(d^3*(2*Pi)^d*s^3) - 2^(2 + d)*(-1 + d)^2*mw^2*Pi^d*
          ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
         2^(1 + d)*d*Pi^d*s*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
           2*t^2)) + gZlL*gZuR*(-(d^3*(2*Pi)^d*s^3) - 2^(2 + d)*(-1 + d)^2*
          mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
         2^(1 + d)*d*Pi^d*s*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 
           2*t^2)) + gZlL*gZuL*(d^3*(2*Pi)^d*s^3 - 2^(1 + d)*d*Pi^d*s*
          ((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         2^(2 + d)*(-1 + d)^2*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZuR*(d^3*(2*Pi)^d*s^3 - 2^(1 + d)*d*Pi^d*s*
          ((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
         2^(2 + d)*(-1 + d)^2*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)))*GaugeXi[Q]^2))/((-1 + d)*d*mw^4*Pi^(2*d)*
    (mz^2 - s)^2*s*GaugeXi[Q]), 
  (I*EL^6*gAl*gAu*gWWZ^2*((2*Pi)^(3*d)*s*(-((-2 + d)*gZlL*gZuL*s) + 
       (-4 + d)*gZlR*gZuL*s + (-4 + d)*gZlL*gZuR*s - (-2 + d)*gZlR*gZuR*s + 
       2*gZlL*gZuL*t + 2*gZlR*gZuL*t + 2*gZlL*gZuR*t + 2*gZlR*gZuR*t)*
      (mw^2 - s + mw^2*GaugeXi[Q])^2 - 2^(1 + 3*d)*Pi^(3*d)*s*
      (gZlL*gZuL*((-2 + d)*s - 2*t) + gZlR*gZuR*((-2 + d)*s - 2*t) - 
       gZlR*gZuL*((-4 + d)*s + 2*t) - gZlL*gZuR*((-4 + d)*s + 2*t))*
      (mw^2 - s + mw^2*GaugeXi[Q])^2 + (2*Pi)^(2*d)*s*
      (mw^2 - s + mw^2*GaugeXi[Q])*
      (-(gZlR*gZuL*(mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(1 + d)*s - 
              t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
       gZlR*gZuR*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
         mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))) + 
       gZlL*(-(gZuR*(mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(1 + d)*s - 
                t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
         gZuL*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
           mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t)))) + 
       mw^2*(gZlL*(-(d*gZuL*(2*Pi)^d*s) + d*gZuR*(2*Pi)^d*s + 
           2^(1 + d)*gZuR*Pi^d*(-2*s + t) + 2^(1 + d)*gZuL*Pi^d*(s + t)) + 
         gZlR*(d*gZuL*(2*Pi)^d*s - d*gZuR*(2*Pi)^d*s + 2^(1 + d)*gZuL*Pi^d*
            (-2*s + t) + 2^(1 + d)*gZuR*Pi^d*(s + t)))*GaugeXi[Q]) + 
     (2^(2 + 3*d)*(gZlL + gZlR)*(gZuL + gZuR)*Pi^(3*d)*s^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2))/(-1 + d) + 
     (2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZuL*((-4 + d)*s - 2*t) + 
        gZlR*gZuR*((-4 + d)*s - 2*t) - gZlR*gZuL*((-2 + d)*s + 2*t) - 
        gZlL*gZuR*((-2 + d)*s + 2*t))*((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2))/(-1 + d) - 
     (4*s*((2*Pi)^(3*d)*(-(gZlR*gZuL*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
             2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*
                t^2))) - gZlL*gZuR*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlL*gZuL*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) + 
          gZlR*gZuR*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) - 
        2^(1 + 3*d)*Pi^(3*d)*(-(gZlR*gZuL*((-4 + d)*s^2*t + 
             mw^4*((-4 + d)*s + 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
               (20 - 21*d + 4*d^2)*s*t - 8*t^2))) - 
          gZlL*gZuR*((-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 8*t^2)) + 
          gZlL*gZuL*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2)) + 
          gZlR*gZuR*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2)))*
         GaugeXi[Q] + (2*Pi)^(3*d)*(-(gZlR*gZuL*((-4 + d)*s^2*t + 
             2*mw^4*(2*(-4 + d)*s + (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*
                s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) - 
          gZlL*gZuR*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + (-8 + 3*d)*t) + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlL*gZuL*((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
            2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)) + 
          gZlR*gZuR*((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
            2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*
         (gZlR*gZuL*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t)) + 
          gZlL*gZuR*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t)) - 
          gZlL*gZuL*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)) - 
          gZlR*gZuR*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
         GaugeXi[Q]^3 - (-((-2 + d)*gZlL*gZuL) + (-4 + d)*gZlR*gZuL + 
          (-4 + d)*gZlL*gZuR - (-2 + d)*gZlR*gZuR)*mw^4*(2*Pi)^(3*d)*t*
         GaugeXi[Q]^4))/(-1 + GaugeXi[Q])^2))/(2^(4*(1 + d))*mw^4*Pi^(4*d)*
    (mz^2 - s)^2), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}}
