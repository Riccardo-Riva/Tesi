(* Created with the Wolfram Language : www.wolfram.com *)
{(-I/16)*EL^6*((2^(2 - d)*(16 - 7*d + d^2)*gAl*gAu^3*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-4 + d)*Pi^d*s*(-mzC^2 + s)) - (2^(2 - d)*gAl*gAu*(2*mz^2 - (-7 + d)*s)*
     (gZlL^2*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR^2*gZlRC*
       (-(gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
    (Pi^d*s^2*(-mzC^2 + s)) - (2^(2 - d)*(16 - 7*d + d^2)*gAu^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
    ((-4 + d)*Pi^d*(mzC^2 - s)*(-mz^2 + s)) - 
   (4^(1 - d)*gAl^3*gAu*(-(gZlRC*gZuLC*((-17 + d)*d^3*(2*Pi)^d*s^2 + 
         2^(1 + d)*Pi^d*((64 - 76*d + 33*d^2 + 2*d^3)*s^2 + 
           (64 - 108*d + 55*d^2 - 12*d^3 + d^4)*s*t - 2*(16 - 7*d + d^2)*
            t^2))) - gZlLC*gZuRC*((-17 + d)*d^3*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*((64 - 76*d + 33*d^2 + 2*d^3)*s^2 + 
          (64 - 108*d + 55*d^2 - 12*d^3 + d^4)*s*t - 2*(16 - 7*d + d^2)*
           t^2)) + gZlLC*gZuLC*((-15 + d)*d^3*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*(2*(16 - 23*d + 12*d^2 + d^3)*s^2 + 
          (128 - 136*d + 59*d^2 - 12*d^3 + d^4)*s*t + 2*(16 - 7*d + d^2)*
           t^2)) + gZlRC*gZuRC*((-15 + d)*d^3*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*(2*(16 - 23*d + 12*d^2 + d^3)*s^2 + 
          (128 - 136*d + 59*d^2 - 12*d^3 + d^4)*s*t + 2*(16 - 7*d + d^2)*
           t^2))))/((-4 + d)*Pi^(2*d)*(mzC^2 - s)*s) - 
   (4^(1 - d)*gWlN*gWNl*gZlLC*gZNL*
     (gZuL*gZuLC*((-11 + d)*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*mw^2*Pi^d*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
        2^(1 + d)*Pi^d*s*(2*(-7 + 8*d)*s^2 + (-56 + 43*d - 12*d^2 + d^3)*s*
           t + 2*(-7 + d)*t^2)) + gZuR*gZuRC*
       (2^(1 + d)*mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2) - s*((-13 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-28 + 25*d)*s^2 + (-28 + 39*d - 12*d^2 + d^3)*s*t - 
            2*(-7 + d)*t^2)))))/(Pi^(2*d)*(mz^2 - s)*s*(-mzC^2 + s)) + 
   (3*2^(3 - 2*d)*gAd^2*gAl*gAu*(gZlRC*(d^3*gZuLC*(2*Pi)^d*s^2 - 
        d^3*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*
         (-2*(4 - 5*d + 2*d^2)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
          2*(-2 + d)*t^2) + 2^(1 + d)*gZuRC*Pi^d*((4 - 6*d + 3*d^2)*s^2 - 
          (-16 + 18*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2)) + 
      gZlLC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
         (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
          2*(-2 + d)*t^2) + gZuLC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
             s*t - 2*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*s*(-mzC^2 + s)) + 
   (4^(2 - d)*gAl^3*gAu*(gZlRC*(d^3*gZuLC*(2*Pi)^d*s^2 - 
        d^3*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*
         (-2*(4 - 5*d + 2*d^2)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
          2*(-2 + d)*t^2) + 2^(1 + d)*gZuRC*Pi^d*((4 - 6*d + 3*d^2)*s^2 - 
          (-16 + 18*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2)) + 
      gZlLC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
         (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
          2*(-2 + d)*t^2) + gZuLC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
             s*t - 2*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*s*(-mzC^2 + s)) + 
   (3*2^(3 - 2*d)*gAl*gAu^3*(gZlRC*(d^3*gZuLC*(2*Pi)^d*s^2 - 
        d^3*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*
         (-2*(4 - 5*d + 2*d^2)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
          2*(-2 + d)*t^2) + 2^(1 + d)*gZuRC*Pi^d*((4 - 6*d + 3*d^2)*s^2 - 
          (-16 + 18*d - 7*d^2 + d^3)*s*t - 2*(-2 + d)*t^2)) + 
      gZlLC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
         (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
          2*(-2 + d)*t^2) + gZuLC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
             s*t - 2*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*s*(-mzC^2 + s)) - 
   (3*4^(1 - d)*gZNL^2*s*
     (gZlL*gZlLC*(gZuR*gZuRC*(-3*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((8 - 10*d + 4*d^2 + d^3)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) + gZuL*gZuLC*(d^3*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-4 + 6*d - 3*d^2)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*
             s*t + 2*(-2 + d)*t^2))) + gZlR*gZlRC*
       (gZuL*gZuLC*(d^3*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
           ((-8 + 10*d - 4*d^2 + d^3)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
            2*(-2 + d)*t^2)) + gZuR*gZuRC*(d^3*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-4 + 6*d - 3*d^2)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*
             s*t + 2*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) + 
   (2^(3 - 2*d)*s*(gZlL^3*gZlLC*(-(d^3*gZuL*gZuLC*(2*Pi)^d*s^2) + 
        3*d^3*gZuR*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*gZuLC*Pi^d*
         ((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*s*t - 
          2*(-2 + d)*t^2) - 2^(1 + d)*gZuR*gZuRC*Pi^d*
         ((8 - 10*d + 4*d^2 + d^3)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
          2*(-2 + d)*t^2)) + gZlL*gZlLC*gZlR^2*
       (gZuR*gZuRC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-8 + 10*d - 4*d^2 + d^3)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
            2*(-2 + d)*t^2)) + gZuL*gZuLC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
             s*t - 2*(-2 + d)*t^2))) + gZlL^2*gZlR*gZlRC*
       (gZuL*gZuLC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-8 + 10*d - 4*d^2 + d^3)*s^2 + (-8 + 14*d - 7*d^2 + d^3)*s*t - 
            2*(-2 + d)*t^2)) + gZuR*gZuRC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((4 - 6*d + 3*d^2)*s^2 - (-16 + 18*d - 7*d^2 + d^3)*
             s*t - 2*(-2 + d)*t^2))) - gZlR^3*gZlRC*
       (gZuL*gZuLC*(-3*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((8 - 10*d + 4*d^2 + d^3)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) + gZuR*gZuRC*(d^3*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-4 + 6*d - 3*d^2)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*
             s*t + 2*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) + 
   (4^(1 - d)*s*(gZlL*gZlLC*(gZuL^3*gZuLC*(-5*d^3*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((12 - 18*d + 9*d^2 + d^3)*s^2 - 
            3*(-16 + 18*d - 7*d^2 + d^3)*s*t - 6*(-2 + d)*t^2)) - 
        3*gZuL^2*gZuR*gZuRC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) - 3*gZuR^3*gZuRC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*(2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*
             s*t + 2*(-2 + d)*t^2)) - gZuL*gZuLC*gZuR^2*(d^3*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-12 + 18*d - 9*d^2 + d^3)*s^2 + 
            3*(-16 + 18*d - 7*d^2 + d^3)*s*t + 6*(-2 + d)*t^2))) + 
      gZlR*gZlRC*(gZuR^3*gZuRC*(-5*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((12 - 18*d + 9*d^2 + d^3)*s^2 - 3*(-16 + 18*d - 7*d^2 + d^3)*s*
             t - 6*(-2 + d)*t^2)) - 3*gZuL^3*gZuLC*(-(d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*(2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*
             s*t + 2*(-2 + d)*t^2)) - 3*gZuL*gZuLC*gZuR^2*
         (-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(4 - 5*d + 2*d^2)*s^2 - 
            (-8 + 14*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2)) - 
        gZuL^2*gZuR*gZuRC*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-12 + 18*d - 9*d^2 + d^3)*s^2 + 3*(-16 + 18*d - 7*d^2 + d^3)*s*
             t + 6*(-2 + d)*t^2)))))/((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) - (4^(1 - d)*((-2 + d)^2*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL^3*gZuLC + gZuR^3*gZuRC)*(2*Pi)^d*s^2*(2*mz^2 + s) + 
      (gZlL*gZlLC + gZlR*gZlRC)*(gZuL^3*gZuLC + gZuR^3*gZuRC)*
       (2^(1 + d)*Pi^d - d*(2*Pi)^d)*(s*(-((-2 + d)*s^2) + 4*s*t + 
          4*(-1 + d)*t^2) + 2*mz^2*((-2 + d)*s^2 + 4*(-1 + d)*s*t + 
          4*(-1 + d)*t^2)) + (2 - d)*(2*Pi)^d*s^2*
       (gZlL*gZlLC*(gZuR^3*gZuRC*(4*(-2 + d)*mz^2 + 
            (-80 + 60*d - 14*d^2 + d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^3)*
             t) + gZuL^3*gZuLC*(4*(-2 + d)*mz^2 - (-40 + 40*d - 12*d^2 + d^3)*
             s - 2*(-56 + 46*d - 12*d^2 + d^3)*t)) + 
        gZlR*gZlRC*(gZuL^3*gZuLC*(4*(-2 + d)*mz^2 + 
            (-80 + 60*d - 14*d^2 + d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^3)*
             t) + gZuR^3*gZuRC*(4*(-2 + d)*mz^2 - (-40 + 40*d - 12*d^2 + d^3)*
             s - 2*(-56 + 46*d - 12*d^2 + d^3)*t))) + 
      2^(1 + d)*(2 - d)*Pi^d*(s + 2*t)*
       (gZlL*gZlLC*(-(gZuR^3*gZuRC*(2*(-4 + d)*s*(s + t) + (-2 + d)*mz^2*
              ((-2 + d)*s + 2*t))) + gZuL^3*gZuLC*
           ((-2 + d)*mz^2*((-4 + d)*s - 2*t) + 2*s*((-2 + d)*s - 
              (-4 + d)*t))) + gZlR*gZlRC*
         (-(gZuL^3*gZuLC*(2*(-4 + d)*s*(s + t) + (-2 + d)*mz^2*
              ((-2 + d)*s + 2*t))) + gZuR^3*gZuRC*
           ((-2 + d)*mz^2*((-4 + d)*s - 2*t) + 2*s*((-2 + d)*s - 
              (-4 + d)*t)))) - (2 - d)*s^2*
       (gZlR*gZlRC*(gZuL^3*gZuLC*(-(d^2*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (2*(-1 + d)*s - (-2 + d)*t)) - gZuR^3*gZuRC*(-(d^2*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*((-4 + 3*d)*s + (-2 + d)*t))) + 
        gZlL*gZlLC*(gZuR^3*gZuRC*(-(d^2*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (2*(-1 + d)*s - (-2 + d)*t)) + gZuL^3*gZuLC*(d^2*(2*Pi)^d*s + 
            2^(1 + d)*Pi^d*(4*s - 3*d*s + 2*t - d*t))))))/
    ((-2 + d)*Pi^(2*d)*(mz^2 - s)*s*(-mzC^2 + s)) - 
   (4*gAl^2*(((-4 + d)*(-2 + d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/(2*Pi)^d + 
      ((gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        ((8 - 6*d + d^2)*s^2 - 4*(-4 + d)*s*t + 8*t^2))/(2*Pi)^d + 
      (2^(2 - d)*((-4 + d)*s - 2*t)*
        (gZlL*gZlLC*((-4 + d)*gZuR*gZuRC*(s + t) + gZuL*gZuLC*
            (-((-2 + d)*s) + (-4 + d)*t)) + gZlR*gZlRC*
          ((-4 + d)*gZuL*gZuLC*(s + t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             (-4 + d)*t))))/Pi^d + 
      ((-4 + d)*s*(gZlL*gZlLC*(gZuR*gZuRC*(-((-80 + 60*d - 14*d^2 + d^3)*s) - 
             2*(-52 + 44*d - 12*d^2 + d^3)*t) + gZuL*gZuLC*
            ((-40 + 40*d - 12*d^2 + d^3)*s + 2*(-56 + 46*d - 12*d^2 + d^3)*
              t)) + gZlR*gZlRC*(gZuL*gZuLC*(-((-80 + 60*d - 14*d^2 + d^3)*
               s) - 2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
           gZuR*gZuRC*((-40 + 40*d - 12*d^2 + d^3)*s + 
             2*(-56 + 46*d - 12*d^2 + d^3)*t))))/(2*Pi)^d - 
      (2^(2 - d)*(3 - d)*(gZlL*gZlLC*(-((-2 + d)*gZuR*gZuRC*
             ((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^2)) + gZuL*gZuLC*
            ((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + (-2 + d)*t^2)) + 
         gZlR*gZlRC*(-((-2 + d)*gZuL*gZuLC*((-4 + d)*s^2 + 2*(-4 + d)*s*t - 
              t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 
             (-2 + d)*t^2))))/Pi^d + 
      ((-4 + d)*s*(-(gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(-2*(-1 + d)*s + (-2 + d)*t)) + 
            gZuL*gZuLC*(-(d^2*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s + 
                (-2 + d)*t)))) + gZlR*gZlRC*
          (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s - 
               (-2 + d)*t)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
              (4*s - 3*d*s + 2*t - d*t)))))/(2*Pi)^(2*d)))/
    ((-4 + d)*(mz^2 - s)*(-mzC^2 + s)) + 
   (8*gAl^2*((2^(1 - d)*d*(gZlL + gZlR)*(gZlLC + gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/((-1 + d)*Pi^d) + 
      ((gZlL + gZlR)*(d*s + 2*t)*(-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + 
         gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*
            ((-2 + d)*s + 2*t))))/((-1 + d)*(2*Pi)^d) + 
      (s*(gZlR*((-4 + d)*gZlLC*gZuR*gZuRC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZlRC*gZuR*gZuRC*((-4 + d)*s + 2*t) - gZlLC*gZuL*gZuLC*
            ((-2 + d)^2*s + 2*(-4 + d)*t) - gZlRC*gZuL*gZuLC*
            ((-4 + d)^2*s - 2*(-2 + d)*t)) + 
         gZlL*((-4 + d)*gZlRC*gZuL*gZuLC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZlLC*gZuL*gZuLC*((-4 + d)*s + 2*t) - gZlRC*gZuR*gZuRC*
            ((-2 + d)^2*s + 2*(-4 + d)*t) - gZlLC*gZuR*gZuRC*
            ((-4 + d)^2*s - 2*(-2 + d)*t))))/(2*Pi)^d - 
      (s*((gZlL + gZlR)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*
              (-((-2 + d)*s) + 2*t))) - (-3 + d)*(gZlL - gZlR)*
          (gZlLC*(gZuR*gZuRC*((-4 + d)*s - 2*t) + gZuL*gZuLC*((-2 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s - 2*t) + 
             gZuR*gZuRC*((-2 + d)*s + 2*t)))))/(2*Pi)^d + 
      (gZlR*(gZlLC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
             ((4 - 3*d + d^2)*s^2 + (8 - 6*d + d^2)*s*t - 2*t^2)) + 
          gZlRC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 + (-4 + d)^2*s*t + 2*t^2)) + 
          gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((8 - 7*d + d^2)*s^2 + (-2 + d)^2*s*t + 2*t^2)) + 
          gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (8 - 6*d + d^2)*s*t + 2*t^2))) + 
        gZlL*(gZlRC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*
             ((4 - 3*d + d^2)*s^2 + (8 - 6*d + d^2)*s*t - 2*t^2)) + 
          gZlLC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 + (-4 + d)^2*s*t + 2*t^2)) + 
          gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((8 - 7*d + d^2)*s^2 + (-2 + d)^2*s*t + 2*t^2)) + 
          gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (8 - 6*d + d^2)*s*t + 2*t^2))))/(2*Pi)^(2*d)))/
    ((mz^2 - s)*(-mzC^2 + s)) + 
   (4*gAd*gAu*((3*2^(1 - d)*d*(gZdL + gZdR)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuLC + gZuRC)*s^2)/((-1 + d)*Pi^d) - 
      (3*(gZdL + gZdR)*(d*s + 2*t)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - 
           (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + 
         gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s + 2*gZuLC*t + 
           2*gZuRC*t)))/((-1 + d)*(2*Pi)^d) + 
      (3*s*(gZdL*gZlL*gZlLC*(-((-4 + d)^2*gZuRC*s) + 2*(-2 + d)*gZuRC*t + 
           (-2 + d)*gZuLC*((-4 + d)*s + 2*t)) + gZdR*gZlR*gZlRC*
          (-((-4 + d)^2*gZuLC*s) + 2*(-2 + d)*gZuLC*t + (-2 + d)*gZuRC*
            ((-4 + d)*s + 2*t)) + gZdR*gZlL*gZlLC*
          ((-4 + d)*gZuRC*((-2 + d)*s - 2*t) - gZuLC*((-2 + d)^2*s + 
             2*(-4 + d)*t)) + gZdL*gZlR*gZlRC*
          ((-4 + d)*gZuLC*((-2 + d)*s - 2*t) - gZuRC*((-2 + d)^2*s + 
             2*(-4 + d)*t))))/(2*Pi)^d - 
      (3*s*((gZdL + gZdR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
             2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
             (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)) - 
         (-3 + d)*(gZdL - gZdR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s + 
             (-4 + d)*gZuRC*s + 2*gZuLC*t - 2*gZuRC*t) - 
           gZlR*gZlRC*((-4 + d)*gZuLC*s + (-2 + d)*gZuRC*s - 2*gZuLC*t + 
             2*gZuRC*t))))/(2*Pi)^d - 
      (gZdR*gZlR*gZlRC*(d^2*gZuLC*(2*Pi)^d*s^2 + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 
            6*t^2) + 2^(1 + d)*gZuLC*Pi^d*((12 - 9*d + d^2)*s^2 + 
            3*(8 - 6*d + d^2)*s*t - 6*t^2)) + gZdL*gZlL*gZlLC*
         (d^2*gZuLC*(2*Pi)^d*s^2 + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 
            6*t^2) + 2^(1 + d)*gZuRC*Pi^d*((12 - 9*d + d^2)*s^2 + 
            3*(8 - 6*d + d^2)*s*t - 6*t^2)) - gZdR*gZlL*gZlLC*
         (d^2*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
           ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2) + 
          gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*s^2 + 
              3*(-2 + d)^2*s*t + 6*t^2))) + gZdL*gZlR*gZlRC*
         (gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
          gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*s^2 + 
              3*(-2 + d)^2*s*t + 6*t^2))))/(2*Pi)^(2*d)))/
    ((mz^2 - s)*(-mzC^2 + s)) - 
   (4^(1 - d)*(gZlR^3*gZlRC*(gZuR*gZuRC*((-11 + d)*d^2*(2*Pi)^d*s^3 - 
          2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
            4*t^2) + 2^(1 + d)*Pi^d*s*(2*(-7 + 8*d)*s^2 + 
            (-56 + 43*d - 12*d^2 + d^3)*s*t + 2*(-7 + d)*t^2)) + 
        gZuL*gZuLC*(2^(1 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2) - s*((-13 + d)*d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-28 + 25*d)*s^2 + (-28 + 39*d - 12*d^2 + d^3)*s*
               t - 2*(-7 + d)*t^2)))) + gZlL^3*gZlLC*
       (gZuL*gZuLC*((-11 + d)*d^2*(2*Pi)^d*s^3 - 2^(1 + d)*mz^2*Pi^d*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
          2^(1 + d)*Pi^d*s*(2*(-7 + 8*d)*s^2 + (-56 + 43*d - 12*d^2 + d^3)*s*
             t + 2*(-7 + d)*t^2)) + gZuR*gZuRC*
         (2^(1 + d)*mz^2*Pi^d*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2) - s*((-13 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((-28 + 25*d)*s^2 + (-28 + 39*d - 12*d^2 + d^3)*s*t - 
              2*(-7 + d)*t^2))))))/(Pi^(2*d)*(mz^2 - s)*s*(-mzC^2 + s)) + 
   (4^(1 - d)*s*(gZdR^2*(gZlR*gZlRC*(3*d^3*gZuL*gZuLC*(2*Pi)^d*s^2 - 
          5*d^3*gZuR*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuR*gZuRC*Pi^d*
           ((12 - 18*d + 9*d^2 + d^3)*s^2 - 3*(-16 + 18*d - 7*d^2 + d^3)*s*
             t - 6*(-2 + d)*t^2) - 3*2^(1 + d)*gZuL*gZuLC*Pi^d*
           (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) - gZlL*gZlLC*
         (3*gZuR*gZuRC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
              2*(-2 + d)*t^2)) + gZuL*gZuLC*(d^3*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-12 + 18*d - 9*d^2 + d^3)*s^2 + 3*(-16 + 18*d - 
                7*d^2 + d^3)*s*t + 6*(-2 + d)*t^2)))) + 
      gZdL^2*(gZlL*gZlLC*(-5*d^3*gZuL*gZuLC*(2*Pi)^d*s^2 + 
          3*d^3*gZuR*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuL*gZuLC*Pi^d*
           ((12 - 18*d + 9*d^2 + d^3)*s^2 - 3*(-16 + 18*d - 7*d^2 + d^3)*s*
             t - 6*(-2 + d)*t^2) - 3*2^(1 + d)*gZuR*gZuRC*Pi^d*
           (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) - gZlR*gZlRC*
         (3*gZuL*gZuLC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             (2*(4 - 5*d + 2*d^2)*s^2 - (-8 + 14*d - 7*d^2 + d^3)*s*t + 
              2*(-2 + d)*t^2)) + gZuR*gZuRC*(d^3*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-12 + 18*d - 9*d^2 + d^3)*s^2 + 3*(-16 + 18*d - 
                7*d^2 + d^3)*s*t + 6*(-2 + d)*t^2))))))/
    ((-1 + d)*Pi^(2*d)*(mz^2 - s)^2*(-mzC^2 + s)) - 
   (4*gAl*gAu*(((-2 + d)*(gZlLC + gZlRC)*(gZuL^2*gZuLC + gZuR^2*gZuRC)*s^2*
        (2*mz^2 + s))/(2*Pi)^d - 
      (s^2*(gZlRC*gZuL^2*gZuLC*(4*(-2 + d)*mz^2 + (-80 + 60*d - 14*d^2 + d^3)*
            s + 2*(-52 + 44*d - 12*d^2 + d^3)*t) + gZlLC*gZuR^2*gZuRC*
          (4*(-2 + d)*mz^2 + (-80 + 60*d - 14*d^2 + d^3)*s + 
           2*(-52 + 44*d - 12*d^2 + d^3)*t) + gZlLC*gZuL^2*gZuLC*
          (4*(-2 + d)*mz^2 - (-40 + 40*d - 12*d^2 + d^3)*s - 
           2*(-56 + 46*d - 12*d^2 + d^3)*t) + gZlRC*gZuR^2*gZuRC*
          (4*(-2 + d)*mz^2 - (-40 + 40*d - 12*d^2 + d^3)*s - 
           2*(-56 + 46*d - 12*d^2 + d^3)*t)))/(2*Pi)^d - 
      ((gZlLC + gZlRC)*(gZuL^2*gZuLC + gZuR^2*gZuRC)*
        (s*(-((-2 + d)*s^2) + 4*s*t + 4*(-1 + d)*t^2) + 
         2*mz^2*((-2 + d)*s^2 + 4*(-1 + d)*s*t + 4*(-1 + d)*t^2)))/(2*Pi)^d + 
      ((-2 + d)*s^2*(-(gZlRC*(gZuR^2*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL^2*gZuLC*((-2 + d)*s + 2*t))) + 
         gZlLC*(gZuL^2*gZuLC*((-4 + d)*s - 2*t) - gZuR^2*gZuRC*
            ((-2 + d)*s + 2*t))))/(2*Pi)^d - 
      (s + 2*t)*(-((2^(2 - d)*(-2 + d)*(gZlLC + gZlRC)*(gZuL^2*gZuLC + 
            gZuR^2*gZuRC)*s*t)/Pi^d) + 
        ((-2 + d)*mz^2*(gZlLC*gZuL^2*gZuLC*((-6 + d)*s - 2*t) - 
           gZlLC*gZuR^2*gZuRC*(d*s + 2*t) - 
           gZlRC*(d*(gZuL^2*gZuLC - gZuR^2*gZuRC)*s + 2*gZuL^2*gZuLC*t + 
             2*gZuR^2*gZuRC*(3*s + t))))/(2*Pi)^d + 
        ((-2 + d)*mz^2*(gZlLC*(gZuL^2*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR^2*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL^2*gZuLC*((-4 + d)*s + 2*t) + gZuR^2*gZuRC*
              (-((-2 + d)*s) + 2*t))))/(2*Pi)^d - 
        (4^(1 - d)*s*(gZlRC*gZuR^2*gZuRC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(s - t)) - gZlRC*gZuL^2*gZuLC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s + t)) + gZlLC*
            (gZuL^2*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
             gZuR^2*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))))/
         Pi^(2*d))))/((mzC^2 - s)*s^2) + 
   (8*gAl*gAu*((2^(1 - d)*d*(gZlL + gZlR)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuLC + gZuRC)*s^2)/((-1 + d)*Pi^d) + 
      ((gZlL + gZlR)*(d*s + 2*t)*(gZlR*gZlRC*(-((-2 + d)*gZuLC*s) + 
           (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) + 
         gZlL*gZlLC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t)))/((-1 + d)*(2*Pi)^d) + 
      (s*(gZlL^2*gZlLC*(-((-4 + d)^2*gZuRC*s) + 2*(-2 + d)*gZuRC*t + 
           (-2 + d)*gZuLC*((-4 + d)*s + 2*t)) + gZlR^2*gZlRC*
          (-((-4 + d)^2*gZuLC*s) + 2*(-2 + d)*gZuLC*t + (-2 + d)*gZuRC*
            ((-4 + d)*s + 2*t)) + gZlL*gZlR*((-4 + d)*gZlRC*gZuLC*
            ((-2 + d)*s - 2*t) + (-4 + d)*gZlLC*gZuRC*((-2 + d)*s - 2*t) - 
           gZlLC*gZuLC*((-2 + d)^2*s + 2*(-4 + d)*t) - gZlRC*gZuRC*
            ((-2 + d)^2*s + 2*(-4 + d)*t))))/(2*Pi)^d - 
      (s*((gZlL + gZlR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
             2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
             (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)) - 
         (-3 + d)*(gZlL - gZlR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s + 
             (-4 + d)*gZuRC*s + 2*gZuLC*t - 2*gZuRC*t) - 
           gZlR*gZlRC*((-4 + d)*gZuLC*s + (-2 + d)*gZuRC*s - 2*gZuLC*t + 
             2*gZuRC*t))))/(2*Pi)^d + 
      (gZlR^2*gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) - d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((-4 + 3*d)*s^2 + (-4 + d)^2*s*t + 2*t^2) + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (8 - 6*d + d^2)*s*t + 
            2*t^2)) + gZlL^2*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) - 
          d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 + 
            (-4 + d)^2*s*t + 2*t^2) + 2^(1 + d)*gZuRC*Pi^d*
           ((-4 + 3*d)*s^2 - (8 - 6*d + d^2)*s*t + 2*t^2)) + 
        gZlL*gZlR*(gZlLC*(d^2*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
             ((4 - 3*d + d^2)*s^2 + (8 - 6*d + d^2)*s*t - 2*t^2) + 
            gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((8 - 7*d + d^2)*s^2 + 
                (-2 + d)^2*s*t + 2*t^2))) + gZlRC*(d^2*gZuLC*(2*Pi)^d*s^2 - 
            2^(1 + d)*gZuLC*Pi^d*((4 - 3*d + d^2)*s^2 + (8 - 6*d + d^2)*s*t - 
              2*t^2) + gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(
                (8 - 7*d + d^2)*s^2 + (-2 + d)^2*s*t + 2*t^2)))))/
       (2*Pi)^(2*d)))/((mz^2 - s)*(-mzC^2 + s)) + 
   (4*gAd*gAl*((3*2^(1 - d)*d*(gZdL + gZdR)*(gZlLC + gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/((-1 + d)*Pi^d) + 
      (3*(gZdL + gZdR)*(d*s + 2*t)*
        (-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZuL*gZuLC*
             ((-2 + d)*s + 2*t))) + gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - 
           gZuR*gZuRC*((-2 + d)*s + 2*t))))/((-1 + d)*(2*Pi)^d) + 
      (3*s*(gZdR*((-4 + d)*gZlLC*gZuR*gZuRC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZlRC*gZuR*gZuRC*((-4 + d)*s + 2*t) - gZlLC*gZuL*gZuLC*
            ((-2 + d)^2*s + 2*(-4 + d)*t) - gZlRC*gZuL*gZuLC*
            ((-4 + d)^2*s - 2*(-2 + d)*t)) + 
         gZdL*((-4 + d)*gZlRC*gZuL*gZuLC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZlLC*gZuL*gZuLC*((-4 + d)*s + 2*t) - gZlRC*gZuR*gZuRC*
            ((-2 + d)^2*s + 2*(-4 + d)*t) - gZlLC*gZuR*gZuRC*
            ((-4 + d)^2*s - 2*(-2 + d)*t))))/(2*Pi)^d - 
      (3*s*((gZdL + gZdR)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*
              (-((-2 + d)*s) + 2*t))) - (-3 + d)*(gZdL - gZdR)*
          (gZlLC*(gZuR*gZuRC*((-4 + d)*s - 2*t) + gZuL*gZuLC*((-2 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s - 2*t) + 
             gZuR*gZuRC*((-2 + d)*s + 2*t)))))/(2*Pi)^d - 
      (gZdL*(gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 6*t^2)) + 
          gZlLC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((12 - 9*d + d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) + 
          gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
          gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((24 - 21*d + 4*d^2)*s^2 + 3*(-2 + d)^2*s*t + 6*t^2))) + 
        gZdR*(gZlRC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(
                (12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 6*t^2)) + 
            gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((12 - 9*d + d^2)*
                 s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2))) - 
          gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 - 2^(1 + d)*Pi^d*(
                (12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) + 
            gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(
                (24 - 21*d + 4*d^2)*s^2 + 3*(-2 + d)^2*s*t + 6*t^2)))))/
       (2*Pi)^(2*d)))/((mz^2 - s)*(-mzC^2 + s)) + 
   (4*gAl*gAu*((3*2^(1 - d)*d*(gZlLC + gZlRC)*(gZuL + gZuR)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/((-1 + d)*Pi^d) + 
      (3*(gZuL + gZuR)*(d*s + 2*t)*(gZlLC*gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + 
         gZlRC*gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*
          ((-2 + d)*s + 2*t) + gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t)))/
       ((1 - d)*(2*Pi)^d) + 
      (3*s*(gZlRC*((-4 + d)*gZuL^2*gZuLC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZuR^2*gZuRC*((-4 + d)*s + 2*t) - 
           gZuL*gZuR*((-4 + d)^2*gZuLC*s + (-2 + d)^2*gZuRC*s - 
             2*(-2 + d)*gZuLC*t + 2*(-4 + d)*gZuRC*t)) + 
         gZlLC*((-4 + d)*gZuR^2*gZuRC*((-2 + d)*s - 2*t) + 
           (-2 + d)*gZuL^2*gZuLC*((-4 + d)*s + 2*t) - 
           gZuL*gZuR*((-2 + d)^2*gZuLC*s + (-4 + d)^2*gZuRC*s + 
             2*(-4 + d)*gZuLC*t - 2*(-2 + d)*gZuRC*t))))/(2*Pi)^d - 
      (3*s*((gZuL + gZuR)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*
              (-((-2 + d)*s) + 2*t))) - (-3 + d)*(gZuL - gZuR)*
          (gZlLC*(gZuR*gZuRC*((-4 + d)*s - 2*t) + gZuL*gZuLC*((-2 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s - 2*t) + 
             gZuR*gZuRC*((-2 + d)*s + 2*t)))))/(2*Pi)^d - 
      (gZlLC*(gZuL^2*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 6*t^2)) + 
          gZuR^2*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) + 
          gZuL*gZuR*(gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(
                (12 - 9*d + d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
            gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*
                 s^2 + 3*(-2 + d)^2*s*t + 6*t^2)))) + 
        gZlRC*(gZuR^2*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 6*t^2)) + 
          gZuL^2*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) + 
          gZuL*gZuR*(gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(
                (12 - 9*d + d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
            gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*
                 s^2 + 3*(-2 + d)^2*s*t + 6*t^2)))))/(2*Pi)^(2*d)))/
    ((mz^2 - s)*(-mzC^2 + s)) + 
   (4*gAu^2*((3*2^(1 - d)*d*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL + gZuR)*
        (gZuLC + gZuRC)*s^2)/((-1 + d)*Pi^d) - 
      (3*(gZuL + gZuR)*(d*s + 2*t)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - 
           (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + 
         gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s + 2*gZuLC*t + 
           2*gZuRC*t)))/((-1 + d)*(2*Pi)^d) + 
      (3*s*(gZlL*gZlLC*(-((-4 + d)^2*gZuL*gZuRC*s) + (-4 + d)*gZuR*gZuRC*
            ((-2 + d)*s - 2*t) + 2*(-2 + d)*gZuL*gZuRC*t + 
           (-2 + d)*gZuL*gZuLC*((-4 + d)*s + 2*t) - gZuLC*gZuR*
            ((-2 + d)^2*s + 2*(-4 + d)*t)) + gZlR*gZlRC*
          (-((-4 + d)^2*gZuLC*gZuR*s) + (-4 + d)*gZuL*gZuLC*
            ((-2 + d)*s - 2*t) + 2*(-2 + d)*gZuLC*gZuR*t + 
           (-2 + d)*gZuR*gZuRC*((-4 + d)*s + 2*t) - gZuL*gZuRC*
            ((-2 + d)^2*s + 2*(-4 + d)*t))))/(2*Pi)^d - 
      (3*s*((gZuL + gZuR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
             2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
             (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)) - 
         (-3 + d)*(gZuL - gZuR)*(gZlL*gZlLC*((-2 + d)*gZuLC*s + 
             (-4 + d)*gZuRC*s + 2*gZuLC*t - 2*gZuRC*t) - 
           gZlR*gZlRC*((-4 + d)*gZuLC*s + (-2 + d)*gZuRC*s - 2*gZuLC*t + 
             2*gZuRC*t))))/(2*Pi)^d - 
      (gZlL*gZlLC*(gZuL*(d^2*gZuLC*(2*Pi)^d*s^2 + d^2*gZuRC*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuLC*Pi^d*((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 
              6*t^2) + 2^(1 + d)*gZuRC*Pi^d*((12 - 9*d + d^2)*s^2 + 
              3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
          gZuR*(d^2*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
             ((12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2) + 
            gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*
                 s^2 + 3*(-2 + d)^2*s*t + 6*t^2)))) + 
        gZlR*gZlRC*(gZuR*(d^2*gZuLC*(2*Pi)^d*s^2 + d^2*gZuRC*(2*Pi)^d*s^2 + 
            2^(1 + d)*gZuRC*Pi^d*((12 - 9*d + d^2)*s^2 - 3*(-4 + d)^2*s*t - 
              6*t^2) + 2^(1 + d)*gZuLC*Pi^d*((12 - 9*d + d^2)*s^2 + 
              3*(8 - 6*d + d^2)*s*t - 6*t^2)) + 
          gZuL*(gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(
                (12 - 9*d + 2*d^2)*s^2 + 3*(8 - 6*d + d^2)*s*t - 6*t^2)) - 
            gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((24 - 21*d + 4*d^2)*
                 s^2 + 3*(-2 + d)^2*s*t + 6*t^2)))))/(2*Pi)^(2*d)))/
    ((mz^2 - s)*(-mzC^2 + s)) + (4^(1 - d)*gWdu*gWud*gZdL*gZuLC*
     (gZlL*gZlLC*(-(d^3*(1 + d)*(2*Pi)^d*s^3) + 2^(1 + d)*(-2 + d)*mw^2*Pi^d*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
        2^(1 + d)*Pi^d*s*((-28 + 46*d - 27*d^2 + 7*d^3)*s^2 - 
          (112 - 142*d + 67*d^2 - 14*d^3 + d^4)*s*t - 2*(14 - 9*d + d^2)*
           t^2)) + gZlR*gZlRC*(d^3*(1 + d)*(2*Pi)^d*s^3 - 
        2^(1 + d)*(-2 + d)*mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2) - 2^(1 + d)*Pi^d*s*
         ((-56 + 78*d - 38*d^2 + 8*d^3)*s^2 - (56 - 106*d + 63*d^2 - 14*d^3 + 
            d^4)*s*t + 2*(14 - 9*d + d^2)*t^2)))*CKM[1, 1]*CKMC[1, 1])/
    ((-2 + d)*Pi^(2*d)*(mz^2 - s)*s*(-mzC^2 + s)) - 
   (4^(1 - d)*gAd*gAl*gWdu*gWud*gZuLC*
     (-(2^(1 + d)*gZlLC*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2)) + gZlLC*s*((-11 + d)*d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*(2*(-7 + 8*d)*s^2 + (-56 + 43*d - 12*d^2 + d^3)*s*t + 
          2*(-7 + d)*t^2)) + gZlRC*(2^(1 + d)*mw^2*Pi^d*
         ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
        s*((-13 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-28 + 25*d)*s^2 + 
            (-28 + 39*d - 12*d^2 + d^3)*s*t - 2*(-7 + d)*t^2))))*CKM[1, 1]*
     CKMC[1, 1])/(Pi^(2*d)*(mzC^2 - s)*s^2) + 
   (gAl^2*gAu^2*(gZlRC*(5*d^4*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
         ((1440 - 1472*d + 506*d^2 - 66*d^3 + 5*d^4)*s^2 + 
          (256 - 272*d + 32*d^2 + 19*d^3 - 3*d^4)*s*t - 
          2*(176 - 80*d + 7*d^2)*t^2) + gZuLC*(-5*d^4*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((1344 - 1256*d + 424*d^2 - 59*d^3 + 5*d^4)*s^2 + 
            (1088 - 608*d + 52*d^2 + 19*d^3 - 3*d^4)*s*t + 
            2*(176 - 80*d + 7*d^2)*t^2))) + 
      gZlLC*(5*d^4*gZuLC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuLC*Pi^d*
         ((1440 - 1472*d + 506*d^2 - 66*d^3 + 5*d^4)*s^2 + 
          (256 - 272*d + 32*d^2 + 19*d^3 - 3*d^4)*s*t - 
          2*(176 - 80*d + 7*d^2)*t^2) + gZuRC*(-5*d^4*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((1344 - 1256*d + 424*d^2 - 59*d^3 + 5*d^4)*s^2 + 
            (1088 - 608*d + 52*d^2 + 19*d^3 - 3*d^4)*s*t + 
            2*(176 - 80*d + 7*d^2)*t^2))) - 
      2*(gZlLC*(3*d^4*gZuLC*(2*Pi)^d*s^2 - 3*d^4*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((-128 + 176*d - 88*d^2 + 19*d^3)*s^2 - 
            (-4 + d)^2*(8 - 11*d + 3*d^2)*s*t + 2*(32 - 20*d + 3*d^2)*t^2) + 
          2^(1 + d)*gZuLC*Pi^d*(-2*(-32 + 52*d - 31*d^2 + 8*d^3)*s^2 + 
            (256 - 320*d + 156*d^2 - 35*d^3 + 3*d^4)*s*t + 
            2*(32 - 20*d + 3*d^2)*t^2)) + gZlRC*(3*d^4*gZuRC*(2*Pi)^d*s^2 - 
          2^(1 + d)*gZuRC*Pi^d*(2*(-32 + 52*d - 31*d^2 + 8*d^3)*s^2 + 
            (-256 + 320*d - 156*d^2 + 35*d^3 - 3*d^4)*s*t - 
            2*(32 - 20*d + 3*d^2)*t^2) + gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-128 + 176*d - 88*d^2 + 19*d^3)*s^2 - 
              (-4 + d)^2*(8 - 11*d + 3*d^2)*s*t + 2*(32 - 20*d + 3*d^2)*t^
                2))))*GaugeXi[Q] + (3*d^4*gZlLC*gZuRC*(2*Pi)^d*s^2 - 
        3*d^4*gZlRC*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZlRC*gZuRC*Pi^d*
         ((-32 + 48*d - 26*d^2 + 6*d^3 + d^4)*s^2 - (-4 + d)^2*
           (8 - 5*d + d^2)*s*t - 2*(-4 + d)^2*t^2) - 2^(1 + d)*gZlLC*gZuRC*
         Pi^d*((-64 + 80*d - 36*d^2 + 7*d^3 + d^4)*s^2 - (-4 + d)^3*(-1 + d)*
           s*t + 2*(-4 + d)^2*t^2) + gZlLC*gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-32 + 48*d - 26*d^2 + 6*d^3 + d^4)*s^2 - 
            (-4 + d)^2*(8 - 5*d + d^2)*s*t - 2*(-4 + d)^2*t^2)) - 
        gZlRC*gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-64 + 80*d - 36*d^2 + 7*d^3 + d^4)*s^2 - (-4 + d)^3*(-1 + d)*s*
             t + 2*(-4 + d)^2*t^2)))*GaugeXi[Q]^2))/
    ((-4 + d)*(2*Pi)^(2*d)*(mzC^2 - s)*s) - 
   (gAl^2*gAu^2*(gZlLC*(13*d^4*gZuLC*(2*Pi)^d*s^2 - 13*d^4*gZuRC*(2*Pi)^d*
         s^2 - 2^(1 + d)*gZuLC*Pi^d*((-128 + 288*d - 206*d^2 + 58*d^3 + d^4)*
           s^2 + (384 - 288*d + 24*d^2 + 19*d^3 - 3*d^4)*s*t - 
          2*(176 - 80*d + 7*d^2)*t^2) + 2^(1 + d)*gZuRC*Pi^d*
         ((-352 + 520*d - 280*d^2 + 65*d^3 + d^4)*s^2 + 
          (960 - 592*d + 60*d^2 + 19*d^3 - 3*d^4)*s*t + 
          2*(176 - 80*d + 7*d^2)*t^2)) + gZlRC*(13*d^4*gZuRC*(2*Pi)^d*s^2 - 
        2^(1 + d)*gZuRC*Pi^d*((-128 + 288*d - 206*d^2 + 58*d^3 + d^4)*s^2 + 
          (384 - 288*d + 24*d^2 + 19*d^3 - 3*d^4)*s*t - 
          2*(176 - 80*d + 7*d^2)*t^2) + gZuLC*(-13*d^4*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-352 + 520*d - 280*d^2 + 65*d^3 + d^4)*s^2 + 
            (960 - 592*d + 60*d^2 + 19*d^3 - 3*d^4)*s*t + 
            2*(176 - 80*d + 7*d^2)*t^2))) - 
      2*(gZlLC*(3*d^4*gZuLC*(2*Pi)^d*s^2 - 3*d^4*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((-128 + 176*d - 88*d^2 + 19*d^3)*s^2 - 
            (-4 + d)^2*(8 - 11*d + 3*d^2)*s*t + 2*(32 - 20*d + 3*d^2)*t^2) + 
          2^(1 + d)*gZuLC*Pi^d*(-2*(-32 + 52*d - 31*d^2 + 8*d^3)*s^2 + 
            (256 - 320*d + 156*d^2 - 35*d^3 + 3*d^4)*s*t + 
            2*(32 - 20*d + 3*d^2)*t^2)) + gZlRC*(3*d^4*gZuRC*(2*Pi)^d*s^2 - 
          2^(1 + d)*gZuRC*Pi^d*(2*(-32 + 52*d - 31*d^2 + 8*d^3)*s^2 + 
            (-256 + 320*d - 156*d^2 + 35*d^3 - 3*d^4)*s*t - 
            2*(32 - 20*d + 3*d^2)*t^2) + gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((-128 + 176*d - 88*d^2 + 19*d^3)*s^2 - 
              (-4 + d)^2*(8 - 11*d + 3*d^2)*s*t + 2*(32 - 20*d + 3*d^2)*t^
                2))))*GaugeXi[Q] + (3*d^4*gZlLC*gZuRC*(2*Pi)^d*s^2 - 
        3*d^4*gZlRC*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZlRC*gZuRC*Pi^d*
         ((-32 + 48*d - 26*d^2 + 6*d^3 + d^4)*s^2 - (-4 + d)^2*
           (8 - 5*d + d^2)*s*t - 2*(-4 + d)^2*t^2) - 2^(1 + d)*gZlLC*gZuRC*
         Pi^d*((-64 + 80*d - 36*d^2 + 7*d^3 + d^4)*s^2 - (-4 + d)^3*(-1 + d)*
           s*t + 2*(-4 + d)^2*t^2) + gZlLC*gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-32 + 48*d - 26*d^2 + 6*d^3 + d^4)*s^2 - 
            (-4 + d)^2*(8 - 5*d + d^2)*s*t - 2*(-4 + d)^2*t^2)) - 
        gZlRC*gZuLC*(-3*d^4*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-64 + 80*d - 36*d^2 + 7*d^3 + d^4)*s^2 - (-4 + d)^3*(-1 + d)*s*
             t + 2*(-4 + d)^2*t^2)))*GaugeXi[Q]^2))/
    ((-4 + d)*(2*Pi)^(2*d)*(mzC^2 - s)*s)), 
 ((I/4)*EL^6*(gAl^2*gAu^2*((((8 + 12*d - 8*d^2 + d^3)*gZlLC*gZuLC - 
         (-8 + 18*d - 8*d^2 + d^3)*gZlRC*gZuLC - (-8 + 18*d - 8*d^2 + d^3)*
          gZlLC*gZuRC + (8 + 12*d - 8*d^2 + d^3)*gZlRC*gZuRC)*
        (1 - (2*s)/((-4 + d)*t))*t)/(2*Pi)^d + 
      (2^(2 - d)*(-3 + d)*(-((-4 + d)*gZlRC*gZuLC*((-2 - 2*d + d^2)*s + 
            4*(-2 + d)*t)) - (-4 + d)*gZlLC*gZuRC*((-2 - 2*d + d^2)*s + 
           4*(-2 + d)*t) + gZlLC*gZuLC*((16 + 4*d - 6*d^2 + d^3)*s + 
           4*(10 - 6*d + d^2)*t) + gZlRC*gZuRC*((16 + 4*d - 6*d^2 + d^3)*s + 
           4*(10 - 6*d + d^2)*t)))/((-4 + d)*Pi^d) + 
      ((-4 + d)*gZlLC*gZuRC*((2 - 4*d + d^2)*s - (26 - 12*d + d^2)*t) + 
        gZlLC*gZuLC*(-((8 + 12*d - 8*d^2 + d^3)*s) + 
          (-112 + 76*d - 16*d^2 + d^3)*t) + 
        gZlRC*(-((8 + 12*d - 8*d^2 + d^3)*gZuRC*s) + 
          (-112 + 76*d - 16*d^2 + d^3)*gZuRC*t + (-4 + d)*gZuLC*
           ((2 - 4*d + d^2)*s - (26 - 12*d + d^2)*t)))/(2*Pi)^d) + 
    (gZlR^2*gZlRC*(gZuR^2*gZuRC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((4 + 6*d - 4*d^2 + d^3)*s + (-52 + 44*d - 12*d^2 + d^3)*t)) - 
        gZuL^2*gZuLC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((-4 + 9*d - 4*d^2 + d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*t))) + 
      gZlL^2*gZlLC*(gZuL^2*gZuLC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((4 + 6*d - 4*d^2 + d^3)*s + (-52 + 44*d - 12*d^2 + d^3)*t)) - 
        gZuR^2*gZuRC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
           ((-4 + 9*d - 4*d^2 + d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*t))))/
     (2*Pi)^(2*d) - (2^(1 - 2*d)*gAl*gAu*
      (gZlR*gZlRC*(gZuR*gZuRC*(mz^2*(2^(2 + d)*(-6 - 7*d + 9*d^2)*Pi^d + 
             (-11 + d)*d^3*(2*Pi)^d) + 19*d^3*(2*Pi)^d*s - 
           2^(1 + d)*Pi^d*((-52 - 2*d + 26*d^2 + d^4)*s + 
             (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) - 
         gZuL*gZuLC*(mz^2*(2^(1 + d)*(12 - 31*d + 21*d^2)*Pi^d + 
             (-11 + d)*d^3*(2*Pi)^d) + 19*d^3*(2*Pi)^d*s - 
           2^(1 + d)*Pi^d*((-20 - 19*d + 28*d^2 + d^4)*s + 
             (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t))) + 
       gZlL*gZlLC*(gZuL*gZuLC*(mz^2*(2^(2 + d)*(-6 - 7*d + 9*d^2)*Pi^d + 
             (-11 + d)*d^3*(2*Pi)^d) + 19*d^3*(2*Pi)^d*s - 
           2^(1 + d)*Pi^d*((-52 - 2*d + 26*d^2 + d^4)*s + 
             (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
         gZuR*gZuRC*(-(mz^2*(2^(1 + d)*(12 - 31*d + 21*d^2)*Pi^d + 
              (-11 + d)*d^3*(2*Pi)^d)) - 19*d^3*(2*Pi)^d*s + 
           2^(1 + d)*Pi^d*((-20 - 19*d + 28*d^2 + d^4)*s + 
             (128 - 136*d + 58*d^2 - 12*d^3 + d^4)*t)))))/
     ((-4 + d)*Pi^(2*d))))/(mzC^2 - s), 
 ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*t*
   (-(gZlRC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(2 + d)*gZuRC*Pi^d*
        ((-2 - 3*d + 2*d^2)*s^2 + 2*(-2 + d)*s*t + 4*t^2) + 
       gZuLC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
           4*(-4 + d)*s*t - 8*t^2)))) + 
    gZlLC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
       ((4 - 9*d + 4*d^2)*s^2 + 4*(-4 + d)*s*t - 8*t^2) + 
      gZuLC*(-(d^3*(2*Pi)^d*s^2) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
          2*(-2 + d)*s*t + 4*t^2)))))/(Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*4^(-1 - 3*d)*EL^6*
   (gAl*gAu*(-(32^(1 + d)*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2) + 
      5*2^(3 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 - 
      2^(4 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 + 
      2^(1 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 + 
      2^(6 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 - 
      2^(6 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 + 
      5*2^(2 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 - 
      2^(1 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s^2 + 
      2^(6 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 - 
      2^(6 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 + 
      5*2^(2 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 - 
      2^(1 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 - 
      32^(1 + d)*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 + 
      5*2^(3 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 - 
      2^(4 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 + 
      2^(1 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s^2 + 
      2^(4 + 5*d)*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 - 
      5*2^(2 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 + 
      2^(3 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 - 
      32^(1 + d)*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 + 
      32^(1 + d)*d*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 - 
      5*2^(1 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^3 - 
      32^(1 + d)*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 + 
      32^(1 + d)*d*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 - 
      5*2^(1 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 + 
      2^(4 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 - 
      5*2^(2 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 + 
      2^(3 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^3 - 
      d^3*gZlLC*gZuL^2*gZuLC*mz^4*(2*Pi)^(5*d)*s^3 + 
      d^3*gZlRC*gZuL^2*gZuLC*mz^4*(2*Pi)^(5*d)*s^3 + 
      d^3*gZlLC*gZuR^2*gZuRC*mz^4*(2*Pi)^(5*d)*s^3 - 
      d^3*gZlRC*gZuR^2*gZuRC*mz^4*(2*Pi)^(5*d)*s^3 + 2^(6 + 5*d)*gZlLC*gZuL^2*
       gZuLC*mz^2*Pi^(5*d)*s^4 - 5*2^(4 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^2*
       Pi^(5*d)*s^4 + 32^(1 + d)*d^2*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 - 
      2^(2 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 - 
      2^(7 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 + 
      2^(7 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 - 
      5*2^(3 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 + 
      2^(2 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^4 - 
      2^(7 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 + 
      2^(7 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 - 
      5*2^(3 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 + 
      2^(2 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 + 
      2^(6 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 - 
      5*2^(4 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 + 
      32^(1 + d)*d^2*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 - 
      2^(2 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^4 - 
      3*2^(4 + 5*d)*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^5 + 
      15*2^(2 + 5*d)*d*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^5 - 
      3*2^(3 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^5 + 
      3*32^(1 + d)*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^5 - 
      3*32^(1 + d)*d*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^5 + 
      15*2^(1 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^5 + 
      3*32^(1 + d)*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^5 - 
      3*32^(1 + d)*d*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^5 + 
      15*2^(1 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^5 - 
      3*2^(4 + 5*d)*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^5 + 
      15*2^(2 + 5*d)*d*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^5 - 
      3*2^(3 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^5 + 
      3*d^3*gZlLC*gZuL^2*gZuLC*(2*Pi)^(5*d)*s^5 - 3*d^3*gZlRC*gZuL^2*gZuLC*
       (2*Pi)^(5*d)*s^5 - 3*d^3*gZlLC*gZuR^2*gZuRC*(2*Pi)^(5*d)*s^5 + 
      3*d^3*gZlRC*gZuR^2*gZuRC*(2*Pi)^(5*d)*s^5 - 2^(7 + 5*d)*gZlLC*gZuL^2*
       gZuLC*mz^6*Pi^(5*d)*s*t + 7*2^(4 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^6*
       Pi^(5*d)*s*t - 9*2^(2 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*
       t + 2^(2 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*t + 
      2^(6 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*t - 
      3*32^(1 + d)*d*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*t + 
      9*2^(2 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*t - 
      2^(2 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*s*t + 
      2^(6 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t - 
      3*32^(1 + d)*d*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t + 
      9*2^(2 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t - 
      2^(2 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t - 
      2^(7 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t + 
      7*2^(4 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t - 
      9*2^(2 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t + 
      2^(2 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*s*t + 
      2^(6 + 5*d)*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t - 
      7*2^(3 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t + 
      9*2^(1 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t - 
      2^(1 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t - 
      32^(1 + d)*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t + 
      3*2^(4 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t - 
      9*2^(1 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t + 
      2^(1 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s^2*t - 
      32^(1 + d)*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t + 
      3*2^(4 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t - 
      9*2^(1 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t + 
      2^(1 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t + 
      2^(6 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t - 
      7*2^(3 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t + 
      9*2^(1 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t - 
      2^(1 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s^2*t + 
      2^(8 + 5*d)*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t - 
      7*32^(1 + d)*d*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t + 
      9*2^(3 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t - 
      2^(3 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t - 
      2^(7 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t + 
      3*2^(6 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t - 
      9*2^(3 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t + 
      2^(3 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^3*t - 
      2^(7 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t + 
      3*2^(6 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t - 
      9*2^(3 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t + 
      2^(3 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t + 
      2^(8 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t - 
      7*32^(1 + d)*d*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t + 
      9*2^(3 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t - 
      2^(3 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^3*t - 
      3*2^(6 + 5*d)*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t + 
      21*2^(3 + 5*d)*d*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t - 
      27*2^(1 + 5*d)*d^2*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t + 
      3*2^(1 + 5*d)*d^3*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t + 
      3*32^(1 + d)*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t - 
      9*2^(4 + 5*d)*d*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t + 
      27*2^(1 + 5*d)*d^2*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t - 
      3*2^(1 + 5*d)*d^3*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^4*t + 
      3*32^(1 + d)*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t - 
      9*2^(4 + 5*d)*d*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t + 
      27*2^(1 + 5*d)*d^2*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t - 
      3*2^(1 + 5*d)*d^3*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t - 
      3*2^(6 + 5*d)*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t + 
      21*2^(3 + 5*d)*d*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t - 
      27*2^(1 + 5*d)*d^2*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t + 
      3*2^(1 + 5*d)*d^3*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^4*t - 
      32^(1 + d)*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*t^2 + 
      2^(3 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*t^2 - 
      32^(1 + d)*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*t^2 + 
      2^(3 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^6*Pi^(5*d)*t^2 - 
      32^(1 + d)*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*t^2 + 
      2^(3 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*t^2 - 
      32^(1 + d)*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*t^2 + 
      2^(3 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^6*Pi^(5*d)*t^2 + 
      2^(4 + 5*d)*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s*t^2 - 
      2^(2 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s*t^2 + 
      2^(4 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s*t^2 - 
      2^(2 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^4*Pi^(5*d)*s*t^2 + 
      2^(4 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s*t^2 - 
      2^(2 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s*t^2 + 
      2^(4 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s*t^2 - 
      2^(2 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^4*Pi^(5*d)*s*t^2 + 
      2^(6 + 5*d)*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^2*t^2 - 
      2^(4 + 5*d)*d*gZlLC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^2*t^2 + 
      2^(6 + 5*d)*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^2*t^2 - 
      2^(4 + 5*d)*d*gZlRC*gZuL^2*gZuLC*mz^2*Pi^(5*d)*s^2*t^2 + 
      2^(6 + 5*d)*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^2*t^2 - 
      2^(4 + 5*d)*d*gZlLC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^2*t^2 + 
      2^(6 + 5*d)*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^2*t^2 - 
      2^(4 + 5*d)*d*gZlRC*gZuR^2*gZuRC*mz^2*Pi^(5*d)*s^2*t^2 - 
      3*2^(4 + 5*d)*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^3*t^2 + 
      3*2^(2 + 5*d)*d*gZlLC*gZuL^2*gZuLC*Pi^(5*d)*s^3*t^2 - 
      3*2^(4 + 5*d)*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^3*t^2 + 
      3*2^(2 + 5*d)*d*gZlRC*gZuL^2*gZuLC*Pi^(5*d)*s^3*t^2 - 
      3*2^(4 + 5*d)*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^3*t^2 + 
      3*2^(2 + 5*d)*d*gZlLC*gZuR^2*gZuRC*Pi^(5*d)*s^3*t^2 - 
      3*2^(4 + 5*d)*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^3*t^2 + 
      3*2^(2 + 5*d)*d*gZlRC*gZuR^2*gZuRC*Pi^(5*d)*s^3*t^2 + 
      (-4 + d)*gZlL^2*gZlLC*(2*Pi)^(5*d)*(mz^2 - s)^2*(2*mz^2 + 3*s)*
       (-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      (-4 + d)*gZlR^2*gZlRC*(2*Pi)^(5*d)*(mz^2 - s)^2*(2*mz^2 + 3*s)*
       (-(gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      4*gZlR*gZlRC*s^3*(gZuL*gZuLC*((120 - 160*d + 76*d^2 - 15*d^3 + d^4)*
           mz^4*(2*Pi)^(5*d) + (-2 + d)*(2*Pi)^(5*d)*s*
           ((-76 + 54*d - 13*d^2 + d^3)*s - 8*t) - 2^(1 + 5*d)*(-2 + d)*mz^2*
           Pi^(5*d)*((-68 + 52*d - 13*d^2 + d^3)*s - 4*t)) + 
        gZuR*gZuRC*(-((120 - 160*d + 76*d^2 - 15*d^3 + d^4)*mz^4*
            (2*Pi)^(5*d)) + 2^(1 + 5*d)*(-2 + d)*mz^2*Pi^(5*d)*
           ((-64 + 52*d - 13*d^2 + d^3)*s + 4*t) - (-2 + d)*(2*Pi)^(5*d)*s*
           ((-68 + 54*d - 13*d^2 + d^3)*s + 8*t))) - 
      4*gZlL*gZlLC*s^3*(-(gZuR*gZuRC*((120 - 160*d + 76*d^2 - 15*d^3 + d^4)*
            mz^4*(2*Pi)^(5*d) + (-2 + d)*(2*Pi)^(5*d)*s*
            ((-76 + 54*d - 13*d^2 + d^3)*s - 8*t) - 2^(1 + 5*d)*(-2 + d)*mz^2*
            Pi^(5*d)*((-68 + 52*d - 13*d^2 + d^3)*s - 4*t))) + 
        gZuL*gZuLC*((120 - 160*d + 76*d^2 - 15*d^3 + d^4)*mz^4*(2*Pi)^(5*d) - 
          2^(1 + 5*d)*(-2 + d)*mz^2*Pi^(5*d)*((-64 + 52*d - 13*d^2 + d^3)*s + 
            4*t) + (-2 + d)*(2*Pi)^(5*d)*s*((-68 + 54*d - 13*d^2 + d^3)*s + 
            8*t)))) + (-4 + d)*(2*Pi)^(5*d)*s*(2*mz^4 + mz^2*s - 3*s^2)*
     (gZlL^3*gZlLC*(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2) - gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlL*gZlLC*(gZuR^3*gZuRC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZuL^3*gZuLC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      gZlR*gZlRC*(gZuL^3*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2) - gZuR^3*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2) + gZlR^2*(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZuR*gZuRC*((-2 + d)^2*s^2 + 
            2*(8 - 5*d + d^2)*s*t + 4*t^2))))))/
  ((-4 + d)*mz^2*Pi^(6*d)*(mz^2 - s)^2*s^2*(-mzC^2 + s)), 
 (I*EL^6*gAl*gAu*
   (gZlL*gZlLC*(gZuR*gZuRC*(mz^2*((328 - 388*d + 168*d^2 - 31*d^3 + 2*d^4)*
           s - 2*(8 - 6*d + d^2)*t) + 
        s*((-424 + 444*d - 176*d^2 + 31*d^3 - 2*d^4)*s + 2*(-16 + 2*d + d^2)*
           t)) + gZuL*gZuLC*(-(mz^2*((344 - 400*d + 170*d^2 - 31*d^3 + 2*d^4)*
            s + 2*(8 - 6*d + d^2)*t)) + 
        s*((392 - 440*d + 178*d^2 - 31*d^3 + 2*d^4)*s + 2*(-16 + 2*d + d^2)*
           t))) + gZlR*gZlRC*
     (gZuL*gZuLC*(mz^2*((328 - 388*d + 168*d^2 - 31*d^3 + 2*d^4)*s - 
          2*(8 - 6*d + d^2)*t) + s*((-424 + 444*d - 176*d^2 + 31*d^3 - 2*d^4)*
           s + 2*(-16 + 2*d + d^2)*t)) + gZuR*gZuRC*
       (-(mz^2*((344 - 400*d + 170*d^2 - 31*d^3 + 2*d^4)*s + 
           2*(8 - 6*d + d^2)*t)) + s*((392 - 440*d + 178*d^2 - 31*d^3 + 
            2*d^4)*s + 2*(-16 + 2*d + d^2)*t)))))/
  ((-4 + d)*(2*Pi)^d*(mz^2 - s)*(-mzC^2 + s)), 
 (I*EL^6*t*(gZlL^2*gZlLC*
     (-(gZuR^2*gZuRC*(2^(2 + d)*(-56 + 46*d - 12*d^2 + d^3)*mz^2*Pi^d + 
         d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*((12 - 3*d - 2*d^2 + d^3)*s + 
           4*(8 - 6*d + d^2)*t))) + gZuL^2*gZuLC*
       (2^(2 + d)*(-52 + 44*d - 12*d^2 + d^3)*mz^2*Pi^d + d^3*(2*Pi)^d*s - 
        2^(1 + d)*Pi^d*((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*
           t))) + gZlR^2*gZlRC*
     (-(gZuL^2*gZuLC*(2^(2 + d)*(-56 + 46*d - 12*d^2 + d^3)*mz^2*Pi^d + 
         d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*((12 - 3*d - 2*d^2 + d^3)*s + 
           4*(8 - 6*d + d^2)*t))) + gZuR^2*gZuRC*
       (2^(2 + d)*(-52 + 44*d - 12*d^2 + d^3)*mz^2*Pi^d + d^3*(2*Pi)^d*s - 
        2^(1 + d)*Pi^d*((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*
           t))) + gAl*gAu*
     (gZlL*gZlLC*(-(gZuR*gZuRC*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*
              Pi^d + d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
            ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t))) + 
        gZuL*gZuLC*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
            d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
           ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t))) + 
      gZlR*gZlRC*(-(gZuL*gZuLC*(mz^2*(2^(1 + d)*(-108 + 83*d - 20*d^2 + d^3)*
              Pi^d + d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
            ((12 - 3*d - 2*d^2 + d^3)*s + 4*(8 - 6*d + d^2)*t))) + 
        gZuR*gZuRC*(mz^2*(2^(1 + d)*(-108 + 82*d - 20*d^2 + d^3)*Pi^d + 
            d^3*(2*Pi)^d) + d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
           ((12 - 2*d - 2*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t))))))/
  (2^(2*(1 + d))*Pi^(2*d)*(mzC^2 - s)), 
 (I*4^(-1 - d)*EL^6*gAl*gAu*t*
   (gZlL*gZlLC*(gZuR*gZuRC*(mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - 
          d^3*(2*Pi)^d) - d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*
         ((-2 - 2*d + d^2)*s + 4*(-2 + d)*t) + 2^(1 + d)*Pi^d*
         ((4 - 9*d + 4*d^2)*s^2 + 4*(-4 + d)*s*t - 8*t^2)) - 
      gZuL*gZuLC*(mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
        d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
          4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
          2*(-2 + d)*s*t + 4*t^2))) + gZlR*gZlRC*
     (gZuL*gZuLC*(mz^4*(2^(1 + d)*(4 - 9*d + 4*d^2)*Pi^d - d^3*(2*Pi)^d) - 
        d^3*(2*Pi)^d*s^2 + 2^(1 + d)*(-4 + d)*mz^2*Pi^d*((-2 - 2*d + d^2)*s + 
          4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
          4*(-4 + d)*s*t - 8*t^2)) - gZuR*gZuRC*
       (mz^4*(2^(2 + d)*(-2 - 3*d + 2*d^2)*Pi^d - d^3*(2*Pi)^d) - 
        d^3*(2*Pi)^d*s^2 + 2^(1 + d)*mz^2*Pi^d*((16 + 4*d - 6*d^2 + d^3)*s + 
          4*(10 - 6*d + d^2)*t) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
          2*(-2 + d)*s*t + 4*t^2)))))/(Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*2^(-3 - d)*EL^6*(2*gAl*gAu*(mz^2 - s)^2*(4*gZlLC*gZuL^2*gZuLC*s^2 - 
      4*d*gZlLC*gZuL^2*gZuLC*s^2 + d^2*gZlLC*gZuL^2*gZuLC*s^2 - 
      8*gZlRC*gZuL^2*gZuLC*s^2 + 6*d*gZlRC*gZuL^2*gZuLC*s^2 - 
      d^2*gZlRC*gZuL^2*gZuLC*s^2 - 8*gZlLC*gZuR^2*gZuRC*s^2 + 
      6*d*gZlLC*gZuR^2*gZuRC*s^2 - d^2*gZlLC*gZuR^2*gZuRC*s^2 + 
      4*gZlRC*gZuR^2*gZuRC*s^2 - 4*d*gZlRC*gZuR^2*gZuRC*s^2 + 
      d^2*gZlRC*gZuR^2*gZuRC*s^2 + 16*gZlLC*gZuL^2*gZuLC*s*t - 
      10*d*gZlLC*gZuL^2*gZuLC*s*t + 2*d^2*gZlLC*gZuL^2*gZuLC*s*t - 
      8*gZlRC*gZuL^2*gZuLC*s*t + 10*d*gZlRC*gZuL^2*gZuLC*s*t - 
      2*d^2*gZlRC*gZuL^2*gZuLC*s*t - 8*gZlLC*gZuR^2*gZuRC*s*t + 
      10*d*gZlLC*gZuR^2*gZuRC*s*t - 2*d^2*gZlLC*gZuR^2*gZuRC*s*t + 
      16*gZlRC*gZuR^2*gZuRC*s*t - 10*d*gZlRC*gZuR^2*gZuRC*s*t + 
      2*d^2*gZlRC*gZuR^2*gZuRC*s*t + 4*gZlLC*gZuL^2*gZuLC*t^2 + 
      4*gZlRC*gZuL^2*gZuLC*t^2 + 4*gZlLC*gZuR^2*gZuRC*t^2 + 
      4*gZlRC*gZuR^2*gZuRC*t^2 + gZlL^2*gZlLC*
       (-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      gZlR^2*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2))) + 
    s*(-(gXXZZ*mz^2*(gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
              2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2)) + gZlR*gZlRC*
          (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
              4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2)))) - 2*(mz^2 - s)*
       (gZlL^3*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
              t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
             t + 4*t^2)) + gZlL*gZlLC*
         (-(gZuR^3*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
             4*t^2)) + gZuL^3*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
            4*t^2)) + gZlR*gZlRC*(-(gZuL^3*gZuLC*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR^3*gZuRC*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
          gZlR^2*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
                t - 4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
               s*t + 4*t^2)))))))/(Pi^d*s*(-mzC^2 + s)*(mz^3 - mz*s)^2), 0, 
 (I*2^(-1 - d)*(-2 + d)*EL^6*
   (gZlL^2*gZlLC*(gZuR^2*gZuRC*(-((-4 + d)*s) + 2*t) + 
      gZuL^2*gZuLC*((-2 + d)*s + 2*t)) + gZlR^2*gZlRC*
     (gZuL^2*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR^2*gZuRC*((-2 + d)*s + 2*t))))/
  (Pi^d*(mzC^2 - s)), ((-I)*2^(-1 - d)*EL^6*s*
   (gZlL^2*gZlLC*(gZuR^2*gZuRC*(2*(-60 + 50*d - 13*d^2 + d^3)*mz^2 - 
        (-76 + 54*d - 13*d^2 + d^3)*s + 8*t) + gZuL^2*gZuLC*
       (-2*(-60 + 50*d - 13*d^2 + d^3)*mz^2 + (-68 + 54*d - 13*d^2 + d^3)*s + 
        8*t)) + gZlR^2*gZlRC*
     (gZuL^2*gZuLC*(2*(-60 + 50*d - 13*d^2 + d^3)*mz^2 - 
        (-76 + 54*d - 13*d^2 + d^3)*s + 8*t) + gZuR^2*gZuRC*
       (-2*(-60 + 50*d - 13*d^2 + d^3)*mz^2 + (-68 + 54*d - 13*d^2 + d^3)*s + 
        8*t))))/(Pi^d*(mzC^2 - s)), 
 ((-I)*2^(-3 - 2*d)*EL^6*
   (gZlL^2*gZlLC*(-(gZuR^2*gZuRC*(2^(2 + d)*(-4 + d)*mz^2*Pi^d*t*
          ((-2 - 2*d + d^2)*s + 4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*
          ((2 - 4*d + d^2)*s - 2*(14 - 8*d + d^2)*t) + 
         t*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 
             4*(-4 + d)*s*t - 8*t^2)))) + gZuL^2*gZuLC*
       (2^(2 + d)*mz^2*Pi^d*t*((16 + 4*d - 6*d^2 + d^3)*s + 
          4*(10 - 6*d + d^2)*t) + 2^(1 + d)*mz^4*Pi^d*
         ((8 + 12*d - 8*d^2 + d^3)*s - 2*(-52 + 44*d - 12*d^2 + d^3)*t) + 
        t*(-(d^3*(2*Pi)^d*s^2) + 2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 
            2*(-2 + d)*s*t + 4*t^2)))) + gZlR^2*gZlRC*
     (-(gZuL^2*gZuLC*(2^(2 + d)*(-4 + d)*mz^2*Pi^d*t*((-2 - 2*d + d^2)*s + 
           4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*((2 - 4*d + d^2)*s - 
           2*(14 - 8*d + d^2)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*((4 - 9*d + 4*d^2)*s^2 + 4*(-4 + d)*s*t - 
             8*t^2)))) + gZuR^2*gZuRC*(2^(2 + d)*mz^2*Pi^d*t*
         ((16 + 4*d - 6*d^2 + d^3)*s + 4*(10 - 6*d + d^2)*t) + 
        2^(1 + d)*mz^4*Pi^d*((8 + 12*d - 8*d^2 + d^3)*s - 
          2*(-52 + 44*d - 12*d^2 + d^3)*t) + t*(-(d^3*(2*Pi)^d*s^2) + 
          2^(2 + d)*Pi^d*((-2 - 3*d + 2*d^2)*s^2 + 2*(-2 + d)*s*t + 
            4*t^2))))))/(Pi^(2*d)*(mzC^2 - s)), 0, 0, 0, 0, 0, 
 ((-I)*EL^6*(gZlR^2*gZlRC*(gZuL^2*gZuLC*(-(d^3*(2*Pi)^d*s) + 
        2^(1 + d)*Pi^d*((-4 - 3*d + 3*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*
           t)) - gZuR^2*gZuRC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
         ((-8 - 2*d + 3*d^2)*s - (-56 + 46*d - 12*d^2 + d^3)*t))) + 
    gZlL^2*gZlLC*(gZuR^2*gZuRC*(-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
         ((-4 - 3*d + 3*d^2)*s - (-52 + 44*d - 12*d^2 + d^3)*t)) + 
      gZuL^2*gZuLC*(d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((8 + 2*d - 3*d^2)*s + 
          (-56 + 46*d - 12*d^2 + d^3)*t))) - 
    (2*gAl*gAu*(gZlL*gZlLC*(gZuR*gZuRC*((-3 + d)*mz^2*
            (2^(1 + d)*(-56 + 41*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d) + 
           7*d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((-280 + 251*d - 75*d^2 + 4*d^3)*
              s + (88 - 116*d + 56*d^2 - 12*d^3 + d^4)*t)) + 
         gZuL*gZuLC*((-3 + d)*mz^2*(2^(1 + d)*(64 - 44*d + 9*d^2)*Pi^d - 
             d^3*(2*Pi)^d) - 7*d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
            ((-272 + 248*d - 75*d^2 + 4*d^3)*s + (128 - 136*d + 58*d^2 - 12*
                d^3 + d^4)*t))) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((-3 + d)*mz^2*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - 
              d^3*(2*Pi)^d) - 7*d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
             ((-280 + 251*d - 75*d^2 + 4*d^3)*s + (88 - 116*d + 56*d^2 - 
                12*d^3 + d^4)*t))) + gZuR*gZuRC*
          ((-3 + d)*mz^2*(2^(1 + d)*(64 - 44*d + 9*d^2)*Pi^d - 
             d^3*(2*Pi)^d) - 7*d^3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
            ((-272 + 248*d - 75*d^2 + 4*d^3)*s + (128 - 136*d + 58*d^2 - 12*
                d^3 + d^4)*t)))))/(-4 + d) - 
    (gAl^2*gAu^2*(-(gZlRC*(d^4*gZuRC*(2*Pi)^d*s - 2^(1 + d)*gZuRC*Pi^d*
           ((512 - 496*d + 164*d^2 - 20*d^3 + d^4)*s - 
            (32 - 32*d + 22*d^2 - 8*d^3 + d^4)*t) + 
          gZuLC*(-(d^4*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((544 - 510*d + 165*d^2 - 
                20*d^3 + d^4)*s + (32 + 4*d - 20*d^2 + 8*d^3 - d^4)*t)))) + 
       gZlLC*(d^4*gZuRC*(2*Pi)^d*s - 2^(1 + d)*gZuRC*Pi^d*
          ((544 - 510*d + 165*d^2 - 20*d^3 + d^4)*s + 
           (32 + 4*d - 20*d^2 + 8*d^3 - d^4)*t) + 
         gZuLC*(-(d^4*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
            ((512 - 496*d + 164*d^2 - 20*d^3 + d^4)*s - 
             (32 - 32*d + 22*d^2 - 8*d^3 + d^4)*t)))))/(-4 + d) + 
    gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(-(d^3*(2*Pi)^d*s) + 
      2^(1 + d)*Pi^d*((8 + 2*d - 3*d^2 + d^3)*s + (-56 + 46*d - 12*d^2 + d^3)*
         t))*CKM[1, 1]*CKMC[1, 1]))/(2^(2*(1 + d))*Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*2^(-3 - 2*d)*EL^6*gAl^2*gAu^2*(s + t)*
   (gZlRC*(d^3*gZuLC*(2*Pi)^d*s^2 - d^3*gZuRC*(2*Pi)^d*s^2 + 
      2^(1 + d)*gZuLC*Pi^d*(-((-72 + 45*d - 9*d^2 + d^3)*s^2) - 
        4*(-6 + d)*s*t + 8*t^2) + 2^(1 + d)*gZuRC*Pi^d*
       ((-72 + 48*d - 9*d^2 + d^3)*s^2 + 4*d*s*t + 8*t^2)) + 
    gZlLC*(d^3*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuRC*Pi^d*
       ((-72 + 45*d - 9*d^2 + d^3)*s^2 + 4*(-6 + d)*s*t - 8*t^2) + 
      gZuLC*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-72 + 48*d - 9*d^2 + d^3)*s^2 + 4*d*s*t + 8*t^2)))))/
  (Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*EL^6*
   ((s + t)*(gZlR^2*gZlRC*(gZuR^2*gZuRC*(2^(2 + d)*(-56 + 46*d - 12*d^2 + 
            d^3)*mz^2*Pi^d - d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
           ((80 - 56*d + 11*d^2)*s + 4*(8 - 6*d + d^2)*t)) - 
        gZuL^2*gZuLC*(2^(2 + d)*(-52 + 44*d - 12*d^2 + d^3)*mz^2*Pi^d - 
          d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((88 - 57*d + 11*d^2)*s + 
            4*(10 - 6*d + d^2)*t))) + gZlL^2*gZlLC*
       (gZuL^2*gZuLC*(2^(2 + d)*(-56 + 46*d - 12*d^2 + d^3)*mz^2*Pi^d - 
          d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((80 - 56*d + 11*d^2)*s + 
            4*(8 - 6*d + d^2)*t)) - gZuR^2*gZuRC*
         (2^(2 + d)*(-52 + 44*d - 12*d^2 + d^3)*mz^2*Pi^d - d^3*(2*Pi)^d*s + 
          2^(1 + d)*Pi^d*((88 - 57*d + 11*d^2)*s + 4*(10 - 6*d + d^2)*t)))) - 
    gAl*gAu*((gZlL*gZlLC*(gZuL*gZuLC*(2^(1 + d)*(64 - 44*d + 9*d^2)*Pi^d - 
            d^3*(2*Pi)^d) + gZuR*gZuRC*(2^(1 + d)*(-56 + 41*d - 9*d^2)*Pi^d + 
            d^3*(2*Pi)^d)) - gZlR*gZlRC*
         (gZuL*gZuLC*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d) + 
          gZuR*gZuRC*(2^(1 + d)*(-64 + 44*d - 9*d^2)*Pi^d + d^3*(2*Pi)^d)))*
       (mz^2*(-s + t) + s*(s + t)) - 
      2*(gZlR*gZlRC*(gZuR*gZuRC*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*(
                (-56 + 46*d - 12*d^2 + d^3)*s + (8 + 2*d - 3*d^2)*t)) + 
            (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*
                 s + (8 - 6*d + d^2)*t))) - gZuL*gZuLC*
           (mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*((-52 + 44*d - 12*d^2 + 
                  d^3)*s + (4 + 3*d - 3*d^2)*t)) + (s + t)*
             (-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((72 - 49*d + 10*d^2)*s + 
                2*(10 - 6*d + d^2)*t)))) + gZlL*gZlLC*
         (gZuL*gZuLC*(mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*(
                (-56 + 46*d - 12*d^2 + d^3)*s + (8 + 2*d - 3*d^2)*t)) + 
            (s + t)*(-(d^3*(2*Pi)^d*s) + 2^(2 + d)*Pi^d*((36 - 25*d + 5*d^2)*
                 s + (8 - 6*d + d^2)*t))) - gZuR*gZuRC*
           (mz^2*(d^3*(2*Pi)^d*t + 2^(1 + d)*Pi^d*((-52 + 44*d - 12*d^2 + 
                  d^3)*s + (4 + 3*d - 3*d^2)*t)) + (s + t)*
             (-(d^3*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((72 - 49*d + 10*d^2)*s + 
                2*(10 - 6*d + d^2)*t))))))))/(2^(2*(1 + d))*Pi^(2*d)*
   (mzC^2 - s)), (I*4^(-1 - d)*EL^6*gAl*gAu*
   (gZlL*gZlLC*(gZuL*gZuLC*(mz^4*(2^(1 + d)*(64 - 44*d + 9*d^2)*Pi^d - 
          d^3*(2*Pi)^d)*(s + t) - d^3*(2*Pi)^d*s^2*(s + 3*t) + 
        2^(1 + d)*(-4 + d)*mz^2*Pi^d*(s + t)*((36 - 16*d + d^2)*s - 
          4*(-2 + d)*t) + 2^(1 + d)*Pi^d*((72 - 48*d + 9*d^2)*s^3 + 
          (72 - 52*d + 9*d^2 + d^3)*s^2*t - 4*(2 + d)*s*t^2 - 8*t^3)) + 
      gZuR*gZuRC*(-(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d)*
          (s + t)) + d^3*(2*Pi)^d*s^2*(s + 3*t) - 2^(1 + d)*mz^2*Pi^d*
         ((-144 + 98*d - 20*d^2 + d^3)*s^2 + (-184 + 122*d - 24*d^2 + d^3)*s*
           t - 4*(10 - 6*d + d^2)*t^2) - 2^(1 + d)*Pi^d*
         (9*(8 - 5*d + d^2)*s^3 + (96 - 49*d + 9*d^2 + d^3)*s^2*t - 
          4*(-8 + d)*s*t^2 + 8*t^3))) - 
    gZlR*gZlRC*(gZuL*gZuLC*(mz^4*(2^(1 + d)*(56 - 41*d + 9*d^2)*Pi^d - 
          d^3*(2*Pi)^d)*(s + t) - d^3*(2*Pi)^d*s^2*(s + 3*t) + 
        2^(1 + d)*mz^2*Pi^d*((-144 + 98*d - 20*d^2 + d^3)*s^2 + 
          (-184 + 122*d - 24*d^2 + d^3)*s*t - 4*(10 - 6*d + d^2)*t^2) + 
        2^(1 + d)*Pi^d*(9*(8 - 5*d + d^2)*s^3 + (96 - 49*d + 9*d^2 + d^3)*s^2*
           t - 4*(-8 + d)*s*t^2 + 8*t^3)) + gZuR*gZuRC*
       (-(mz^4*(2^(1 + d)*(64 - 44*d + 9*d^2)*Pi^d - d^3*(2*Pi)^d)*(s + t)) + 
        d^3*(2*Pi)^d*s^2*(s + 3*t) - 2^(1 + d)*(-4 + d)*mz^2*Pi^d*(s + t)*
         ((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 2^(1 + d)*Pi^d*
         ((-72 + 48*d - 9*d^2)*s^3 - (72 - 52*d + 9*d^2 + d^3)*s^2*t + 
          4*(2 + d)*s*t^2 + 8*t^3)))))/(Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*2^(-3 - 2*d)*EL^6*
   (gZlL^2*gZlLC*(gZuR^2*gZuRC*(d^3*(2*Pi)^d*s^2*(s + 3*t) - 
        2^(1 + d)*mz^4*Pi^d*((-216 + 170*d - 42*d^2 + 3*d^3)*s + 
          2*(-52 + 44*d - 12*d^2 + d^3)*t) + 2^(2 + d)*mz^2*Pi^d*
         ((-144 + 98*d - 20*d^2 + d^3)*s^2 + (-184 + 122*d - 24*d^2 + d^3)*s*
           t - 4*(10 - 6*d + d^2)*t^2) + 2^(1 + d)*Pi^d*
         (-((-72 + 45*d - 9*d^2 + d^3)*s^3) + (96 - 49*d + 9*d^2 - 2*d^3)*s^2*
           t - 4*(-8 + d)*s*t^2 + 8*t^3)) + gZuL^2*gZuLC*
       (-(d^3*(2*Pi)^d*s^2*(s + 3*t)) - 2^(2 + d)*(-4 + d)*mz^2*Pi^d*(s + t)*
         ((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*
         (3*(20 - 10*d + d^2)*s + 2*(14 - 8*d + d^2)*t) + 
        2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^3 + 
          (-72 + 52*d - 9*d^2 + 2*d^3)*s^2*t + 4*(2 + d)*s*t^2 + 8*t^3))) + 
    gZlR^2*gZlRC*(gZuL^2*gZuLC*(d^3*(2*Pi)^d*s^2*(s + 3*t) - 
        2^(1 + d)*mz^4*Pi^d*((-216 + 170*d - 42*d^2 + 3*d^3)*s + 
          2*(-52 + 44*d - 12*d^2 + d^3)*t) + 2^(2 + d)*mz^2*Pi^d*
         ((-144 + 98*d - 20*d^2 + d^3)*s^2 + (-184 + 122*d - 24*d^2 + d^3)*s*
           t - 4*(10 - 6*d + d^2)*t^2) + 2^(1 + d)*Pi^d*
         (-((-72 + 45*d - 9*d^2 + d^3)*s^3) + (96 - 49*d + 9*d^2 - 2*d^3)*s^2*
           t - 4*(-8 + d)*s*t^2 + 8*t^3)) + gZuR^2*gZuRC*
       (-(d^3*(2*Pi)^d*s^2*(s + 3*t)) - 2^(2 + d)*(-4 + d)*mz^2*Pi^d*(s + t)*
         ((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mz^4*Pi^d*
         (3*(20 - 10*d + d^2)*s + 2*(14 - 8*d + d^2)*t) + 
        2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2 + d^3)*s^3 + 
          (-72 + 52*d - 9*d^2 + 2*d^3)*s^2*t + 4*(2 + d)*s*t^2 + 8*t^3)))))/
  (Pi^(2*d)*(mzC^2 - s)), ((-I)*4^(-2 - 3*d)*EL^6*
   (2^(2 + 5*d)*(1 - d)*d*gWlN*gWNl*gZlLC*gZNL*mw^2*Pi^(5*d)*(mz^2 - s)*s*
     (2*mw^2 + 3*s)*sw^2*(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZuL*gZuLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2))*(-1 + GaugeXi[Q])^2*GaugeXi[Q] - 
    2^(2 + 5*d)*(1 - d)*d*gAd*gAl*gWdu*gWud*gZuLC*mw^2*Pi^(5*d)*(mz^2 - s)^2*
     (2*mw^2 + 3*s)*sw^2*(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
         t - 4*t^2) - gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     CKM[1, 1]*CKMC[1, 1]*(-1 + GaugeXi[Q])^2*GaugeXi[Q] + 
    2^(2 + 5*d)*(1 - d)*d*gWdu*gWud*gZdL*gZuLC*mw^2*Pi^(5*d)*(mz^2 - s)*s*
     (2*mw^2 + 3*s)*sw^2*(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlL*gZlLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*CKMC[1, 1]*
     (-1 + GaugeXi[Q])^2*GaugeXi[Q] + 2^(3 + 5*d)*(-1 + d)^2*gAl*gAu*gWWAA*
     mw^4*Pi^(5*d)*(mz^2 - s)^2*sw^2*
     (gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (-1 + GaugeXi[Q])^2*(1 + (-1 + d)*GaugeXi[Q]) + 
    2^(3 + 5*d)*(-1 + d)^2*gAu*gWWAZ*mw^4*Pi^(5*d)*(mz^2 - s)*s*sw^2*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2)))*(-1 + GaugeXi[Q])^2*
     (1 + (-1 + d)*GaugeXi[Q]) + 2^(1 + 5*d)*d*gAu*gWlN*gWNl*gWWA*gZlLC*mw^2*
     Pi^(5*d)*(mz^2 - s)^2*sw^2*
     (gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (-1 + GaugeXi[Q])^2*GaugeXi[Q]*(4*(-1 + d)*mw^2 + (-1 + 4*d)*s - 
      s*GaugeXi[Q]) + 2^(1 + 5*d)*d*gWlN*gWNl*gWWZ*gZlLC*mw^2*Pi^(5*d)*
     (mz^2 - s)*s*sw^2*(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZuL*gZuLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
     (4*(-1 + d)*mw^2 + (-1 + 4*d)*s - s*GaugeXi[Q]) - 
    2^(1 + 4*d)*d*gFZW^2*mw^2*Pi^(4*d)*s*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
     (gZlL*gZlLC*(-(gZuR*gZuRC*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
            ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
           mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + 
               (4 - 5*d + d^2)*s*t - 2*t^2)))) + gZuL*gZuLC*
         (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2) + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
            2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
              2*t^2)))) + gZlR*gZlRC*
       (-(gZuL*gZuLC*(d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*((4 - 3*d)*s^2 + 
             (4 - 5*d + d^2)*s*t - 2*t^2) + mw^2*(-(d^2*(2*Pi)^d*s^2) + 
             2^(1 + d)*Pi^d*((4 - 3*d + d^2)*s^2 + (4 - 5*d + d^2)*s*t - 2*
                t^2)))) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^3 + 
          2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
          mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((2 - 2*d + d^2)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
      mw^2*(gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
          gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2))) - gZlR*gZlRC*
         (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
              (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))*
       GaugeXi[Q]) + 2^(1 + 5*d)*gAl*gAu*gWWA^2*mw^2*Pi^(5*d)*(mz^2 - s)^2*
     sw^2*(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) + gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) - gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
        4*t^2) - gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
        4*t^2))*(-1 + GaugeXi[Q])^2*(4*(-1 + d)^2*mw^2 + 
      (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2) + 
    2^(1 + 5*d)*gAl*gWWA*gWWZ*mw^2*Pi^(5*d)*(mz^2 - s)*s*sw^2*
     (gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) + gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*gZuL*gZuLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (-1 + GaugeXi[Q])^2*(4*(-1 + d)^2*mw^2 + 
      (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2) - 
    2^(1 + 5*d)*gAu*gWWA*gWWZ*mw^2*Pi^(5*d)*(mz^2 - s)*s*sw^2*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2)))*(-1 + GaugeXi[Q])^2*
     (4*(-1 + d)^2*mw^2 + (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + 
      d*s*GaugeXi[Q]^2) - 2^(1 + 5*d)*gWWZ^2*mw^2*Pi^(5*d)*s^2*sw^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
     (-1 + GaugeXi[Q])^2*(4*(-1 + d)^2*mw^2 + 
      (4*(-1 + d)*mw^2 + d*(-9 + 4*d)*s)*GaugeXi[Q] + d*s*GaugeXi[Q]^2) - 
    2^(3 + 4*d)*(1 - d)*gAl*gWWAZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*sw^2*
     (1 - GaugeXi[Q])*((-1 + d)*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      ((-1 + d)*gZlLC*gZuL*gZuLC*(d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-4 + 6*d - 3*d^2)*s^2 + (-16 + 18*d - 7*d^2 + d^3)*s*t + 
            2*(-2 + d)*t^2)) + (-1 + d)*gZlRC*gZuR*gZuRC*
         (d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-4 + 6*d - 3*d^2)*s^2 + 
            (-16 + 18*d - 7*d^2 + d^3)*s*t + 2*(-2 + d)*t^2)) + 
        gZlRC*gZuL*gZuLC*(-((-3 + d)*d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((-8 + 18*d - 14*d^2 + 3*d^3)*s^2 - 
            (-1 + d)^2*(8 - 6*d + d^2)*s*t + 2*(2 - 3*d + d^2)*t^2)) + 
        gZlLC*gZuR*gZuRC*(-((-3 + d)*d^3*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((-8 + 18*d - 14*d^2 + 3*d^3)*s^2 - 
            (-1 + d)^2*(8 - 6*d + d^2)*s*t + 2*(2 - 3*d + d^2)*t^2)))*
       GaugeXi[Q] + (-((-1 + d)*gZlLC*gZuL*gZuLC*(d^2*(1 + d)*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-2 + 4*d - 3*d^2)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*
              s*t + 2*(-1 + d)*t^2))) - (-1 + d)*gZlRC*gZuR*gZuRC*
         (d^2*(1 + d)*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 4*d - 3*d^2)*s^2 + 
            (-8 + 13*d - 6*d^2 + d^3)*s*t + 2*(-1 + d)*t^2)) + 
        gZlRC*gZuL*gZuLC*(d^2*(1 + d^2)*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((4 - 11*d + 10*d^2 - 4*d^3)*s^2 + (-4 + d)*(-1 + d)^3*s*t - 
            2*(-1 + d)^2*t^2)) + gZlLC*gZuR*gZuRC*
         (d^2*(1 + d^2)*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((4 - 11*d + 10*d^2 - 4*d^3)*s^2 + (-4 + d)*(-1 + d)^3*s*t - 
            2*(-1 + d)^2*t^2)))*GaugeXi[Q]^2) + 2^(3 + 4*d)*(1 - d)*gWWZZ*
     mw^4*Pi^(4*d)*s^2*sw^2*(1 - GaugeXi[Q])*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((-7 + d)*d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 
             2*(-1 + d)*t^2))) + gZuL*gZuLC*((-5 + d)*d^2*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*t + 
            2*(-1 + d)*t^2))) + gZlR*gZlRC*
       (-(gZuL*gZuLC*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) + 
        gZuR*gZuRC*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*t + 
            2*(-1 + d)*t^2))) + 
      (gZlL*gZlLC*(-(gZuR*gZuRC*((-9 + d)*d^3*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*(2*(4 - 9*d + 7*d^2)*s^2 + (-1 + d)^2*
                (8 - 6*d + d^2)*s*t - 2*(2 - 3*d + d^2)*t^2))) + 
          gZuL*gZuLC*((-7 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 10*d + 9*d^2)*s^2 + (16 - 34*d + 25*d^2 - 8*d^3 + d^4)*s*
               t + 2*(2 - 3*d + d^2)*t^2))) + gZlR*gZlRC*
         (-(gZuL*gZuLC*((-9 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              (2*(4 - 9*d + 7*d^2)*s^2 + (-1 + d)^2*(8 - 6*d + d^2)*s*t - 2*
                (2 - 3*d + d^2)*t^2))) + gZuR*gZuRC*
           ((-7 + d)*d^3*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 10*d + 9*d^2)*s^2 + (16 - 34*d + 25*d^2 - 8*d^3 + d^4)*s*
               t + 2*(2 - 3*d + d^2)*t^2))))*GaugeXi[Q] + 
      (gZlL*gZlLC*(gZuR*gZuRC*(d^2*(21 + d^2)*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((4 - 11*d - 4*d^3)*s^2 + (-4 + d)*(-1 + d)^3*s*
               t - 2*(-1 + d)^2*t^2)) + gZuL*gZuLC*
           (-(d^2*(13 + d^2)*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-2 + 6*d + 3*d^3)*s^2 - (-1 + d)^2*(8 - 5*d + d^2)*s*t - 
              2*(-1 + d)^2*t^2))) - gZlR*gZlRC*
         (gZuL*gZuLC*(-(d^2*(21 + d^2)*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 11*d + 4*d^3)*s^2 - (-4 + d)*(-1 + d)^3*s*t + 
              2*(-1 + d)^2*t^2)) + gZuR*gZuRC*(d^2*(13 + d^2)*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*((2 - 6*d - 3*d^3)*s^2 + (-1 + d)^2*(8 - 5*d + 
                d^2)*s*t + 2*(-1 + d)^2*t^2))))*GaugeXi[Q]^2) + 
    d*gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(2*Pi)^(4*d)*(mz^2 - s)^2*s*sw^2*
     CKM[1, 1]*CKMC[1, 1]*GaugeXi[Q]*(d^2*(2*Pi)^d*s^3 + 
      2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
      mw^2*(-13*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(2*(-1 + d + 3*d^2)*s^2 - 
          (8 - 5*d + d^2)*s*t - 2*t^2)) + 
      (-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
        mw^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + 4*d^2)*s^2 + 
            3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q] + 
      (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
          (8 - 5*d + d^2)*s*t + 2*t^2) + mw^2*(-13*d^2*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-6 + 6*d + 5*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*t - 
            6*t^2)))*GaugeXi[Q]^2 + mw^2*(-5*d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*((2 - 2*d + 3*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))*
       GaugeXi[Q]^3) + gAl*gWdu*gWud*gWWA*gZuLC*(mz^2 - s)^2*sw^2*CKM[1, 1]*
     CKMC[1, 1]*(2^(2 + 5*d)*(-1 + d)^2*mw^2*Pi^(5*d)*s*
       (-(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      (2^(3 + 5*d)*d^4*(gZlLC - gZlRC)*mw^4*Pi^(5*d)*s*(s + 2*t) - 
        32^(1 + d)*mw^2*Pi^(5*d)*s*(gZlRC*(-2*s^2 - 2*s*t + t^2) + 
          gZlLC*(s^2 + 4*s*t + t^2)) - d^3*(2*Pi)^(5*d)*s*
         (gZlLC*(-13*mw^2*s*(s + 2*t) + s^2*(s + 2*t) + 
            8*mw^4*(5*s + 12*t)) - gZlRC*(-13*mw^2*s*(s + 2*t) + 
            s^2*(s + 2*t) + 8*mw^4*(7*s + 12*t))) + 2^(1 + 5*d)*d^2*Pi^(5*d)*
         (gZlRC*(-(s^3*(3*s + 5*t)) + mw^2*s^2*(43*s + 73*t) - 
            8*mw^4*(7*s^2 + 9*s*t - 2*t^2)) + gZlLC*(s^3*(2*s + 5*t) - 
            mw^2*s^2*(30*s + 73*t) + 8*mw^4*(4*s^2 + 13*s*t + 2*t^2))) - 
        2^(2 + 5*d)*d*Pi^(5*d)*(gZlRC*(mw^2*s*(38*s^2 + 46*s*t - 13*t^2) - 
            8*mw^4*(2*s^2 + 2*s*t - t^2) + s^2*(-2*s^2 - 2*s*t + t^2)) + 
          gZlLC*(8*mw^4*(s^2 + 4*s*t + t^2) + s^2*(s^2 + 4*s*t + t^2) - 
            mw^2*s*(21*s^2 + 72*s*t + 13*t^2))))*GaugeXi[Q] + 
      (-(2^(2 + 5*d)*d^4*(gZlLC - gZlRC)*mw^2*Pi^(5*d)*s*(4*mw^2 + 3*s)*
          (s + 2*t)) + 2^(4 + 5*d)*mw^2*Pi^(5*d)*s*
         (gZlRC*(-2*s^2 - 2*s*t + t^2) + gZlLC*(s^2 + 4*s*t + t^2)) + 
        d^3*(2*Pi)^(5*d)*s*(gZlLC*(2*s^2*(s + 2*t) + 16*mw^4*(5*s + 12*t) + 
            3*mw^2*s*(15*s + 38*t)) - gZlRC*(2*s^2*(s + 2*t) + 
            16*mw^4*(7*s + 12*t) + 3*mw^2*s*(23*s + 38*t))) + 
        2^(2 + 5*d)*d*Pi^(5*d)*(gZlRC*(mw^2*s*(12*s^2 + 16*s*t - 3*t^2) - 
            16*mw^4*(2*s^2 + 2*s*t - t^2) + 2*s^2*(-2*s^2 - 2*s*t + t^2)) + 
          gZlLC*(16*mw^4*(s^2 + 4*s*t + t^2) + 2*s^2*(s^2 + 4*s*t + t^2) - 
            mw^2*s*(7*s^2 + 22*s*t + 3*t^2))) - 2^(1 + 5*d)*d^2*Pi^(5*d)*
         (-(gZlRC*(2*s^3*(3*s + 5*t) + mw^2*s*(37*s^2 + 29*s*t - 24*t^2) + 
             16*mw^4*(7*s^2 + 9*s*t - 2*t^2))) + gZlLC*(2*s^3*(2*s + 5*t) + 
            16*mw^4*(4*s^2 + 13*s*t + 2*t^2) + mw^2*s*(16*s^2 + 77*s*t + 
              24*t^2))))*GaugeXi[Q]^2 + d*(2*Pi)^(5*d)*
       (gZlRC*(-8*(-1 + d)*mw^4 + s^2 + mw^2*(s - 8*d*s))*
         ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
        gZlLC*(8*(-1 + d)*mw^4 + (-1 + 8*d)*mw^2*s - s^2)*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^3 - 
      d*mw^2*(2*Pi)^(5*d)*s*(-(gZlRC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZlLC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^4) + 
    gWdu*gWud*gWWZ*gZuLC*(2*Pi)^(2*d)*(mz^2 - s)*s*sw^2*CKM[1, 1]*CKMC[1, 1]*
     (2^(2 + 3*d)*(-1 + d)^2*mw^2*Pi^(3*d)*s*
       (-(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
        gZlL*gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
      (8^(1 + d)*d^4*(gZlL*gZlLC - gZlR*gZlRC)*mw^4*Pi^(3*d)*s*(s + 2*t) - 
        2^(5 + 3*d)*mw^2*Pi^(3*d)*s*(gZlR*gZlRC*(-2*s^2 - 2*s*t + t^2) + 
          gZlL*gZlLC*(s^2 + 4*s*t + t^2)) - d^3*(2*Pi)^(3*d)*s*
         (gZlL*gZlLC*(-13*mw^2*s*(s + 2*t) + s^2*(s + 2*t) + 
            8*mw^4*(5*s + 12*t)) - gZlR*gZlRC*(-13*mw^2*s*(s + 2*t) + 
            s^2*(s + 2*t) + 8*mw^4*(7*s + 12*t))) + 2^(1 + 3*d)*d^2*Pi^(3*d)*
         (gZlR*gZlRC*(-(s^3*(3*s + 5*t)) + mw^2*s^2*(43*s + 73*t) - 
            8*mw^4*(7*s^2 + 9*s*t - 2*t^2)) + gZlL*gZlLC*(s^3*(2*s + 5*t) - 
            mw^2*s^2*(30*s + 73*t) + 8*mw^4*(4*s^2 + 13*s*t + 2*t^2))) - 
        2^(2 + 3*d)*d*Pi^(3*d)*(gZlR*gZlRC*(mw^2*s*(38*s^2 + 46*s*t - 
              13*t^2) - 8*mw^4*(2*s^2 + 2*s*t - t^2) + 
            s^2*(-2*s^2 - 2*s*t + t^2)) + gZlL*gZlLC*
           (8*mw^4*(s^2 + 4*s*t + t^2) + s^2*(s^2 + 4*s*t + t^2) - 
            mw^2*s*(21*s^2 + 72*s*t + 13*t^2))))*GaugeXi[Q] + 
      (-(2^(2 + 3*d)*d^4*(gZlL*gZlLC - gZlR*gZlRC)*mw^2*Pi^(3*d)*s*
          (4*mw^2 + 3*s)*(s + 2*t)) + 2^(4 + 3*d)*mw^2*Pi^(3*d)*s*
         (gZlR*gZlRC*(-2*s^2 - 2*s*t + t^2) + gZlL*gZlLC*(s^2 + 4*s*t + 
            t^2)) + d^3*(2*Pi)^(3*d)*s*(gZlL*gZlLC*(2*s^2*(s + 2*t) + 
            16*mw^4*(5*s + 12*t) + 3*mw^2*s*(15*s + 38*t)) - 
          gZlR*gZlRC*(2*s^2*(s + 2*t) + 16*mw^4*(7*s + 12*t) + 
            3*mw^2*s*(23*s + 38*t))) + 2^(2 + 3*d)*d*Pi^(3*d)*
         (gZlR*gZlRC*(mw^2*s*(12*s^2 + 16*s*t - 3*t^2) - 
            16*mw^4*(2*s^2 + 2*s*t - t^2) + 2*s^2*(-2*s^2 - 2*s*t + t^2)) + 
          gZlL*gZlLC*(16*mw^4*(s^2 + 4*s*t + t^2) + 
            2*s^2*(s^2 + 4*s*t + t^2) - mw^2*s*(7*s^2 + 22*s*t + 3*t^2))) - 
        2^(1 + 3*d)*d^2*Pi^(3*d)*(-(gZlR*gZlRC*(2*s^3*(3*s + 5*t) + 
             mw^2*s*(37*s^2 + 29*s*t - 24*t^2) + 16*mw^4*(7*s^2 + 9*s*t - 2*
                t^2))) + gZlL*gZlLC*(2*s^3*(2*s + 5*t) + 
            16*mw^4*(4*s^2 + 13*s*t + 2*t^2) + mw^2*s*(16*s^2 + 77*s*t + 
              24*t^2))))*GaugeXi[Q]^2 + d*(2*Pi)^(3*d)*
       (gZlR*gZlRC*(-8*(-1 + d)*mw^4 + s^2 + mw^2*(s - 8*d*s))*
         ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
        gZlL*gZlLC*(8*(-1 + d)*mw^4 + (-1 + 8*d)*mw^2*s - s^2)*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^3 - 
      d*mw^2*(2*Pi)^(3*d)*s*(-(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZlL*gZlLC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*GaugeXi[Q]^4)))/
  ((-1 + d)*d*mw^4*Pi^(6*d)*(mz^2 - s)^2*(mzC^2 - s)*s^2*sw^2*
   (-1 + GaugeXi[Q])^2*GaugeXi[Q]), 
 ((-I/16)*EL^6*(-((gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(mz^2 - s)^2*s^4*
       (2^(2 + 3*d)*(4 - 5*d + d^2)*mw^4*Pi^(3*d)*((-4 - 2*d + d^2)*s + 
          2*(14 - 8*d + d^2)*t) + 2^(2 + 3*d)*(-3 + 2*d)*mw^2*Pi^(3*d)*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
        (2*Pi)^(3*d)*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
       CKM[1, 1]*CKMC[1, 1]*(-1 + GaugeXi[Q])^4)/(2*Pi)^(4*d)) + 
    (gAu*gWlN*gWNl*gWWA*gZlLC*(2*mw^2 - s)*(mz^2 - s)^2*s^2*
      (4*(-1 + d)*mw^4 + 4*(-3 + 2*d)*mw^2*s + s^2)*
      (-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
      (-1 + GaugeXi[Q])^2*((2*Pi)^(7*d) - 2^(1 + 7*d)*Pi^(7*d)*GaugeXi[Q] + 
       (2*Pi)^(7*d)*GaugeXi[Q]^2))/(2*Pi)^(8*d) - 
    (gAl*gAu*gWWA^2*(mz^2 - s)^2*(s - s*GaugeXi[Q])^2*
      ((gZlLC + gZlRC)*(gZuLC + gZuRC)*(2*Pi)^(3*d)*s*(4*(-1 + d)*mw^4 - 
         4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*
        (-1 + GaugeXi[Q])^2 + (gZlLC + gZlRC)*(gZuLC + gZuRC)*(2*Pi)^(2*d)*s*
        (4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*
        (2^(2 + d)*(-1 + d)*mw^4*Pi^d - 2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
        (-1 + GaugeXi[Q])^2 + (1 - d)*(2*Pi)^(3*d)*(-2*mw^2 + s)^2*
        (4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
         gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
         gZlLC*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2 + 
       (2*Pi)^(3*d)*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlLC*gZuLC*((-4 + d)*s - 2*t) + gZlRC*gZuRC*((-4 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-2 + d)*s + 2*t) - gZlLC*gZuRC*((-2 + d)*s + 2*t))*
        (4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (-1 + GaugeXi[Q])^2 - 2*(1 - d)*
        (gZlLC*((-4 + d)*gZuRC*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*(-1 + d)*gZuRC*
            mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) + 8^(1 + d)*gZuRC*mw^6*Pi^(3*d)*
            s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) - 2^(1 + 3*d)*gZuRC*mw^4*
            Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 
             32*t^2) + 2^(2 + 3*d)*gZuRC*mw^2*Pi^(3*d)*s^2*
            ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2) + 
           gZuLC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
             (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
              ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
              s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
             2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 2*
                (69 - 41*d + 7*d^2)*s*t + 32*t^2))) + 
         gZlRC*((-4 + d)*gZuLC*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*(-1 + d)*gZuLC*
            mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) + 8^(1 + d)*gZuLC*mw^6*Pi^(3*d)*
            s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) - 2^(1 + 3*d)*gZuLC*mw^4*
            Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 
             32*t^2) + 2^(2 + 3*d)*gZuLC*mw^2*Pi^(3*d)*s^2*
            ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2) + 
           gZuRC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
             (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
              ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
              s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
             2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 2*
                (69 - 41*d + 7*d^2)*s*t + 32*t^2))))*(-1 + GaugeXi[Q])^2 + 
       (1 - d)*(-2*mw^2 + s)^2*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlLC*gZuLC*((-2 + d)*s - 2*t) + gZlRC*gZuRC*((-2 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-4 + d)*s + 2*t) - gZlLC*gZuRC*((-4 + d)*s + 2*t))*
        ((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
         (2*Pi)^(3*d)*GaugeXi[Q]^2)))/(2*Pi)^(4*d) - 
    (gAu*gWWA*gWWZ*(mz^2 - s)*s*(s - s*GaugeXi[Q])^2*
      ((gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(2*Pi)^(3*d)*s*
        (4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + 
         d*s^2)*(-1 + GaugeXi[Q])^2 + (gZlL*gZlLC + gZlR*gZlRC)*
        (gZuLC + gZuRC)*(2*Pi)^(2*d)*s*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*
        (2^(2 + d)*(-1 + d)*mw^4*Pi^d - 2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
        (-1 + GaugeXi[Q])^2 - 2*(1 - d)*
        (gZlL*gZlLC*((-4 + d)*gZuRC*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*(-1 + d)*
            gZuRC*mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) + 8^(1 + d)*gZuRC*mw^6*
            Pi^(3*d)*s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) - 
           2^(1 + 3*d)*gZuRC*mw^4*Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 
             2*(45 - 39*d + 7*d^2)*s*t - 32*t^2) + 2^(2 + 3*d)*gZuRC*mw^2*
            Pi^(3*d)*s^2*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
             4*t^2) + gZuLC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*
              ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(3*d)*s^4*t - 
             8^(1 + d)*mw^6*Pi^(3*d)*s*((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 
             2^(2 + 3*d)*mw^2*Pi^(3*d)*s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + 
                 d^2)*s*t + 4*t^2) + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*
              ((30 - 31*d + 8*d^2)*s^2 + 2*(69 - 41*d + 7*d^2)*s*t + 32*
                t^2))) + gZlR*gZlRC*((-4 + d)*gZuLC*(2*Pi)^(3*d)*s^4*t - 
           8^(1 + d)*(-1 + d)*gZuLC*mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) + 
           8^(1 + d)*gZuLC*mw^6*Pi^(3*d)*s*((-4 + d)*s - 2*(3 - 5*d + d^2)*
              t) - 2^(1 + 3*d)*gZuLC*mw^4*Pi^(3*d)*s*
            ((60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 32*t^2) + 
           2^(2 + 3*d)*gZuLC*mw^2*Pi^(3*d)*s^2*((8 - 6*d + d^2)*s^2 + 
             2*(8 - 6*d + d^2)*s*t - 4*t^2) + 
           gZuRC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
             (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
              ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
              s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
             2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 2*
                (69 - 41*d + 7*d^2)*s*t + 32*t^2))))*(-1 + GaugeXi[Q])^2 + 
       (2*Pi)^d*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 
         4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlL*gZlLC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t) - gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t))*((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*
          GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) + 2^(1 + d)*(1 - d)*Pi^d*
        (2*mw^2 - s)*(mw^2 - s/2)*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t) - gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t))*((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*
          GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) + 2*(1 - d)*(2*mw^2 - s)*
        (mw^2 - s/2)*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t) - gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t))*((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*
          GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2)))/(2*Pi)^(4*d) - 
    (gAl*gWWA*gWWZ*(mz^2 - s)*s*(s - s*GaugeXi[Q])^2*
      ((gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*(2*Pi)^(3*d)*s*
        (4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + 
         d*s^2)*(-1 + GaugeXi[Q])^2 + (gZlLC + gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*(2*Pi)^(2*d)*s*(4*(-1 + d)*mw^4 - 
         4*d*mw^2*s + d*s^2)*(2^(2 + d)*(-1 + d)*mw^4*Pi^d - 
         2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*(-1 + GaugeXi[Q])^2 + 
       2*(1 - d)*(gZlRC*gZuL*gZuLC*(-((-4 + d)*(2*Pi)^(3*d)*s^4*t) + 
           8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) - 
           8^(1 + d)*mw^6*Pi^(3*d)*s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) + 
           2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 
             2*(45 - 39*d + 7*d^2)*s*t - 32*t^2) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
            s^2*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2)) + 
         gZlLC*gZuR*gZuRC*(-((-4 + d)*(2*Pi)^(3*d)*s^4*t) + 
           8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) - 
           8^(1 + d)*mw^6*Pi^(3*d)*s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) + 
           2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 
             2*(45 - 39*d + 7*d^2)*s*t - 32*t^2) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
            s^2*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2)) - 
         gZlLC*gZuL*gZuLC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*
            ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(3*d)*s^4*t - 
           8^(1 + d)*mw^6*Pi^(3*d)*s*((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 
           2^(2 + 3*d)*mw^2*Pi^(3*d)*s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*
              s*t + 4*t^2) + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*
            ((30 - 31*d + 8*d^2)*s^2 + 2*(69 - 41*d + 7*d^2)*s*t + 32*t^2)) - 
         gZlRC*gZuR*gZuRC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*
            ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(3*d)*s^4*t - 
           8^(1 + d)*mw^6*Pi^(3*d)*s*((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 
           2^(2 + 3*d)*mw^2*Pi^(3*d)*s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*
              s*t + 4*t^2) + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*
            ((30 - 31*d + 8*d^2)*s^2 + 2*(69 - 41*d + 7*d^2)*s*t + 32*t^2)))*
        (-1 + GaugeXi[Q])^2 + (2*Pi)^d*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlLC*gZuL*gZuLC*((-4 + d)*s - 2*t) + gZlRC*gZuR*gZuRC*
          ((-4 + d)*s - 2*t) - gZlRC*gZuL*gZuLC*((-2 + d)*s + 2*t) - 
         gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*(4*(-1 + d)*mw^4 - 
         4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*((2*Pi)^(2*d) - 
         2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) + 
       (1 - d)*(2*Pi)^d*(-2*mw^2 + s)^2*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(2*d) - 
         2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) + 
       (1 - d)*(-2*mw^2 + s)^2*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(3*d) - 
         2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2)))/
     (2*Pi)^(4*d) - (gWWZ^2*s^2*(s - s*GaugeXi[Q])^2*
      (2^(1 + 3*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        Pi^(3*d)*s*(4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*(4*(-1 + d)*mw^4 - 
         4*d*mw^2*s + d*s^2)*(-1 + GaugeXi[Q])^2 - 
       2*(1 - d)*(gZlL*gZlLC*(-(gZuR*gZuRC*(-((-4 + d)*(2*Pi)^(3*d)*s^4*t) + 
              8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-4 + d)*s + 2*t) - 
              8^(1 + d)*mw^6*Pi^(3*d)*s*((-4 + d)*s - 2*(3 - 5*d + d^2)*t) + 
              2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((60 - 47*d + 8*d^2)*s^2 + 
                2*(45 - 39*d + 7*d^2)*s*t - 32*t^2) - 2^(2 + 3*d)*mw^2*Pi^
                (3*d)*s^2*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
                4*t^2))) + gZuL*gZuLC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*
              ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(3*d)*s^4*t - 
             8^(1 + d)*mw^6*Pi^(3*d)*s*((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 
             2^(2 + 3*d)*mw^2*Pi^(3*d)*s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + 
                 d^2)*s*t + 4*t^2) + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*
              ((30 - 31*d + 8*d^2)*s^2 + 2*(69 - 41*d + 7*d^2)*s*t + 32*
                t^2))) + gZlR*gZlRC*(-(gZuL*gZuLC*(-((-4 + d)*(2*Pi)^(3*d)*
                s^4*t) + 8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-4 + d)*s + 
                2*t) - 8^(1 + d)*mw^6*Pi^(3*d)*s*((-4 + d)*s - 
                2*(3 - 5*d + d^2)*t) + 2^(1 + 3*d)*mw^4*Pi^(3*d)*s*(
                (60 - 47*d + 8*d^2)*s^2 + 2*(45 - 39*d + 7*d^2)*s*t - 
                32*t^2) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*s^2*((8 - 6*d + d^2)*
                 s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2))) + 
           gZuR*gZuRC*(8^(1 + d)*(-1 + d)*mw^8*Pi^(3*d)*((-2 + d)*s - 2*t) - 
             (-2 + d)*(2*Pi)^(3*d)*s^4*t - 8^(1 + d)*mw^6*Pi^(3*d)*s*
              ((-2 + d)*s - 2*(3 - 3*d + d^2)*t) - 2^(2 + 3*d)*mw^2*Pi^(3*d)*
              s^2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 4*t^2) + 
             2^(1 + 3*d)*mw^4*Pi^(3*d)*s*((30 - 31*d + 8*d^2)*s^2 + 2*
                (69 - 41*d + 7*d^2)*s*t + 32*t^2))))*(-1 + GaugeXi[Q])^2 + 
       2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(mw^2 - s/2)*
        (gZlL*gZlLC*(gZuR*gZuRC*(-(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-4 + d)*s + 
                2*t)) + 2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-4 + d)*s + 2*t) - 
             3*2^(1 + d)*mw^2*Pi^d*s^2*((-4 + d)*s + 2*t) + 
             s^3*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
           gZuL*gZuLC*(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-2 + d)*s - 2*t) - 
             2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-2 + d)*s - 2*t) + 
             3*2^(1 + d)*mw^2*Pi^d*s^2*((-2 + d)*s - 2*t) + 
             s^3*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) + 
         gZlR*gZlRC*(gZuL*gZuLC*(-(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-4 + d)*s + 
                2*t)) + 2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-4 + d)*s + 2*t) - 
             3*2^(1 + d)*mw^2*Pi^d*s^2*((-4 + d)*s + 2*t) + 
             s^3*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
           gZuR*gZuRC*(2^(3 + d)*(-1 + d)*mw^6*Pi^d*((-2 + d)*s - 2*t) - 
             2^(2 + d)*(1 + d)*mw^4*Pi^d*s*((-2 + d)*s - 2*t) + 
             3*2^(1 + d)*mw^2*Pi^d*s^2*((-2 + d)*s - 2*t) + 
             s^3*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*
        (-1 + GaugeXi[Q])^2 + (1 - d)*(-2*mw^2 + s)^2*(4*(-1 + d)*mw^4 - 
         4*mw^2*s + s^2)*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        ((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
         (2*Pi)^(3*d)*GaugeXi[Q]^2) + (4*(-1 + d)*mw^4 - 4*mw^2*s + s^2)*
        (4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlR*gZlRC*(gZuR*gZuRC*((-4 + d)*s - 2*t) - gZuL*gZuLC*
            ((-2 + d)*s + 2*t)) + gZlL*gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - 
           gZuR*gZuRC*((-2 + d)*s + 2*t)))*((2*Pi)^(3*d) - 
         2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2)))/
     (2*Pi)^(4*d) - (gWlN*gWNl*gWWZ*gZlLC*(mz^2 - s)*s*(s - s*GaugeXi[Q])^2*
      (2^(2 + 5*d)*(-1 + d)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*Pi^(5*d)*
        (2*mw^2 - s)*((-2 + d)*s^2 - 4*s*t - 4*(-1 + d)*t^2)*
        (-1 + GaugeXi[Q])^2 + (2*Pi)^(5*d)*(2*mw^2 - s)*s*
        (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t))*
        (4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (-1 + GaugeXi[Q])^2 + 2^(2 + 5*d)*(1 - d)*mw^4*Pi^(5*d)*(s + 2*t)*
        (gZuR*gZuRC*(-2*(-2 + d)*mw^2*((-4 + d)*s + 2*t) + 
           s*((24 - 10*d + d^2)*s + 2*(2 + d)*t)) + 
         gZuL*gZuLC*(2*(-2 + d)*mw^2*((-2 + d)*s - 2*t) + 
           s*(-((12 - 8*d + d^2)*s) + 2*(2 + d)*t)))*(-1 + GaugeXi[Q])^2 - 
       2*(1 - d)*s*(gZuR*gZuRC*(-((-4 + d)*(2*Pi)^(5*d)*s^3*t) + 
           2^(2 + 5*d)*(-3 + d)*mw^6*Pi^(5*d)*((-4 + d)*s + 2*t) + 
           2^(1 + 5*d)*mw^4*Pi^(5*d)*s*(3*(12 - 7*d + d^2)*s + 
             2*(47 - 27*d + 4*d^2)*t) - 2^(1 + 5*d)*mw^2*Pi^(5*d)*s*
            (2*(8 - 6*d + d^2)*s^2 + (28 - 23*d + 4*d^2)*s*t - 8*t^2)) - 
         gZuL*gZuLC*(2^(2 + 5*d)*(-3 + d)*mw^6*Pi^(5*d)*((-2 + d)*s - 2*t) - 
           (-2 + d)*(2*Pi)^(5*d)*s^3*t + 2^(1 + 5*d)*mw^4*Pi^(5*d)*s*
            (3*(6 - 5*d + d^2)*s + 2*(37 - 25*d + 4*d^2)*t) - 
           2^(1 + 5*d)*mw^2*Pi^(5*d)*s*(2*(-2 + d)^2*s^2 + 
             (38 - 23*d + 4*d^2)*s*t + 8*t^2)))*(-1 + GaugeXi[Q])^2 + 
       (gZuL*gZuLC + gZuR*gZuRC)*(2*Pi)^(5*d)*(2*mw^2 - s)*
        (4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*(s - s*GaugeXi[Q])^2 - 
       2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(mw^2 - s/2)*s*
        (gZuR*gZuRC*(8*mw^4*((-3 + d)*s + t) - 4*mw^2*s*((-4 + d)*s + 2*t) + 
           s^2*((-4 + d)*s + 2*t)) + gZuL*gZuLC*
          (4*mw^2*s*((-2 + d)*s - 2*t) + 8*mw^4*t + 
           s^2*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*
          GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2) - 2*(1 - d)*(mw^2 - s/2)*s*
        (gZuL*gZuLC*(4*mw^2*s*((-2 + d)*s - 2*t) + 
           s^2*(-((-2 + d)*s) + 2*t) + 4*mw^4*((10 - 7*d + d^2)*s - 
             2*(-3 + d)*t)) + gZuR*gZuRC*(-4*mw^2*s*((-4 + d)*s + 2*t) + 
           s^2*((-4 + d)*s + 2*t) - 4*mw^4*((8 - 5*d + d^2)*s + 
             2*(-3 + d)*t)))*((2*Pi)^(5*d) - 2^(1 + 5*d)*Pi^(5*d)*
          GaugeXi[Q] + (2*Pi)^(5*d)*GaugeXi[Q]^2) + (gZuL*gZuLC + gZuR*gZuRC)*
        (2*Pi)^(4*d)*s^2*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*
        (2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*mw^2 - s)*
          GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s)*GaugeXi[Q]^2)))/
     (2*Pi)^(6*d) + gAl*gWdu*gWud*gWWA*gZuLC*(mz^2 - s)^2*s^2*CKM[1, 1]*
     CKMC[1, 1]*(-1 + GaugeXi[Q])^2*
     (((gZlLC + gZlRC)*(2*mw^2 - s)*s^2*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + 
         d*s^2)*(-1 + GaugeXi[Q])^2)/(2*Pi)^d + 
      (2^(2 - d)*(-1 + d)*(gZlLC + gZlRC)*mw^4*(2*mw^2 - s)*
        ((-2 + d)*s^2 - 4*s*t - 4*(-1 + d)*t^2)*(-1 + GaugeXi[Q])^2)/Pi^d - 
      4*(1 - d)*mw^4*(s + 2*t)*(-((2^(2 - d)*(-2 + d)*(gZlLC + gZlRC)*mw^2*s)/
          Pi^d) - (2^(2 - d)*(-2 + d)*(gZlLC + gZlRC)*s*t)/Pi^d + 
        ((2 - d)*mw^2*((-2 + d)*gZlLC*s - (-4 + d)*gZlRC*s - 2*gZlLC*t - 
           2*gZlRC*t))/(2*Pi)^d + ((2 - d)*mw^2*((-6 + d)*gZlLC*s - 
           2*gZlLC*t - gZlRC*(d*s + 2*t)))/(2*Pi)^d + 
        (s*(d^2*gZlLC*(2*Pi)^d*s - d^2*gZlRC*(2*Pi)^d*s + 
           2^(1 + d)*gZlLC*Pi^d*((6 - 4*d)*s + (-6 + d)*t) + 
           2^(1 + d)*gZlRC*Pi^d*((-12 + 5*d)*s + (-6 + d)*t)))/(2*Pi)^(2*d))*
       (-1 + GaugeXi[Q])^2 + ((-1 + d)*(2*mw^2 - s)*s*
        (gZlLC*(4*mw^2*s*((-2 + d)*s - 2*t) + s^2*(-((-2 + d)*s) + 2*t) + 
           4*mw^4*((10 - 7*d + d^2)*s - 2*(-3 + d)*t)) + 
         gZlRC*(-4*mw^2*s*((-4 + d)*s + 2*t) + s^2*((-4 + d)*s + 2*t) - 
           4*mw^4*((8 - 5*d + d^2)*s + 2*(-3 + d)*t)))*(-1 + GaugeXi[Q])^2)/
       (2*Pi)^d - (2^(1 - 3*d)*(1 - d)*s*(gZlRC*(2*Pi)^(2*d)*
          (-((-4 + d)*s^3*t) + 4*(-3 + d)*mw^6*((-4 + d)*s + 2*t) + 
           2*mw^4*s*(3*(12 - 7*d + d^2)*s + 2*(47 - 27*d + 4*d^2)*t) - 
           2*mw^2*s*(2*(8 - 6*d + d^2)*s^2 + (28 - 23*d + 4*d^2)*s*t - 
             8*t^2)) - gZlLC*(4^(1 + d)*(-3 + d)*mw^6*Pi^(2*d)*
            ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(2*d)*s^3*t + 
           2^(1 + 2*d)*mw^4*Pi^(2*d)*s*(3*(6 - 5*d + d^2)*s + 
             2*(37 - 25*d + 4*d^2)*t) - 2^(1 + 2*d)*mw^2*Pi^(2*d)*s*
            (2*(-2 + d)^2*s^2 + (38 - 23*d + 4*d^2)*s*t + 8*t^2)))*
        (-1 + GaugeXi[Q])^2)/Pi^(3*d) + ((-1 + d)*(2*mw^2 - s)*s*
        (gZlRC*(8*mw^4*((-3 + d)*s + t) - 4*mw^2*s*((-4 + d)*s + 2*t) + 
           s^2*((-4 + d)*s + 2*t)) + gZlLC*(4*mw^2*s*((-2 + d)*s - 2*t) + 
           8*mw^4*t + s^2*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(3*d) - 
         2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2))/
       (2*Pi)^(4*d) + ((gZlLC + gZlRC)*s^2*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + 
         d*s^2)*(2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s - 2^(1 + d)*Pi^d*
          (2*mw^2 - s)*GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s)*
          GaugeXi[Q]^2))/(2*Pi)^(2*d) - 
      (s*(4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlRC*(s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s - t)) + 
           2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t)) - 
         gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
           s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s + t))) + 
         2^(1 + d)*Pi^d*(2*mw^2 - s)*((-4 + d)*gZlLC*s - (-2 + d)*gZlRC*s - 
           2*gZlLC*t - 2*gZlRC*t)*GaugeXi[Q] - 
         (-(gZlRC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) + 
              2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t))) + 
           gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
             s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*GaugeXi[Q]^2))/
       (2*Pi)^(2*d)) + (gWdu*gWud*gWWZ*gZuLC*(mz^2 - s)*s*CKM[1, 1]*
      CKMC[1, 1]*(s - s*GaugeXi[Q])^2*(2^(2 + 3*d)*(-1 + d)*
        (gZlL*gZlLC + gZlR*gZlRC)*mw^4*Pi^(3*d)*(2*mw^2 - s)*
        ((-2 + d)*s^2 - 4*s*t - 4*(-1 + d)*t^2)*(-1 + GaugeXi[Q])^2 - 
       2^(1 + 3*d)*(1 - d)*Pi^(3*d)*(mw^2 - s/2)*s*
        (gZlL*gZlLC*(4*mw^2*s*((-2 + d)*s - 2*t) + 
           s^2*(-((-2 + d)*s) + 2*t) + 4*mw^4*((10 - 7*d + d^2)*s - 
             2*(-3 + d)*t)) + gZlR*gZlRC*(-4*mw^2*s*((-4 + d)*s + 2*t) + 
           s^2*((-4 + d)*s + 2*t) - 4*mw^4*((8 - 5*d + d^2)*s + 
             2*(-3 + d)*t)))*(-1 + GaugeXi[Q])^2 + 2^(2 + 3*d)*(1 - d)*mw^4*
        Pi^(3*d)*(s + 2*t)*(gZlR*gZlRC*(-2*(-2 + d)*mw^2*((-4 + d)*s + 2*t) + 
           s*((24 - 10*d + d^2)*s + 2*(2 + d)*t)) + 
         gZlL*gZlLC*(2*(-2 + d)*mw^2*((-2 + d)*s - 2*t) + 
           s*(-((12 - 8*d + d^2)*s) + 2*(2 + d)*t)))*(-1 + GaugeXi[Q])^2 - 
       2^(1 + d)*(1 - d)*Pi^d*s*(gZlR*gZlRC*(2*Pi)^(2*d)*(-((-4 + d)*s^3*t) + 
           4*(-3 + d)*mw^6*((-4 + d)*s + 2*t) + 2*mw^4*s*
            (3*(12 - 7*d + d^2)*s + 2*(47 - 27*d + 4*d^2)*t) - 
           2*mw^2*s*(2*(8 - 6*d + d^2)*s^2 + (28 - 23*d + 4*d^2)*s*t - 
             8*t^2)) - gZlL*gZlLC*(4^(1 + d)*(-3 + d)*mw^6*Pi^(2*d)*
            ((-2 + d)*s - 2*t) - (-2 + d)*(2*Pi)^(2*d)*s^3*t + 
           2^(1 + 2*d)*mw^4*Pi^(2*d)*s*(3*(6 - 5*d + d^2)*s + 
             2*(37 - 25*d + 4*d^2)*t) - 2^(1 + 2*d)*mw^2*Pi^(2*d)*s*
            (2*(-2 + d)^2*s^2 + (38 - 23*d + 4*d^2)*s*t + 8*t^2)))*
        (-1 + GaugeXi[Q])^2 - 2*(1 - d)*(mw^2 - s/2)*s*
        (gZlR*gZlRC*(8*mw^4*((-3 + d)*s + t) - 4*mw^2*s*((-4 + d)*s + 2*t) + 
           s^2*((-4 + d)*s + 2*t)) + gZlL*gZlLC*
          (4*mw^2*s*((-2 + d)*s - 2*t) + 8*mw^4*t + 
           s^2*(-((-2 + d)*s) + 2*t)))*((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*
          GaugeXi[Q] + (2*Pi)^(3*d)*GaugeXi[Q]^2) + (gZlL*gZlLC + gZlR*gZlRC)*
        (2*Pi)^(2*d)*s^2*(4*(-1 + d)*mw^4 - 4*d*mw^2*s + d*s^2)*
        (2^(1 + d)*mw^2*Pi^d + 2^(1 + d)*Pi^d*s - 3*(2*Pi)^d*s - 
         2^(1 + d)*Pi^d*(2*mw^2 - s)*GaugeXi[Q] + 
         (2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s)*GaugeXi[Q]^2) + 
       (gZlL*gZlLC + gZlR*gZlRC)*(2*Pi)^(2*d)*s^2*(4*(-1 + d)*mw^4 - 
         4*d*mw^2*s + d*s^2)*(2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s - 
         2^(1 + d)*Pi^d*(2*mw^2 - s)*GaugeXi[Q] + 
         (2^(1 + d)*mw^2*Pi^d - (2*Pi)^d*s)*GaugeXi[Q]^2) - 
       (2*Pi)^(2*d)*s*(4*(-1 + d)*mw^4 - 4*mw^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlR*gZlRC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) + 
           2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t)) - 
         gZlL*gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
           s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
         2^(1 + d)*Pi^d*(2*mw^2 - s)*(gZlL*gZlLC*((-4 + d)*s - 2*t) - 
           gZlR*gZlRC*((-2 + d)*s + 2*t))*GaugeXi[Q] - 
         (-(gZlR*gZlRC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) + 
              2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t))) + 
           gZlL*gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
             s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*GaugeXi[Q]^2)))/
     (2*Pi)^(4*d)))/((-1 + d)*mw^4*(mz^2 - s)^2*(mzC^2 - s)*s^4*
   (-1 + GaugeXi[Q])^4), 
 (I*4^(-1 - 2*d)*EL^6*(-(2^(1 + 3*d)*gAu*gWlN*gWNl*gWWA*gZlLC*Pi^(3*d)*
      (mz^2 - s)*(mw^2 + 2*s)*(gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZuLC*((-2 + d)^2*s^2 + 
         2*(8 - 5*d + d^2)*s*t + 4*t^2))*(mw - mw*GaugeXi[Q])^2) - 
    2^(1 + 3*d)*gWlN*gWNl*gWWZ*gZlLC*Pi^(3*d)*s*(mw^2 + 2*s)*
     (gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (mw - mw*GaugeXi[Q])^2 + 2^(1 + 3*d)*gAl*gWdu*gWud*gWWA*gZuLC*Pi^(3*d)*
     (mz^2 - s)*(mw^2 + 2*s)*(gZlRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*CKMC[1, 1]*
     (mw - mw*GaugeXi[Q])^2 + 2^(1 + 3*d)*gWdu*gWud*gWWZ*gZuLC*Pi^(3*d)*s*
     (mw^2 + 2*s)*(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) - gZlL*gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     CKM[1, 1]*CKMC[1, 1]*(mw - mw*GaugeXi[Q])^2 + 
    gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(mz^2 - s)*s^2*
     (2*(-128 + 88*d - 18*d^2 + d^3)*mw^2*s - (-144 + 96*d - 18*d^2 + d^3)*
       s^2 - 8*d*s*t - 16*t^2)*CKM[1, 1]*CKMC[1, 1]*
     ((2*Pi)^(3*d) - 2^(1 + 3*d)*Pi^(3*d)*GaugeXi[Q] + 
      (2*Pi)^(3*d)*GaugeXi[Q]^2)))/(Pi^(4*d)*(mz^2 - s)*(mzC^2 - s)*
   (s - s*GaugeXi[Q])^2), ((-I)*4^(-1 - d)*EL^6*gWdu*gWlN*gWNl*gWud*gZlLC*
   gZuLC*(s + t)*(2^(2 + d)*(-56 + 46*d - 12*d^2 + d^3)*mw^2*Pi^d - 
    d^3*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((80 - 56*d + 11*d^2)*s + 
      4*(8 - 6*d + d^2)*t))*CKM[1, 1]*CKMC[1, 1])/(Pi^(2*d)*(mzC^2 - s)), 
 ((-I)*2^(-3 - 2*d)*EL^6*gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*
   (d^3*(2*Pi)^d*s^2*(s + 3*t) - 2^(2 + d)*(-4 + d)*mw^2*Pi^d*(s + t)*
     ((36 - 16*d + d^2)*s - 4*(-2 + d)*t) + 2^(1 + d)*(-4 + d)*mw^4*Pi^d*
     (3*(20 - 10*d + d^2)*s + 2*(14 - 8*d + d^2)*t) + 
    2^(1 + d)*Pi^d*((-72 + 48*d - 9*d^2)*s^3 - (72 - 52*d + 9*d^2 + d^3)*s^2*
       t + 4*(2 + d)*s*t^2 + 8*t^3))*CKM[1, 1]*CKMC[1, 1])/
  (Pi^(2*d)*(mzC^2 - s)), (I/16)*EL^6*
  (-((2^(1 - d)*gAu*gWlN*gWNl*gWWA*gZlLC*((-4 + 6*d)*mw^2 + d*s)*
      (-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
       gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*d*mw^4*Pi^d*(mzC^2 - s)*s)) + 
   (2^(1 - d)*gWlN*gWNl*gWWZ*gZlLC*((-4 + 6*d)*mw^2 + d*s)*
     (-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*(-mzC^2 + s)) + 
   (2^(3 - d)*gAl*gAu*ggmgmAA*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    (Pi^d*(mzC^2 - s)*s^2) + (2^(3 - d)*gAl*gAu*ggpgpAA*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    (Pi^d*(mzC^2 - s)*s^2) - (2^(3 - d)*gAl*gAu*gFFA^2*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*s^2*(-mzC^2 + s)) + 
   (2^(3 - d)*gAl*gAu*ggmgmA^2*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*s^2*(-mzC^2 + s)) + 
   (2^(3 - d)*gAl*gAu*ggpgpA^2*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*s^2*(-mzC^2 + s)) - 
   (2^(3 - d)*gAl*gFFA*gFFZ*(-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuR*gZuRC*
       ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*(mz^2 - s)*s*(-mzC^2 + s)) + 
   (2^(3 - d)*gAl*ggmgmA*ggmgmZ*
     (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
         4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*(mz^2 - s)*s*(-mzC^2 + s)) + 
   (2^(3 - d)*gAl*ggpgpA*ggpgpZ*
     (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
         4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
    ((-1 + d)*Pi^d*(mz^2 - s)*s*(-mzC^2 + s)) + 
   (4^(1 - d)*gWlN*gWNl*gZlLC*gZNL*
     (gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
    (mw^2*Pi^(2*d)*(mz^2 - s)*(-mzC^2 + s)) + 
   (4^(1 - d)*gAl*gFFAZ*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 
        2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
    (Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) - 
   (2^(3 - 2*d)*gAl*ggmgmAZ*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 
        2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
    (Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) - 
   (2^(3 - 2*d)*gAl*ggpgpAZ*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 
        2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))/
    (Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) - 
   (4^(1 - d)*gAl*gAu*gFFAA*(gZlLC*(d^2*gZuLC*(2*Pi)^d*s^2 - 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuRC*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuLC*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2))))/(Pi^(2*d)*(mzC^2 - s)*s^2) + 
   (2^(3 - 2*d)*gAu*ggmgmAZ*(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + 
          (4 - 5*d + d^2)*s*t - 2*t^2) + 2^(1 + d)*gZuLC*Pi^d*
         (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
      gZlR*gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2))))/(Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) + 
   (2^(3 - 2*d)*gAu*ggpgpAZ*(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + 
          (4 - 5*d + d^2)*s*t - 2*t^2) + 2^(1 + d)*gZuLC*Pi^d*
         (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2)) - 
      gZlR*gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2))))/(Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) + 
   (4^(1 - d)*gAu*gFFAZ*(-(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
         d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + 
           (4 - 5*d + d^2)*s*t - 2*t^2) + 2^(1 + d)*gZuLC*Pi^d*
          (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))) + 
      gZlR*gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2))))/(Pi^(2*d)*s*(-mz^2 + s)*(-mzC^2 + s)) - 
   (2^(3 - d)*gAu*gFFA*gFFZ*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*Pi^d*(mz^2 - s)*s*
     (-mzC^2 + s)) + (2^(3 - d)*gAu*ggmgmA*ggmgmZ*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*Pi^d*(mz^2 - s)*s*
     (-mzC^2 + s)) + (2^(3 - d)*gAu*ggpgpA*ggpgpZ*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*Pi^d*(mz^2 - s)*s*
     (-mzC^2 + s)) - (2^(3 - d)*gFFZ^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
    ((-1 + d)*Pi^d*(mz^2 - s)^2*(-mzC^2 + s)) + 
   (2^(3 - d)*ggmgmZ^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
    ((-1 + d)*Pi^d*(mz^2 - s)^2*(-mzC^2 + s)) + 
   (2^(3 - d)*ggpgpZ^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
    ((-1 + d)*Pi^d*(mz^2 - s)^2*(-mzC^2 + s)) + 
   (4^(1 - d)*gFFZZ*(gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))))/(Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) - (2^(3 - 2*d)*ggmgmZZ*
     (gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))))/(Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) - (2^(3 - 2*d)*ggpgpZZ*
     (gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))))/(Pi^(2*d)*(mz^2 - s)^2*
     (-mzC^2 + s)) + (4^(1 - d)*gFZW^2*
     (gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))))/((-1 + d)*mw^2*Pi^(2*d)*
     (mz^2 - s)^2*(-mzC^2 + s)*sw^2) - 
   (2^(2 - d)*gAd*gAl*gWdu*gWud*gZuLC*
     (-(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
     CKMC[1, 1])/(mw^2*Pi^d*s*(-mzC^2 + s)) + 
   (4^(1 - d)*gWdu*gWud*gZdL*gZuLC*
     (gZlR*gZlRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2)) + gZlL*gZlLC*(d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
     CKM[1, 1]*CKMC[1, 1])/(mw^2*Pi^(2*d)*(mz^2 - s)*(-mzC^2 + s)) - 
   (2^(3 - d)*gAl*gAu*gWWAA*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (1 + (-1 + d)*GaugeXi[Q]))/(d*Pi^d*s^2*(-mzC^2 + s)) - 
   (2^(3 - d)*gWWZZ*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
     (1 + (-1 + d)*GaugeXi[Q]))/(d*Pi^d*(mz^2 - s)^2*(-mzC^2 + s)) + 
   (gAl*gWdu*gWud*gWWA*gZuLC*
     (-(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
     CKMC[1, 1]*((-4 + 13*d - 4*d^2)*mw^2 + d*s - d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*(2*Pi)^d*(mzC^2 - s)*s) - 
   (gWdu*gWud*gWWZ*gZuLC*(-(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZlL*gZlLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*CKMC[1, 1]*
     ((-4 + 13*d - 4*d^2)*mw^2 + d*s - d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*(2*Pi)^d*(mz^2 - s)*(-mzC^2 + s)) + 
   (2^(3 - 2*d)*gAl*gWWAZ*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 
        2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      (-(gZlRC*gZuL*gZuLC*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) - 
        gZlLC*gZuR*gZuRC*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2)) + 
        gZlLC*gZuL*gZuLC*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*t + 
            2*(-1 + d)*t^2)) + gZlRC*gZuR*gZuRC*((-5 + d)*d^2*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*t + 
            2*(-1 + d)*t^2)))*GaugeXi[Q]))/(d*Pi^(2*d)*(mz^2 - s)*s*
     (-mzC^2 + s)) + (2^(3 - 2*d)*gAu*gWWAZ*
     (-(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
         2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2) + 
         2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 
           2*t^2))) + gZlR*gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuRC*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      (gZlR*gZlRC*(-((-7 + d)*d^2*gZuLC*(2*Pi)^d*s^2) + (-5 + d)*d^2*gZuRC*
           (2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*((4 - 7*d)*s^2 - 
            (-4 + d)*(-1 + d)^2*s*t + 2*(-1 + d)*t^2) + 2^(1 + d)*gZuRC*Pi^d*
           ((-2 + 4*d)*s^2 + (-8 + 13*d - 6*d^2 + d^3)*s*t + 
            2*(-1 + d)*t^2)) + gZlL*gZlLC*
         (-(gZuRC*((-7 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
              ((-4 + 7*d)*s^2 + (-4 + d)*(-1 + d)^2*s*t - 2*(-1 + d)*t^2))) + 
          gZuLC*((-5 + d)*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 4*d)*s^2 + 
              (-8 + 13*d - 6*d^2 + d^3)*s*t + 2*(-1 + d)*t^2))))*GaugeXi[Q]))/
    (d*Pi^(2*d)*(mz^2 - s)*s*(-mzC^2 + s)) - 
   (gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*CKM[1, 1]*CKMC[1, 1]*
     (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*(-2*(-1 + d)*s^2 + 
        (8 - 5*d + d^2)*s*t + 2*t^2) + mw^2*(-5*d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*((2 - 2*d + 3*d^2)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2)) + (-(2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + mw^2*(-13*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           ((-6 + 6*d + 5*d^2)*s^2 - 3*(8 - 5*d + d^2)*s*t - 6*t^2)))*
       GaugeXi[Q] + (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
        mw^2*(-5*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + 4*d^2)*s^2 + 
            3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q]^2 + 
      mw^2*(-13*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(2*(-1 + d + 3*d^2)*s^2 - 
          (8 - 5*d + d^2)*s*t - 2*t^2))*GaugeXi[Q]^3))/
    ((-1 + d)*mw^4*(2*Pi)^(2*d)*(mzC^2 - s)*s*(-1 + GaugeXi[Q])^2) + 
   (2*gAl*gAu*gWWA^2*((3*2^(1 - d)*(-1 + d)*(4 + d)*(gZlLC + gZlRC)*
        (gZuLC + gZuRC)*mw^4*s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d + 
      (2^(1 - 2*d)*(-1 + d)*(4 + d)*mw^4*
        (gZlRC*(3*2^(3 + d)*gZuRC*Pi^d + gZuLC*(2*Pi)^d - 
           23*gZuRC*(2*Pi)^d) + gZlLC*(3*2^(3 + d)*gZuLC*Pi^d - 
           23*gZuLC*(2*Pi)^d + gZuRC*(2*Pi)^d))*s^2*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2)/Pi^(2*d) + (2^(2 - d)*(-1 + d)*d*(gZlLC + gZlRC)*
        (gZuLC + gZuRC)*mw^4*s*(2*mw^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^3)/
       Pi^d + (3*4^(1 - d)*(-1 + d)*d*(gZlLC + gZlRC)*(gZuLC + gZuRC)*mw^4*s*
        (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^3)/
       Pi^(2*d) - ((-1 + d)*d*(2*mw^2 + s)^2*
        (gZlLC*gZuLC*((-2 + d)*s - 2*t) + gZlRC*gZuRC*((-2 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-4 + d)*s + 2*t) - gZlLC*gZuRC*((-4 + d)*s + 2*t))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(-s + 2*mw^2*GaugeXi[Q]))/(2*Pi)^d + 
      ((-1 + d)*d*(gZlRC*gZuLC*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
           2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
           s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
         gZlLC*gZuRC*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
           2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
           s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
         gZlLC*gZuLC*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
           2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
           s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
         gZlRC*gZuRC*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
           2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
           s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(-s + 2*mw^2*GaugeXi[Q]))/
       (2*Pi)^(2*d) - (2^(2 - d)*(-1 + d)*mw^2*s*
        (gZlLC*gZuLC*((-2 + d)*s - 2*t) + gZlRC*gZuRC*((-2 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-4 + d)*s + 2*t) - gZlLC*gZuRC*((-4 + d)*s + 2*t))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]*((4 + d)*s + 4*mw^2*GaugeXi[Q]))/
       Pi^d - (2^(1 - d)*(-1 + d)*((-2 + d)*gZlLC*gZuLC - 
         (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*
        s^2*t*(-1 + GaugeXi[Q])^2*(d*s + 12*mw^2*GaugeXi[Q]))/Pi^d - 
      (d*(gZlLC + gZlRC)*(gZuLC + gZuRC)*s*(2*mw^2 + s)^2*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2*(d*s - 4*(-1 + d)*mw^2*GaugeXi[Q]))/(2*Pi)^d - 
      (d*(gZlLC + gZlRC)*(gZuLC + gZuRC)*s*(2^(2 + d)*mw^4*Pi^d + 
         2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2*(d*s - 4*(-1 + d)*mw^2*GaugeXi[Q]))/(2*Pi)^(2*d) + 
      (d*(gZlRC*gZuLC*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
           2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
           s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
         gZlLC*gZuRC*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
           2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
           s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
         gZlLC*gZuLC*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
           2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
           s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
         gZlRC*gZuRC*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
           2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
           s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(d*s + 2*t - 4*(-1 + d)*mw^2*
          GaugeXi[Q]))/(2*Pi)^(2*d) + (2^(3 - 2*d)*(-1 + d)*mw^2*
        (-(gZlRC*(-(2^(1 + d)*gZuRC*mw^2*Pi^d*((-4 + d)*s - 2*t)) + 
            2^(1 + d)*gZuLC*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
            gZuLC*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
            gZuRC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))) + 
         gZlLC*(-(gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
              s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
           gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
             s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(-2*t + d*mw^2*GaugeXi[Q]))/
       Pi^(2*d) + (2^(2 - d)*(-1 + d)*mw^2*s*
        (gZlLC*gZuLC*((-4 + d)*s - 2*t) + gZlRC*gZuRC*((-4 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-2 + d)*s + 2*t) - gZlLC*gZuRC*((-2 + d)*s + 2*t))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]*(-2*t + (4 + d)*mw^2*GaugeXi[Q]))/
       Pi^d + ((1 - d)*(2 + d)*s*(gZlLC*(-((-2 + d)*gZuLC*s) + 
           (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + 
         gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2*(s - 2*(3*mw^2 + s)*GaugeXi[Q]))/
       (2*Pi)^d + ((1 - d)*(2 + d)*s*(gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 
           d*gZuRC*(2*Pi)^d*s + 2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 
           2^(1 + d)*gZuLC*Pi^d*(s + t)) + gZlRC*(d*gZuLC*(2*Pi)^d*s - 
           d*gZuRC*(2*Pi)^d*s + 2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 
           2^(1 + d)*gZuRC*Pi^d*(s + t)))*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(2*Pi)^(2*d) - 
      (2^(1 - d)*(-1 + d)*(2 + d)*mw^2*s*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
         gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
         gZlLC*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        (-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/Pi^d - 
      (2^(1 - d)*(-1 + d)*d*mw^2*(2*mw^2 + s)*
        (gZlLC*gZuLC*((-2 + d)*s - 2*t) + gZlRC*gZuRC*((-2 + d)*s - 2*t) - 
         gZlRC*gZuLC*((-4 + d)*s + 2*t) - gZlLC*gZuRC*((-4 + d)*s + 2*t))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(-2*s + (6*mw^2 + s)*GaugeXi[Q]))/
       Pi^d + (2^(1 - d)*(-1 + d)*s*(-1 + GaugeXi[Q])^2*
        (d*s + 4*mw^2*GaugeXi[Q])*(((-2 + d)*gZlLC*gZuLC - 
           (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*
            gZuRC)*s*t + (gZlLC*(-((-2 + d)*gZuLC*s*t) + (-4 + d)*gZuRC*s*t + 
             gZuRC*mw^2*(-((-4 + d)*s) + 2*(-5 + d)*t) + gZuLC*mw^2*
              ((-2 + d)*s - 2*(-1 + d)*t)) + gZlRC*((-4 + d)*gZuLC*s*t - 
             (-2 + d)*gZuRC*s*t + gZuLC*mw^2*(-((-4 + d)*s) + 2*(-5 + d)*t) + 
             gZuRC*mw^2*((-2 + d)*s - 2*(-1 + d)*t)))*GaugeXi[Q]))/Pi^d - 
      (2^(1 - 2*d)*(1 - d)*d*mw^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*
        (2^(1 + d)*Pi^d*s*(2*mw^2 + s)*(gZlLC*((-2 + d)*gZuLC*s - 
             (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) - 
           gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 
             2*gZuRC*t)) + (gZlRC*gZuLC*(3*2^(2 + d)*mw^4*Pi^d*
              ((-4 + d)*s + 2*t) + 2^(3 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
           gZlLC*gZuRC*(3*2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             2^(3 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) - 
           gZlLC*gZuLC*(3*2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
             2^(3 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
             s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))) + 
           gZlRC*gZuRC*(-3*2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) - 
             2^(3 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
             s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]))/
       Pi^(2*d) + (2^(1 - 2*d)*(-1 + d)*s*(-1 + GaugeXi[Q])^2*
        (d*s + 4*mw^2*GaugeXi[Q])*
        ((gZlLC*(-(2^(1 + d)*gZuLC*Pi^d) + 2^(2 + d)*gZuRC*Pi^d + 
             d*gZuLC*(2*Pi)^d - d*gZuRC*(2*Pi)^d) + 
           gZlRC*(2^(2 + d)*gZuLC*Pi^d - 2^(1 + d)*gZuRC*Pi^d - 
             d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d))*s*t + 
         (gZlLC*(gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
             gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
             gZuRC*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 
                 (-5 + d)*t)) + gZuLC*mw^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + (-1 + d)*t))) + gZlRC*(gZuLC*((-(2^(2 + d)*Pi^d) + 
                 d*(2*Pi)^d)*s*t + mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                  (2*s + (-5 + d)*t))) - gZuRC*((-(2^(1 + d)*Pi^d) + 
                 d*(2*Pi)^d)*s*t + mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                  (s + (-1 + d)*t)))))*GaugeXi[Q]))/Pi^(2*d) - 
      (2^(2 - d)*(1 - d)*d*(2*mw^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        ((-((-2 + d)*gZlLC*gZuLC) + (-4 + d)*gZlRC*gZuLC + 
           (-4 + d)*gZlLC*gZuRC - (-2 + d)*gZlRC*gZuRC)*s^2*t + 
         ((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*
            gZuRC + (-2 + d)*gZlRC*gZuRC)*s*(6*mw^2 + s)*t*GaugeXi[Q] + 
         mw^2*(4*mw^2 + s)*(gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
             2*gZuLC*t - 2*gZuRC*t) - gZlRC*((-4 + d)*gZuLC*s - 
             (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*GaugeXi[Q]^2))/Pi^d - 
      ((1 - d)*d*s*((-((-2 + d)*gZlLC*gZuLC) + (-4 + d)*gZlRC*gZuLC + 
           (-4 + d)*gZlLC*gZuRC - (-2 + d)*gZlRC*gZuRC)*(2*Pi)^(2*d)*s^2*t + 
         3*2^(1 + 2*d)*((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - 
           (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*Pi^(2*d)*s*
          (2*mw^2 + s)*t*GaugeXi[Q] - 2^(1 + 2*d)*Pi^(2*d)*
          (gZlRC*gZuLC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + (30 - 7*d)*
                t) + mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
           gZlLC*gZuRC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + (30 - 7*d)*
                t) + mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
           gZlLC*gZuLC*(5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + (12 - 7*d)*
                t) + mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t)) + 
           gZlRC*gZuRC*(5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + (12 - 7*d)*
                t) + mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t)))*GaugeXi[Q]^2 - 
         2^(1 + 2*d)*Pi^(2*d)*(gZlLC*(gZuRC*(3*(-4 + d)*s^2*t - 2*mw^2*s*
                (2*(-4 + d)*s + (24 - 5*d)*t) + mw^4*(-10*(-4 + d)*s + 
                 4*(-9 + d)*t)) + gZuLC*(-3*(-2 + d)*s^2*t + 2*mw^2*s*
                (2*(-2 + d)*s + (6 - 5*d)*t) + 2*mw^4*(5*(-2 + d)*s - 
                 2*(3 + d)*t))) - gZlRC*(gZuLC*(-3*(-4 + d)*s^2*t + 2*mw^2*s*
                (2*(-4 + d)*s + (24 - 5*d)*t) + 2*mw^4*(5*(-4 + d)*s - 
                 2*(-9 + d)*t)) + gZuRC*(3*(-2 + d)*s^2*t - 2*mw^2*s*
                (2*(-2 + d)*s + (6 - 5*d)*t) + mw^4*(-10*(-2 + d)*s + 
                 4*(3 + d)*t))))*GaugeXi[Q]^3 + (2*Pi)^(2*d)*
          (gZlLC*(gZuRC*((-4 + d)*s^2*t + mw^4*(-10*(-4 + d)*s + 4*(-9 + d)*
                  t) - 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
             gZuLC*(-((-2 + d)*s^2*t) + 4*mw^2*s*((-2 + d)*s - d*t) + 2*mw^4*
                (5*(-2 + d)*s - 2*(3 + d)*t))) - 
           gZlRC*(gZuLC*(-((-4 + d)*s^2*t) + 2*mw^4*(5*(-4 + d)*s - 
                 2*(-9 + d)*t) + 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
             gZuRC*((-2 + d)*s^2*t + 4*mw^2*s*(-((-2 + d)*s) + d*t) + mw^4*
                (-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^4))/
       (2*Pi)^(3*d) - ((1 - d)*d*s*(2^(1 + d)*(gZlLC + gZlRC)*(gZuLC + gZuRC)*
          mw^4*Pi^d*s*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 - 
         3*2^(1 + d)*((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - 
           (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*mw^4*Pi^d*t*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 - mw^4*(2*Pi)^d*
          (6*gZlLC*gZuLC*t + 6*gZlRC*gZuRC*t - 6*gZlRC*gZuLC*(s + t) - 
           6*gZlLC*gZuRC*(s + t) - d*(gZlLC - gZlRC)*(gZuLC - gZuRC)*
            (s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 + 
         3*2^(1 + d)*mw^4*Pi^d*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
           gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
           gZlLC*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 - 
         mw^4*(2*Pi)^d*(gZlLC*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuLC*((-8 + 3*d)*s + 
             6*t) + gZlLC*gZuRC*((-8 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2 + 3*2^(2 + d)*((-2 + d)*gZlLC*gZuLC - 
           (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*
            gZuRC)*Pi^d*s*t*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2 - 
         3*2^(1 + d)*Pi^d*s*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
           gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
           gZlLC*gZuRC*((-4 + d)*s + 2*t))*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^
           2 - 3*2^(1 + d)*((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - 
           (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*Pi^d*s*t*GaugeXi[Q]*
          (1 + GaugeXi[Q])*(mw - mw*GaugeXi[Q])^2 + 2^(1 + d)*Pi^d*s*
          (gZlLC*gZuLC*((-2 + d)*s - 2*t) + gZlRC*gZuRC*((-2 + d)*s - 2*t) - 
           gZlRC*gZuLC*((-4 + d)*s + 2*t) - gZlLC*gZuRC*((-4 + d)*s + 2*t))*
          GaugeXi[Q]*(1 + GaugeXi[Q])*(mw - mw*GaugeXi[Q])^2 - 
         3*2^(1 + d)*((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - 
           (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*Pi^d*t*
          (s - s*GaugeXi[Q])^2 + 3*2^(1 + d)*((-2 + d)*gZlLC*gZuLC - 
           (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*
            gZuRC)*Pi^d*t*(1 + GaugeXi[Q])*(s - s*GaugeXi[Q])^2 + 
         2^(1 + d)*Pi^d*s*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2*
          (gZlLC*(2*(-2 + d)*gZuLC*s - 2*(-4 + d)*gZuRC*s + (-10 + 3*d)*gZuLC*
              t + (8 - 3*d)*gZuRC*t) + gZlRC*(-2*(-4 + d)*gZuLC*s + 
             2*(-2 + d)*gZuRC*s + (8 - 3*d)*gZuLC*t + (-10 + 3*d)*gZuRC*t) + 
           (gZlLC*gZuLC*((-2 + d)*s + (-4 + d)*t) + gZlRC*gZuRC*
              ((-2 + d)*s + (-4 + d)*t) - gZlRC*gZuLC*((-4 + d)*s + (-2 + d)*
                t) - gZlLC*gZuRC*((-4 + d)*s + (-2 + d)*t))*GaugeXi[Q]) + 
         s^2*t*(gZlRC*(-(2^(2 + d)*gZuLC*Pi^d) + 2^(1 + d)*gZuRC*Pi^d + 
             d*gZuLC*(2*Pi)^d - d*gZuRC*(2*Pi)^d) + 
           gZlLC*(2^(1 + d)*gZuLC*Pi^d - 2^(2 + d)*gZuRC*Pi^d - 
             d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d) + 2^(1 + d)*
            ((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - (-4 + d)*gZlLC*
              gZuRC + (-2 + d)*gZlRC*gZuRC)*Pi^d*GaugeXi[Q]^2 + 
           (gZlRC*(-(2^(2 + d)*gZuLC*Pi^d) + 2^(1 + d)*gZuRC*Pi^d + d*gZuLC*
                (2*Pi)^d - d*gZuRC*(2*Pi)^d) + gZlLC*(2^(1 + d)*gZuLC*Pi^d - 
               2^(2 + d)*gZuRC*Pi^d - d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d))*
            GaugeXi[Q]^4)))/(2*Pi)^(2*d)))/((-1 + d)*d*mw^4*(mzC^2 - s)*s^2*
     (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) - 
   (2*gAu*gWWA*gWWZ*((2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s)/
       Pi^d + (3*2^(1 - d)*(4 + d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*
        s)/(d*Pi^d) + (2^(1 - 2*d)*(4 + d)*
        (gZlL*gZlLC*(5*2^(3 + d)*gZuLC*Pi^d - 2^(3 + d)*gZuRC*Pi^d - 
           39*gZuLC*(2*Pi)^d + 9*gZuRC*(2*Pi)^d) - gZlR*gZlRC*
          (2^(3 + d)*gZuLC*Pi^d - 5*2^(3 + d)*gZuRC*Pi^d - 9*gZuLC*(2*Pi)^d + 
           39*gZuRC*(2*Pi)^d))*s)/(d*Pi^(2*d)) + 
      (2^(1 - d)*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((4 - 3*d)*gZuLC*s + 
           (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)))/Pi^d + 
      (2^(2 - d)*(gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((8 - 3*d)*gZuLC*s + 
           (-10 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)))/Pi^d + 
      (3*2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)))/Pi^d - 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2)/
       (mw^2*Pi^d*GaugeXi[Q]) - 
      (s*(gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 6*gZuLC*t - 
           6*gZuRC*t) + gZlR*gZlRC*((8 - 3*d)*gZuLC*s + (-10 + 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t)))/(mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      (3*s*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t)))/(mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      (3*2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*GaugeXi[Q])/
       Pi^d + (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*
        (2*mw^2 + s)*GaugeXi[Q])/Pi^d + 
      (3*4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*
        (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q])/Pi^(2*d) - 
      (2^(1 - d)*mw^2*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((4 - 3*d)*gZuLC*s + 
           (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t))*GaugeXi[Q])/
       (Pi^d*s) - (mw^2*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + 
           (4 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t) + 
         gZlR*gZlRC*((4 - 3*d)*gZuLC*s + (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 
           6*gZuRC*t))*GaugeXi[Q])/((2*Pi)^d*s) - 
      (2^(1 - d)*mw^2*(gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((8 - 3*d)*gZuLC*s + 
           (-10 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t))*GaugeXi[Q])/
       (Pi^d*s) - (mw^2*(gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + 
           (8 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t) + 
         gZlR*gZlRC*((8 - 3*d)*gZuLC*s + (-10 + 3*d)*gZuRC*s - 6*gZuLC*t - 
           6*gZuRC*t))*GaugeXi[Q])/((2*Pi)^d*s) - 
      (3*mw^2*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t))*GaugeXi[Q])/((2*Pi)^d*s) + 
      (3*mw^2*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 2*gZuLC*t + 
           2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
           2*gZuRC*(3*s + t)))*GaugeXi[Q])/((2*Pi)^d*s) - 
      (2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s*
        (1 + GaugeXi[Q]))/Pi^d - 
      (2^(2 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*(1 + GaugeXi[Q]))/
       Pi^d + (2^(3 - d)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*(1 + GaugeXi[Q]))/
       Pi^d + (2^(2 - d)*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
           2*gZuLC*t + 2*gZuRC*(3*s + t)))*(1 + GaugeXi[Q]))/Pi^d + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2*
        (1 + GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(2 - d)*s*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*(1 + GaugeXi[Q]))/
       (mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(2 - d)*s*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*(1 + GaugeXi[Q]))/
       (mw^2*Pi^d*GaugeXi[Q]) - (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuLC + gZuRC)*s^2*(1 + GaugeXi[Q])^2)/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(1 - d)*(2*mw^2 + s)^2*(gZlL*gZlLC*((-2 + d)*gZuLC*s - 
           (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) + 
         gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s - 2*gZuLC*t - 
           2*gZuRC*t))*(s - 2*mw^2*GaugeXi[Q]))/(mw^4*Pi^d*s) - 
      (2^(2 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*
        ((4 + d)*s + 4*mw^2*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
         gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*s*t*
        (d*s + 12*mw^2*GaugeXi[Q]))/(d*mw^4*Pi^d*GaugeXi[Q]^2) + 
      ((gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(2*mw^2 + s)^2*
        (-(d*s) + 4*(-1 + d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^d) + 
      ((gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(2^(2 + d)*mw^4*Pi^d + 
         2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*(-(d*s) + 
         4*(-1 + d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^(2*d)) + 
      (2^(3 - 2*d)*(-(gZlR*gZlRC*(-(2^(1 + d)*gZuRC*mw^2*Pi^d*
              ((-4 + d)*s - 2*t)) + 2^(1 + d)*gZuLC*mw^2*Pi^d*
             ((-2 + d)*s + 2*t) + gZuLC*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                -s + t)) + gZuRC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 
                t)))) + gZlL*gZlLC*
          (-(gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
              s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
           gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
             s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))))*
        (-2*t + d*mw^2*GaugeXi[Q]))/(d*mw^2*Pi^(2*d)*s) + 
      (2^(2 - d)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        (2*t - (4 + d)*mw^2*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(1 - d)*(2 + d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) - 
      ((2 + d)*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*((-4 + d)*gZuLC*s - 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      ((2 + d)*(gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
           2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*(s + t)) + 
         gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*s + 
           2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*(s + t)))*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*(2*Pi)^(2*d)*GaugeXi[Q]) - 
      (2^(1 - d)*(2*mw^2 + s)*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + 
           (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + 
         gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 
           2*gZuRC*t))*(2*s - (6*mw^2 + s)*GaugeXi[Q]))/(mw^2*Pi^d*s) + 
      (2^(1 - d)*(d*s + 4*mw^2*GaugeXi[Q])*
        ((gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*s*t + 
         (gZlL*gZlLC*(-((-2 + d)*gZuLC*s*t) + (-4 + d)*gZuRC*s*t + 
             gZuRC*mw^2*(-((-4 + d)*s) + 2*(-5 + d)*t) + gZuLC*mw^2*
              ((-2 + d)*s - 2*(-1 + d)*t)) + gZlR*gZlRC*((-4 + d)*gZuLC*s*t - 
             (-2 + d)*gZuRC*s*t + gZuLC*mw^2*(-((-4 + d)*s) + 2*(-5 + d)*t) + 
             gZuRC*mw^2*((-2 + d)*s - 2*(-1 + d)*t)))*GaugeXi[Q]))/
       (d*mw^4*Pi^d*GaugeXi[Q]^2) + (2^(1 - 2*d)*(d*s + 4*mw^2*GaugeXi[Q])*
        ((gZlR*gZlRC*(2^(2 + d)*gZuLC*Pi^d - 2^(1 + d)*gZuRC*Pi^d - 
             d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d) - gZlL*gZlLC*
            (2^(1 + d)*gZuLC*Pi^d - 2^(2 + d)*gZuRC*Pi^d - d*gZuLC*(2*Pi)^d + 
             d*gZuRC*(2*Pi)^d))*s*t + 
         (gZlL*gZlLC*(gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
             gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
             gZuRC*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 
                 (-5 + d)*t)) + gZuLC*mw^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + (-1 + d)*t))) + gZlR*gZlRC*
            (gZuLC*((-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + mw^2*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + (-5 + d)*t))) - 
             gZuRC*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + mw^2*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + (-1 + d)*t)))))*
          GaugeXi[Q]))/(d*mw^4*Pi^(2*d)*GaugeXi[Q]^2) - 
      ((2*mw^2 + s)^2*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        (-(d*s) - 2*t + 4*(-1 + d)*mw^2*GaugeXi[Q])*((2*Pi)^(2*d) - 
         2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2))/
       ((-1 + d)*mw^4*(2*Pi)^(3*d)*s*(-1 + GaugeXi[Q])^2) + 
      (2^(2 - d)*(2*mw^2 + s)*
        ((gZlL*gZlLC*(-((-2 + d)*gZuLC) + (-4 + d)*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuLC - (-2 + d)*gZuRC))*s^2*t + 
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*s*(6*mw^2 + s)*t*
          GaugeXi[Q] + mw^2*(4*mw^2 + s)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - 
             (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) - 
           gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 
             2*gZuRC*t))*GaugeXi[Q]^2))/(mw^4*Pi^d*s*GaugeXi[Q]) + 
      (s*(gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
           2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*(s + t)) + 
         gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*s + 
           2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*(s + t)) + 
         2^(1 + d)*Pi^d*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
             2*gZuLC*t - 2*gZuRC*t) - gZlR*gZlRC*((-4 + d)*gZuLC*s - 
             (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*GaugeXi[Q]^2 + 
         (gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
             2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*
              (s + t)) + gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*
              s + 2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*
              (s + t)))*GaugeXi[Q]^4))/(mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]) + (s*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 
           2^(1 + d)*gZuRC*Pi^d*(3*s + t) + gZuLC*(d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*t)) + gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 
           2^(1 + d)*gZuLC*Pi^d*(3*s + t) + gZuRC*(d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*t)) + 2^(1 + d)*Pi^d*
          (-(gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 2*gZuRC*(3*s + 
                t))) + gZlL*gZlLC*((-6 + d)*gZuLC*s - 2*gZuLC*t - 
             gZuRC*(d*s + 2*t)))*GaugeXi[Q]^2 + 
         (gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
              (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
           gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
              (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
          GaugeXi[Q]^4))/(mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]) - 
      ((gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*(2*Pi)^(2*d)*s^2*
         t - 3*2^(1 + 2*d)*(gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*Pi^(2*d)*s*
         (2*mw^2 + s)*t*GaugeXi[Q] + 2^(1 + 2*d)*Pi^(2*d)*
         (gZlL*gZlLC*(gZuRC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + 
                (30 - 7*d)*t) + mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
            gZuLC*(5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + 
              mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t))) + gZlR*gZlRC*
           (gZuLC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + (30 - 7*d)*t) + 
              mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + gZuRC*(5*(-2 + d)*s^2*t - 
              2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + mw^4*(-5*(-2 + d)*s + 
                2*(3 + d)*t))))*GaugeXi[Q]^2 + 2^(1 + 2*d)*Pi^(2*d)*
         (gZlL*gZlLC*(gZuRC*(3*(-4 + d)*s^2*t - 2*mw^2*s*(2*(-4 + d)*s + 
                (24 - 5*d)*t) + mw^4*(-10*(-4 + d)*s + 4*(-9 + d)*t)) + 
            gZuLC*(-3*(-2 + d)*s^2*t + 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*
                 t) + 2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
          gZlR*gZlRC*(gZuLC*(-3*(-4 + d)*s^2*t + 2*mw^2*s*(2*(-4 + d)*s + 
                (24 - 5*d)*t) + 2*mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
            gZuRC*(3*(-2 + d)*s^2*t - 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*t) + 
              mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^3 - 
        (2*Pi)^(2*d)*(gZlL*gZlLC*(gZuRC*((-4 + d)*s^2*t + 
              mw^4*(-10*(-4 + d)*s + 4*(-9 + d)*t) - 4*mw^2*s*((-4 + d)*s - 
                (-6 + d)*t)) + gZuLC*(-((-2 + d)*s^2*t) + 4*mw^2*s*(
                (-2 + d)*s - d*t) + 2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
          gZlR*gZlRC*(gZuLC*(-((-4 + d)*s^2*t) + 2*mw^4*(5*(-4 + d)*s - 
                2*(-9 + d)*t) + 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
            gZuRC*((-2 + d)*s^2*t + 4*mw^2*s*(-((-2 + d)*s) + d*t) + 
              mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^4)/
       (mw^4*(2*Pi)^(3*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) + 
      (2^(1 + d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*Pi^d*s*
         (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 - 3*2^(1 + d)*
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*mw^4*Pi^d*t*
         (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 + mw^4*(2*Pi)^d*
         (gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 6*gZuLC*t - 
            6*gZuRC*t) + gZlR*gZlRC*((8 - 3*d)*gZuLC*s + (-10 + 3*d)*gZuRC*
             s - 6*gZuLC*t - 6*gZuRC*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 + 
        3*2^(1 + d)*mw^4*Pi^d*(gZlL*gZlLC*((-2 + d)*gZuLC*s - 
            (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s - 2*gZuLC*t - 
            2*gZuRC*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 + 
        mw^4*(2*Pi)^d*(d*(gZlL*gZlLC - gZlR*gZlRC)*(gZuLC - gZuRC)*
           (s + 2*t) + 6*gZlR*gZlRC*(-(gZuRC*t) + gZuLC*(s + t)) + 
          6*gZlL*gZlLC*(-(gZuLC*t) + gZuRC*(s + t)))*(-1 + GaugeXi[Q])^2*
         GaugeXi[Q]^2 + 3*2^(2 + d)*(gZlL*gZlLC*((-2 + d)*gZuLC - 
            (-4 + d)*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuLC) + 
            (-2 + d)*gZuRC))*Pi^d*s*t*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2 - 
        3*2^(1 + d)*Pi^d*s*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
            2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
            (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*GaugeXi[Q]*
         (mw - mw*GaugeXi[Q])^2 - 3*2^(1 + d)*
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*Pi^d*s*t*
         GaugeXi[Q]*(1 + GaugeXi[Q])*(mw - mw*GaugeXi[Q])^2 + 
        2^(1 + d)*Pi^d*s*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
            2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
            (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*GaugeXi[Q]*
         (1 + GaugeXi[Q])*(mw - mw*GaugeXi[Q])^2 - 
        3*2^(1 + d)*(gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*Pi^d*t*
         (s - s*GaugeXi[Q])^2 + 3*2^(1 + d)*
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*Pi^d*t*
         (1 + GaugeXi[Q])*(s - s*GaugeXi[Q])^2 + 2^(1 + d)*Pi^d*s*GaugeXi[Q]*
         (mw - mw*GaugeXi[Q])^2*(gZlL*gZlLC*(2*(-2 + d)*gZuLC*s - 
            2*(-4 + d)*gZuRC*s + (-10 + 3*d)*gZuLC*t + (8 - 3*d)*gZuRC*t) + 
          gZlR*gZlRC*(-2*(-4 + d)*gZuLC*s + 2*(-2 + d)*gZuRC*s + 
            (8 - 3*d)*gZuLC*t + (-10 + 3*d)*gZuRC*t) + 
          (gZlR*gZlRC*(gZuRC*((-2 + d)*s + (-4 + d)*t) - gZuLC*((-4 + d)*s + 
                (-2 + d)*t)) + gZlL*gZlLC*(gZuLC*((-2 + d)*s + (-4 + d)*t) - 
              gZuRC*((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q]) - 
        s^2*t*(gZlR*gZlRC*(2^(2 + d)*gZuLC*Pi^d - 2^(1 + d)*gZuRC*Pi^d - 
            d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d) - gZlL*gZlLC*
           (2^(1 + d)*gZuLC*Pi^d - 2^(2 + d)*gZuRC*Pi^d - d*gZuLC*(2*Pi)^d + 
            d*gZuRC*(2*Pi)^d) - 2^(1 + d)*(gZlL*gZlLC*((-2 + d)*gZuLC - 
              (-4 + d)*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuLC) + 
              (-2 + d)*gZuRC))*Pi^d*GaugeXi[Q]^2 + 
          (gZlR*gZlRC*(2^(2 + d)*gZuLC*Pi^d - 2^(1 + d)*gZuRC*Pi^d - 
              d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d) - gZlL*gZlLC*
             (2^(1 + d)*gZuLC*Pi^d - 2^(2 + d)*gZuRC*Pi^d - d*gZuLC*(2*Pi)^
                d + d*gZuRC*(2*Pi)^d))*GaugeXi[Q]^4))/
       (mw^4*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)))/
    ((mz^2 - s)*(-mzC^2 + s)) + 
   (2*gAl*gWWA*gWWZ*((-3*2^(1 - d)*(-1 + d)*(4 + d)*(gZlLC + gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*mw^4*s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/
       Pi^d - (2^(1 - 2*d)*(-1 + d)*(4 + d)*mw^4*(gZlRC*gZuL*gZuLC*(2*Pi)^d + 
         gZlLC*gZuR*gZuRC*(2*Pi)^d + gZlLC*gZuL*gZuLC*(3*2^(3 + d)*Pi^d - 
           23*(2*Pi)^d) + gZlRC*gZuR*gZuRC*(3*2^(3 + d)*Pi^d - 23*(2*Pi)^d))*
        s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^(2*d) - 
      (2^(2 - d)*(-1 + d)*d*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
        (2*mw^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^3)/Pi^d - 
      (3*4^(1 - d)*(-1 + d)*d*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*
        s*(2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^3)/Pi^(2*d) + (2^(1 - d)*(-1 + d)*d*(2*mw^2 + s)^2*
        (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2*(-s + 2*mw^2*GaugeXi[Q]))/Pi^d + 
      (2^(2 - d)*(-1 + d)*mw^2*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*((4 + d)*s + 
         4*mw^2*GaugeXi[Q]))/Pi^d + (2^(1 - d)*(-1 + d)*
        ((-2 + d)*gZlLC*gZuL*gZuLC - (-4 + d)*gZlRC*gZuL*gZuLC - 
         (-4 + d)*gZlLC*gZuR*gZuRC + (-2 + d)*gZlRC*gZuR*gZuRC)*s^2*t*
        (-1 + GaugeXi[Q])^2*(d*s + 12*mw^2*GaugeXi[Q]))/Pi^d + 
      (d*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*(2*mw^2 + s)^2*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(d*s - 4*(-1 + d)*mw^2*GaugeXi[Q]))/
       (2*Pi)^d + (d*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (2^(2 + d)*mw^4*Pi^d + 2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(d*s - 4*(-1 + d)*mw^2*GaugeXi[Q]))/
       (2*Pi)^(2*d) + (2^(3 - 2*d)*(-1 + d)*mw^2*
        (gZlRC*gZuL*gZuLC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
           s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
         gZlLC*gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
           s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) - 
         gZlRC*gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
           s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))) + 
         gZlLC*gZuL*gZuLC*(-(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t)) + 
           s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2*(-2*t + d*mw^2*GaugeXi[Q]))/
       Pi^(2*d) - (2^(2 - d)*(-1 + d)*mw^2*s*
        (-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZuL*gZuLC*
             ((-2 + d)*s + 2*t))) + gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - 
           gZuR*gZuRC*((-2 + d)*s + 2*t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        (-2*t + (4 + d)*mw^2*GaugeXi[Q]))/Pi^d - 
      ((-1 + d)*(2 + d)*mw^2*s*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
           2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuR*gZuRC*
          (d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuL*gZuLC*
          (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + gZlRC*gZuR*gZuRC*
          (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]*(-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/(2*Pi)^(2*d) + 
      (2^(1 - d)*(-1 + d)*(2 + d)*mw^2*s*
        (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        (-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/Pi^d + 
      ((-1 + d)*(2 + d)*mw^2*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        (-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/(2*Pi)^d + 
      (2^(1 - d)*(-1 + d)*d*mw^2*(2*mw^2 + s)*
        (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2*(-2*s + (6*mw^2 + s)*GaugeXi[Q]))/Pi^d - 
      (2^(1 - d)*(-1 + d)*s*(-1 + GaugeXi[Q])^2*(d*s + 4*mw^2*GaugeXi[Q])*
        (((-2 + d)*gZlLC*gZuL*gZuLC - (-4 + d)*gZlRC*gZuL*gZuLC - 
           (-4 + d)*gZlLC*gZuR*gZuRC + (-2 + d)*gZlRC*gZuR*gZuRC)*s*t + 
         (gZlRC*gZuL*gZuLC*((-4 + d)*s*t + mw^2*(-((-4 + d)*s) + 2*(-5 + d)*
                t)) + gZlLC*gZuR*gZuRC*((-4 + d)*s*t + 
             mw^2*(-((-4 + d)*s) + 2*(-5 + d)*t)) + gZlLC*gZuL*gZuLC*
            (-((-2 + d)*s*t) + mw^2*((-2 + d)*s - 2*(-1 + d)*t)) + 
           gZlRC*gZuR*gZuRC*(-((-2 + d)*s*t) + mw^2*((-2 + d)*s - 2*(-1 + d)*
                t)))*GaugeXi[Q]))/Pi^d + (2^(1 - 2*d)*(-1 + d)*s*
        (-1 + GaugeXi[Q])^2*(d*s + 4*mw^2*GaugeXi[Q])*
        ((gZlLC*gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
           gZlRC*gZuR*gZuRC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
           gZlRC*gZuL*gZuLC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d) + 
           gZlLC*gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d))*s*t + 
         (-(gZlRC*gZuL*gZuLC*((-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
              mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + (-5 + d)*t)))) + 
           gZlRC*gZuR*gZuRC*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
             mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + (-1 + d)*t))) + 
           gZlLC*(-(gZuR*gZuRC*((-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
                mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + (-5 + d)*
                     t)))) + gZuL*gZuLC*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*
                t + mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + (-1 + d)*
                    t)))))*GaugeXi[Q]))/Pi^(2*d) - 
      (d*(2*mw^2 + s)^2*(gZlLC*gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + 
         gZlRC*gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*
          ((-2 + d)*s + 2*t) + gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*
        GaugeXi[Q]^2*(d*s + 2*t - 4*(-1 + d)*mw^2*GaugeXi[Q])*
        ((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + 
         (2*Pi)^(2*d)*GaugeXi[Q]^2))/(2*Pi)^(3*d) + 
      (2^(2 - d)*(1 - d)*d*(2*mw^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
        ((-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*gZuLC + 
           (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*s^2*t + 
         ((-2 + d)*gZlLC*gZuL*gZuLC - (-4 + d)*gZlRC*gZuL*gZuLC - 
           (-4 + d)*gZlLC*gZuR*gZuRC + (-2 + d)*gZlRC*gZuR*gZuRC)*s*
          (6*mw^2 + s)*t*GaugeXi[Q] + mw^2*(4*mw^2 + s)*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^2))/Pi^d + 
      ((1 - d)*d*s*((-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*
            gZuLC + (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*
          (2*Pi)^(2*d)*s^2*t + 3*2^(1 + 2*d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] - 
         2^(1 + 2*d)*Pi^(2*d)*(gZlRC*gZuL*gZuLC*(-5*(-4 + d)*s^2*t + 
             2*mw^2*s*((-4 + d)*s + (30 - 7*d)*t) + mw^4*(5*(-4 + d)*s - 2*
                (-9 + d)*t)) + gZlLC*gZuR*gZuRC*(-5*(-4 + d)*s^2*t + 
             2*mw^2*s*((-4 + d)*s + (30 - 7*d)*t) + mw^4*(5*(-4 + d)*s - 2*
                (-9 + d)*t)) + gZlLC*gZuL*gZuLC*(5*(-2 + d)*s^2*t - 
             2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + mw^4*(-5*(-2 + d)*s + 2*
                (3 + d)*t)) + gZlRC*gZuR*gZuRC*(5*(-2 + d)*s^2*t - 
             2*mw^2*s*((-2 + d)*s + (12 - 7*d)*t) + mw^4*(-5*(-2 + d)*s + 2*
                (3 + d)*t)))*GaugeXi[Q]^2 - 2^(1 + 2*d)*Pi^(2*d)*
          (gZlLC*(gZuR*gZuRC*(3*(-4 + d)*s^2*t - 2*mw^2*s*(2*(-4 + d)*s + 
                 (24 - 5*d)*t) + mw^4*(-10*(-4 + d)*s + 4*(-9 + d)*t)) + 
             gZuL*gZuLC*(-3*(-2 + d)*s^2*t + 2*mw^2*s*(2*(-2 + d)*s + 
                 (6 - 5*d)*t) + 2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
           gZlRC*(gZuL*gZuLC*(-3*(-4 + d)*s^2*t + 2*mw^2*s*(2*(-4 + d)*s + 
                 (24 - 5*d)*t) + 2*mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
             gZuR*gZuRC*(3*(-2 + d)*s^2*t - 2*mw^2*s*(2*(-2 + d)*s + 
                 (6 - 5*d)*t) + mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*
          GaugeXi[Q]^3 + (2*Pi)^(2*d)*
          (gZlLC*(gZuR*gZuRC*((-4 + d)*s^2*t + mw^4*(-10*(-4 + d)*s + 
                 4*(-9 + d)*t) - 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
             gZuL*gZuLC*(-((-2 + d)*s^2*t) + 4*mw^2*s*((-2 + d)*s - d*t) + 2*
                mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
           gZlRC*(gZuL*gZuLC*(-((-4 + d)*s^2*t) + 2*mw^4*(5*(-4 + d)*s - 
                 2*(-9 + d)*t) + 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
             gZuR*gZuRC*((-2 + d)*s^2*t + 4*mw^2*s*(-((-2 + d)*s) + d*t) + 
               mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^4))/
       (2*Pi)^(3*d) + ((1 - d)*d*s*(2^(1 + d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^4*Pi^d*s*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2 - 3*2^(1 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*mw^4*Pi^d*t*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2 - mw^4*(2*Pi)^d*(6*gZlLC*gZuL*gZuLC*t + 
           6*gZlRC*gZuR*gZuRC*t - 6*gZlRC*gZuL*gZuLC*(s + t) - 
           6*gZlLC*gZuR*gZuRC*(s + t) - d*(gZlLC - gZlRC)*(gZuL*gZuLC - 
             gZuR*gZuRC)*(s + 2*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 - 
         mw^4*(2*Pi)^d*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2 + 3*2^(1 + d)*mw^4*Pi^d*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2 + 3*2^(2 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^d*s*t*GaugeXi[Q]*
          (mw - mw*GaugeXi[Q])^2 - 3*2^(1 + d)*Pi^d*s*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]*
          (mw - mw*GaugeXi[Q])^2 - 3*2^(1 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^d*s*t*GaugeXi[Q]*(1 + GaugeXi[Q])*
          (mw - mw*GaugeXi[Q])^2 + 2^(1 + d)*Pi^d*s*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]*(1 + GaugeXi[Q])*
          (mw - mw*GaugeXi[Q])^2 - 3*2^(1 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^d*t*(s - s*GaugeXi[Q])^2 + 
         3*2^(1 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - (-4 + d)*gZlRC*gZuL*gZuLC - 
           (-4 + d)*gZlLC*gZuR*gZuRC + (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^d*t*
          (1 + GaugeXi[Q])*(s - s*GaugeXi[Q])^2 + 2^(1 + d)*Pi^d*s*GaugeXi[Q]*
          (mw - mw*GaugeXi[Q])^2*(gZlRC*gZuL*gZuLC*(-2*(-4 + d)*s + 
             (8 - 3*d)*t) + gZlLC*gZuR*gZuRC*(-2*(-4 + d)*s + (8 - 3*d)*t) + 
           gZlLC*gZuL*gZuLC*(2*(-2 + d)*s + (-10 + 3*d)*t) + 
           gZlRC*gZuR*gZuRC*(2*(-2 + d)*s + (-10 + 3*d)*t) + 
           (gZlLC*gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t) + gZlRC*gZuR*gZuRC*
              ((-2 + d)*s + (-4 + d)*t) - gZlRC*gZuL*gZuLC*((-4 + d)*s + 
               (-2 + d)*t) - gZlLC*gZuR*gZuRC*((-4 + d)*s + (-2 + d)*t))*
            GaugeXi[Q]) + s^2*t*(gZlRC*(gZuR*gZuRC*(2^(1 + d)*Pi^d - d*
                (2*Pi)^d) + gZuL*gZuLC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)) + 
           gZlLC*(gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
             gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)) + 
           2^(1 + d)*((-2 + d)*gZlLC*gZuL*gZuLC - (-4 + d)*gZlRC*gZuL*gZuLC - 
             (-4 + d)*gZlLC*gZuR*gZuRC + (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^d*
            GaugeXi[Q]^2 + (gZlLC*gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
             gZlRC*gZuR*gZuRC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
             gZlRC*gZuL*gZuLC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d) + 
             gZlLC*gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d))*
            GaugeXi[Q]^4)))/(2*Pi)^(2*d) - (1 - d)*d*mw^2*GaugeXi[Q]*
       ((3*s^2*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
              ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2)/
         (2*Pi)^d - (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*
          s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (3*2^(1 - d)*mw^2*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*
              (-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(4 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d - 
        (2^(1 - d)*mw^4*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d - 
        (mw^4*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-4 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d + 
        (3*mw^4*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
              ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d - (2^(2 - d)*s^2*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q]))/Pi^d + (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*
          (1 + GaugeXi[Q]))/Pi^d + (2^(2 - d)*mw^2*s*
          (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*((-4 + d)*s + 2*
                t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
             gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d + 
        (2^(2 - d)*mw^2*s*(-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
              gZuL*gZuLC*((-2 + d)*s + 2*t))) + 
           gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*
                t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)/Pi^d - 
        (s^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
           gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
           2^(1 + d)*Pi^d*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
                ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
               gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^2 + 
           (gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
             gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
             gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
             gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*
            GaugeXi[Q]^4))/(2*Pi)^(2*d)) - (1 - d)*d*mw^2*GaugeXi[Q]*
       ((2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2)/Pi^d - (3*2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/
         Pi^d + (2^(5 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d - 
        (mw^4*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-8 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d - (2^(1 - d)*mw^4*
          (gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-4 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/Pi^d + (3*mw^4*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
           gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*
              s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/(2*Pi)^d - 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q]))/Pi^d + 
        (3*2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d + 
        (2^(2 - d)*mw^2*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
           gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*
              s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d + 
        (2^(2 - d)*mw^2*s*(-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
              gZuL*gZuLC*((-2 + d)*s + 2*t))) + 
           gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*
                t)))*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
          GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)/Pi^d - 
        ((gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-8 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*(s - s*GaugeXi[Q])^2)/
         (2*Pi)^d + (2^(2 - d)*(-(gZlLC*gZuL*gZuLC*((-4 + d)*s - 2*t)) + 
           gZlRC*gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*
            ((-2 + d)*s + 2*t) + gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*
          (1 + GaugeXi[Q])*(s - s*GaugeXi[Q])^2)/Pi^d + 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
          (-1 + GaugeXi[Q]^2)^2)/Pi^d - 
        (s^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
           gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
           2^(1 + d)*Pi^d*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
             gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                 gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
            GaugeXi[Q]^2 + (gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                t) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
             gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))*
            GaugeXi[Q]^4))/(2*Pi)^(2*d))))/((-1 + d)*d*mw^4*(mz^2 - s)*s*
     (-mzC^2 + s)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) - 
   (2*gWWZ^2*((2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        s^2)/Pi^d + (3*2^(1 - d)*(4 + d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/(d*Pi^d) + 
      (2^(1 - 2*d)*(4 + d)*(gZlL*gZlLC*(gZuL*gZuLC*(5*2^(3 + d)*Pi^d - 
             39*(2*Pi)^d) + gZuR*gZuRC*(-(2^(3 + d)*Pi^d) + 9*(2*Pi)^d)) - 
         gZlR*gZlRC*(gZuL*gZuLC*(2^(3 + d)*Pi^d - 9*(2*Pi)^d) + 
           gZuR*gZuRC*(-5*2^(3 + d)*Pi^d + 39*(2*Pi)^d)))*s^2)/(d*Pi^(2*d)) + 
      (3*2^(1 - d)*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t))))/Pi^d - 
      (2^(2 - d)*s*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t))))/Pi^d - 
      (2^(1 - d)*s*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t))))/Pi^d - (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^3)/(mw^2*Pi^d*GaugeXi[Q]) - 
      (3*s^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t))))/(mw^2*(2*Pi)^d*GaugeXi[Q]) + 
      (s^2*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t))))/(mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      (3*2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*
        GaugeXi[Q])/Pi^d + (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s*(2*mw^2 + s)*GaugeXi[Q])/Pi^d + 
      (3*4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q])/Pi^(2*d) - 
      (3*mw^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        GaugeXi[Q])/(2*Pi)^d + 
      (3*mw^2*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
           2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t)))*
        GaugeXi[Q])/(2*Pi)^d + (2^(1 - d)*mw^2*
        (gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t)))*GaugeXi[Q])/Pi^d + 
      (mw^2*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t)))*GaugeXi[Q])/(2*Pi)^d + 
      (2^(1 - d)*mw^2*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t)))*GaugeXi[Q])/Pi^d + 
      (mw^2*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t)))*GaugeXi[Q])/(2*Pi)^d - 
      (2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*
        (1 + GaugeXi[Q]))/Pi^d - 
      (2^(2 - d)*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (1 + GaugeXi[Q]))/Pi^d - 
      (2^(3 - d)*s*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (1 + GaugeXi[Q]))/Pi^d + 
      (2^(2 - d)*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
           2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
         gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + 
           gZuR*gZuRC*(d*s + 2*t)))*(1 + GaugeXi[Q]))/Pi^d + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
        (1 + GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(2 - d)*s^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (1 + GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(2 - d)*s^2*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (1 + GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(1 - d)*(2*mw^2 + s)^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (s - 2*mw^2*GaugeXi[Q]))/(mw^4*Pi^d) - 
      (2^(3 - 2*d)*(gZlL*gZlLC*(gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*
              ((-2 + d)*s + 2*t) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-s + t))) - gZuL*gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*
                t) + s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))) + 
         gZlR*gZlRC*(gZuL*gZuLC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
             s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) - 
           gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
             s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))))*
        ((-2*t)/d + mw^2*GaugeXi[Q]))/(mw^2*Pi^(2*d)) + 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (2*mw^2 + s)^2*((d*s)/(2 - 2*d) + 2*mw^2*GaugeXi[Q]))/(mw^4*Pi^d) - 
      (2^(2 - d)*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        ((4 + d)*s + 4*mw^2*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
         gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*s^2*t*
        (s + (12*mw^2*GaugeXi[Q])/d))/(mw^4*Pi^d*GaugeXi[Q]^2) + 
      (2^(2 - d)*s*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (-2*t + (4 + d)*mw^2*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) - 
      ((2 + d)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-4 + d)*s + 2*t) + 
           gZuL*gZuLC*(-((-2 + d)*s) + 2*t)) + gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      ((2 + d)*s*(-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 
              2^(1 + d)*Pi^d*(s + t)))) + gZlL*gZlLC*
          (gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
        (s - 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*(2*Pi)^(2*d)*GaugeXi[Q]) - 
      (2^(1 - d)*(2 + d)*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (-s + 2*(3*mw^2 + s)*GaugeXi[Q]))/(d*mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(1 - d)*(2*mw^2 + s)*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (-2*s + (6*mw^2 + s)*GaugeXi[Q]))/(mw^2*Pi^d) - 
      (2^(2 - d)*s*(s + (4*mw^2*GaugeXi[Q])/d)*
        ((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - (-2 + d)*gZuR*gZuRC))*s*t + 
         (gZlL*gZlLC*(gZuR*gZuRC*(-((-4 + d)*s*t) + mw^2*((-4 + d)*s - 
                 2*(-5 + d)*t)) + gZuL*gZuLC*((-2 + d)*s*t + mw^2*
                (-((-2 + d)*s) + 2*(-1 + d)*t))) + gZlR*gZlRC*
            (gZuL*gZuLC*(-((-4 + d)*s*t) + mw^2*((-4 + d)*s - 2*(-5 + d)*
                  t)) + gZuR*gZuRC*((-2 + d)*s*t + mw^2*(-((-2 + d)*s) + 
                 2*(-1 + d)*t))))*GaugeXi[Q]))/(mw^4*Pi^d*GaugeXi[Q]^2) - 
      (4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
        ((2*Pi)^d + 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2))/
       (mw^2*Pi^(2*d)*GaugeXi[Q]) + 
      ((2*mw^2 + s)^2*(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
           gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (d*s + 2*t - 4*(-1 + d)*mw^2*GaugeXi[Q])*((2*Pi)^(2*d) - 
         2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2))/
       ((-1 + d)*mw^4*(2*Pi)^(3*d)*(-1 + GaugeXi[Q])^2) + 
      (2^(2 - d)*(2*mw^2 + s)*((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + 
             (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - 
             (-2 + d)*gZuR*gZuRC))*s^2*t + 
         (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*s*
          (6*mw^2 + s)*t*GaugeXi[Q] + mw^2*(4*mw^2 + s)*
          (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
              ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*
                t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^2))/
       (mw^4*Pi^d*GaugeXi[Q]) + 
      (s^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - 
                t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)))) + 
         gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
         2^(1 + d)*Pi^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
            (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*
                t)))*GaugeXi[Q]^2 + 
         (-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 (2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                 (s + t)))) + gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
               2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
               2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^4))/
       (mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]) + 
      (s^2*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
              2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + 
           gZlL*gZlLC*(gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*
              (d*s + 2*t)))*GaugeXi[Q]^2 + 
         (gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
          GaugeXi[Q]^4))/(mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]) + 
      (s*(-((gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
            gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*
           (2*Pi)^(2*d)*s^2*t) + 3*2^(1 + 2*d)*
          (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*
          Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] - 2^(1 + 2*d)*Pi^(2*d)*
          (gZlL*gZlLC*(gZuR*gZuRC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + 
                 (30 - 7*d)*t) + mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
             gZuL*gZuLC*(5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + 
                 (12 - 7*d)*t) + mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(-5*(-4 + d)*s^2*t + 2*mw^2*s*((-4 + d)*s + 
                 (30 - 7*d)*t) + mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + 
             gZuR*gZuRC*(5*(-2 + d)*s^2*t - 2*mw^2*s*((-2 + d)*s + 
                 (12 - 7*d)*t) + mw^4*(-5*(-2 + d)*s + 2*(3 + d)*t))))*
          GaugeXi[Q]^2 - 2^(1 + 2*d)*Pi^(2*d)*
          (-(gZlR*gZlRC*gZuL*gZuLC*(-3*(-4 + d)*s^2*t + 2*mw^2*s*(
                2*(-4 + d)*s + (24 - 5*d)*t) + 2*mw^4*(5*(-4 + d)*s - 
                2*(-9 + d)*t))) - gZlL*gZlLC*gZuR*gZuRC*(-3*(-4 + d)*s^2*t + 
             2*mw^2*s*(2*(-4 + d)*s + (24 - 5*d)*t) + 
             2*mw^4*(5*(-4 + d)*s - 2*(-9 + d)*t)) + gZlL*gZlLC*gZuL*gZuLC*
            (-3*(-2 + d)*s^2*t + 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*t) + 
             2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t)) + gZlR*gZlRC*gZuR*gZuRC*
            (-3*(-2 + d)*s^2*t + 2*mw^2*s*(2*(-2 + d)*s + (6 - 5*d)*t) + 
             2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t)))*GaugeXi[Q]^3 + 
         (2*Pi)^(2*d)*(gZlL*gZlLC*(gZuR*gZuRC*((-4 + d)*s^2*t + mw^4*
                (-10*(-4 + d)*s + 4*(-9 + d)*t) - 4*mw^2*s*((-4 + d)*s - 
                 (-6 + d)*t)) + gZuL*gZuLC*(-((-2 + d)*s^2*t) + 4*mw^2*s*
                ((-2 + d)*s - d*t) + 2*mw^4*(5*(-2 + d)*s - 2*(3 + d)*t))) - 
           gZlR*gZlRC*(gZuL*gZuLC*(-((-4 + d)*s^2*t) + 2*mw^4*(5*(-4 + d)*s - 
                 2*(-9 + d)*t) + 4*mw^2*s*((-4 + d)*s - (-6 + d)*t)) + 
             gZuR*gZuRC*((-2 + d)*s^2*t + 4*mw^2*s*(-((-2 + d)*s) + d*t) + 
               mw^4*(-10*(-2 + d)*s + 4*(3 + d)*t))))*GaugeXi[Q]^4))/
       (mw^4*(2*Pi)^(3*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) + 
      (s*(((-(gZlR*gZlRC*(gZuL*gZuLC*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + gZuR*
                gZuRC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d))) + 
            gZlL*gZlLC*(gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
              gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)))*s^2*t)/
          (mw^4*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) + 
         (6*s*(gZlR*gZlRC*(gZuR*gZuRC*(2^(1 + d)*(-2 + d)*mw^2*Pi^d - 
                2^(1 + d)*Pi^d*s + d*(2*Pi)^d*s) - gZuL*gZuLC*(2^(1 + d)*
                 (-4 + d)*mw^2*Pi^d - 2^(2 + d)*Pi^d*s + d*(2*Pi)^d*s)) + 
            gZlL*gZlLC*(gZuL*gZuLC*(2^(1 + d)*(-2 + d)*mw^2*Pi^d - 
                2^(1 + d)*Pi^d*s + d*(2*Pi)^d*s) - gZuR*gZuRC*(2^(1 + d)*
                 (-4 + d)*mw^2*Pi^d - 2^(2 + d)*Pi^d*s + d*(2*Pi)^d*s)))*t)/
          (mw^4*GaugeXi[Q]) + 
         ((-(gZlR*gZlRC*(gZuL*gZuLC*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + gZuR*
                gZuRC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d))) + 
            gZlL*gZlLC*(gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
              gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)))*s^2*t*
           GaugeXi[Q]^2)/(mw^4*(-1 + GaugeXi[Q])^2) + 2^(1 + d)*Pi^d*
          (gZlL*gZlLC*(gZuR*gZuRC*(-5*(-4 + d)*s + 2*(-9 + d)*t + 
               (2*(-6 + d)*s*t)/mw^2 - ((-4 + d)*s^2*(2*mw^2 + t - 
                  4*mw^2*GaugeXi[Q] + 2*mw^2*GaugeXi[Q]^2))/(mw^4*
                 (-1 + GaugeXi[Q])^2)) + gZuL*gZuLC*(-2*(3 + d)*t + s*
                (-10 + d*(5 - (2*t)/mw^2)) + ((-2 + d)*s^2*(2*mw^2 + t - 
                  4*mw^2*GaugeXi[Q] + 2*mw^2*GaugeXi[Q]^2))/(mw^4*
                 (-1 + GaugeXi[Q])^2))) + gZlR*gZlRC*
            (gZuL*gZuLC*(-5*(-4 + d)*s + 2*(-9 + d)*t + (2*(-6 + d)*s*t)/
                mw^2 - ((-4 + d)*s^2*(2*mw^2 + t - 4*mw^2*GaugeXi[Q] + 
                  2*mw^2*GaugeXi[Q]^2))/(mw^4*(-1 + GaugeXi[Q])^2)) + 
             gZuR*gZuRC*(-2*(3 + d)*t + s*(-10 + d*(5 - (2*t)/mw^2)) + 
               ((-2 + d)*s^2*(2*mw^2 + t - 4*mw^2*GaugeXi[Q] + 2*mw^2*
                   GaugeXi[Q]^2))/(mw^4*(-1 + GaugeXi[Q])^2))))))/
       (2*Pi)^(2*d)))/((mz^2 - s)^2*(-mzC^2 + s))), 
 ((-I)*4^(-2 - 3*d)*EL^6*(4^(1 + 2*d)*gAl*gAu*gFFA^2*mw^4*Pi^(4*d)*
     (mz^2 - s)^2*sw^2*(gZlLC*(d^2*gZuLC*(2*Pi)^d*s^2 - 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuRC*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuLC*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2)))*(-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) - 
    4^(1 + 2*d)*gAl*gAu*ggmgmA^2*mw^4*Pi^(4*d)*(mz^2 - s)^2*sw^2*
     (gZlLC*(d^2*gZuLC*(2*Pi)^d*s^2 - d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuRC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuLC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2)) + gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuRC*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
     (-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) - 
    4^(1 + 2*d)*gAl*gAu*ggpgpA^2*mw^4*Pi^(4*d)*(mz^2 - s)^2*sw^2*
     (gZlLC*(d^2*gZuLC*(2*Pi)^d*s^2 - d^2*gZuRC*(2*Pi)^d*s^2 + 
        2^(1 + d)*gZuRC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(1 + d)*gZuLC*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
          2*t^2)) + gZlRC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + 
        d^2*gZuRC*(2*Pi)^d*s^2 + 2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - 
          (4 - 5*d + d^2)*s*t + 2*t^2) + 2^(1 + d)*gZuRC*Pi^d*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*
     (-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) + 
    2^(2 + 5*d)*gFFZ^2*mw^4*Pi^(5*d)*s^2*sw^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
     (-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) - 
    2^(2 + 5*d)*ggmgmZ^2*mw^4*Pi^(5*d)*s^2*sw^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
     (-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) - 
    2^(2 + 5*d)*ggpgpZ^2*mw^4*Pi^(5*d)*s^2*sw^2*
     (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuR*gZuRC*
         ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))*
     (-1 + GaugeXi[Q])^2*(s - 4*mw^2*GaugeXi[Q]) - 
    4^(1 + 2*d)*gAl*gFFA*gFFZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
          gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2))) - 
        gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
          gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
      4*mw^2*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) + 
    4^(1 + 2*d)*gAl*ggmgmA*ggmgmZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
          gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2))) - 
        gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
          gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
      4*mw^2*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) + 
    4^(1 + 2*d)*gAl*ggpgpA*ggpgpZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
          gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2))) - 
        gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
          gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2)))) + 
      4*mw^2*(gZlRC*gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlLC*gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZlRC*gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
           (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) - 
    4^(1 + 2*d)*gAu*gFFA*gFFZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
            2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
            (8 - 5*d + d^2)*s*t - 2*t^2)) - gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      4*mw^2*(-(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*
            s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
             2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2))) + gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) + 
    4^(1 + 2*d)*gAu*ggmgmA*ggmgmZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
            2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
            (8 - 5*d + d^2)*s*t - 2*t^2)) - gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      4*mw^2*(-(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*
            s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
             2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2))) + gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) + 
    4^(1 + 2*d)*gAu*ggpgpA*ggpgpZ*mw^4*Pi^(4*d)*(mz^2 - s)*s*
     (sw - sw*GaugeXi[Q])^2*
     (s*(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
            2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
            (8 - 5*d + d^2)*s*t - 2*t^2)) - gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      4*mw^2*(-(gZlL*gZlLC*(-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*
            s^2 + 2^(1 + d)*gZuRC*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 
             2*t^2) + 2^(1 + d)*gZuLC*Pi^d*(2*(-1 + d)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2))) + gZlR*gZlRC*
         (-(d^2*gZuLC*(2*Pi)^d*s^2) + d^2*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuLC*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 
            2*t^2) + 2^(1 + d)*gZuRC*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2)))*GaugeXi[Q]) + 
    2^(1 + 4*d)*gFZW^2*mw^2*Pi^(4*d)*s^2*(-1 + GaugeXi[Q])^2*
     (s*(gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
             ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
          gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
              (8 - 5*d + d^2)*s*t - 2*t^2))) - gZlR*gZlRC*
         (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
              (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 
              2*t^2)))) + 4*mw^2*
       (gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
             ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
          gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
              (8 - 5*d + d^2)*s*t + 2*t^2))) + gZlR*gZlRC*
         (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
              (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
            2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))*
       GaugeXi[Q]) - gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(2*Pi)^(4*d)*
     (mz^2 - s)^2*s^2*sw^2*CKM[1, 1]*CKMC[1, 1]*(d^2*(2*Pi)^d*s^3 - 
      2^(1 + d)*Pi^d*s*(2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2) - 
      2^(1 + d)*Pi^d*(2*mw^2 + s)*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
        4*t^2)*GaugeXi[Q] + (d^2*(2*Pi)^d*s^3 + 2^(1 + d)*Pi^d*s*
         (-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2) + 
        2^(3 + d)*mw^2*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
       GaugeXi[Q]^2 - 2^(2 + d)*mw^2*Pi^d*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2)*GaugeXi[Q]^3) + 
    gAl*gWdu*gWud*gWWA*gZuLC*(2*Pi)^(3*d)*(mz^2 - s)^2*s*sw^2*CKM[1, 1]*
     CKMC[1, 1]*((-1 + d)*(2*Pi)^(2*d)*(2*mw^2 + s)*((-2 + d)*gZlLC*s - 
        (-4 + d)*gZlRC*s - 2*gZlLC*t - 2*gZlRC*t)*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 - (gZlLC + gZlRC)*(2*Pi)^(2*d)*s*
       (2*mw^2 + s)*(-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - (gZlLC + gZlRC)*(2*Pi)^d*s*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*mw^2 + s)*
         GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q]^2) - 
      (2*Pi)^d*(s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (gZlRC*s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s - t)) - 
        2^(1 + d)*gZlRC*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
        gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) - 
          s*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s + t))) - 
        2^(1 + d)*Pi^d*(2*mw^2 + s)*((-4 + d)*gZlLC*s - (-2 + d)*gZlRC*s - 
          2*gZlLC*t - 2*gZlRC*t)*GaugeXi[Q] + 
        (-(gZlRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
             s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
          gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))))*GaugeXi[Q]^2) + 
      (1 - d)*(2*Pi)^d*(s - 2*mw^2*GaugeXi[Q])*
       (s*(-(2^(1 + d)*gZlLC*mw^2*Pi^d*((-2 + d)*s - 2*t)) + 
          2^(1 + d)*gZlRC*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
          gZlRC*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZlLC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        2*(-(gZlRC*(-3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
             2^(1 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZlLC*(2^(1 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) - 
            3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
         GaugeXi[Q] + (gZlRC*(2^(3 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
          gZlLC*(-(2^(3 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
            3*2^(1 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^2 + 
        2^(1 + d)*mw^2*Pi^d*(2*mw^2 + s)*((-2 + d)*gZlLC*s - 
          (-4 + d)*gZlRC*s - 2*gZlLC*t - 2*gZlRC*t)*GaugeXi[Q]^3) - 
      2*(1 - d)*(1 - GaugeXi[Q])*(((-2 + d)*gZlLC - (-4 + d)*gZlRC)*
         (2*Pi)^(2*d)*s^2*(2*mw^2 + s)*t - ((-2 + d)*gZlLC - (-4 + d)*gZlRC)*
         (2*Pi)^(2*d)*s*(8*mw^4 + 6*mw^2*s + s^2)*t*GaugeXi[Q] - 
        2^(1 + 2*d)*mw^2*Pi^(2*d)*(2*mw^2 + s)*(2*(-4 + d)*gZlRC*s*t - 
          gZlRC*mw^2*((-4 + d)*s + 2*t) + gZlLC*(mw^2*((-2 + d)*s - 2*t) - 
            2*(-2 + d)*s*t))*GaugeXi[Q]^2 + 2^(1 + 2*d)*mw^4*Pi^(2*d)*
         (2*mw^2 + s)*((-2 + d)*gZlLC*s - (-4 + d)*gZlRC*s - 2*gZlLC*t - 
          2*gZlRC*t)*GaugeXi[Q]^3)) + gWdu*gWud*gWWZ*gZuLC*(2*Pi)^(3*d)*
     (mz^2 - s)*s^2*sw^2*CKM[1, 1]*CKMC[1, 1]*
     ((-1 + d)*(2*Pi)^(2*d)*(2*mw^2 + s)*(gZlL*gZlLC*((-2 + d)*s - 2*t) - 
        gZlR*gZlRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 - (gZlL*gZlLC + gZlR*gZlRC)*(2*Pi)^d*s*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*mw^2 + s)*
         GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q]^2) - 
      (gZlL*gZlLC + gZlR*gZlRC)*(2*Pi)^d*s*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*(2^(1 + d)*mw^2*Pi^d - 
        2^(1 + d)*Pi^d*s + 3*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*mw^2 + s)*
         GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q]^2) - 
      2*(1 - d)*(2*mw^2 + s)*(-1 + GaugeXi[Q])^2*
       (((-2 + d)*gZlL*gZlLC - (-4 + d)*gZlR*gZlRC)*(2*Pi)^(2*d)*s^2*t - 
        4^(1 + d)*((-2 + d)*gZlL*gZlLC - (-4 + d)*gZlR*gZlRC)*mw^2*Pi^(2*d)*s*
         t*GaugeXi[Q] - 2^(1 + 2*d)*mw^4*Pi^(2*d)*
         (gZlL*gZlLC*((-2 + d)*s - 2*t) - gZlR*gZlRC*((-4 + d)*s + 2*t))*
         GaugeXi[Q]^2) + (2*Pi)^d*(s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*
         GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (gZlR*gZlRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) - 
        gZlL*gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
          s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))) + 
        2^(1 + d)*Pi^d*(2*mw^2 + s)*(gZlL*gZlLC*((-4 + d)*s - 2*t) - 
          gZlR*gZlRC*((-2 + d)*s + 2*t))*GaugeXi[Q] - 
        (-(gZlR*gZlRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
             s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
          gZlL*gZlLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))))*GaugeXi[Q]^2) + 
      (1 - d)*(2*Pi)^d*(s - 2*mw^2*GaugeXi[Q])*
       (s*(gZlL*gZlLC*(-(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s - 2*t)) + 
            s*(5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 3*d*s + t))) + 
          gZlR*gZlRC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
            s*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + t)))) + 
        2*(-(gZlR*gZlRC*(-3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t)) + 2^(1 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZlL*gZlLC*(2^(1 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) - 
            3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
         GaugeXi[Q] + (gZlR*gZlRC*(2^(3 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) - 
          gZlL*gZlLC*(2^(3 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^2 + 
        2^(1 + d)*mw^2*Pi^d*(2*mw^2 + s)*(gZlL*gZlLC*((-2 + d)*s - 2*t) - 
          gZlR*gZlRC*((-4 + d)*s + 2*t))*GaugeXi[Q]^3)) - 
    gAu*gWlN*gWNl*gWWA*gZlLC*(2*Pi)^d*(mz^2 - s)^2*s*sw^2*
     ((-1 + d)*(2*Pi)^(4*d)*(2*mw^2 + s)*((-2 + d)*gZuLC*s - 
        (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 - (gZuLC + gZuRC)*(2*Pi)^(4*d)*s*
       (2*mw^2 + s)*(-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - (2*Pi)^(3*d)*
       (-(gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
           s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
        gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
          s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))))*(-1 + GaugeXi[Q])^2*
       (s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - (gZuLC + gZuRC)*(2*Pi)^(3*d)*s*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*mw^2 + s)*
         GaugeXi[Q] + (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q]^2) + 
      (1 - d)*(2*Pi)^(3*d)*(s - 2*mw^2*GaugeXi[Q])*
       (s*(-(2^(1 + d)*gZuLC*mw^2*Pi^d*((-2 + d)*s - 2*t)) + 
          2^(1 + d)*gZuRC*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
          gZuRC*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZuLC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
        2*(-(gZuRC*(-3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
             2^(1 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZuLC*(2^(1 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) - 
            3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
         GaugeXi[Q] + (gZuRC*(2^(3 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
          gZuLC*(-(2^(3 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
            3*2^(1 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^2 + 
        2^(1 + d)*mw^2*Pi^d*(2*mw^2 + s)*((-2 + d)*gZuLC*s - 
          (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)*GaugeXi[Q]^3) - 
      2*(1 - d)*(2*mw^2 + s)*(((-2 + d)*gZuLC - (-4 + d)*gZuRC)*(2*Pi)^(4*d)*
         s^2*t - 2^(1 + 4*d)*((-2 + d)*gZuLC - (-4 + d)*gZuRC)*Pi^(4*d)*s*
         (2*mw^2 + s)*t*GaugeXi[Q] - (2*Pi)^(4*d)*
         (gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 8*(-2 + d)*mw^2*s*t - 
            (-2 + d)*s^2*t) + gZuRC*(8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 
            2*mw^4*((-4 + d)*s + 2*t)))*GaugeXi[Q]^2 + 
        4^(1 + 2*d)*mw^2*Pi^(4*d)*((-4 + d)*gZuRC*s*t - 
          gZuRC*mw^2*((-4 + d)*s + 2*t) + gZuLC*(mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*s*t))*GaugeXi[Q]^3 - 2^(1 + 4*d)*mw^4*Pi^(4*d)*
         ((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t)*
         GaugeXi[Q]^4)) - gAl*gAu*gWWA^2*(2*Pi)^(3*d)*(mz^2 - s)^2*sw^2*
     ((1 - d)*(2*Pi)^(2*d)*(2*mw^2 + s)^2*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
        gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
        gZlLC*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 + (1 - d)*(2*Pi)^d*
       (gZlLC*(-(gZuRC*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZuLC*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 2^(2 + d)*mw^2*Pi^d*
             s*((-2 + d)*s - 2*t) + s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + 
                t)))) - gZlRC*(gZuLC*(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s + 
              2*t) + 2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
          gZuRC*(-(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t)) - 
            2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*
       (-1 + GaugeXi[Q])^2*(s - 2*mw^2*GaugeXi[Q])^2 + 
      (gZlLC + gZlRC)*(gZuLC + gZuRC)*(2*Pi)^(2*d)*s*(2*mw^2 + s)^2*
       (-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) + (gZlLC + gZlRC)*(gZuLC + gZuRC)*
       (2*Pi)^d*s*(2^(2 + d)*mw^4*Pi^d + 2^(2 + d)*mw^2*Pi^d*s + 
        (2*Pi)^d*s^2)*(-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - 
      (2*Pi)^d*(gZlRC*gZuLC*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlLC*gZuRC*(2^(2 + d)*mw^4*Pi^d*((-2 + d)*s + 2*t) + 
          2^(2 + d)*mw^2*Pi^d*s*((-2 + d)*s + 2*t) + 
          s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) + 
        gZlLC*gZuLC*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))) + 
        gZlRC*gZuRC*(-(2^(2 + d)*mw^4*Pi^d*((-4 + d)*s - 2*t)) - 
          2^(2 + d)*mw^2*Pi^d*s*((-4 + d)*s - 2*t) + 
          s^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
       (-1 + GaugeXi[Q])^2*(s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - 2*(1 - d)*(2*mw^2 + s)^2*
       ((-((-2 + d)*gZlLC*gZuLC) + (-4 + d)*gZlRC*gZuLC + 
          (-4 + d)*gZlLC*gZuRC - (-2 + d)*gZlRC*gZuRC)*(2*Pi)^(2*d)*s^2*t + 
        2^(1 + 2*d)*((-2 + d)*gZlLC*gZuLC - (-4 + d)*gZlRC*gZuLC - 
          (-4 + d)*gZlLC*gZuRC + (-2 + d)*gZlRC*gZuRC)*Pi^(2*d)*s*
         (2*mw^2 + s)*t*GaugeXi[Q] + (2*Pi)^(2*d)*
         (gZlLC*(gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 8*(-2 + d)*mw^2*s*t - 
              (-2 + d)*s^2*t) + gZuRC*(8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 
              2*mw^4*((-4 + d)*s + 2*t))) - 
          gZlRC*(gZuLC*(-8*(-4 + d)*mw^2*s*t - (-4 + d)*s^2*t + 
              2*mw^4*((-4 + d)*s + 2*t)) + gZuRC*(8*(-2 + d)*mw^2*s*t + 
              (-2 + d)*s^2*t + mw^4*(4*s - 2*d*s + 4*t))))*GaugeXi[Q]^2 - 
        4^(1 + d)*mw^2*Pi^(2*d)*(gZlLC*(gZuLC*mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*gZuLC*s*t + (-4 + d)*gZuRC*s*t - gZuRC*mw^2*
             ((-4 + d)*s + 2*t)) - gZlRC*(-((-4 + d)*gZuLC*s*t) + 
            (-2 + d)*gZuRC*s*t + gZuLC*mw^2*((-4 + d)*s + 2*t) + 
            gZuRC*mw^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^3 + 
        2^(1 + 2*d)*mw^4*Pi^(2*d)*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
          gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
          gZlLC*gZuRC*((-4 + d)*s + 2*t))*GaugeXi[Q]^4)) + 
    gWlN*gWNl*gWWZ*gZlLC*(mz^2 - s)*s^2*sw^2*
     ((1 - d)*(2*Pi)^(5*d)*(2*mw^2 + s)*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
        gZuR*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 + (gZuL*gZuLC + gZuR*gZuRC)*(2*Pi)^(5*d)*s*
       (2*mw^2 + s)*(-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) + (gZuL*gZuLC + gZuR*gZuRC)*
       (2*Pi)^(4*d)*s*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*(2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s - 
        2^(1 + d)*Pi^d*(2*mw^2 + s)*GaugeXi[Q] + 
        (2^(1 + d)*mw^2*Pi^d + (2*Pi)^d*s)*GaugeXi[Q]^2) - 
      (2*Pi)^(4*d)*(s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       (gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t))) - 
        gZuL*gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
          s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))) + 
        2^(1 + d)*Pi^d*(2*mw^2 + s)*(gZuL*gZuLC*((-4 + d)*s - 2*t) - 
          gZuR*gZuRC*((-2 + d)*s + 2*t))*GaugeXi[Q] - 
        (-(gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s + 2*t) + 
             s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)))) + 
          gZuL*gZuLC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s - 2*t) + 
            s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))))*GaugeXi[Q]^2) - 
      (1 - d)*(2*Pi)^(4*d)*(s - 2*mw^2*GaugeXi[Q])*
       (s*(gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
            s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) + 
          gZuL*gZuLC*(-(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s - 2*t)) + 
            s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) + 
        2*(-(gZuR*gZuRC*(-3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t)) + 2^(1 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
             s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
          gZuL*gZuLC*(2^(1 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) - 
            3*mw^2*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
         GaugeXi[Q] + (gZuR*gZuRC*(2^(3 + d)*mw^4*Pi^d*((-4 + d)*s + 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-4 + d)*s + 2*t) + 
            s^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) - 
          gZuL*gZuLC*(2^(3 + d)*mw^4*Pi^d*((-2 + d)*s - 2*t) + 
            3*2^(1 + d)*mw^2*Pi^d*s*((-2 + d)*s - 2*t) + 
            s^2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]^2 + 
        2^(1 + d)*mw^2*Pi^d*(2*mw^2 + s)*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
          gZuR*gZuRC*((-4 + d)*s + 2*t))*GaugeXi[Q]^3) + 
      2*(1 - d)*(2*mw^2 + s)*(((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC)*
         (2*Pi)^(5*d)*s^2*t - 2^(1 + 5*d)*((-2 + d)*gZuL*gZuLC - 
          (-4 + d)*gZuR*gZuRC)*Pi^(5*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] - 
        (2*Pi)^(5*d)*(gZuL*gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 
            8*(-2 + d)*mw^2*s*t - (-2 + d)*s^2*t) + gZuR*gZuRC*
           (8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 2*mw^4*((-4 + d)*s + 
              2*t)))*GaugeXi[Q]^2 + 2^(2 + 5*d)*mw^2*Pi^(5*d)*
         (gZuL*gZuLC*(mw^2*((-2 + d)*s - 2*t) - (-2 + d)*s*t) + 
          gZuR*gZuRC*((-4 + d)*s*t - mw^2*((-4 + d)*s + 2*t)))*GaugeXi[Q]^3 - 
        2^(1 + 5*d)*mw^4*Pi^(5*d)*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
          gZuR*gZuRC*((-4 + d)*s + 2*t))*GaugeXi[Q]^4)) - 
    gAu*gWWA*gWWZ*(2*Pi)^(3*d)*(mz^2 - s)*s*sw^2*
     (2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(2*mw^2 + s)^2*
       (gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 
          2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s - 
          2*gZuLC*t - 2*gZuRC*t))*(-1 + GaugeXi[Q])^2*(s - 2*mw^2*GaugeXi[Q])^
        2 + (gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(2*Pi)^(2*d)*s*
       (2*mw^2 + s)^2*(-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) + (gZlL*gZlLC + gZlR*gZlRC)*
       (gZuLC + gZuRC)*(2*Pi)^d*s*(2^(2 + d)*mw^4*Pi^d + 
        2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*(-1 + GaugeXi[Q])^2*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2) + 
      (2*mw^2 + s)^2*(gZlL*gZlLC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s - 
          2*gZuLC*t - 2*gZuRC*t) - gZlR*gZlRC*((-2 + d)*gZuLC*s - 
          (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
       (s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*
         GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) - 2*(1 - d)*(2*mw^2 + s)^2*
       ((gZlL*gZlLC*(-((-2 + d)*gZuLC) + (-4 + d)*gZuRC) + 
          gZlR*gZlRC*((-4 + d)*gZuLC - (-2 + d)*gZuRC))*(2*Pi)^(2*d)*s^2*t + 
        2^(1 + 2*d)*(gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*Pi^(2*d)*s*
         (2*mw^2 + s)*t*GaugeXi[Q] + (2*Pi)^(2*d)*
         (gZlL*gZlLC*(gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 8*(-2 + d)*mw^2*s*
               t - (-2 + d)*s^2*t) + gZuRC*(8*(-4 + d)*mw^2*s*t + 
              (-4 + d)*s^2*t - 2*mw^4*((-4 + d)*s + 2*t))) - 
          gZlR*gZlRC*(gZuLC*(-8*(-4 + d)*mw^2*s*t - (-4 + d)*s^2*t + 
              2*mw^4*((-4 + d)*s + 2*t)) + gZuRC*(8*(-2 + d)*mw^2*s*t + 
              (-2 + d)*s^2*t + mw^4*(4*s - 2*d*s + 4*t))))*GaugeXi[Q]^2 - 
        4^(1 + d)*mw^2*Pi^(2*d)*(gZlL*gZlLC*(gZuLC*mw^2*((-2 + d)*s - 2*t) - 
            (-2 + d)*gZuLC*s*t + (-4 + d)*gZuRC*s*t - gZuRC*mw^2*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(-((-4 + d)*gZuLC*s*t) + 
            (-2 + d)*gZuRC*s*t + gZuLC*mw^2*((-4 + d)*s + 2*t) + 
            gZuRC*mw^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q]^3 + 
        2^(1 + 2*d)*mw^4*Pi^(2*d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - 
            (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t) - 
          gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 
            2*gZuRC*t))*GaugeXi[Q]^4)) - gAl*gWWA*gWWZ*(2*Pi)^(3*d)*
     (mz^2 - s)*s*sw^2*(2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(2*mw^2 + s)^2*
       (gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
           ((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
          gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 + (gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
       (2*Pi)^(2*d)*s*(2*mw^2 + s)^2*(-1 + GaugeXi[Q])^2*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2) + 
      (gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*(2*Pi)^d*s*
       (2^(2 + d)*mw^4*Pi^d + 2^(2 + d)*mw^2*Pi^d*s + (2*Pi)^d*s^2)*
       (-1 + GaugeXi[Q])^2*(d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2) - (2*mw^2 + s)^2*
       (gZlLC*gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZlRC*gZuR*gZuRC*
         (-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*((-2 + d)*s + 2*t) + 
        gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*(s*(d*s + 2*t) - 
        4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2)*
       ((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*GaugeXi[Q] + 
        (2*Pi)^(2*d)*GaugeXi[Q]^2) - 2*(1 - d)*(2*mw^2 + s)^2*
       ((-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*gZuLC + 
          (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*(2*Pi)^(2*d)*
         s^2*t + 2^(1 + 2*d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
          (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
          (-2 + d)*gZlRC*gZuR*gZuRC)*Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] + 
        (2*Pi)^(2*d)*(gZlLC*(gZuL*gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 
              8*(-2 + d)*mw^2*s*t - (-2 + d)*s^2*t) + gZuR*gZuRC*
             (8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 2*mw^4*((-4 + d)*s + 
                2*t))) - gZlRC*(gZuL*gZuLC*(-8*(-4 + d)*mw^2*s*t - 
              (-4 + d)*s^2*t + 2*mw^4*((-4 + d)*s + 2*t)) + 
            gZuR*gZuRC*(8*(-2 + d)*mw^2*s*t + (-2 + d)*s^2*t + 
              mw^4*(4*s - 2*d*s + 4*t))))*GaugeXi[Q]^2 - 
        4^(1 + d)*mw^2*Pi^(2*d)*(gZlLC*(gZuL*gZuLC*(mw^2*((-2 + d)*s - 2*t) - 
              (-2 + d)*s*t) + gZuR*gZuRC*((-4 + d)*s*t - mw^2*((-4 + d)*s + 
                2*t))) - gZlRC*(gZuL*gZuLC*(-((-4 + d)*s*t) + 
              mw^2*((-4 + d)*s + 2*t)) + gZuR*gZuRC*((-2 + d)*s*t + 
              mw^2*(2*s - d*s + 2*t))))*GaugeXi[Q]^3 + 
        2^(1 + 2*d)*mw^4*Pi^(2*d)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
          gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t)))*GaugeXi[Q]^4)) - gWWZ^2*(2*Pi)^(3*d)*s^2*(2*mw^2 + s)^2*
     sw^2*(2^(1 + 2*d)*(1 - d)*Pi^(2*d)*
       (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
           ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
          gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
       (s - 2*mw^2*GaugeXi[Q])^2 + 2^(1 + 2*d)*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL*gZuLC + gZuR*gZuRC)*Pi^(2*d)*s*(-1 + GaugeXi[Q])^2*
       (d*s^2 - 4*d*mw^2*s*GaugeXi[Q] + 4*(-1 + d)*mw^4*GaugeXi[Q]^2) - 
      (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
          gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
         (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 2*t)))*
       (s*(d*s + 2*t) - 4*mw^2*(d*s + 2*t)*GaugeXi[Q] + 
        4*(-1 + d)*mw^4*GaugeXi[Q]^2)*((2*Pi)^(2*d) - 2^(1 + 2*d)*Pi^(2*d)*
         GaugeXi[Q] + (2*Pi)^(2*d)*GaugeXi[Q]^2) - 
      2*(1 - d)*((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + (-4 + d)*gZuR*gZuRC) + 
          gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - (-2 + d)*gZuR*gZuRC))*
         (2*Pi)^(2*d)*s^2*t + 2^(1 + 2*d)*(gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - 
            (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
            (-2 + d)*gZuR*gZuRC))*Pi^(2*d)*s*(2*mw^2 + s)*t*GaugeXi[Q] + 
        (2*Pi)^(2*d)*(gZlL*gZlLC*(gZuL*gZuLC*(2*mw^4*((-2 + d)*s - 2*t) - 
              8*(-2 + d)*mw^2*s*t - (-2 + d)*s^2*t) + gZuR*gZuRC*
             (8*(-4 + d)*mw^2*s*t + (-4 + d)*s^2*t - 2*mw^4*((-4 + d)*s + 
                2*t))) - gZlR*gZlRC*(gZuL*gZuLC*(-8*(-4 + d)*mw^2*s*t - 
              (-4 + d)*s^2*t + 2*mw^4*((-4 + d)*s + 2*t)) + 
            gZuR*gZuRC*(8*(-2 + d)*mw^2*s*t + (-2 + d)*s^2*t + 
              mw^4*(4*s - 2*d*s + 4*t))))*GaugeXi[Q]^2 - 
        4^(1 + d)*mw^2*Pi^(2*d)*(gZlL*gZlLC*
           (gZuL*gZuLC*(mw^2*((-2 + d)*s - 2*t) - (-2 + d)*s*t) + 
            gZuR*gZuRC*((-4 + d)*s*t - mw^2*((-4 + d)*s + 2*t))) - 
          gZlR*gZlRC*(gZuL*gZuLC*(-((-4 + d)*s*t) + mw^2*((-4 + d)*s + 
                2*t)) + gZuR*gZuRC*((-2 + d)*s*t + mw^2*(2*s - d*s + 2*t))))*
         GaugeXi[Q]^3 + 2^(1 + 2*d)*mw^4*Pi^(2*d)*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t)))*GaugeXi[Q]^4))))/((-1 + d)*mw^4*Pi^(6*d)*(mz^2 - s)^2*
   (mzC^2 - s)*s^2*sw^2*(-1 + GaugeXi[Q])^2), 
 (I/16)*EL^6*((2^(1 - d)*gAu*gWlN*gWNl*gWWA*gZlLC*
     (-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     ((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*Pi^d*(mzC^2 - s)*s) - 
   (2^(1 - d)*gWlN*gWNl*gWWZ*gZlLC*
     (-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     ((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*Pi^d*(mz^2 - s)*(-mzC^2 + s)) - 
   (gAl*gWdu*gWud*gWWA*gZuLC*
     (-(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
      gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*
     CKMC[1, 1]*((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*(2*Pi)^d*(mzC^2 - s)*s) + 
   (gWdu*gWud*gWWZ*gZuLC*(-(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZlL*gZlLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*CKM[1, 1]*CKMC[1, 1]*
     ((-4 - d + 4*d^2)*mw^2 + d*s + d*mw^2*GaugeXi[Q]))/
    ((-1 + d)*d*mw^4*(2*Pi)^d*(mz^2 - s)*(-mzC^2 + s)) + 
   (2^(1 - 2*d)*gFZW^2*
     (-((mw^2 - s)*(gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
           gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
               (8 - 5*d + d^2)*s*t - 2*t^2))) - gZlR*gZlRC*
          (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
               (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
             2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*
                t^2))))) + 
      mw^2*(-(gZlR*gZlRC*(-3*d^2*gZuL*gZuLC*(2*Pi)^d*s^2 + 
           3*d^2*gZuR*gZuRC*(2*Pi)^d*s^2 - 2^(1 + d)*gZuR*gZuRC*Pi^d*
            ((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2) + 
           2^(1 + d)*gZuL*gZuLC*Pi^d*((-4 + 3*d + d^2)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2))) + gZlL*gZlLC*
         (-3*d^2*gZuL*gZuLC*(2*Pi)^d*s^2 + 3*d^2*gZuR*gZuRC*(2*Pi)^d*s^2 + 
          2^(1 + d)*gZuL*gZuLC*Pi^d*((-2 + 2*d + d^2)*s^2 - 
            (8 - 5*d + d^2)*s*t - 2*t^2) - 2^(1 + d)*gZuR*gZuRC*Pi^d*
           ((-4 + 3*d + d^2)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)))*
       GaugeXi[Q]))/((-1 + d)*mw^2*Pi^(2*d)*(mz^2 - s)^2*s*(-mzC^2 + s)*
     sw^2) - (2^(1 - d)*gAl*gAu*gWWA^2*
     (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
      gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
      gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
      gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (4*(-1 + d)*mw^2*s + (4*(-3 + 2*d + d^2)*mw^4 + (-8 + 3*d + 4*d^2)*mw^2*
         s + d*s^2)*GaugeXi[Q] + (-4*(-1 + d)^2*mw^4 + d*mw^2*s)*
       GaugeXi[Q]^2))/((-1 + d)*d*mw^4*Pi^d*(mzC^2 - s)*s^2*GaugeXi[Q]) - 
   (gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*CKM[1, 1]*CKMC[1, 1]*
     (-((mw^2 - s)*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
           (8 - 5*d + d^2)*s*t - 2*t^2))) + 
      (2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
        3*mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
            (8 - 5*d + d^2)*s*t - 2*t^2)))*GaugeXi[Q] + 
      (-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*(2*(-1 + d)*s^2 - 
          (8 - 5*d + d^2)*s*t - 2*t^2) + mw^2*(d^2*(2*Pi)^d*s^2 + 
          2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 3*(8 - 5*d + d^2)*s*t + 
            6*t^2)))*GaugeXi[Q]^2 + mw^2*(-3*d^2*(2*Pi)^d*s^2 + 
        2^(1 + d)*Pi^d*((-2 + 2*d + d^2)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))*
       GaugeXi[Q]^3))/((-1 + d)*mw^4*(2*Pi)^(2*d)*(mzC^2 - s)*s*
     (-1 + GaugeXi[Q])^2) - 
   (2*gWWZ^2*((2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        mw^2*s)/Pi^d - (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2)/Pi^d + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*t)/
       Pi^d - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        s*(s + t))/Pi^d + 
      (2^(1 - d)*s*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t))))/Pi^d - (2^(2 - d)*mw^2*
        (gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t))))/Pi^d + 
      (2^(1 - d)*s*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t))))/Pi^d + (3*2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s)/(Pi^d*GaugeXi[Q]) - 
      (2^(5 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2)/
       (Pi^d*GaugeXi[Q]) + (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^3)/(mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*t)/
       (Pi^d*GaugeXi[Q]) - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2*t)/(mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (s + t))/(Pi^d*GaugeXi[Q]) + (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2*(s + t))/(mw^2*Pi^d*GaugeXi[Q]) - 
      (3*2^(1 - d)*mw^2*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
           2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
         gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + 
           gZuR*gZuRC*(d*s + 2*t))))/(Pi^d*GaugeXi[Q]) + 
      (3*2^(1 - d)*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
           2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
         gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + 
           gZuR*gZuRC*(d*s + 2*t))))/(Pi^d*GaugeXi[Q]) - 
      (3*s^2*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
           2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))))/
       (mw^2*(2*Pi)^d*GaugeXi[Q]) - 
      (s^2*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t))))/(mw^2*(2*Pi)^d*GaugeXi[Q]) + 
      (2^(1 - d)*s*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
             6*t))))/(Pi^d*GaugeXi[Q]) + (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*GaugeXi[Q])/Pi^d - 
      (2^(1 - d)*mw^2*(gZlR*gZlRC*(gZuR*gZuRC*(10*s - 3*d*s + 6*t) + 
           gZuL*gZuLC*(-8*s + 3*d*s + 6*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(10*s - 3*d*s + 6*t) + gZuR*gZuRC*(-8*s + 3*d*s + 
             6*t)))*GaugeXi[Q])/Pi^d - (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*(mw^2 - s)*s*(1 + GaugeXi[Q]))/Pi^d - 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (-mw^2 + s)*(1 + GaugeXi[Q]))/Pi^d + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        (mw^2 - s)*s^2*(1 + GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(1 - 2*d)*(2^(1 + d)*Pi^d*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*
              s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
           gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + 
             gZuR*gZuRC*(d*s + 2*t))) + 
         mw^2*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
          (-1 + GaugeXi[Q]))*(1 + GaugeXi[Q]))/(Pi^(2*d)*GaugeXi[Q]) + 
      (2^(1 - 2*d)*s*(2^(1 + d)*Pi^d*s*
          (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
             2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
            (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))) + 
         mw^2*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
          (-1 + GaugeXi[Q]))*(1 + GaugeXi[Q]))/(mw^2*Pi^(2*d)*GaugeXi[Q]) + 
      (2^(1 - d)*s^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (mw^2 - s + mw^2*GaugeXi[Q]))/(mw^4*Pi^d) + 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d + 
      (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/(Pi^d*GaugeXi[Q]) - 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*
        (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/
       (mw^2*Pi^d*GaugeXi[Q]) + (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s*t*(1 + GaugeXi[Q])*
        (-mw^2 + 2*s + mw^2*GaugeXi[Q]))/(mw^2*Pi^d*GaugeXi[Q]) - 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (s + t)*(1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/
       (mw^2*Pi^d*GaugeXi[Q]) + (2^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^3*(d*(-mw^2 + s) + 
         (4 - 3*d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*Pi^d) - 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/(d*Pi^d) - 
      (4^(1 - d)*(gZlL*gZlLC*(gZuL*gZuLC*(5*2^(3 + d)*Pi^d - 39*(2*Pi)^d) + 
           gZuR*gZuRC*(-(2^(3 + d)*Pi^d) + 9*(2*Pi)^d)) - 
         gZlR*gZlRC*(gZuL*gZuLC*(2^(3 + d)*Pi^d - 9*(2*Pi)^d) + 
           gZuR*gZuRC*(-5*2^(3 + d)*Pi^d + 39*(2*Pi)^d)))*s*
        (4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/(d*Pi^(2*d)) + 
      (s*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (-((mw^2 - s)*(d*s + 2*t)) + mw^2*((4 - 3*d)*s + 2*t)*GaugeXi[Q]))/
       ((-1 + d)*mw^4*(2*Pi)^d) - (3*2^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s*(mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/Pi^d - 
      (2^(2 - d)*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        ((-2*t)/d + mw^2*GaugeXi[Q])*(mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/(mw^2*Pi^d*GaugeXi[Q]) + 
      (3*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(2*s + d*(-mw^2 + s) + 
         d*mw^2*GaugeXi[Q])*(2*mw^2 - s + (3*mw^2 + 2*s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/(d*mw^2*(2*Pi)^d*GaugeXi[Q]) + 
      (2^(2 - d)*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        ((d*(mw^2 - s) - 4*s)*(mw^2 - s) + 2*mw^2*(4*s + d*(-mw^2 + s))*
          GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/(d*mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
         gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*t*
        (-mw^2 + s + mw^2*GaugeXi[Q])*(d*(mw^2 - s)^2 + 
         2*mw^2*(6*s + d*(-mw^2 + s))*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/
       (d*mw^4*Pi^d*GaugeXi[Q]^2) - 
      (2^(2 - d)*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (2*(mw^2 - s)*t + mw^2*(4*s + d*(-mw^2 + s) - 2*t)*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2))/(d*mw^2*Pi^d*GaugeXi[Q]) + 
      (2^(3 - 2*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (mw^2*(2^(1 + d)*Pi^d - 3*(2*Pi)^d) + 2^(1 + d)*Pi^d*s + 
         2^(1 + d)*Pi^d*s*GaugeXi[Q] + mw^2*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*
          GaugeXi[Q]^2))/(Pi^(2*d)*GaugeXi[Q]) - 
      (2^(1 - 2*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (mw^2*(2^(2 + d)*Pi^d - 3*(2*Pi)^d) + 2^(1 + d)*Pi^d*(mw^2 + s)*
          GaugeXi[Q] + mw^2*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*GaugeXi[Q]^2))/
       Pi^(2*d) + (4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2*(-(2^(1 + d)*mw^2*Pi^d) + (2*Pi)^d*s - 
         2^(1 + d)*Pi^d*(2*mw^2 - s)*GaugeXi[Q] + 
         (-(2^(1 + d)*mw^2*Pi^d) + (2*Pi)^d*s)*GaugeXi[Q]^2))/
       (mw^2*Pi^(2*d)*GaugeXi[Q]) + (4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s^2*((2*Pi)^d*(-mw^2 + s) - 
         2^(1 + d)*Pi^d*(mw^2 - s)*GaugeXi[Q] + 
         (mw^2*(-(2^(1 + d)*Pi^d) + (2*Pi)^d) + (2*Pi)^d*s)*GaugeXi[Q]^2))/
       (mw^2*Pi^(2*d)*GaugeXi[Q]) - 
      (((mw^2 - s)^2 + 2*mw^2*(-mw^2 + s + (2*s)/d)*GaugeXi[Q] + 
         mw^4*GaugeXi[Q]^2)*((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + 
             (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - 
             (-2 + d)*gZuR*gZuRC))*(2*Pi)^(2*d)*(3*mw^2 - 2*s)*t - 
         2^(1 + 2*d)*Pi^(2*d)*(gZlL*gZlLC*(gZuR*gZuRC*(-((-4 + d)*s*t) + mw^2*
                ((-4 + d)*s + 2*t)) + gZuL*gZuLC*((-2 + d)*s*t + mw^2*
                (2*s - d*s + 2*t))) + gZlR*gZlRC*
            (gZuL*gZuLC*(-((-4 + d)*s*t) + mw^2*((-4 + d)*s + 2*t)) + 
             gZuR*gZuRC*((-2 + d)*s*t + mw^2*(2*s - d*s + 2*t))))*
          GaugeXi[Q] - (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*
              gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
             (-2 + d)*gZuR*gZuRC))*mw^2*(2*Pi)^(2*d)*t*GaugeXi[Q]^2))/
       (mw^4*(2*Pi)^(3*d)*GaugeXi[Q]^2) + 
      (((mw^2 - s)^2 + 2*mw^2*(-mw^2 + s + (2*s)/d)*GaugeXi[Q] + 
         mw^4*GaugeXi[Q]^2)*((gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - 
             (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
             (-2 + d)*gZuR*gZuRC))*(2*Pi)^(3*d)*(3*mw^2 - 2*s)*t + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZlLC*(gZuR*gZuRC*(-((-4 + d)*s*t) + mw^2*
                ((-4 + d)*s + 2*t)) + gZuL*gZuLC*((-2 + d)*s*t + mw^2*
                (2*s - d*s + 2*t))) + gZlR*gZlRC*
            (gZuL*gZuLC*(-((-4 + d)*s*t) + mw^2*((-4 + d)*s + 2*t)) + 
             gZuR*gZuRC*((-2 + d)*s*t + mw^2*(2*s - d*s + 2*t))))*
          GaugeXi[Q] + (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*
              gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
             (-2 + d)*gZuR*gZuRC))*mw^2*(2*Pi)^(3*d)*t*GaugeXi[Q]^2))/
       (mw^4*(2*Pi)^(4*d)*GaugeXi[Q]^2) + 
      (2^(1 - d)*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (mw^4 - mw^2*s + (3*mw^4 - 2*s^2)*GaugeXi[Q] + 
         (3*mw^4 + mw^2*s + s^2)*GaugeXi[Q]^2 + mw^4*GaugeXi[Q]^3))/
       (mw^2*Pi^d*GaugeXi[Q]) + 
      ((mw^2 - s)*s*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*t) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(3*s + t))) + gZlR*gZlRC*
          (gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
           gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
         2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
              2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + 
           gZlL*gZlLC*(gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*
              (d*s + 2*t)))*GaugeXi[Q]^2 + 
         (gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
          GaugeXi[Q]^4))/(mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]) - 
      (2^(1 - 4*d)*(-mw^2 + s + mw^2*GaugeXi[Q])*
        ((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - (-2 + d)*gZuR*gZuRC))*
          (2*Pi)^(3*d)*(3*mw^4 - 4*mw^2*s + s^2)*t + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlL*gZlLC*(gZuR*gZuRC*(3*(-4 + d)*mw^2*s*t - 3*(-4 + d)*s^2*t + 
               mw^4*(8*s - 2*d*s + 8*t - 3*d*t)) + gZuL*gZuLC*
              (-3*(-2 + d)*mw^2*s*t + 3*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + 
                 (-10 + 3*d)*t))) + gZlR*gZlRC*(gZuL*gZuLC*(3*(-4 + d)*mw^2*s*
                t - 3*(-4 + d)*s^2*t + mw^4*(8*s - 2*d*s + 8*t - 3*d*t)) + 
             gZuR*gZuRC*(-3*(-2 + d)*mw^2*s*t + 3*(-2 + d)*s^2*t + mw^4*
                (2*(-2 + d)*s + (-10 + 3*d)*t))))*GaugeXi[Q] - 
         2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZlLC*(-(gZuR*gZuRC*(5*(-4 + d)*s^2*t + 
                mw^4*(2*(-4 + d)*s + d*t) + mw^2*((-4 + d)^2*s^2 + 
                  (16 - 13*d + 2*d^2)*s*t - 4*t^2))) + gZuL*gZuLC*
              (5*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + (-6 + d)*t) + mw^2*
                ((8 - 6*d + d^2)*s^2 + (26 - 13*d + 2*d^2)*s*t + 4*t^2))) + 
           gZlR*gZlRC*(-(gZuL*gZuLC*(5*(-4 + d)*s^2*t + mw^4*(2*(-4 + d)*s + 
                  d*t) + mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 
                  4*t^2))) + gZuR*gZuRC*(5*(-2 + d)*s^2*t + mw^4*
                (2*(-2 + d)*s + (-6 + d)*t) + mw^2*((8 - 6*d + d^2)*s^2 + 
                 (26 - 13*d + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q]^2 + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZlLC*(gZuR*gZuRC*(-3*(-4 + d)*s^2*t + 
               mw^4*((-4 + d)*s + 2*t) + mw^2*(-2*(-4 + d)^2*s^2 + 
                 (-28 + 25*d - 4*d^2)*s*t + 8*t^2)) + gZuL*gZuLC*
              (3*(-2 + d)*s^2*t + mw^4*(-((-2 + d)*s) + 2*t) + mw^2*
                (2*(8 - 6*d + d^2)*s^2 + (50 - 25*d + 4*d^2)*s*t + 8*t^2))) + 
           gZlR*gZlRC*(gZuL*gZuLC*(-3*(-4 + d)*s^2*t + mw^4*((-4 + d)*s + 
                 2*t) + mw^2*(-2*(-4 + d)^2*s^2 + (-28 + 25*d - 4*d^2)*s*t + 
                 8*t^2)) + gZuR*gZuRC*(3*(-2 + d)*s^2*t + mw^4*
                (-((-2 + d)*s) + 2*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
                 (50 - 25*d + 4*d^2)*s*t + 8*t^2))))*GaugeXi[Q]^3 + 
         (2*Pi)^(3*d)*(gZlR*gZlRC*gZuL*gZuLC*(3*(-4 + d)*mw^4*t + 
             (-4 + d)*s^2*t + 2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*
                t - 4*t^2)) + gZlL*gZlLC*gZuR*gZuRC*(3*(-4 + d)*mw^4*t + 
             (-4 + d)*s^2*t + 2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*
                t - 4*t^2)) - gZlL*gZlLC*gZuL*gZuLC*(3*(-2 + d)*mw^4*t + 
             (-2 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 
                 2*d^2)*s*t + 4*t^2)) - gZlR*gZlRC*gZuR*gZuRC*
            (3*(-2 + d)*mw^4*t + (-2 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*
                s^2 + (26 - 13*d + 2*d^2)*s*t + 4*t^2)))*GaugeXi[Q]^4 + 
         2^(1 + 3*d)*mw^4*Pi^(3*d)*(gZlR*gZlRC*
            (gZuR*gZuRC*((-2 + d)*s + (-4 + d)*t) - gZuL*gZuLC*
              ((-4 + d)*s + (-2 + d)*t)) + gZlL*gZlLC*
            (gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t) - gZuR*gZuRC*
              ((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q]^5))/
       (mw^4*Pi^(4*d)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) - 
      (2^(1 - 4*d)*((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + (-4 + d)*gZuR*
              gZuRC) + gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - (-2 + d)*gZuR*
              gZuRC))*(2*Pi)^(3*d)*(mw^3 - mw*s)^2*t + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlR*gZlRC*(gZuR*gZuRC*(2*(-2 + d)*mw^2*s^2*t - (-2 + d)*s^3*t + 
               mw^6*((-2 + d)*s + (-4 + d)*t)) + gZuL*gZuLC*(-2*(-4 + d)*mw^2*
                s^2*t + (-4 + d)*s^3*t - mw^6*((-4 + d)*s + (-2 + d)*t))) + 
           gZlL*gZlLC*(gZuL*gZuLC*(2*(-2 + d)*mw^2*s^2*t - (-2 + d)*s^3*t + 
               mw^6*((-2 + d)*s + (-4 + d)*t)) + gZuR*gZuRC*(-2*(-4 + d)*mw^2*
                s^2*t + (-4 + d)*s^3*t - mw^6*((-4 + d)*s + (-2 + d)*t))))*
          GaugeXi[Q] + (2*Pi)^(3*d)*(gZlL*gZlLC*
            (-(gZuR*gZuRC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^3*t + 
                4*mw^4*s*((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*
                 ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
             gZuL*gZuLC*((-2 + d)*mw^6*t + 6*(-2 + d)*s^3*t + 4*mw^4*s*
                ((-2 + d)*s + (-4 + d)*t) + 4*mw^2*s*((-2 + d)^2*s^2 + 
                 (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + gZlR*gZlRC*
            (-(gZuL*gZuLC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^3*t + 
                4*mw^4*s*((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*
                 ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
             gZuR*gZuRC*((-2 + d)*mw^6*t + 6*(-2 + d)*s^3*t + 4*mw^4*s*
                ((-2 + d)*s + (-4 + d)*t) + 4*mw^2*s*((-2 + d)^2*s^2 + 
                 (18 - 11*d + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q]^2 - 
         2*(gZlL*gZlLC*(-(gZuR*gZuRC*(3*(-4 + d)*(2*Pi)^(3*d)*s^3*t + 
                2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-4 + d)*s + 2*(-3 + d)*t) + 
                2^(1 + 3*d)*mw^6*Pi^(3*d)*((-4 + d)*s + (-2 + d)*t) + 
                mw^2*(2*Pi)^(3*d)*s*((36 - 25*d + 4*d^2)*s^2 + 
                  (34 - 41*d + 8*d^2)*s*t - 16*t^2))) + gZuL*gZuLC*
              (3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
                ((-2 + d)*s + (-4 + d)*t) + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
                ((-2 + d)*s + 2*(-3 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
                ((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 8*d^2)*s*t + 
                 16*t^2))) + gZlR*gZlRC*(-(gZuL*gZuLC*(3*(-4 + d)*
                 (2*Pi)^(3*d)*s^3*t + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
                 ((-4 + d)*s + 2*(-3 + d)*t) + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
                 ((-4 + d)*s + (-2 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
                 ((36 - 25*d + 4*d^2)*s^2 + (34 - 41*d + 8*d^2)*s*t - 
                  16*t^2))) + gZuR*gZuRC*(3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 
               2^(1 + 3*d)*mw^6*Pi^(3*d)*((-2 + d)*s + (-4 + d)*t) + 
               2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-2 + d)*s + 2*(-3 + d)*t) + mw^2*
                (2*Pi)^(3*d)*s*((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 8*d^2)*
                  s*t + 16*t^2))))*GaugeXi[Q]^3 + (2*Pi)^(3*d)*
          (gZlL*gZlLC*(-(gZuR*gZuRC*((-4 + d)*mw^6*t + 2*(-4 + d)*s^3*t + 
                2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + mw^2*s*
                 (4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 
                  16*t^2))) + gZuL*gZuLC*((-2 + d)*mw^6*t + 2*(-2 + d)*s^3*
                t + 2*mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + mw^2*s*
                (4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 
                 16*t^2))) + gZlR*gZlRC*(-(gZuL*gZuLC*((-4 + d)*mw^6*t + 
                2*(-4 + d)*s^3*t + 2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + 
                mw^2*s*(4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 
                  16*t^2))) + gZuR*gZuRC*((-2 + d)*mw^6*t + 2*(-2 + d)*s^3*
                t + 2*mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + mw^2*s*
                (4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 16*t^2))))*
          GaugeXi[Q]^4 - 2^(1 + 3*d)*mw^2*Pi^(3*d)*(mw^4 + s^2)*
          (gZlR*gZlRC*(-(gZuR*gZuRC*((-2 + d)*s + (-4 + d)*t)) + 
             gZuL*gZuLC*((-4 + d)*s + (-2 + d)*t)) + gZlL*gZlLC*
            (-(gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t)) + gZuR*gZuRC*
              ((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q]^5 - 
         (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*mw^6*
          (2*Pi)^(3*d)*t*GaugeXi[Q]^6))/(mw^4*Pi^(4*d)*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2) + 
      (-(2^(2 + d)*Pi^d*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
             2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
           gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + 
             gZuR*gZuRC*(d*s + 2*t)))*(1 + GaugeXi[Q])) + 
        mw^2*(3*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
            gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))) - 
          2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*
                gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + 
            gZlL*gZlLC*(gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*(d*s + 
                2*t)))*GaugeXi[Q] + 
          (gZlL*gZlLC*(gZuL*gZuLC*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                 (-3*s + 2*d*s - t)) - gZuR*gZuRC*(d*(2^(2 + d)*Pi^d - 
                  3*(2*Pi)^d)*s + 2^(1 + d)*Pi^d*t)) - gZlR*gZlRC*
             (d*(gZuL*gZuLC - gZuR*gZuRC)*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*s + 
              2^(1 + d)*Pi^d*(gZuL*gZuLC*t + gZuR*gZuRC*(3*s + t))))*
           GaugeXi[Q]^2))/(2*Pi)^(2*d) + 
      (2^(2 + d)*Pi^d*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t)))*(1 + GaugeXi[Q]) + 
        mw^2*(-3*gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(
                2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + 
                t))) + 3*gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(s + t))) - 2^(1 + d)*Pi^d*
           (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*(
                (-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 
                2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q] + 
          (gZlL*gZlLC*(-3*d*gZuL*gZuLC*(2*Pi)^d*s + 3*d*gZuR*gZuRC*(2*Pi)^
                d*s + 2^(1 + d)*gZuL*gZuLC*Pi^d*((-1 + 2*d)*s - t) - 
              2^(1 + d)*gZuR*gZuRC*Pi^d*(2*(-1 + d)*s + t)) - 
            gZlR*gZlRC*(gZuL*gZuLC*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                 (2*(-1 + d)*s + t)) + gZuR*gZuRC*(3*d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(s - 2*d*s + t))))*GaugeXi[Q]^2))/
       (2*Pi)^(2*d) + 
      (s*((2^(1 - 2*d)*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                 t) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 (3*s + t))) + gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*t) + gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 
                2^(1 + d)*Pi^d*(3*s + t))))*(1 + GaugeXi[Q])^2)/Pi^(2*d) - 
         (s*(gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
            gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
            2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
                 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + 
              gZlL*gZlLC*(gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*
                 (d*s + 2*t)))*GaugeXi[Q]^2 + 
            (gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
                gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + 
              gZlR*gZlRC*(gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
                gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))))*
             GaugeXi[Q]^4))/(mw^2*(2*Pi)^(2*d)*(-1 + GaugeXi[Q])^2)))/
       GaugeXi[Q] - 
      (2*((2^(1 - d)*(mw^2 - s)*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
              2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
            gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 
                2*t)))*(1 + GaugeXi[Q]))/Pi^d + 
         (2^(2 + d)*Pi^d*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*
                gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
              (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t)))*
            (1 + GaugeXi[Q]) - mw^2*(3*(gZlL*gZlLC*(gZuR*gZuRC*
                  (d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZuL*gZuLC*
                  (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + gZlR*gZlRC*
                (gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZuR*gZuRC*
                  (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))) - 
             2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
                  2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + gZlL*gZlLC*
                (gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*(d*s + 2*t)))*
              GaugeXi[Q] + (gZlL*gZlLC*(gZuL*gZuLC*(-3*d*(2*Pi)^d*s + 
                   2^(1 + d)*Pi^d*(-3*s + 2*d*s - t)) - gZuR*gZuRC*
                  (d*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*s + 2^(1 + d)*Pi^d*t)) - 
               gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*(2^(2 + d)*Pi^d - 
                   3*(2*Pi)^d)*s + 2^(1 + d)*Pi^d*(gZuL*gZuLC*t + gZuR*gZuRC*
                    (3*s + t))))*GaugeXi[Q]^2))/(2*Pi)^(2*d)))/GaugeXi[Q] + 
      ((2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        ((3*2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
           mw^2*s)/Pi^d - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
           (gZuL*gZuLC + gZuR*gZuRC)*s^2)/Pi^d - 
         (3*mw^2*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
              2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + 
            gZlL*gZlLC*(gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 
                2*t))))/(2*Pi)^d + 
         (s*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + gZuL*gZuLC*(-4*s + 
                3*d*s + 6*t)) + gZlL*gZlLC*(gZuL*gZuLC*(14*s - 3*d*s + 6*t) + 
              gZuR*gZuRC*(-4*s + 3*d*s + 6*t))))/(2*Pi)^d + 
         (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*
           s*GaugeXi[Q])/Pi^d - 
         (mw^2*(gZlR*gZlRC*(gZuR*gZuRC*(14*s - 3*d*s + 6*t) + 
              gZuL*gZuLC*(-4*s + 3*d*s + 6*t)) + gZlL*gZlLC*
             (gZuL*gZuLC*(14*s - 3*d*s + 6*t) + gZuR*gZuRC*(-4*s + 3*d*s + 
                6*t)))*GaugeXi[Q])/(2*Pi)^d - (2^(1 - d)*(mw^2 - s)*
           (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
              2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
             (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t)))*
           (1 + GaugeXi[Q]))/Pi^d + (4^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
           (gZuL*gZuLC + gZuR*gZuRC)*s*(mw^2*(2^(1 + d)*Pi^d - 3*(2*Pi)^d) + 
            2^(1 + d)*Pi^d*s + 2^(1 + d)*Pi^d*s*GaugeXi[Q] + 
            mw^2*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*GaugeXi[Q]^2))/Pi^(2*d) + 
         (-(2^(2 + d)*Pi^d*s*(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
                2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*(
                gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t)))*
             (1 + GaugeXi[Q])) + mw^2*(3*(gZlL*gZlLC*(gZuR*gZuRC*
                  (d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZuL*gZuLC*
                  (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))) + gZlR*gZlRC*
                (gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZuR*gZuRC*
                  (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))) - 
             2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
                  2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))) + gZlL*gZlLC*
                (gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*(d*s + 2*t)))*
              GaugeXi[Q] + (gZlL*gZlLC*(gZuL*gZuLC*(-3*d*(2*Pi)^d*s + 
                   2^(1 + d)*Pi^d*(-3*s + 2*d*s - t)) - gZuR*gZuRC*
                  (d*(2^(2 + d)*Pi^d - 3*(2*Pi)^d)*s + 2^(1 + d)*Pi^d*t)) - 
               gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*(2^(2 + d)*Pi^d - 
                   3*(2*Pi)^d)*s + 2^(1 + d)*Pi^d*(gZuL*gZuLC*t + gZuR*gZuRC*
                    (3*s + t))))*GaugeXi[Q]^2))/(2*Pi)^(2*d)))/
       (d*mw^2*GaugeXi[Q]) + 
      (s*((2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
           (-mw^2 + s)*(1 + GaugeXi[Q]))/Pi^d - 
         (2^(2 + d)*Pi^d*s*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*
                gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*
                ((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
            (1 + GaugeXi[Q]) + mw^2*(-3*gZlR*gZlRC*(gZuL*gZuLC*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + gZuR*gZuRC*
                (d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))) + 3*gZlL*gZlLC*
              (gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*
                gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
             2^(1 + d)*Pi^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
                 gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
                (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
                   2*t)))*GaugeXi[Q] + (gZlL*gZlLC*(-3*d*gZuL*gZuLC*(2*Pi)^d*
                  s + 3*d*gZuR*gZuRC*(2*Pi)^d*s + 2^(1 + d)*gZuL*gZuLC*Pi^d*
                  ((-1 + 2*d)*s - t) - 2^(1 + d)*gZuR*gZuRC*Pi^d*
                  (2*(-1 + d)*s + t)) - gZlR*gZlRC*(gZuL*gZuLC*
                  (-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(-1 + d)*s + t)) + 
                 gZuR*gZuRC*(3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 2*d*s + 
                     t))))*GaugeXi[Q]^2))/(2*Pi)^(2*d)))/(mw^2*GaugeXi[Q])))/
    ((mz^2 - s)^2*(-mzC^2 + s)) - 
   (2*gAl*gWWA*gWWZ*((2^(1 - d)*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*(mw^2 - s + mw^2*GaugeXi[Q]))/(mw^4*Pi^d) + 
      (2^(1 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*
        (d*(-mw^2 + s) + (4 - 3*d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*Pi^d) - 
      (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        (4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/(d*Pi^d) - 
      (4^(1 - d)*(gZlRC*gZuL*gZuLC*(2*Pi)^d + gZlLC*gZuR*gZuRC*(2*Pi)^d + 
         gZlLC*gZuL*gZuLC*(3*2^(3 + d)*Pi^d - 23*(2*Pi)^d) + 
         gZlRC*gZuR*gZuRC*(3*2^(3 + d)*Pi^d - 23*(2*Pi)^d))*
        (4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/(d*Pi^(2*d)) + 
      ((-(gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZuL*gZuLC*
             ((-2 + d)*s + 2*t))) + gZlLC*(gZuL*gZuLC*((-4 + d)*s - 2*t) - 
           gZuR*gZuRC*((-2 + d)*s + 2*t)))*(-((mw^2 - s)*(d*s + 2*t)) + 
         mw^2*((4 - 3*d)*s + 2*t)*GaugeXi[Q]))/((-1 + d)*mw^4*(2*Pi)^d) - 
      (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
        (mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + mw^2*GaugeXi[Q]^2))/Pi^d + 
      (2^(2 - d)*(gZlLC*gZuL*gZuLC*((-4 + d)*s - 2*t) + 
         gZlRC*gZuR*gZuRC*((-4 + d)*s - 2*t) - gZlRC*gZuL*gZuLC*
          ((-2 + d)*s + 2*t) - gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*
        (2*t - d*mw^2*GaugeXi[Q])*(mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/(d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      (2^(1 - d)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*(2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        (2*mw^2 - s + (3*mw^2 + 2*s)*GaugeXi[Q] + mw^2*GaugeXi[Q]^2))/
       (d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      (2^(2 - d)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*((d*(mw^2 - s) - 4*s)*(mw^2 - s) + 
         2*mw^2*(4*s + d*(-mw^2 + s))*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/
       (d*mw^2*Pi^d*s*GaugeXi[Q]) + (2^(1 - d)*((-2 + d)*gZlLC*gZuL*gZuLC - 
         (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
         (-2 + d)*gZlRC*gZuR*gZuRC)*t*(-mw^2 + s + mw^2*GaugeXi[Q])*
        (d*(mw^2 - s)^2 + 2*mw^2*(6*s + d*(-mw^2 + s))*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2))/(d*mw^4*Pi^d*s*GaugeXi[Q]^2) + 
      (2^(2 - d)*(-(gZlLC*gZuL*gZuLC*((-4 + d)*s - 2*t)) + 
         gZlRC*gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*
          ((-2 + d)*s + 2*t) + gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*
        (2*(mw^2 - s)*t + mw^2*(4*s + d*(-mw^2 + s) - 2*t)*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2))/(d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      ((d*(mw^2 - s)^2 + 2*mw^2*(2*s + d*(-mw^2 + s))*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2)*(((-2 + d)*gZlLC*gZuL*gZuLC - 
           (-4 + d)*gZlRC*gZuL*gZuLC - (-4 + d)*gZlLC*gZuR*gZuRC + 
           (-2 + d)*gZlRC*gZuR*gZuRC)*(2*Pi)^(2*d)*(3*mw^2 - 2*s)*t + 
         2^(1 + 2*d)*Pi^(2*d)*(gZlRC*gZuL*gZuLC*(-((-4 + d)*s*t) + 
             mw^2*((-4 + d)*s + 2*t)) + gZlLC*gZuR*gZuRC*(-((-4 + d)*s*t) + 
             mw^2*((-4 + d)*s + 2*t)) + gZlLC*gZuL*gZuLC*((-2 + d)*s*t + 
             mw^2*(-((-2 + d)*s) + 2*t)) + gZlRC*gZuR*gZuRC*
            ((-2 + d)*s*t + mw^2*(-((-2 + d)*s) + 2*t)))*GaugeXi[Q] - 
         (-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*gZuLC + 
           (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*mw^2*
          (2*Pi)^(2*d)*t*GaugeXi[Q]^2))/(d*mw^4*(2*Pi)^(3*d)*s*
        GaugeXi[Q]^2) + ((d*(mw^2 - s)^2 + 2*mw^2*(2*s + d*(-mw^2 + s))*
          GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2)*
        ((gZlRC*gZuL*gZuLC*(3*mw^2*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
             2^(1 + d)*(-4 + d)*Pi^d*s) + gZlLC*gZuR*gZuRC*
            (3*mw^2*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*Pi^d*
              s) - gZlLC*gZuL*gZuLC*(3*mw^2*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
             2^(1 + d)*(-2 + d)*Pi^d*s) - gZlRC*gZuR*gZuRC*
            (3*mw^2*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-2 + d)*Pi^d*
              s))*t + 2*(-(gZlRC*gZuL*gZuLC*(mw^2*(-(d*(2*Pi)^d*s) + 
                2^(1 + d)*Pi^d*(2*s - t)) + (-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*
               s*t)) + gZlRC*gZuR*gZuRC*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*
              t + mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
           gZlLC*(-(gZuR*gZuRC*(mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                   (2*s - t)) + (-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)*s*t)) + 
             gZuL*gZuLC*((-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + mw^2*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*GaugeXi[Q] + 
         mw^2*(gZlRC*gZuL*gZuLC*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
           gZlLC*gZuR*gZuRC*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
           gZlLC*gZuL*gZuLC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d) + 
           gZlRC*gZuR*gZuRC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d))*t*
          GaugeXi[Q]^2))/(d*mw^4*(2*Pi)^(2*d)*s*GaugeXi[Q]^2) - 
      ((2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        (gZlRC*gZuL*gZuLC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
           2^(1 + d)*mw^2*Pi^d*((-4 + d)*s + 2*t)) + gZlLC*gZuR*gZuRC*
          (s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
           2^(1 + d)*mw^2*Pi^d*((-4 + d)*s + 2*t)) - gZlLC*gZuL*gZuLC*
          (2^(1 + d)*mw^2*Pi^d*((-2 + d)*s - 2*t) + 
           s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
         gZlRC*gZuR*gZuRC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s - 2*t) + 
           s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
         (-(gZlRC*(gZuL*gZuLC*(3*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                   (2*s - t)) - 2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
              gZuR*gZuRC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) - 
                3*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))) + 
           gZlLC*(gZuR*gZuRC*(mw^2*(3*d*(2*Pi)^d*s - 3*2^(1 + d)*Pi^d*
                  (2*s - t)) + 2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
             gZuL*gZuLC*(-(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t)) + 3*mw^2*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))*GaugeXi[Q] + 
         mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
           gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*
          GaugeXi[Q]^2))/(d*mw^2*(2*Pi)^(2*d)*s*GaugeXi[Q]) + 
      (2^(1 - d)*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
         gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t)))*(mw^4 - mw^2*s + (3*mw^4 - 2*s^2)*GaugeXi[Q] + 
         (3*mw^4 + mw^2*s + s^2)*GaugeXi[Q]^2 + mw^4*GaugeXi[Q]^3))/
       (mw^2*Pi^d*s*GaugeXi[Q]) + (2^(1 - 4*d)*(mw^2 - s - mw^2*GaugeXi[Q])*
        ((-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*gZuLC + 
           (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*
          (2*Pi)^(3*d)*(3*mw^4 - 4*mw^2*s + s^2)*t + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlRC*gZuL*gZuLC*(3*(-4 + d)*mw^2*s*t - 3*(-4 + d)*s^2*t + 
             mw^4*(-2*(-4 + d)*s + (8 - 3*d)*t)) + gZlLC*gZuR*gZuRC*
            (3*(-4 + d)*mw^2*s*t - 3*(-4 + d)*s^2*t + 
             mw^4*(-2*(-4 + d)*s + (8 - 3*d)*t)) + gZlLC*gZuL*gZuLC*
            (-3*(-2 + d)*mw^2*s*t + 3*(-2 + d)*s^2*t + 
             mw^4*(2*(-2 + d)*s + (-10 + 3*d)*t)) + gZlRC*gZuR*gZuRC*
            (-3*(-2 + d)*mw^2*s*t + 3*(-2 + d)*s^2*t + 
             mw^4*(2*(-2 + d)*s + (-10 + 3*d)*t)))*GaugeXi[Q] - 
         2^(1 + 3*d)*Pi^(3*d)*(-(gZlRC*gZuL*gZuLC*(5*(-4 + d)*s^2*t + 
              mw^4*(2*(-4 + d)*s + d*t) + mw^2*((-4 + d)^2*s^2 + 
                (16 - 13*d + 2*d^2)*s*t - 4*t^2))) - gZlLC*gZuR*gZuRC*
            (5*(-4 + d)*s^2*t + mw^4*(2*(-4 + d)*s + d*t) + 
             mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 4*t^2)) + 
           gZlLC*gZuL*gZuLC*(5*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + (-6 + d)*
                t) + mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 2*d^2)*s*t + 4*
                t^2)) + gZlRC*gZuR*gZuRC*(5*(-2 + d)*s^2*t + 
             mw^4*(2*(-2 + d)*s + (-6 + d)*t) + mw^2*((8 - 6*d + d^2)*s^2 + 
               (26 - 13*d + 2*d^2)*s*t + 4*t^2)))*GaugeXi[Q]^2 + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlRC*gZuL*gZuLC*(-3*(-4 + d)*s^2*t + 
             mw^4*((-4 + d)*s + 2*t) + mw^2*(-2*(-4 + d)^2*s^2 + 
               (-28 + 25*d - 4*d^2)*s*t + 8*t^2)) + gZlLC*gZuR*gZuRC*
            (-3*(-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*t) + 
             mw^2*(-2*(-4 + d)^2*s^2 + (-28 + 25*d - 4*d^2)*s*t + 8*t^2)) + 
           gZlLC*gZuL*gZuLC*(3*(-2 + d)*s^2*t + mw^4*(-((-2 + d)*s) + 2*t) + 
             mw^2*(2*(8 - 6*d + d^2)*s^2 + (50 - 25*d + 4*d^2)*s*t + 8*
                t^2)) + gZlRC*gZuR*gZuRC*(3*(-2 + d)*s^2*t + 
             mw^4*(-((-2 + d)*s) + 2*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
               (50 - 25*d + 4*d^2)*s*t + 8*t^2)))*GaugeXi[Q]^3 + 
         (2*Pi)^(3*d)*(gZlRC*gZuL*gZuLC*(3*(-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
             2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 4*t^2)) + 
           gZlLC*gZuR*gZuRC*(3*(-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
             2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 4*t^2)) - 
           gZlLC*gZuL*gZuLC*(3*(-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
             2*mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 2*d^2)*s*t + 4*
                t^2)) - gZlRC*gZuR*gZuRC*(3*(-2 + d)*mw^4*t + 
             (-2 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 
                 2*d^2)*s*t + 4*t^2)))*GaugeXi[Q]^4 + 2^(1 + 3*d)*mw^4*
          Pi^(3*d)*(gZlLC*gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t) + 
           gZlRC*gZuR*gZuRC*((-2 + d)*s + (-4 + d)*t) - gZlRC*gZuL*gZuLC*
            ((-4 + d)*s + (-2 + d)*t) - gZlLC*gZuR*gZuRC*((-4 + d)*s + 
             (-2 + d)*t))*GaugeXi[Q]^5))/(mw^4*Pi^(4*d)*s*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2) - (2^(1 - 4*d)*((-((-2 + d)*gZlLC*gZuL*gZuLC) + 
           (-4 + d)*gZlRC*gZuL*gZuLC + (-4 + d)*gZlLC*gZuR*gZuRC - 
           (-2 + d)*gZlRC*gZuR*gZuRC)*(2*Pi)^(3*d)*(mw^3 - mw*s)^2*t + 
         2^(1 + 3*d)*Pi^(3*d)*(gZlLC*gZuL*gZuLC*(2*(-2 + d)*mw^2*s^2*t - 
             (-2 + d)*s^3*t + mw^6*((-2 + d)*s + (-4 + d)*t)) + 
           gZlRC*gZuR*gZuRC*(2*(-2 + d)*mw^2*s^2*t - (-2 + d)*s^3*t + 
             mw^6*((-2 + d)*s + (-4 + d)*t)) + gZlRC*gZuL*gZuLC*
            (-2*(-4 + d)*mw^2*s^2*t + (-4 + d)*s^3*t - 
             mw^6*((-4 + d)*s + (-2 + d)*t)) + gZlLC*gZuR*gZuRC*
            (-2*(-4 + d)*mw^2*s^2*t + (-4 + d)*s^3*t - 
             mw^6*((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q] + 
         (2*Pi)^(3*d)*(-(gZlRC*gZuL*gZuLC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^
                3*t + 4*mw^4*s*((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*(
                (8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) - 
           gZlLC*gZuR*gZuRC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^3*t + 
             4*mw^4*s*((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*((8 - 6*d + d^2)*
                s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + gZlLC*gZuL*gZuLC*
            ((-2 + d)*mw^6*t + 6*(-2 + d)*s^3*t + 4*mw^4*s*((-2 + d)*s + 
               (-4 + d)*t) + 4*mw^2*s*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*
                t + 4*t^2)) + gZlRC*gZuR*gZuRC*((-2 + d)*mw^6*t + 
             6*(-2 + d)*s^3*t + 4*mw^4*s*((-2 + d)*s + (-4 + d)*t) + 
             4*mw^2*s*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)))*
          GaugeXi[Q]^2 - 2*(-(gZlRC*gZuL*gZuLC*(3*(-4 + d)*(2*Pi)^(3*d)*s^
                3*t + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-4 + d)*s + 2*(-3 + d)*
                 t) + 2^(1 + 3*d)*mw^6*Pi^(3*d)*((-4 + d)*s + (-2 + d)*t) + 
              mw^2*(2*Pi)^(3*d)*s*((36 - 25*d + 4*d^2)*s^2 + 
                (34 - 41*d + 8*d^2)*s*t - 16*t^2))) - gZlLC*gZuR*gZuRC*
            (3*(-4 + d)*(2*Pi)^(3*d)*s^3*t + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
              ((-4 + d)*s + 2*(-3 + d)*t) + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
              ((-4 + d)*s + (-2 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
              ((36 - 25*d + 4*d^2)*s^2 + (34 - 41*d + 8*d^2)*s*t - 16*t^2)) + 
           gZlLC*gZuL*gZuLC*(3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 
             2^(1 + 3*d)*mw^6*Pi^(3*d)*((-2 + d)*s + (-4 + d)*t) + 
             2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-2 + d)*s + 2*(-3 + d)*t) + 
             mw^2*(2*Pi)^(3*d)*s*((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 
                 8*d^2)*s*t + 16*t^2)) + gZlRC*gZuR*gZuRC*
            (3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
              ((-2 + d)*s + (-4 + d)*t) + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
              ((-2 + d)*s + 2*(-3 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
              ((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 8*d^2)*s*t + 16*t^2)))*
          GaugeXi[Q]^3 + (2*Pi)^(3*d)*(-(gZlRC*gZuL*gZuLC*((-4 + d)*mw^6*t + 
              2*(-4 + d)*s^3*t + 2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + 
              mw^2*s*(4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 
                16*t^2))) - gZlLC*gZuR*gZuRC*((-4 + d)*mw^6*t + 
             2*(-4 + d)*s^3*t + 2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + 
             mw^2*s*(4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 16*
                t^2)) + gZlLC*gZuL*gZuLC*((-2 + d)*mw^6*t + 
             2*(-2 + d)*s^3*t + 2*mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + 
             mw^2*s*(4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 16*
                t^2)) + gZlRC*gZuR*gZuRC*((-2 + d)*mw^6*t + 
             2*(-2 + d)*s^3*t + 2*mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + 
             mw^2*s*(4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 16*
                t^2)))*GaugeXi[Q]^4 - 2^(1 + 3*d)*mw^2*Pi^(3*d)*(mw^4 + s^2)*
          (-(gZlLC*gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t)) - 
           gZlRC*gZuR*gZuRC*((-2 + d)*s + (-4 + d)*t) + gZlRC*gZuL*gZuLC*
            ((-4 + d)*s + (-2 + d)*t) + gZlLC*gZuR*gZuRC*((-4 + d)*s + 
             (-2 + d)*t))*GaugeXi[Q]^5 + (-((-2 + d)*gZlLC*gZuL*gZuLC) + 
           (-4 + d)*gZlRC*gZuL*gZuLC + (-4 + d)*gZlLC*gZuR*gZuRC - 
           (-2 + d)*gZlRC*gZuR*gZuRC)*mw^6*(2*Pi)^(3*d)*t*GaugeXi[Q]^6))/
       (mw^4*Pi^(4*d)*s*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2) + 
      ((2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        ((3*2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s)/
          Pi^d - (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2)/
          Pi^d + (s*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
            gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
             ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t)))/
          (2*Pi)^d + (3*mw^2*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
            gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*
               s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t))))/(2*Pi)^d + 
         (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*
           GaugeXi[Q])/Pi^d - (mw^2*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
            gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
             ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
           GaugeXi[Q])/(2*Pi)^d + (2^(1 - d)*(mw^2 - s)*
           (gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
             (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
              2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(1 + GaugeXi[Q]))/
          Pi^d + (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
           (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d + 
         (2^(2 + d)*Pi^d*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
             gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                 gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
            (1 + GaugeXi[Q]) + mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
               2^(1 + d)*Pi^d*t) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*
                Pi^d*t) + gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (3*s + t)) + gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*
                Pi^d*(3*s + t)))*(3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/
          (2*Pi)^(2*d)))/(d*mw^2*s*GaugeXi[Q]) + 
      ((3*2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(4 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2)/Pi^d + (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*t*(-1 + GaugeXi[Q])^2)/Pi^d - 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*t*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*(s + t)*(-1 + GaugeXi[Q])^2)/
         Pi^d + (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*
          (s + t)*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (3*mw^4*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
            (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
             2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2)/
         (2*Pi)^d - (3*2^(1 - d)*mw^2*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 
             2*t) - gZlLC*gZuR*gZuRC*(d*s + 2*t) - 
           gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
             2*gZuR*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (3*s^2*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
            (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
             2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2)/
         (2*Pi)^d + (2^(4 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*
          s*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*t*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*(s + t)*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(1 - d)*mw^4*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d - 
        (mw^4*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-8 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d - (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*(mw^2 - s)*s*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d - (2^(2 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*(mw^2 - s)*s^2*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
          GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
           gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*
              s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(mw^2 - 2*s - 
           mw^2*GaugeXi[Q]))/Pi^d + (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d - 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^2*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
           mw^2*GaugeXi[Q]))/Pi^d + (2^(2 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*s*t*(-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*
          (-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d - 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*(s + t)*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
           mw^2*GaugeXi[Q]))/Pi^d + (2^(1 - d)*mw^2*
          (gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
            (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
             2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])*(-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d + 
        (s*(mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
             gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))*
            (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])^2 - 
           s*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
             gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
             gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
             2^(1 + d)*Pi^d*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*
                gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
                 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*GaugeXi[Q]^2 + 
             (gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZlLC*gZuR*
                gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + gZlLC*gZuL*gZuLC*
                (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + gZlRC*gZuR*
                gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))*
              GaugeXi[Q]^4)))/(2*Pi)^(2*d) - GaugeXi[Q]*(mw - mw*GaugeXi[Q])^
          2*((2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
            (1 + GaugeXi[Q])*(mw^2 - 2*s - mw^2*GaugeXi[Q]))/Pi^d - 
          (2^(2 + d)*Pi^d*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
              gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                  gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
             (1 + GaugeXi[Q]) + mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*t) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*t) + gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
                2^(1 + d)*Pi^d*(3*s + t)) + gZlRC*gZuR*gZuRC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))*
             (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)))/
       (s*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2) + 
      ((3*2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(4 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2)/Pi^d + 
        (3*mw^4*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
            (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 
             2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2)/
         (2*Pi)^d + (2^(4 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*
          s*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s^2*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(1 - d)*mw^4*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(2 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d - 
        (mw^4*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + gZlRC*gZuR*gZuRC*
            ((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*((-8 + 3*d)*s + 6*t) + 
           gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d + (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*(mw^2 - s)*s^2*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q]))/Pi^d - (2^(3 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*mw^2*(mw^2 - s)*s*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d - (2^(2 - d)*(gZlLC + gZlRC)*
          (gZuL*gZuLC + gZuR*gZuRC)*(2*mw^2 - s)*s^2*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((14 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((14 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-4 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-4 + 3*d)*s + 6*t))*
          (mw - mw*GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*s*(gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)/Pi^d + 
        (2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*mw^2*s*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
           mw^2*GaugeXi[Q]))/Pi^d - ((gZlLC*gZuL*gZuLC*((10 - 3*d)*s + 6*t) + 
           gZlRC*gZuR*gZuRC*((10 - 3*d)*s + 6*t) + gZlRC*gZuL*gZuLC*
            ((-8 + 3*d)*s + 6*t) + gZlLC*gZuR*gZuRC*((-8 + 3*d)*s + 6*t))*
          (s - s*GaugeXi[Q])^2)/(2*Pi)^d - 
        (2^(1 - 2*d)*s*(mw^2*(2*Pi)^d*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
             gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                 gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
            (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])^2 + 
           (s*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t) + 
              gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
              gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
              2^(1 + d)*Pi^d*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
                gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                    gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
               GaugeXi[Q]^2 + (gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*
                   Pi^d*t) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                   t) + gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                   (3*s + t)) + gZlRC*gZuR*gZuRC*(-(d*(2*Pi)^d*s) + 
                  2^(1 + d)*Pi^d*(3*s + t)))*GaugeXi[Q]^4))/2))/Pi^(2*d) - 
        s*(-1 + GaugeXi[Q])^2*((2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + 
             gZuR*gZuRC)*(mw^2 - s)*s*(1 + GaugeXi[Q]))/Pi^d + 
          (2^(2 + d)*Pi^d*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
                gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*
                 ((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
             (1 + GaugeXi[Q]) + mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuL*gZuLC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + gZlRC*gZuR*gZuRC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*
             (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)) + 
        GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2*
         ((2^(3 - d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*(mw^2 - s)*s*
            (1 + GaugeXi[Q]))/Pi^d + 
          (2^(2 + d)*Pi^d*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
                gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlRC*(gZuL*gZuLC*
                 ((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
             (1 + GaugeXi[Q]) + mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*(-2*s + t)) + gZlLC*gZuL*gZuLC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + gZlRC*gZuR*gZuRC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*
             (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)) + 
        2*(mw - mw*GaugeXi[Q])^2*((2^(1 - d)*(mw^2 - s)*
            (gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - gZlLC*gZuR*gZuRC*
              (d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*
                gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*(1 + GaugeXi[Q]))/Pi^d + 
          (2^(2 + d)*Pi^d*s*(gZlLC*gZuL*gZuLC*((-6 + d)*s - 2*t) - 
              gZlLC*gZuR*gZuRC*(d*s + 2*t) - gZlRC*(d*(gZuL*gZuLC - 
                  gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 2*gZuR*gZuRC*(3*s + t)))*
             (1 + GaugeXi[Q]) + mw^2*(gZlRC*gZuL*gZuLC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*t) + gZlLC*gZuR*gZuRC*(d*(2*Pi)^d*s + 
                2^(1 + d)*Pi^d*t) + gZlLC*gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
                2^(1 + d)*Pi^d*(3*s + t)) + gZlRC*gZuR*gZuRC*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)))*
             (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)))/
       (s*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)))/((mz^2 - s)*(-mzC^2 + s)) - 
   (2*gAu*gWWA*gWWZ*
     (-((2^(1 - d)*s*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + (-4 + d)*gZuRC*s + 
            2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*((-4 + d)*gZuLC*s - 
            (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
         (mw^2 - s + mw^2*GaugeXi[Q]))/(mw^4*Pi^d)) + 
      (2^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2*
        (d*(-mw^2 + s) + (4 - 3*d)*mw^2*GaugeXi[Q]))/((-1 + d)*mw^4*Pi^d) - 
      (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*
        (4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/(d*Pi^d) - 
      (4^(1 - d)*(gZlL*gZlLC*(5*2^(3 + d)*gZuLC*Pi^d - 2^(3 + d)*gZuRC*Pi^d - 
           39*gZuLC*(2*Pi)^d + 9*gZuRC*(2*Pi)^d) - gZlR*gZlRC*
          (2^(3 + d)*gZuLC*Pi^d - 5*2^(3 + d)*gZuRC*Pi^d - 9*gZuLC*(2*Pi)^d + 
           39*gZuRC*(2*Pi)^d))*(4*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q]))/
       (d*Pi^(2*d)) + ((gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        ((mw^2 - s)*(d*s + 2*t) + mw^2*((-4 + 3*d)*s - 2*t)*GaugeXi[Q]))/
       ((-1 + d)*mw^4*(2*Pi)^d) - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuLC + gZuRC)*(mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + mw^2*GaugeXi[Q]^2))/
       Pi^d + (2^(2 - d)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*
        (-2*t + d*mw^2*GaugeXi[Q])*(mw^2 + 2*(mw^2 + s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/(d*mw^2*Pi^d*s*GaugeXi[Q]) - 
      (2^(1 - d)*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*((-4 + d)*gZuLC*s - 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*(2*s + d*(-mw^2 + s) + 
         d*mw^2*GaugeXi[Q])*(2*mw^2 - s + (3*mw^2 + 2*s)*GaugeXi[Q] + 
         mw^2*GaugeXi[Q]^2))/(d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      (2^(2 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 
           2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*
        ((d*(mw^2 - s) - 4*s)*(mw^2 - s) + 2*mw^2*(4*s + d*(-mw^2 + s))*
          GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/(d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      (2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
         gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*t*
        (-mw^2 + s + mw^2*GaugeXi[Q])*(d*(mw^2 - s)^2 + 
         2*mw^2*(6*s + d*(-mw^2 + s))*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/
       (d*mw^4*Pi^d*s*GaugeXi[Q]^2) + 
      (2^(2 - d)*(gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*(2*(mw^2 - s)*t + 
         mw^2*(4*s + d*(-mw^2 + s) - 2*t)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2))/
       (d*mw^2*Pi^d*s*GaugeXi[Q]) + 
      ((d*(mw^2 - s)^2 + 2*mw^2*(2*s + d*(-mw^2 + s))*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2)*
        ((gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*(2*Pi)^(2*d)*
          (3*mw^2 - 2*s)*t + 2^(1 + 2*d)*Pi^(2*d)*
          (gZlL*gZlLC*((-2 + d)*gZuLC*s*t - (-4 + d)*gZuRC*s*t + 
             gZuRC*mw^2*((-4 + d)*s + 2*t) + gZuLC*mw^2*(-((-2 + d)*s) + 2*
                t)) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s*t) + (-2 + d)*gZuRC*s*
              t + gZuLC*mw^2*((-4 + d)*s + 2*t) + gZuRC*mw^2*
              (-((-2 + d)*s) + 2*t)))*GaugeXi[Q] + 
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*mw^2*(2*Pi)^(2*d)*
          t*GaugeXi[Q]^2))/(d*mw^4*(2*Pi)^(3*d)*s*GaugeXi[Q]^2) - 
      ((d*(mw^2 - s)^2 + 2*mw^2*(2*s + d*(-mw^2 + s))*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2)*
        ((gZlL*gZlLC*(3*gZuLC*mw^2*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
             gZuRC*mw^2*(-3*2^(2 + d)*Pi^d + 3*d*(2*Pi)^d) + 
             2^(1 + d)*(-2 + d)*gZuLC*Pi^d*s - 2^(1 + d)*(-4 + d)*gZuRC*Pi^d*
              s) - gZlR*gZlRC*(3*gZuLC*mw^2*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
             gZuRC*mw^2*(-3*2^(1 + d)*Pi^d + 3*d*(2*Pi)^d) + 
             2^(1 + d)*(-4 + d)*gZuLC*Pi^d*s - 2^(1 + d)*(-2 + d)*gZuRC*Pi^d*
              s))*t - 2*(gZlL*gZlLC*(gZuRC*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*
              t + gZuLC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
             gZuRC*mw^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
             gZuLC*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
           gZlR*gZlRC*(gZuLC*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
             gZuRC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)*s*t + 
             gZuLC*mw^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
             gZuRC*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
          GaugeXi[Q] + mw^2*(-(gZlR*gZlRC*(2^(2 + d)*gZuLC*Pi^d - 
              2^(1 + d)*gZuRC*Pi^d - d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d)) + 
           gZlL*gZlLC*(2^(1 + d)*gZuLC*Pi^d - 2^(2 + d)*gZuRC*Pi^d - 
             d*gZuLC*(2*Pi)^d + d*gZuRC*(2*Pi)^d))*t*GaugeXi[Q]^2))/
       (d*mw^4*(2*Pi)^(2*d)*s*GaugeXi[Q]^2) + 
      ((2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        (gZlR*gZlRC*(2^(1 + d)*gZuRC*mw^2*Pi^d*((-2 + d)*s - 2*t) - 
           2^(1 + d)*gZuLC*mw^2*Pi^d*((-4 + d)*s + 2*t) + 
           gZuLC*s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZuRC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) + 
         gZlL*gZlLC*(-(gZuRC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 (2*s - t)) + 2^(1 + d)*mw^2*Pi^d*((-4 + d)*s + 2*t))) + 
           gZuLC*(2^(1 + d)*mw^2*Pi^d*((-2 + d)*s - 2*t) + 
             s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) + 
         (-(gZlL*gZlLC*(gZuRC*mw^2*(3*d*(2*Pi)^d*s - 3*2^(1 + d)*Pi^d*
                 (2*s - t)) - 2^(1 + d)*gZuLC*Pi^d*s*((-2 + d)*s - 2*t) + 
              2^(1 + d)*gZuRC*Pi^d*s*((-4 + d)*s + 2*t) + 3*gZuLC*mw^2*(
                -(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) + 
           gZlR*gZlRC*(2^(1 + d)*gZuRC*Pi^d*s*((-2 + d)*s - 2*t) - 
             3*gZuRC*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
             gZuLC*(3*mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) - 
               2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t))))*GaugeXi[Q] - 
         mw^2*(gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
             2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*
              (s + t)) + gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*
              s + 2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*
              (s + t)))*GaugeXi[Q]^2))/(d*mw^2*(2*Pi)^(2*d)*s*GaugeXi[Q]) - 
      (2^(1 - d)*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + (-4 + d)*gZuRC*s + 
           2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*((-4 + d)*gZuLC*s - 
           (-2 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t))*(mw^4 - mw^2*s + 
         (3*mw^4 - 2*s^2)*GaugeXi[Q] + (3*mw^4 + mw^2*s + s^2)*GaugeXi[Q]^2 + 
         mw^4*GaugeXi[Q]^3))/(mw^2*Pi^d*s*GaugeXi[Q]) + 
      (2^(1 - 4*d)*(mw^2 - s - mw^2*GaugeXi[Q])*
        ((gZlL*gZlLC*(-((-2 + d)*gZuLC) + (-4 + d)*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuLC - (-2 + d)*gZuRC))*(2*Pi)^(3*d)*
          (3*mw^4 - 4*mw^2*s + s^2)*t + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlL*gZlLC*(gZuRC*(3*(-4 + d)*mw^2*s*t - 3*(-4 + d)*s^2*t + mw^4*
                (8*s - 2*d*s + 8*t - 3*d*t)) + gZuLC*(-3*(-2 + d)*mw^2*s*t + 
               3*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + (-10 + 3*d)*t))) + 
           gZlR*gZlRC*(gZuLC*(3*(-4 + d)*mw^2*s*t - 3*(-4 + d)*s^2*t + mw^4*
                (8*s - 2*d*s + 8*t - 3*d*t)) + gZuRC*(-3*(-2 + d)*mw^2*s*t + 
               3*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + (-10 + 3*d)*t))))*
          GaugeXi[Q] - 2^(1 + 3*d)*Pi^(3*d)*
          (gZlL*gZlLC*(-(gZuRC*(5*(-4 + d)*s^2*t + mw^4*(2*(-4 + d)*s + 
                  d*t) + mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 
                  4*t^2))) + gZuLC*(5*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + 
                 (-6 + d)*t) + mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 
                   2*d^2)*s*t + 4*t^2))) + gZlR*gZlRC*
            (-(gZuLC*(5*(-4 + d)*s^2*t + mw^4*(2*(-4 + d)*s + d*t) + 
                mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*t - 4*t^2))) + 
             gZuRC*(5*(-2 + d)*s^2*t + mw^4*(2*(-2 + d)*s + (-6 + d)*t) + 
               mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 2*d^2)*s*t + 
                 4*t^2))))*GaugeXi[Q]^2 + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlL*gZlLC*(gZuRC*(-3*(-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*t) + 
               mw^2*(-2*(-4 + d)^2*s^2 + (-28 + 25*d - 4*d^2)*s*t + 8*t^2)) + 
             gZuLC*(3*(-2 + d)*s^2*t + mw^4*(-((-2 + d)*s) + 2*t) + mw^2*
                (2*(8 - 6*d + d^2)*s^2 + (50 - 25*d + 4*d^2)*s*t + 8*t^2))) + 
           gZlR*gZlRC*(gZuLC*(-3*(-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*t) + 
               mw^2*(-2*(-4 + d)^2*s^2 + (-28 + 25*d - 4*d^2)*s*t + 8*t^2)) + 
             gZuRC*(3*(-2 + d)*s^2*t + mw^4*(-((-2 + d)*s) + 2*t) + mw^2*
                (2*(8 - 6*d + d^2)*s^2 + (50 - 25*d + 4*d^2)*s*t + 8*t^2))))*
          GaugeXi[Q]^3 + (2*Pi)^(3*d)*(gZlR*gZlRC*gZuLC*(3*(-4 + d)*mw^4*t + 
             (-4 + d)*s^2*t + 2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*
                t - 4*t^2)) + gZlL*gZlLC*gZuRC*(3*(-4 + d)*mw^4*t + 
             (-4 + d)*s^2*t + 2*mw^2*((-4 + d)^2*s^2 + (16 - 13*d + 2*d^2)*s*
                t - 4*t^2)) - gZlL*gZlLC*gZuLC*(3*(-2 + d)*mw^4*t + 
             (-2 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 
                 2*d^2)*s*t + 4*t^2)) - gZlR*gZlRC*gZuRC*(3*(-2 + d)*mw^4*t + 
             (-2 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (26 - 13*d + 
                 2*d^2)*s*t + 4*t^2)))*GaugeXi[Q]^4 + 2^(1 + 3*d)*mw^4*
          Pi^(3*d)*(gZlR*gZlRC*(gZuRC*((-2 + d)*s + (-4 + d)*t) - 
             gZuLC*((-4 + d)*s + (-2 + d)*t)) + gZlL*gZlLC*
            (gZuLC*((-2 + d)*s + (-4 + d)*t) - gZuRC*((-4 + d)*s + (-2 + d)*
                t)))*GaugeXi[Q]^5))/(mw^4*Pi^(4*d)*s*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2) - (2^(1 - 4*d)*
        ((gZlL*gZlLC*(-((-2 + d)*gZuLC) + (-4 + d)*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuLC - (-2 + d)*gZuRC))*(2*Pi)^(3*d)*
          (mw^3 - mw*s)^2*t + 2^(1 + 3*d)*Pi^(3*d)*
          (gZlR*gZlRC*(gZuRC*(2*(-2 + d)*mw^2*s^2*t - (-2 + d)*s^3*t + mw^6*
                ((-2 + d)*s + (-4 + d)*t)) + gZuLC*(-2*(-4 + d)*mw^2*s^2*t + 
               (-4 + d)*s^3*t - mw^6*((-4 + d)*s + (-2 + d)*t))) + 
           gZlL*gZlLC*(gZuLC*(2*(-2 + d)*mw^2*s^2*t - (-2 + d)*s^3*t + mw^6*
                ((-2 + d)*s + (-4 + d)*t)) + gZuRC*(-2*(-4 + d)*mw^2*s^2*t + 
               (-4 + d)*s^3*t - mw^6*((-4 + d)*s + (-2 + d)*t))))*
          GaugeXi[Q] + (2*Pi)^(3*d)*(gZlL*gZlLC*
            (-(gZuRC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^3*t + 4*mw^4*s*
                 ((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*((8 - 6*d + d^2)*s^2 + 
                  (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
             gZuLC*((-2 + d)*mw^6*t + 6*(-2 + d)*s^3*t + 4*mw^4*s*
                ((-2 + d)*s + (-4 + d)*t) + 4*mw^2*s*((-2 + d)^2*s^2 + 
                 (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + gZlR*gZlRC*
            (-(gZuLC*((-4 + d)*mw^6*t + 6*(-4 + d)*s^3*t + 4*mw^4*s*
                 ((-4 + d)*s + (-2 + d)*t) + 4*mw^2*s*((8 - 6*d + d^2)*s^2 + 
                  (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
             gZuRC*((-2 + d)*mw^6*t + 6*(-2 + d)*s^3*t + 4*mw^4*s*
                ((-2 + d)*s + (-4 + d)*t) + 4*mw^2*s*((-2 + d)^2*s^2 + 
                 (18 - 11*d + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q]^2 - 
         2*(gZlL*gZlLC*(-(gZuRC*(3*(-4 + d)*(2*Pi)^(3*d)*s^3*t + 
                2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-4 + d)*s + 2*(-3 + d)*t) + 
                2^(1 + 3*d)*mw^6*Pi^(3*d)*((-4 + d)*s + (-2 + d)*t) + 
                mw^2*(2*Pi)^(3*d)*s*((36 - 25*d + 4*d^2)*s^2 + 
                  (34 - 41*d + 8*d^2)*s*t - 16*t^2))) + 
             gZuLC*(3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
                ((-2 + d)*s + (-4 + d)*t) + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
                ((-2 + d)*s + 2*(-3 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
                ((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 8*d^2)*s*t + 
                 16*t^2))) + gZlR*gZlRC*(-(gZuLC*(3*(-4 + d)*(2*Pi)^(3*d)*s^3*
                 t + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*((-4 + d)*s + 2*(-3 + d)*
                   t) + 2^(1 + 3*d)*mw^6*Pi^(3*d)*((-4 + d)*s + (-2 + d)*t) + 
                mw^2*(2*Pi)^(3*d)*s*((36 - 25*d + 4*d^2)*s^2 + 
                  (34 - 41*d + 8*d^2)*s*t - 16*t^2))) + 
             gZuRC*(3*(-2 + d)*(2*Pi)^(3*d)*s^3*t + 2^(1 + 3*d)*mw^6*Pi^(3*d)*
                ((-2 + d)*s + (-4 + d)*t) + 2^(2 + 3*d)*mw^4*Pi^(3*d)*s*
                ((-2 + d)*s + 2*(-3 + d)*t) + mw^2*(2*Pi)^(3*d)*s*
                ((18 - 17*d + 4*d^2)*s^2 + (68 - 41*d + 8*d^2)*s*t + 
                 16*t^2))))*GaugeXi[Q]^3 + (2*Pi)^(3*d)*
          (gZlL*gZlLC*(-(gZuRC*((-4 + d)*mw^6*t + 2*(-4 + d)*s^3*t + 
                2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + mw^2*s*
                 (4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 
                  16*t^2))) + gZuLC*((-2 + d)*mw^6*t + 2*(-2 + d)*s^3*t + 2*
                mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + mw^2*s*
                (4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 
                 16*t^2))) + gZlR*gZlRC*(-(gZuLC*((-4 + d)*mw^6*t + 
                2*(-4 + d)*s^3*t + 2*mw^4*s*(2*(-4 + d)*s + (-16 + 5*d)*t) + 
                mw^2*s*(4*(12 - 7*d + d^2)*s^2 + (36 - 43*d + 8*d^2)*s*t - 
                  16*t^2))) + gZuRC*((-2 + d)*mw^6*t + 2*(-2 + d)*s^3*t + 2*
                mw^4*s*(2*(-2 + d)*s + (-14 + 5*d)*t) + mw^2*s*
                (4*(6 - 5*d + d^2)*s^2 + (78 - 43*d + 8*d^2)*s*t + 16*t^2))))*
          GaugeXi[Q]^4 - 2^(1 + 3*d)*mw^2*Pi^(3*d)*(mw^4 + s^2)*
          (gZlR*gZlRC*(-(gZuRC*((-2 + d)*s + (-4 + d)*t)) + 
             gZuLC*((-4 + d)*s + (-2 + d)*t)) + gZlL*gZlLC*
            (-(gZuLC*((-2 + d)*s + (-4 + d)*t)) + gZuRC*((-4 + d)*s + 
               (-2 + d)*t)))*GaugeXi[Q]^5 - 
         (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*mw^6*(2*Pi)^(3*d)*
          t*GaugeXi[Q]^6))/(mw^4*Pi^(4*d)*s*(-1 + GaugeXi[Q])^2*
        GaugeXi[Q]^2) + ((2*s + d*(-mw^2 + s) + d*mw^2*GaugeXi[Q])*
        ((3*2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s)/
          Pi^d - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2)/
          Pi^d - (s*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*s - 
              6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((4 - 3*d)*gZuLC*s + 
              (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)))/(2*Pi)^d - 
         (3*mw^2*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 2*gZuLC*t + 
              2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
              2*gZuRC*(3*s + t))))/(2*Pi)^d + 
         (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s*
           GaugeXi[Q])/Pi^d + (mw^2*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + 
              (4 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t) + 
            gZlR*gZlRC*((4 - 3*d)*gZuLC*s + (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 
              6*gZuRC*t))*GaugeXi[Q])/(2*Pi)^d - 
         (2^(1 - d)*(mw^2 - s)*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + 
              d*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*
             (d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 2*gZuRC*(3*s + t)))*
           (1 + GaugeXi[Q]))/Pi^d + (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
           (gZuLC + gZuRC)*s*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
            mw^2*GaugeXi[Q]))/Pi^d + 
         (-(2^(2 + d)*Pi^d*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
                2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
                2*gZuLC*t + 2*gZuRC*(3*s + t)))*(1 + GaugeXi[Q])) + 
           mw^2*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
             gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
            (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)))/
       (d*mw^2*s*GaugeXi[Q]) + 
      ((3*2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(1 - d)*gZlL*gZlLC*mw^2*s*
          ((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)*
          (-1 + GaugeXi[Q])^2)/Pi^d + (gZlL*gZlLC*s^2*((-10 + 3*d)*gZuLC*s + 
           (8 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)*(-1 + GaugeXi[Q])^2)/
         (2*Pi)^d - (gZlR*gZlRC*s^2*((-8 + 3*d)*gZuLC*s + (10 - 3*d)*gZuRC*
            s + 6*gZuLC*t + 6*gZuRC*t)*(-1 + GaugeXi[Q])^2)/(2*Pi)^d + 
        (2^(1 - d)*gZlR*gZlRC*mw^2*s*((-4 + 3*d)*gZuLC*s + 
           (14 - 3*d)*gZuRC*s + 6*gZuLC*t + 6*gZuRC*t)*(-1 + GaugeXi[Q])^2)/
         Pi^d - (3*gZlR*gZlRC*mw^4*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
           2*gZuRC*(3*s + t))*(-1 + GaugeXi[Q])^2)/(2*Pi)^d + 
        (3*gZlL*gZlLC*mw^4*((-6 + d)*gZuLC*s - 2*gZuLC*t - gZuRC*(d*s + 2*t))*
          (-1 + GaugeXi[Q])^2)/(2*Pi)^d + 
        (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s^2*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(1 - d)*gZlL*gZlLC*mw^4*((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(1 - d)*gZlL*gZlLC*mw^2*s*((-10 + 3*d)*gZuLC*s + 
           (8 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t)*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q])/Pi^d + (2^(1 - d)*gZlR*gZlRC*mw^2*s*
          ((-8 + 3*d)*gZuLC*s + (10 - 3*d)*gZuRC*s + 6*gZuLC*t + 6*gZuRC*t)*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(1 - d)*gZlR*gZlRC*mw^4*((-4 + 3*d)*gZuLC*s + (14 - 3*d)*gZuRC*s + 
           6*gZuLC*t + 6*gZuRC*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d + 
        (gZlL*gZlLC*mw^4*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 
           6*gZuLC*t - 6*gZuRC*t)*(-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/
         (2*Pi)^d - (gZlR*gZlRC*mw^4*((-8 + 3*d)*gZuLC*s + 
           (10 - 3*d)*gZuRC*s + 6*gZuLC*t + 6*gZuRC*t)*(-1 + GaugeXi[Q])^2*
          GaugeXi[Q]^2)/(2*Pi)^d - (2^(2 - d)*mw^2*(mw^2 - s)*
          (gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 2*gZuLC*t + 
             2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
             2*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q]))/Pi^d - 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(2*mw^2 - s)*s^2*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(1 - d)*mw^2*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
             2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
             2*gZuLC*t + 2*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])^2)/Pi^d + (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*mw^2*s*(-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*
          (-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d - 
        (s^2*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
              (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
           gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
              (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
           2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
                2*gZuRC*(3*s + t))) + gZlL*gZlLC*((-6 + d)*gZuLC*s - 2*gZuLC*
                t - gZuRC*(d*s + 2*t)))*GaugeXi[Q]^2 + 
           (gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
             gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
            GaugeXi[Q]^4))/(2*Pi)^(2*d) - (s*(-1 + GaugeXi[Q])^2*
          (2^(2 + d)*Pi^d*s*(gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*
                s - 2*gZuLC*t - 2*gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*
                 s) + (-2 + d)*gZuRC*s - 2*gZuLC*t - 2*gZuRC*t))*
            (1 + GaugeXi[Q]) + mw^2*(gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*
                gZuRC*(2*Pi)^d*s + 2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 
               2^(1 + d)*gZuLC*Pi^d*(s + t)) + gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*
                s - d*gZuRC*(2*Pi)^d*s + 2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 
               2^(1 + d)*gZuRC*Pi^d*(s + t)))*(3 + 2*GaugeXi[Q] - 
             GaugeXi[Q]^2)))/(2*Pi)^(2*d) + 
        (GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2*(2^(2 + d)*Pi^d*s*
            (gZlL*gZlLC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s - 2*gZuLC*t - 2*
                gZuRC*t) + gZlR*gZlRC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*
                s - 2*gZuLC*t - 2*gZuRC*t))*(1 + GaugeXi[Q]) + 
           mw^2*(gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
               2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*
                (s + t)) + gZlR*gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*
                s + 2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*
                (s + t)))*(3 + 2*GaugeXi[Q] - GaugeXi[Q]^2)))/(2*Pi)^(2*d) + 
        (2^(1 - 2*d)*(mw - mw*GaugeXi[Q])^2*
          (-(2^(2 + d)*Pi^d*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + 
                d*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(
                d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 2*gZuRC*(3*s + t)))*
             (1 + GaugeXi[Q])) + mw^2*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 
               2^(1 + d)*gZuRC*Pi^d*(3*s + t) + gZuLC*(d*(2*Pi)^d*s + 
                 2^(1 + d)*Pi^d*t)) + gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 
               2^(1 + d)*gZuLC*Pi^d*(3*s + t) + gZuRC*(d*(2*Pi)^d*s + 
                 2^(1 + d)*Pi^d*t)))*(3 + 2*GaugeXi[Q] - GaugeXi[Q]^2)))/
         Pi^(2*d))/(s*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2) + 
      ((3*2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*mw^2*s^2*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^3*
          (-1 + GaugeXi[Q])^2)/Pi^d + (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*mw^2*s*t*(-1 + GaugeXi[Q])^2)/Pi^d - 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2*t*
          (-1 + GaugeXi[Q])^2)/Pi^d - (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*mw^2*s*(s + t)*(-1 + GaugeXi[Q])^2)/Pi^d + 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s^2*(s + t)*
          (-1 + GaugeXi[Q])^2)/Pi^d - 
        (3*mw^4*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 2*gZuLC*t + 
             2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
             2*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2)/(2*Pi)^d + 
        (2^(4 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s^2*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s*t*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s*(s + t)*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(1 - d)*mw^4*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + (4 - 3*d)*gZuRC*
              s - 6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((4 - 3*d)*gZuLC*s + 
             (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d - 
        (2^(1 - d)*mw^2*s*(gZlL*gZlLC*((-14 + 3*d)*gZuLC*s + 
             (4 - 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t) + 
           gZlR*gZlRC*((4 - 3*d)*gZuLC*s + (-14 + 3*d)*gZuRC*s - 6*gZuLC*t - 
             6*gZuRC*t))*(-1 + GaugeXi[Q])^2*GaugeXi[Q])/Pi^d + 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^4*s*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/Pi^d + 
        (mw^4*(gZlL*gZlLC*((-10 + 3*d)*gZuLC*s + (8 - 3*d)*gZuRC*s - 
             6*gZuLC*t - 6*gZuRC*t) + gZlR*gZlRC*((8 - 3*d)*gZuLC*s + 
             (-10 + 3*d)*gZuRC*s - 6*gZuLC*t - 6*gZuRC*t))*
          (-1 + GaugeXi[Q])^2*GaugeXi[Q]^2)/(2*Pi)^d - 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*(mw^2 - s)*
          s*(-1 + GaugeXi[Q])^2*GaugeXi[Q]*(1 + GaugeXi[Q]))/Pi^d - 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*(mw^2 - s)*s^2*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])^2)/Pi^d + 
        (3*2^(1 - d)*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
             2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
             2*gZuLC*t + 2*gZuRC*(3*s + t)))*(mw - mw*GaugeXi[Q])^2)/Pi^d - 
        (2^(1 - d)*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
             2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
             2*gZuLC*t + 2*gZuRC*(3*s + t)))*(-1 + GaugeXi[Q])^2*
          (1 + GaugeXi[Q])*(mw^2 - 2*s - mw^2*GaugeXi[Q]))/Pi^d + 
        (2^(1 - d)*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
             2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
             2*gZuLC*t + 2*gZuRC*(3*s + t)))*(1 + GaugeXi[Q])*
          (mw - mw*GaugeXi[Q])^2*(mw^2 - 2*s - mw^2*GaugeXi[Q]))/Pi^d + 
        (2^(3 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*mw^2*s*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
           mw^2*GaugeXi[Q]))/Pi^d - (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*s^2*(-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*
          (-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d + 
        (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s*t*
          (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*(-mw^2 + 2*s + 
           mw^2*GaugeXi[Q]))/Pi^d - (2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
          (gZuLC + gZuRC)*s*(s + t)*(-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])*
          (-mw^2 + 2*s + mw^2*GaugeXi[Q]))/Pi^d - 
        (3*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 2*gZuLC*t + 
             2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
             2*gZuRC*(3*s + t)))*(s - s*GaugeXi[Q])^2)/(2*Pi)^d + 
        (s*(mw^2*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
             gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
            (-1 + GaugeXi[Q])^2*(1 + GaugeXi[Q])^2 - 
           s*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
             gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
             2^(1 + d)*Pi^d*(-(gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 2*gZuLC*t + 
                  2*gZuRC*(3*s + t))) + gZlL*gZlLC*((-6 + d)*gZuLC*s - 
                 2*gZuLC*t - gZuRC*(d*s + 2*t)))*GaugeXi[Q]^2 + 
             (gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                  (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + gZlL*
                gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                  (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
              GaugeXi[Q]^4)))/(2*Pi)^(2*d) - GaugeXi[Q]*(mw - mw*GaugeXi[Q])^
          2*((2^(2 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*s*
            (1 + GaugeXi[Q])*(mw^2 - 2*s - mw^2*GaugeXi[Q]))/Pi^d + 
          (2^(2 + d)*Pi^d*s*(gZlL*gZlLC*(6*gZuLC*s - d*gZuLC*s + d*gZuRC*s + 
                2*gZuLC*t + 2*gZuRC*t) + gZlR*gZlRC*(d*(gZuLC - gZuRC)*s + 
                2*gZuLC*t + 2*gZuRC*(3*s + t)))*(1 + GaugeXi[Q]) - 
            mw^2*(gZlR*gZlRC*(-(d*gZuRC*(2*Pi)^d*s) + 2^(1 + d)*gZuRC*Pi^d*
                 (3*s + t) + gZuLC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)) + 
              gZlL*gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + 2^(1 + d)*gZuLC*Pi^d*
                 (3*s + t) + gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*t)))*
             (3 + 2*GaugeXi[Q] - GaugeXi[Q]^2))/(2*Pi)^(2*d)))/
       (s*GaugeXi[Q]*(mw - mw*GaugeXi[Q])^2)))/((mz^2 - s)*(-mzC^2 + s))), 
 (I*EL^6*(2^(1 + 3*d)*gAu*gWlN*gWNl*gWWA*gZlLC*Pi^(3*d)*(mz^2 - s)^2*sw^2*
     (gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (-1 + GaugeXi[Q])^2*(mw^4 + 2*(-3 + 2*d)*mw^2*s + s^2 - 
      2*mw^2*(mw^2 + s)*GaugeXi[Q] + mw^4*GaugeXi[Q]^2) + 
    2^(1 + 3*d)*gWlN*gWNl*gWWZ*gZlLC*Pi^(3*d)*(mz^2 - s)*s*
     (gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))*
     (sw - sw*GaugeXi[Q])^2*(mw^4 + 2*(-3 + 2*d)*mw^2*s + s^2 - 
      2*mw^2*(mw^2 + s)*GaugeXi[Q] + mw^4*GaugeXi[Q]^2) - 
    2^(1 + d)*gFZW^2*mw^2*Pi^d*(-1 + GaugeXi[Q])^2*
     ((1 - d)*(2*Pi)^(2*d)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-4 + d)*s + 2*t) + 
          gZuL*gZuLC*(-((-2 + d)*s) + 2*t)) + gZlR*gZlRC*
         (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
       (mw^2 - s + mw^2*GaugeXi[Q])^2 - (1 - d)*(2*Pi)^d*s*
       (gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
          gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t))) - 
        gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))))*
       (mw^2 - s + mw^2*GaugeXi[Q])^2 - 2^(1 + 2*d)*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL*gZuLC + gZuR*gZuRC)*Pi^(2*d)*s^2*(d*(mw^2 - s)^2 + 
        2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) + 
      2*(1 - d)*s*((2*Pi)^(2*d)*(gZlR*gZlRC*gZuL*gZuLC*((-4 + d)*mw^4*t + 
            (-4 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 
                2*d^2)*s*t - 4*t^2)) + gZlL*gZlLC*gZuR*gZuRC*
           ((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + 
              (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - gZlL*gZlLC*gZuL*gZuLC*
           ((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*s^2 + 
              (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - gZlR*gZlRC*gZuR*gZuRC*
           ((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*s^2 + 
              (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 2^(1 + 2*d)*mw^2*Pi^(2*d)*
         (gZlR*gZlRC*(gZuR*gZuRC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 
                (-4 + d)*t)) - gZuL*gZuLC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 
                (-2 + d)*t))) + gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s*t + 
              mw^2*((-2 + d)*s + (-4 + d)*t)) - gZuR*gZuRC*((-4 + d)*s*t + 
              mw^2*((-4 + d)*s + (-2 + d)*t))))*GaugeXi[Q] - 
        (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*mw^4*
         (2*Pi)^(2*d)*t*GaugeXi[Q]^2) - 
      (2*Pi)^d*(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
             (2*s + t))) - gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
            2^(1 + d)*Pi^d*(-s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
            2^(1 + d)*Pi^d*(2*s + t))))*((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2)) - gAl*gAu*gWWA^2*(mz^2 - s)^2*sw^2*
     ((1 - d)*(2*Pi)^(3*d)*s*((-2 + d)*gZlLC*gZuLC*s - (-4 + d)*gZlRC*gZuLC*
         s - (-4 + d)*gZlLC*gZuRC*s + (-2 + d)*gZlRC*gZuRC*s - 
        2*gZlLC*gZuLC*t - 2*gZlRC*gZuLC*t - 2*gZlLC*gZuRC*t - 
        2*gZlRC*gZuRC*t)*(-1 + GaugeXi[Q])^2*(mw^2 - s + mw^2*GaugeXi[Q])^2 + 
      2^(1 + 3*d)*(1 - d)*Pi^(3*d)*s*(gZlLC*gZuLC*((-2 + d)*s - 2*t) + 
        gZlRC*gZuRC*((-2 + d)*s - 2*t) - gZlRC*gZuLC*((-4 + d)*s + 2*t) - 
        gZlLC*gZuRC*((-4 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*
       (mw^2 - s + mw^2*GaugeXi[Q])^2 + (1 - d)*(2*Pi)^(2*d)*s*
       (-1 + GaugeXi[Q])^2*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlRC*gZuLC*(mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (2*(1 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (-2*s + t))) + gZlLC*gZuRC*
         (mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(1 + d)*s - t)) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) - 
        gZlLC*gZuLC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
          mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))) - 
        gZlRC*gZuRC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
          mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))) - 
        mw^2*(gZlLC*(-(d*gZuLC*(2*Pi)^d*s) + d*gZuRC*(2*Pi)^d*s + 
            2^(1 + d)*gZuRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuLC*Pi^d*(s + t)) + 
          gZlRC*(d*gZuLC*(2*Pi)^d*s - d*gZuRC*(2*Pi)^d*s + 
            2^(1 + d)*gZuLC*Pi^d*(-2*s + t) + 2^(1 + d)*gZuRC*Pi^d*(s + t)))*
         GaugeXi[Q]) + 2^(2 + 3*d)*(gZlLC + gZlRC)*(gZuLC + gZuRC)*Pi^(3*d)*
       (s - s*GaugeXi[Q])^2*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
         GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) + 2^(1 + 3*d)*Pi^(3*d)*
       (gZlLC*gZuLC*((-4 + d)*s - 2*t) + gZlRC*gZuRC*((-4 + d)*s - 2*t) - 
        gZlRC*gZuLC*((-2 + d)*s + 2*t) - gZlLC*gZuRC*((-2 + d)*s + 2*t))*
       (-1 + GaugeXi[Q])^2*((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2) - 4*(1 - d)*s*
       ((2*Pi)^(3*d)*(gZlRC*gZuLC*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlLC*gZuRC*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
          gZlLC*gZuLC*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
          gZlRC*gZuRC*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
            2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
        2^(1 + 3*d)*Pi^(3*d)*(-(gZlRC*gZuLC*((-4 + d)*s^2*t + 
             mw^4*((-4 + d)*s + 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
               (20 - 21*d + 4*d^2)*s*t - 8*t^2))) - gZlLC*gZuRC*
           ((-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 8*t^2)) + 
          gZlLC*gZuLC*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2)) + 
          gZlRC*gZuRC*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2)))*
         GaugeXi[Q] - (2*Pi)^(3*d)*(-(gZlRC*gZuLC*((-4 + d)*s^2*t + 
             2*mw^4*(2*(-4 + d)*s + (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*
                s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) - 
          gZlLC*gZuRC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
              (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*
               s*t - 4*t^2)) + gZlLC*gZuLC*((-2 + d)*s^2*t + 
            mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 2*mw^2*((-2 + d)^2*s^2 + 
              (14 - 9*d + 2*d^2)*s*t + 4*t^2)) + gZlRC*gZuRC*
           ((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
            2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*
         (-(gZlRC*gZuLC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) - 
          gZlLC*gZuRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t)) + 
          gZlLC*gZuLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)) + 
          gZlRC*gZuRC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
         GaugeXi[Q]^3 + (-((-2 + d)*gZlLC*gZuLC) + (-4 + d)*gZlRC*gZuLC + 
          (-4 + d)*gZlLC*gZuRC - (-2 + d)*gZlRC*gZuRC)*mw^4*(2*Pi)^(3*d)*t*
         GaugeXi[Q]^4)) - 2*gAl*gWWA*gWWZ*(mz^2 - s)*s*sw^2*
     (2^(1 + 3*d)*(1 - d)*Pi^(3*d)*s*(gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
          gZuR*gZuRC*((-4 + d)*s + 2*t)) - 
        gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
            2*t)))*(-1 + GaugeXi[Q])^2*(mw^2 - s + mw^2*GaugeXi[Q])^2 + 
      2^(1 + 3*d)*(gZlLC + gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*
       (s - s*GaugeXi[Q])^2*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
         GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) - (2*Pi)^(3*d)*
       (-(gZlLC*gZuL*gZuLC*((-4 + d)*s - 2*t)) + gZlRC*gZuR*gZuRC*
         (-((-4 + d)*s) + 2*t) + gZlRC*gZuL*gZuLC*((-2 + d)*s + 2*t) + 
        gZlLC*gZuR*gZuRC*((-2 + d)*s + 2*t))*(-1 + GaugeXi[Q])^2*
       ((mw^2 - s)^2*(d*s + 2*t) + 2*(mw^4*((-2 + d)*s - 2*t) - 
          mw^2*s*(d*s + 2*t))*GaugeXi[Q] + mw^4*(d*s + 2*t)*GaugeXi[Q]^2) + 
      2*(1 - d)*s*((2*Pi)^(3*d)*(-(gZlRC*gZuL*gZuLC*((-4 + d)*mw^4*t + 
             (-4 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 
                 2*d^2)*s*t - 4*t^2))) - gZlLC*gZuR*gZuRC*((-4 + d)*mw^4*t + 
            (-4 + d)*s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 
                2*d^2)*s*t - 4*t^2)) + gZlLC*gZuL*gZuLC*((-2 + d)*mw^4*t + 
            (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*
               t + 4*t^2)) + gZlRC*gZuR*gZuRC*((-2 + d)*mw^4*t + 
            (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*
               t + 4*t^2))) - 2^(1 + 3*d)*Pi^(3*d)*
         (-(gZlRC*gZuL*gZuLC*((-4 + d)*s^2*t + mw^4*((-4 + d)*s + 2*(-3 + d)*
                t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + (20 - 21*d + 4*d^2)*s*t - 
               8*t^2))) - gZlLC*gZuR*gZuRC*((-4 + d)*s^2*t + 
            mw^4*((-4 + d)*s + 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
              (20 - 21*d + 4*d^2)*s*t - 8*t^2)) + gZlLC*gZuL*gZuLC*
           ((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
            mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2)) + 
          gZlRC*gZuR*gZuRC*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 
              2*(-3 + d)*t) + mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*
               t + 8*t^2)))*GaugeXi[Q] + (2*Pi)^(3*d)*
         (-(gZlRC*gZuL*gZuLC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
               (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 
                 2*d^2)*s*t - 4*t^2))) - gZlLC*gZuR*gZuRC*((-4 + d)*s^2*t + 
            2*mw^4*(2*(-4 + d)*s + (-8 + 3*d)*t) + 
            2*mw^2*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2)) + 
          gZlLC*gZuL*gZuLC*((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 
              2*(-10 + 3*d)*t) + 2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*
               s*t + 4*t^2)) + gZlRC*gZuR*gZuRC*((-2 + d)*s^2*t + 
            mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 2*mw^2*((-2 + d)^2*s^2 + 
              (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*GaugeXi[Q]^2 + 
        2^(1 + 3*d)*mw^2*Pi^(3*d)*(gZlRC*gZuL*gZuLC*((-4 + d)*s*t + 
            mw^2*((-4 + d)*s + 2*(-3 + d)*t)) + gZlLC*gZuR*gZuRC*
           ((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t)) - 
          gZlLC*gZuL*gZuLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 
              2*(-3 + d)*t)) - gZlRC*gZuR*gZuRC*((-2 + d)*s*t + 
            mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*GaugeXi[Q]^3 - 
        (-((-2 + d)*gZlLC*gZuL*gZuLC) + (-4 + d)*gZlRC*gZuL*gZuLC + 
          (-4 + d)*gZlLC*gZuR*gZuRC - (-2 + d)*gZlRC*gZuR*gZuRC)*mw^4*
         (2*Pi)^(3*d)*t*GaugeXi[Q]^4)) + 2*gAu*gWWA*gWWZ*(mz^2 - s)*s*sw^2*
     (2^(1 + 3*d)*(1 - d)*Pi^(3*d)*s*(gZlL*gZlLC*(-((-2 + d)*gZuLC*s) + 
          (-4 + d)*gZuRC*s + 2*gZuLC*t + 2*gZuRC*t) + 
        gZlR*gZlRC*((-4 + d)*gZuLC*s - (-2 + d)*gZuRC*s + 2*gZuLC*t + 
          2*gZuRC*t))*(-1 + GaugeXi[Q])^2*(mw^2 - s + mw^2*GaugeXi[Q])^2 - 
      2^(1 + 3*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuLC + gZuRC)*Pi^(3*d)*
       (s - s*GaugeXi[Q])^2*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
         GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) + (2*Pi)^(3*d)*
       (gZlR*gZlRC*((-2 + d)*gZuLC*s - (-4 + d)*gZuRC*s + 2*gZuLC*t + 
          2*gZuRC*t) + gZlL*gZlLC*(-((-4 + d)*gZuLC*s) + (-2 + d)*gZuRC*s + 
          2*gZuLC*t + 2*gZuRC*t))*(-1 + GaugeXi[Q])^2*
       ((mw^2 - s)^2*(d*s + 2*t) + 2*(mw^4*((-2 + d)*s - 2*t) - 
          mw^2*s*(d*s + 2*t))*GaugeXi[Q] + mw^4*(d*s + 2*t)*GaugeXi[Q]^2) - 
      2*(1 - d)*s*((2*Pi)^(3*d)*(gZlL*gZlLC*
           (-(gZuRC*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 2*mw^2*
                ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
            gZuLC*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*
                 s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2))) + 
          gZlR*gZlRC*(-(gZuLC*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 2*mw^2*
                ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
            gZuRC*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*
                 s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)))) - 
        2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZlLC*(-(gZuRC*((-4 + d)*s^2*t + mw^4*
                ((-4 + d)*s + 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
                 (20 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
            gZuLC*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
              mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2))) + 
          gZlR*gZlRC*(-(gZuLC*((-4 + d)*s^2*t + mw^4*((-4 + d)*s + 
                 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
                 (20 - 21*d + 4*d^2)*s*t - 8*t^2))) + 
            gZuRC*((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
              mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2))))*
         GaugeXi[Q] + (2*Pi)^(3*d)*
         (gZlL*gZlLC*(-(gZuRC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
                 (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + 
                 (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
            gZuLC*((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
              2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))) + 
          gZlR*gZlRC*(-(gZuLC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
                 (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + 
                 (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
            gZuRC*((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
              2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*
         (gZlL*gZlLC*(gZuRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*
                 t)) - gZuLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*
                 t))) + gZlR*gZlRC*(gZuLC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 
                2*(-3 + d)*t)) - gZuRC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 
                2*(-3 + d)*t))))*GaugeXi[Q]^3 + 
        (gZlL*gZlLC*((-2 + d)*gZuLC - (-4 + d)*gZuRC) + 
          gZlR*gZlRC*(-((-4 + d)*gZuLC) + (-2 + d)*gZuRC))*mw^4*(2*Pi)^(3*d)*
         t*GaugeXi[Q]^4)) - 2*gWWZ^2*s^2*sw^2*
     (2^(1 + 3*d)*(1 - d)*Pi^(3*d)*s*
       (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
           ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
          gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(-1 + GaugeXi[Q])^2*
       (mw^2 - s + mw^2*GaugeXi[Q])^2 + 2^(1 + 3*d)*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*(s - s*GaugeXi[Q])^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2) - (2*Pi)^(3*d)*
       (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
          gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
         (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 2*t)))*
       (-1 + GaugeXi[Q])^2*((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2) + 2*(1 - d)*s*
       ((2*Pi)^(3*d)*(gZlL*gZlLC*(-(gZuR*gZuRC*((-4 + d)*mw^4*t + (-4 + d)*
                s^2*t + 2*mw^2*((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*
                  t - 4*t^2))) + gZuL*gZuLC*((-2 + d)*mw^4*t + 
              (-2 + d)*s^2*t + 2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*
                 t + 4*t^2))) + gZlR*gZlRC*
           (-(gZuL*gZuLC*((-4 + d)*mw^4*t + (-4 + d)*s^2*t + 2*mw^2*
                ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2))) + 
            gZuR*gZuRC*((-2 + d)*mw^4*t + (-2 + d)*s^2*t + 
              2*mw^2*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)))) - 
        2^(1 + 3*d)*Pi^(3*d)*(gZlL*gZlLC*(-(gZuR*gZuRC*((-4 + d)*s^2*t + mw^4*
                ((-4 + d)*s + 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
                 (20 - 21*d + 4*d^2)*s*t - 8*t^2))) + gZuL*gZuLC*
             ((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
              mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2))) + 
          gZlR*gZlRC*(-(gZuL*gZuLC*((-4 + d)*s^2*t + mw^4*((-4 + d)*s + 
                 2*(-3 + d)*t) + mw^2*(2*(8 - 6*d + d^2)*s^2 + 
                 (20 - 21*d + 4*d^2)*s*t - 8*t^2))) + gZuR*gZuRC*
             ((-2 + d)*s^2*t + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
              mw^2*(2*(-2 + d)^2*s^2 + (34 - 21*d + 4*d^2)*s*t + 8*t^2))))*
         GaugeXi[Q] + (2*Pi)^(3*d)*
         (gZlL*gZlLC*(-(gZuR*gZuRC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
                 (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + 
                 (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + gZuL*gZuLC*
             ((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
              2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))) + 
          gZlR*gZlRC*(-(gZuL*gZuLC*((-4 + d)*s^2*t + 2*mw^4*(2*(-4 + d)*s + 
                 (-8 + 3*d)*t) + 2*mw^2*((8 - 6*d + d^2)*s^2 + 
                 (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + gZuR*gZuRC*
             ((-2 + d)*s^2*t + mw^4*(4*(-2 + d)*s + 2*(-10 + 3*d)*t) + 
              2*mw^2*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2))))*
         GaugeXi[Q]^2 + 2^(1 + 3*d)*mw^2*Pi^(3*d)*
         (gZlL*gZlLC*(gZuR*gZuRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 
                2*(-3 + d)*t)) - gZuL*gZuLC*((-2 + d)*s*t + 
              mw^2*((-2 + d)*s + 2*(-3 + d)*t))) + gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t)) - 
            gZuR*gZuRC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t))))*
         GaugeXi[Q]^3 + (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - 
            (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
            (-2 + d)*gZuR*gZuRC))*mw^4*(2*Pi)^(3*d)*t*GaugeXi[Q]^4)) - 
    gAl*gWdu*gWud*gWWA*gZuLC*(2*Pi)^(2*d)*(mz^2 - s)^2*sw^2*CKM[1, 1]*
     CKMC[1, 1]*((gZlLC + gZlRC)*(2*Pi)^d*(s - s*GaugeXi[Q])^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2) + (gZlLC + gZlRC)*s^2*(d*(mw^2 - s)^2 + 
        2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2)*
       ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
      (1 - d)*s*(1 - GaugeXi[Q])*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlLC*(d*mw^2*(2*Pi)^d*s + d*(2*Pi)^d*s^2 - 2^(1 + d)*mw^2*Pi^d*
           (s + t) + 2^(1 + d)*Pi^d*s*(s - d*s + t)) + 
        gZlRC*(mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
          s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t))) - 
        s*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 2^(1 + d)*gZlRC*Pi^d*
           (-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*GaugeXi[Q] + 
        mw^2*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
          2^(1 + d)*gZlRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*
         GaugeXi[Q]^2) + ((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2)*(3*d*gZlLC*(2*Pi)^d*s - 
        3*d*gZlRC*(2*Pi)^d*s + 2^(1 + d)*gZlRC*Pi^d*(s + d*s - t) - 
        2^(1 + d)*gZlLC*Pi^d*((2 + d)*s + t) - 2^(1 + d)*Pi^d*
         ((-4 + d)*gZlLC*s - (-2 + d)*gZlRC*s - 2*gZlLC*t - 2*gZlRC*t)*
         GaugeXi[Q] - (-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
          2^(1 + d)*gZlRC*Pi^d*(-s + t) + 2^(1 + d)*gZlLC*Pi^d*(2*s + t))*
         GaugeXi[Q]^2) + (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlRC*(mw^2*(-9*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*s + 4*d*s - t)) + 
          s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t))) - 
        gZlLC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
          mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))) + 
        (-(gZlRC*(mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
             2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t))) + 
          gZlLC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) + 
            mw^2*(3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 2*d*s + t))))*
         GaugeXi[Q] + (-(gZlRC*(mw^2 + s)*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s - t))) + 
          gZlLC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
            mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))))*
         GaugeXi[Q]^2 - mw^2*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
          2^(1 + d)*gZlRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*
         GaugeXi[Q]^3) - 2*(1 - d)*s*
       (gZlRC*(mw^4*(2^(1 + d)*(-2 + 9*d)*Pi^d - 17*d*(2*Pi)^d)*t + 
          (2^(1 + d)*(-2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
        gZlLC*(mw^4*(2^(1 + d)*(-1 + 9*d)*Pi^d - 17*d*(2*Pi)^d)*t + 
          (2^(1 + d)*(-1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
           ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) + 
        2*(gZlRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
            mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
            mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 
                2*(5 + d^2)*s*t - 4*t^2))) + 
          gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
            mw^4*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + (-3 + d)*t)) + 
            mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + 
                (17 + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q] - 
        (-(gZlRC*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*
              Pi^d*(2*(-4 + d)*s + (-8 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
              ((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
          gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^d*
             (2*(-2 + d)*s + (-10 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
             ((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
         GaugeXi[Q]^2 + 2^(1 + d)*mw^2*Pi^d*
         (-(gZlRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
          gZlLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
         GaugeXi[Q]^3 + mw^4*(2^(1 + d)*gZlLC*Pi^d - 2^(2 + d)*gZlRC*Pi^d - 
          d*gZlLC*(2*Pi)^d + d*gZlRC*(2*Pi)^d)*t*GaugeXi[Q]^4)) + 
    gWdu*gWud*gWWZ*gZuLC*(2*Pi)^(2*d)*(mz^2 - s)*s*sw^2*CKM[1, 1]*CKMC[1, 1]*
     ((gZlL*gZlLC + gZlR*gZlRC)*s^2*(d*(mw^2 - s)^2 + 
        2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2)*
       (2^(1 + d)*Pi^d - 3*(2*Pi)^d + 2^(1 + d)*Pi^d*GaugeXi[Q] - 
        (2*Pi)^d*GaugeXi[Q]^2) - (gZlL*gZlLC + gZlR*gZlRC)*s^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2)*((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + 
        (2*Pi)^d*GaugeXi[Q]^2) - (1 - d)*s*(1 - GaugeXi[Q])*
       (mw^2 - s + mw^2*GaugeXi[Q])*
       ((mw^2 - s)*(gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             ((-1 + d)*s - t)) + gZlR*gZlRC*(d*(2*Pi)^d*s - 
            2^(1 + d)*Pi^d*((-2 + d)*s + t))) - 
        s*(gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*GaugeXi[Q] + 
        mw^2*(gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
          gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))*
         GaugeXi[Q]^2) + ((mw^2 - s)^2*(d*s + 2*t) + 
        2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
        mw^4*(d*s + 2*t)*GaugeXi[Q]^2)*
       (gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
        gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)) + 
        2^(1 + d)*Pi^d*(gZlL*gZlLC*((-4 + d)*s - 2*t) - 
          gZlR*gZlRC*((-2 + d)*s + 2*t))*GaugeXi[Q] + 
        (gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
          gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))*
         GaugeXi[Q]^2) + (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlL*gZlLC*(s*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + 3*d*s - t)) + 
          mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t))) - 
        gZlR*gZlRC*(mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(1 + d)*s - 
              t)) + s*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + 
              t))) + (gZlR*gZlRC*(mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (2 + d)*s - t)) + 2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) - 
          gZlL*gZlLC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) + 
            mw^2*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - d*s + t))))*GaugeXi[Q] - 
        (gZlR*gZlRC*(s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
            mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-2 + d)*s + t))) + 
          gZlL*gZlLC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
            mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t))))*
         GaugeXi[Q]^2 + mw^2*(gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (-2*s + t)) + gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (s + t)))*GaugeXi[Q]^3) - 2*(1 - d)*s*
       (gZlR*gZlRC*(mw^4*(2^(2 + d)*(1 - 6*d)*Pi^d + 23*d*(2*Pi)^d)*t - 
          (2^(1 + d)*(-2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
        gZlL*gZlLC*(mw^4*(2^(1 + d)*(-1 + 12*d)*Pi^d - 23*d*(2*Pi)^d)*t + 
          (2^(1 + d)*(-1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
           ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
        2*(gZlR*gZlRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
            mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
            mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 
                2*(5 + d^2)*s*t - 4*t^2))) - gZlL*gZlLC*
           ((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + mw^4*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(s + 3*t - d*t)) - mw^2*(-21*d*(2*Pi)^d*s*t + 
              2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + (17 + 2*d^2)*s*t + 4*t^2))))*
         GaugeXi[Q] + (-(gZlR*gZlRC*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
             2^(1 + d)*mw^4*Pi^d*(2*(-4 + d)*s + (-8 + 3*d)*t) + 
             2^(1 + d)*mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*
                t - 4*t^2))) + gZlL*gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*
              s^2*t) + 2^(1 + d)*mw^4*Pi^d*(2*(-2 + d)*s + (-10 + 3*d)*t) + 
            2^(1 + d)*mw^2*Pi^d*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 
              4*t^2)))*GaugeXi[Q]^2 - 2^(1 + d)*mw^2*Pi^d*
         (-(gZlR*gZlRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
          gZlL*gZlLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
         GaugeXi[Q]^3 - mw^4*(gZlL*gZlLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
          gZlR*gZlRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d))*t*GaugeXi[Q]^4)) + 
    gWdu*gWlN*gWNl*gWud*gZlLC*gZuLC*(mz^2 - s)^2*sw^2*CKM[1, 1]*CKMC[1, 1]*
     (2^(1 + 3*d)*Pi^(3*d)*(s - s*GaugeXi[Q])^2*(d*(mw^2 - s)^2 + 
        2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) - 
      (2*Pi)^(2*d)*((mw^2 - s)^2*((-2 + d)*s - 2*t) + 
        2*mw^2*(d*(mw^2 - s)*s + 2*(s^2 + mw^2*t + s*t))*GaugeXi[Q] + 
        mw^4*((-2 + d)*s - 2*t)*GaugeXi[Q]^2)*(d*(2*Pi)^d*s - 
        2^(1 + d)*Pi^d*(2*s + t) - 2^(1 + d)*Pi^d*((-4 + d)*s - 2*t)*
         GaugeXi[Q] - (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))*
         GaugeXi[Q]^2) - (1 - d)*(2*Pi)^(2*d)*s*(mw^2 - s + mw^2*GaugeXi[Q])^
        2*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t) - 2^(1 + d)*Pi^d*
         ((-6 + d)*s - 2*t)*GaugeXi[Q] + 
        (d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t))*GaugeXi[Q]^2) + 
      (1 - d)*(2*Pi)^(2*d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       ((mw^2 - s)*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t)) + 
        (mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-3*s + 2*d*s - t)) - 
          2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t))*GaugeXi[Q] + 
        (mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) + 
          s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)))*GaugeXi[Q]^2 + 
        mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t))*
         GaugeXi[Q]^3) + 2*(1 - d)*s*((2*Pi)^(3*d)*((-4 + d)*mw^4*(s + t) + 
          (-4 + d)*s^2*(s + t) + 2*mw^2*((8 - 5*d + d^2)*s^2 + 
            (20 - 11*d + 2*d^2)*s*t + 4*t^2)) - 2^(1 + 3*d)*Pi^(3*d)*
         ((-4 + d)*s^2*(s + t) + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
          mw^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*t^2))*
         GaugeXi[Q] + (2*Pi)^(3*d)*(2*d^2*mw^2*s*(s + 2*t) - 
          4*(s^3 + 4*mw^4*t - 6*mw^2*s*t + s^2*t - 2*mw^2*t^2) + 
          d*(s^2*(s + t) + 2*mw^4*(s + 3*t) - 6*mw^2*s*(s + 3*t)))*
         GaugeXi[Q]^2 - 2^(1 + 3*d)*mw^2*Pi^(3*d)*((-4 + d)*s*(s + t) + 
          mw^2*((-2 + d)*s + 2*(-3 + d)*t))*GaugeXi[Q]^3 + 
        (-4 + d)*mw^4*(2*Pi)^(3*d)*(s + t)*GaugeXi[Q]^4))))/
  (2^(4*(1 + d))*(-1 + d)*mw^4*Pi^(4*d)*(mz^2 - s)^2*(mzC^2 - s)*s*sw^2*
   (-1 + GaugeXi[Q])^2), (I*EL^6*gWdu*gWud*gZuLC*CKM[1, 1]*CKMC[1, 1]*
   ((gAl*gWWA*(2*Pi)^d*(-(gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
           t - 4*t^2)) + gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2))*(4*(-1 + d)^2*mw^2 - d*(mw^2 + s)*GaugeXi[Q] + 
       d*mw^2*GaugeXi[Q]^2))/(d*s*GaugeXi[Q]) - 
    (gWWZ*(2*Pi)^d*(-(gZlR*gZlRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
           t - 4*t^2)) + gZlL*gZlLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
         4*t^2))*(4*(-1 + d)^2*mw^2 - d*(mw^2 + s)*GaugeXi[Q] + 
       d*mw^2*GaugeXi[Q]^2))/(d*(-mz^2 + s)*GaugeXi[Q]) - 
    (gWlN*gWNl*gZlLC*(-(d^2*(2*Pi)^d*s^3) + 2^(1 + d)*Pi^d*s*
        (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2) + 
       mw^2*(-3*d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((-2 + 2*d + d^2)*s^2 - 
           (8 - 5*d + d^2)*s*t - 2*t^2)) + 
       (2^(1 + d)*Pi^d*s*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
         mw^2*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*((6 - 6*d + d^2)*s^2 + 
             3*(8 - 5*d + d^2)*s*t + 6*t^2)))*GaugeXi[Q] + 
       (3*mw^2 + s)*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
          (2*(-1 + d)*s^2 - (8 - 5*d + d^2)*s*t - 2*t^2))*GaugeXi[Q]^2 - 
       mw^2*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
           (8 - 5*d + d^2)*s*t - 2*t^2))*GaugeXi[Q]^3))/
     (s*(-1 + GaugeXi[Q])^2)))/(2^(2*(2 + d))*(-1 + d)*mw^4*Pi^(2*d)*
   (mzC^2 - s)), (I*EL^6*gWdu*gWud*gZuLC*CKM[1, 1]*CKMC[1, 1]*
   (-(gAl*gWWA*(2*Pi)^(2*d)*(mz^2 - s)*((gZlLC + gZlRC)*(2*Pi)^d*
        (s - s*GaugeXi[Q])^2*(d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*
          GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2) + (gZlLC + gZlRC)*s^2*
        (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
         d*mw^4*GaugeXi[Q]^2)*((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + 
         (2*Pi)^d*GaugeXi[Q]^2) + (1 - d)*s*(1 - GaugeXi[Q])*
        (mw^2 - s + mw^2*GaugeXi[Q])*(gZlLC*(d*mw^2*(2*Pi)^d*s + 
           d*(2*Pi)^d*s^2 - 2^(1 + d)*mw^2*Pi^d*(s + t) + 2^(1 + d)*Pi^d*s*
            (s - d*s + t)) + gZlRC*(mw^2*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s - t)) + s*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*((-2 + d)*s + t))) - 
         s*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 2^(1 + d)*gZlRC*Pi^d*
            (-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*GaugeXi[Q] + 
         mw^2*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
           2^(1 + d)*gZlRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*
          GaugeXi[Q]^2) + ((mw^2 - s)^2*(d*s + 2*t) + 
         2*(mw^4*((-2 + d)*s - 2*t) - mw^2*s*(d*s + 2*t))*GaugeXi[Q] + 
         mw^4*(d*s + 2*t)*GaugeXi[Q]^2)*(3*d*gZlLC*(2*Pi)^d*s - 
         3*d*gZlRC*(2*Pi)^d*s + 2^(1 + d)*gZlRC*Pi^d*(s + d*s - t) - 
         2^(1 + d)*gZlLC*Pi^d*((2 + d)*s + t) - 2^(1 + d)*Pi^d*
          ((-4 + d)*gZlLC*s - (-2 + d)*gZlRC*s - 2*gZlLC*t - 2*gZlRC*t)*
          GaugeXi[Q] - (-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
           2^(1 + d)*gZlRC*Pi^d*(-s + t) + 2^(1 + d)*gZlLC*Pi^d*(2*s + t))*
          GaugeXi[Q]^2) - (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
        (gZlRC*s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
         gZlLC*s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
         gZlRC*mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(-1 + d)*s + t)) + 
         gZlLC*mw^2*(5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 3*d*s + t)) + 
         (gZlRC*(mw^2*(-11*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*s + 5*d*s - t)) + 
             2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) - 
           gZlLC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) + 
             mw^2*(-9*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 4*d*s + t))))*
          GaugeXi[Q] + (gZlLC*(mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-s + 4*d*s - t)) + s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + t))) - gZlRC*(s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + t)) + mw^2*(-9*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + 5*d*s + t))))*GaugeXi[Q]^2 + 
         mw^2*(-(d*gZlLC*(2*Pi)^d*s) + d*gZlRC*(2*Pi)^d*s + 
           2^(1 + d)*gZlRC*Pi^d*(-2*s + t) + 2^(1 + d)*gZlLC*Pi^d*(s + t))*
          GaugeXi[Q]^3) - 2*(1 - d)*s*
        (gZlRC*(mw^4*(2^(2 + d)*(-1 + 7*d)*Pi^d - 27*d*(2*Pi)^d)*t + 
           (2^(1 + d)*(-2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
            ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) - 
         gZlLC*(mw^4*(2^(1 + d)*(-1 + 12*d)*Pi^d - 23*d*(2*Pi)^d)*t + 
           (2^(1 + d)*(-1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
            ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) + 
         2*(gZlRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
             mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
             mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 
                 2*(5 + d^2)*s*t - 4*t^2))) + 
           gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
             mw^4*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + (-3 + d)*t)) + 
             mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + 
                 (17 + 2*d^2)*s*t + 4*t^2))))*GaugeXi[Q] - 
         (-(gZlRC*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*Pi^
                d*(2*(-4 + d)*s + (-8 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*(
                (8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*t - 4*t^2))) + 
           gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 2^(1 + d)*mw^4*
              Pi^d*(2*(-2 + d)*s + (-10 + 3*d)*t) + 2^(1 + d)*mw^2*Pi^d*
              ((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 4*t^2)))*
          GaugeXi[Q]^2 + 2^(1 + d)*mw^2*Pi^d*
          (-(gZlRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
           gZlLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
          GaugeXi[Q]^3 + mw^4*(2^(1 + d)*gZlLC*Pi^d - 2^(2 + d)*gZlRC*Pi^d - 
           d*gZlLC*(2*Pi)^d + d*gZlRC*(2*Pi)^d)*t*GaugeXi[Q]^4))) + 
    gWWZ*(2*Pi)^(2*d)*s*((gZlL*gZlLC + gZlR*gZlRC)*s^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2)*(2^(1 + d)*Pi^d - 3*(2*Pi)^d + 
        2^(1 + d)*Pi^d*GaugeXi[Q] - (2*Pi)^d*GaugeXi[Q]^2) - 
      (gZlL*gZlLC + gZlR*gZlRC)*s^2*(d*(mw^2 - s)^2 + 
        2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + d*mw^4*GaugeXi[Q]^2)*
       ((2*Pi)^d - 2^(1 + d)*Pi^d*GaugeXi[Q] + (2*Pi)^d*GaugeXi[Q]^2) + 
      ((mw^2 - s)^2*(d*s + 2*t) + 2*(mw^4*((-2 + d)*s - 2*t) - 
          mw^2*s*(d*s + 2*t))*GaugeXi[Q] + mw^4*(d*s + 2*t)*GaugeXi[Q]^2)*
       (gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
        gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)) + 
        2^(1 + d)*Pi^d*(gZlL*gZlLC*((-4 + d)*s - 2*t) - 
          gZlR*gZlRC*((-2 + d)*s + 2*t))*GaugeXi[Q] + 
        (gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
          gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))*
         GaugeXi[Q]^2) - (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlL*gZlLC*(mw^2*(-13*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (-s + 7*d*s - t)) + s*(5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (s - 3*d*s + t))) + gZlR*gZlRC*
         (s*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 3*d*s + t)) + 
          mw^2*(9*d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(-2*s + 5*d*s + t))) + 
        (gZlR*gZlRC*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
            mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(2*(-1 + d)*s + t))) + 
          gZlL*gZlLC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) + 
            mw^2*(7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 4*d*s + t))))*
         GaugeXi[Q] + (-(gZlR*gZlRC*(mw^2 + s)*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s - t))) + gZlL*gZlLC*
           (s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
            mw^2*(-5*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 2*d*s + t))))*
         GaugeXi[Q]^2 - mw^2*(gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (-2*s + t)) + gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (s + t)))*GaugeXi[Q]^3) - (1 - d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       (gZlL*gZlLC*(mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + 4*d*s - 
              t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - d*s + t))) - 
        gZlR*gZlRC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*((-2 + d)*s + t)) + 
          mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 4*d*s + t))) + 
        (gZlL*gZlLC*(2^(1 + d)*Pi^d*s*((-2 + d)*s - 2*t) + 
            mw^2*(7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s - 4*d*s + t))) + 
          gZlR*gZlRC*(-(2^(1 + d)*Pi^d*s*((-4 + d)*s + 2*t)) + 
            mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + 4*d*s + t))))*
         GaugeXi[Q] + (-(gZlR*gZlRC*(s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t)) + mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (2*s + 3*d*s - t)))) + gZlL*gZlLC*
           (s*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)) + 
            mw^2*(-7*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + 3*d*s + t))))*
         GaugeXi[Q]^2 - mw^2*(gZlR*gZlRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
             (-2*s + t)) + gZlL*gZlLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
             (s + t)))*GaugeXi[Q]^3) - 2*(1 - d)*s*
       (gZlR*gZlRC*(mw^4*(2^(2 + d)*(1 - 8*d)*Pi^d + 31*d*(2*Pi)^d)*t - 
          (2^(1 + d)*(-2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mw^2*Pi^d*
           ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2)) + 
        gZlL*gZlLC*(mw^4*(2^(1 + d)*(-1 + 16*d)*Pi^d - 31*d*(2*Pi)^d)*t + 
          (2^(1 + d)*(-1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 2^(1 + d)*mw^2*Pi^d*
           ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2)) - 
        2*(gZlR*gZlRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + 
            mw^4*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + 3*t - d*t)) - 
            mw^2*(-21*d*(2*Pi)^d*s*t + 2^(1 + d)*Pi^d*((8 - 6*d + d^2)*s^2 + 
                2*(5 + d^2)*s*t - 4*t^2))) - gZlL*gZlLC*
           ((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t + mw^4*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(s + 3*t - d*t)) - mw^2*(-21*d*(2*Pi)^d*s*t + 
              2^(1 + d)*Pi^d*((-2 + d)^2*s^2 + (17 + 2*d^2)*s*t + 4*t^2))))*
         GaugeXi[Q] + (-(gZlR*gZlRC*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
             2^(1 + d)*mw^4*Pi^d*(2*(-4 + d)*s + (-8 + 3*d)*t) + 
             2^(1 + d)*mw^2*Pi^d*((8 - 6*d + d^2)*s^2 + (4 - 9*d + 2*d^2)*s*
                t - 4*t^2))) + gZlL*gZlLC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*
              s^2*t) + 2^(1 + d)*mw^4*Pi^d*(2*(-2 + d)*s + (-10 + 3*d)*t) + 
            2^(1 + d)*mw^2*Pi^d*((-2 + d)^2*s^2 + (14 - 9*d + 2*d^2)*s*t + 
              4*t^2)))*GaugeXi[Q]^2 - 2^(1 + d)*mw^2*Pi^d*
         (-(gZlR*gZlRC*((-4 + d)*s*t + mw^2*((-4 + d)*s + 2*(-3 + d)*t))) + 
          gZlL*gZlLC*((-2 + d)*s*t + mw^2*((-2 + d)*s + 2*(-3 + d)*t)))*
         GaugeXi[Q]^3 - mw^4*(gZlL*gZlLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
          gZlR*gZlRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d))*t*GaugeXi[Q]^4)) + 
    gWlN*gWNl*gZlLC*(mz^2 - s)*(2^(1 + 3*d)*Pi^(3*d)*(s - s*GaugeXi[Q])^2*
       (d*(mw^2 - s)^2 + 2*((-2 + d)*mw^4 - d*mw^2*s)*GaugeXi[Q] + 
        d*mw^4*GaugeXi[Q]^2) - (2*Pi)^(2*d)*
       ((mw^2 - s)^2*((-2 + d)*s - 2*t) + 2*mw^2*(d*(mw^2 - s)*s + 
          2*(s^2 + mw^2*t + s*t))*GaugeXi[Q] + mw^4*((-2 + d)*s - 2*t)*
         GaugeXi[Q]^2)*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t) - 
        2^(1 + d)*Pi^d*((-4 + d)*s - 2*t)*GaugeXi[Q] - 
        (-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))*GaugeXi[Q]^2) - 
      (1 - d)*(2*Pi)^(2*d)*s*(mw^2 - s + mw^2*GaugeXi[Q])^2*
       (d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t) - 2^(1 + d)*Pi^d*
         ((-6 + d)*s - 2*t)*GaugeXi[Q] + 
        (d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t))*GaugeXi[Q]^2) + 
      (1 - d)*(2*Pi)^(2*d)*s*(mw^2 - s + mw^2*GaugeXi[Q])*
       (s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)) + 
        mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((3 + d)*s + t)) + 
        (mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*((-3 + d)*s - t)) - 
          2^(1 + d)*Pi^d*s*((-6 + d)*s - 2*t))*GaugeXi[Q] + 
        (mw^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-3*s + 2*d*s - t)) + 
          s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(3*s + t)))*GaugeXi[Q]^2 + 
        mw^2*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(3*s + t))*GaugeXi[Q]^3) + 
      2*(1 - d)*s*((2*Pi)^(3*d)*((-4 + d)*mw^4*(s + t) + 
          (-4 + d)*s^2*(s + t) + 2*mw^2*((8 - 5*d + d^2)*s^2 + 
            (20 - 11*d + 2*d^2)*s*t + 4*t^2)) - 2^(1 + 3*d)*Pi^(3*d)*
         ((-4 + d)*s^2*(s + t) + mw^4*((-2 + d)*s + 2*(-3 + d)*t) + 
          mw^2*((12 - 9*d + 2*d^2)*s^2 + (36 - 21*d + 4*d^2)*s*t + 8*t^2))*
         GaugeXi[Q] + (2*Pi)^(3*d)*(2*d^2*mw^2*s*(s + 2*t) - 
          4*(s^3 + 4*mw^4*t - 6*mw^2*s*t + s^2*t - 2*mw^2*t^2) + 
          d*(s^2*(s + t) + 2*mw^4*(s + 3*t) - 6*mw^2*s*(s + 3*t)))*
         GaugeXi[Q]^2 - 2^(1 + 3*d)*mw^2*Pi^(3*d)*((-4 + d)*s*(s + t) + 
          mw^2*((-2 + d)*s + 2*(-3 + d)*t))*GaugeXi[Q]^3 + 
        (-4 + d)*mw^4*(2*Pi)^(3*d)*(s + t)*GaugeXi[Q]^4))))/
  (2^(4*(1 + d))*(-1 + d)*mw^4*Pi^(4*d)*(mz^2 - s)*(mzC^2 - s)*s*
   (-1 + GaugeXi[Q])^2), 
 ((I/4)*EL^6*(-(((-2 + d)*gAl*gAu*(mz^2 - s)*(-2*mz^4 + (-8 + d)*mz^2*s - 
        2*s^2)*(gZlL^2*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 
            2*(8 - 5*d + d^2)*s*t + 4*t^2)) + gZlR^2*gZlRC*
         (-(gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
          gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2))))/
      (2*Pi)^d) + ((2 - d)*s*(2*mz^4 - (-8 + d)*mz^2*s + 2*s^2)*
      (gZlL^3*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR^3*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/(2*Pi)^d + 
    (s*(2*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL^3*gZuLC + gZuR^3*gZuRC)*
        (2^(1 + d)*Pi^d - d*(2*Pi)^d)*((-2 + d)*s^2*t^2 + 
         mz^4*((-2 + d)*s^2 + 4*(-1 + d)*s*t + 4*(-1 + d)*t^2) + 
         2*mz^2*s*t*(-2*t + d*(s + 2*t))) + 2^(1 + d)*(2 - d)*Pi^d*
        (s*t + mz^2*(s + 2*t))*
        (gZlL*gZlLC*(-(gZuR^3*gZuRC*(2*(-4 + d)*s*(s + t) + (-2 + d)*mz^2*(
                (-2 + d)*s + 2*t))) + gZuL^3*gZuLC*
            ((-2 + d)*mz^2*((-4 + d)*s - 2*t) + 2*s*((-2 + d)*s - (-4 + d)*
                t))) + gZlR*gZlRC*(-(gZuL^3*gZuLC*(2*(-4 + d)*s*(s + t) + 
              (-2 + d)*mz^2*((-2 + d)*s + 2*t))) + gZuR^3*gZuRC*
            ((-2 + d)*mz^2*((-4 + d)*s - 2*t) + 2*s*((-2 + d)*s - (-4 + d)*
                t)))) + (2 - d)*(2*Pi)^d*s^2*
        (gZlL*gZlLC*(gZuR^3*gZuRC*(2*(-2 + d)*mz^4 + 
             mz^2*((-80 + 60*d - 14*d^2 + d^3)*s + 2*(-52 + 44*d - 12*d^2 + 
                 d^3)*t) - 2*(-2 + d)*((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^
                2)) + gZuL^3*gZuLC*(2*(-2 + d)*mz^4 + 
             mz^2*(-((-40 + 40*d - 12*d^2 + d^3)*s) - 2*(-56 + 46*d - 
                 12*d^2 + d^3)*t) + 2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*
                t + (-2 + d)*t^2))) + gZlR*gZlRC*
          (gZuL^3*gZuLC*(2*(-2 + d)*mz^4 + mz^2*((-80 + 60*d - 14*d^2 + d^3)*
                s + 2*(-52 + 44*d - 12*d^2 + d^3)*t) - 2*(-2 + d)*
              ((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^2)) + gZuR^3*gZuRC*
            (2*(-2 + d)*mz^4 + mz^2*(-((-40 + 40*d - 12*d^2 + d^3)*s) - 2*
                (-56 + 46*d - 12*d^2 + d^3)*t) + 2*((-2 + d)^2*s^2 + 2*
                (10 - 6*d + d^2)*s*t + (-2 + d)*t^2))))))/(2*Pi)^(2*d) - 
    (2 - d)*gAl*gAu*(mz^2 - s)*
     ((2^(1 - d)*(gZlLC + gZlRC)*(gZuL^2*gZuLC + gZuR^2*gZuRC)*
        ((-2 + d)*s^2*t^2 + mz^4*((-2 + d)*s^2 + 4*(-1 + d)*s*t + 
           4*(-1 + d)*t^2) + 2*mz^2*s*t*(-2*t + d*(s + 2*t))))/Pi^d + 
      (s^2*(gZlRC*gZuL^2*gZuLC*(2*(-2 + d)*mz^4 + 
           mz^2*((-80 + 60*d - 14*d^2 + d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^
                3)*t) - 2*(-2 + d)*((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^2)) + 
         gZlLC*gZuR^2*gZuRC*(2*(-2 + d)*mz^4 + 
           mz^2*((-80 + 60*d - 14*d^2 + d^3)*s + 2*(-52 + 44*d - 12*d^2 + d^
                3)*t) - 2*(-2 + d)*((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^2)) + 
         gZlLC*gZuL^2*gZuLC*(2*(-2 + d)*mz^4 + 
           mz^2*(-((-40 + 40*d - 12*d^2 + d^3)*s) - 2*(-56 + 46*d - 12*d^2 + 
               d^3)*t) + 2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 
             (-2 + d)*t^2)) + gZlRC*gZuR^2*gZuRC*(2*(-2 + d)*mz^4 + 
           mz^2*(-((-40 + 40*d - 12*d^2 + d^3)*s) - 2*(-56 + 46*d - 12*d^2 + 
               d^3)*t) + 2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + 
             (-2 + d)*t^2))))/(2*Pi)^d + (s*t + mz^2*(s + 2*t))*
       (-((2^(2 - d)*(-2 + d)*(gZlLC + gZlRC)*(gZuL^2*gZuLC + gZuR^2*gZuRC)*s*
           t)/Pi^d) + ((-2 + d)*mz^2*(gZlLC*gZuL^2*gZuLC*((-6 + d)*s - 2*t) - 
           gZlLC*gZuR^2*gZuRC*(d*s + 2*t) - 
           gZlRC*(d*(gZuL^2*gZuLC - gZuR^2*gZuRC)*s + 2*gZuL^2*gZuLC*t + 
             2*gZuR^2*gZuRC*(3*s + t))))/(2*Pi)^d + 
        ((-2 + d)*mz^2*(gZlLC*(gZuL^2*gZuLC*((-2 + d)*s - 2*t) - 
             gZuR^2*gZuRC*((-4 + d)*s + 2*t)) - 
           gZlRC*(gZuL^2*gZuLC*((-4 + d)*s + 2*t) + gZuR^2*gZuRC*
              (-((-2 + d)*s) + 2*t))))/(2*Pi)^d - 
        (4^(1 - d)*s*(gZlRC*gZuR^2*gZuRC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(s - t)) - gZlRC*gZuL^2*gZuLC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(2*s + t)) + gZlLC*
            (gZuL^2*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) - 
             gZuR^2*gZuRC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))))/
         Pi^(2*d)))))/((-2 + d)*(mz^2 - s)*s^2*(-mzC^2 + s)), 
 ((-I)*EL^6*((2 - d)*gWlN*gWNl*gZlLC*gZNL*(2*Pi)^d*s*
     (2*mw^4 - (-8 + d)*mw^2*s + 2*s^2)*
     (gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) - 
      gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
    (2 - d)*gAd*gAl*gWdu*gWud*gZuLC*(mz^2 - s)*
     (gZlLC*(2^(1 + d)*mw^4*Pi^d*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2) + 2^(1 + d)*Pi^d*s^2*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
           t + 4*t^2) + mw^2*s*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           (2*(8 - 9*d + 3*d^2)*s^2 - (-64 + 48*d - 13*d^2 + d^3)*s*t - 
            2*(-8 + d)*t^2))) - gZlRC*(2^(1 + d)*mw^4*Pi^d*
         ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
        2^(1 + d)*Pi^d*s^2*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2) + mw^2*s*(-(d^3*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((32 - 28*d + 7*d^2)*s^2 - (-32 + 44*d - 13*d^2 + d^3)*s*t + 
            2*(-8 + d)*t^2))))*CKM[1, 1]*CKMC[1, 1] - 
    gWdu*gWud*gZdL*gZuLC*s*(2*(gZlL*gZlLC + gZlR*gZlRC)*
       (2^(1 + d)*Pi^d - d*(2*Pi)^d)*((-2 + d)*s^2*t^2 + 
        mw^4*((-2 + d)*s^2 + 4*(-1 + d)*s*t + 4*(-1 + d)*t^2) + 
        2*mw^2*s*t*(-2*t + d*(s + 2*t))) - 2^(1 + d)*(2 - d)*Pi^d*
       (s*t + mw^2*(s + 2*t))*(gZlR*gZlRC*(2*(-4 + d)*s*(s + t) + 
          (-2 + d)*mw^2*((-2 + d)*s + 2*t)) - gZlL*gZlLC*
         ((-2 + d)*mw^2*((-4 + d)*s - 2*t) + 2*s*((-2 + d)*s - 
            (-4 + d)*t))) + (2 - d)*(2*Pi)^d*s^2*
       (gZlR*gZlRC*(2*(-2 + d)*mw^4 + mw^2*((-80 + 60*d - 14*d^2 + d^3)*s + 
            2*(-52 + 44*d - 12*d^2 + d^3)*t) - 2*(-2 + d)*
           ((-4 + d)*s^2 + 2*(-4 + d)*s*t - t^2)) + 
        gZlL*gZlLC*(2*(-2 + d)*mw^4 + mw^2*(-((-40 + 40*d - 12*d^2 + d^3)*
              s) - 2*(-56 + 46*d - 12*d^2 + d^3)*t) + 
          2*((-2 + d)^2*s^2 + 2*(10 - 6*d + d^2)*s*t + (-2 + d)*t^2))))*
     CKM[1, 1]*CKMC[1, 1]))/(2^(2*(1 + d))*(-2 + d)*Pi^(2*d)*(mz^2 - s)*s^2*
   (-mzC^2 + s)), 0, 
 ((I/16)*EL^6*
   ((2^(1 - 2*d)*gHHZZ*(gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 
           2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
         gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
             (8 - 5*d + d^2)*s*t + 2*t^2))) + gZlR*gZlRC*
        (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2)))))/
     Pi^(2*d) + 
    (gHZZ^2*(gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
            ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
         gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
             (8 - 5*d + d^2)*s*t - 2*t^2))) - gZlR*gZlRC*
        (gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - 
             (4 - 5*d + d^2)*s*t + 2*t^2)) + gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 
           2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + (8 - 5*d + d^2)*s*t + 2*t^2))))*
      (-1 + GaugeXi[Q]))/((-1 + d)*(2*Pi)^(2*d)*s) + 
    4*gHXZ^2*((2^(1 - d)*mh^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
             2*t))))/Pi^d - (2^(1 - 2*d)*mh^2*
        (-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - 
                t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)))) + 
         gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
           gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))))/
       Pi^(2*d) + (2^(1 - d)*(gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - 
           (-4 + d)*gZuR*gZuRC) + gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + 
           (-2 + d)*gZuR*gZuRC))*t*(mh^2 + s - mz^2*GaugeXi[Q]))/Pi^d + 
      ((gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(mh^2 - s + mz^2*GaugeXi[Q]))/
       (2*Pi)^d + (2^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*
        (gZuL*gZuLC + gZuR*gZuRC)*s*((4 - 3*d)*mh^2 + d*s - 
         d*mz^2*GaugeXi[Q]))/((-1 + d)*Pi^d) + 
      (4^(1 - d)*(gZlL*gZlLC*(-(gZuR*gZuRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*
               t + mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*
                 (2*s + t)))) + gZuL*gZuLC*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*
              t + mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))) + 
         gZlR*gZlRC*(-(gZuL*gZuLC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
              mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t)))) + 
           gZuR*gZuRC*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
             mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))) - 
         mz^2*(-(gZlR*gZlRC*(2^(2 + d)*gZuL*gZuLC*Pi^d - 2^(1 + d)*gZuR*gZuRC*
               Pi^d - d*gZuL*gZuLC*(2*Pi)^d + d*gZuR*gZuRC*(2*Pi)^d)) + 
           gZlL*gZlLC*(2^(1 + d)*gZuL*gZuLC*Pi^d - 2^(2 + d)*gZuR*gZuRC*
              Pi^d - d*gZuL*gZuLC*(2*Pi)^d + d*gZuR*gZuRC*(2*Pi)^d))*t*
          GaugeXi[Q]))/Pi^(2*d) + 
      ((-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        (mh^2*(4*s - 3*d*s + 2*t) + s*(d*s + 2*t) - mz^2*(d*s + 2*t)*
          GaugeXi[Q]))/((-1 + d)*(2*Pi)^d*s) - 
      (gZlL*gZlLC*(-(gZuR*gZuRC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((2 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + t)))) + gZuL*gZuLC*
           (s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
            mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
        gZlR*gZlRC*(-(gZuL*gZuLC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((2 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + t)))) + gZuR*gZuRC*
           (s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
            mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
        mz^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + t)))) + gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q])/(2*Pi)^(2*d))))/
  ((mz^2 - s)^2*(-mzC^2 + s)), 
 ((-I/2)*(-2 + d)*EL^6*
   ((2^(1 - d)*gAl^3*gAu*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     (Pi^d*s^2) - (gAl^2*(gZlL + gZlR)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((2*Pi)^d*(mz^2 - s)*s) - (gAl*gAu*(gZlL + gZlR)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((2*Pi)^d*(mz^2 - s)*s) + 
    ((gZlL^2 + gZlR^2)*
      (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/((2*Pi)^d*(mz^2 - s)^2)))/((-1 + d)*(-mzC^2 + s)), 
 (I*4^(-1 - 2*d)*EL^6*((2^(1 + 3*d)*gAl^3*gAu*Pi^(3*d)*(4*ml^2 + (-2 + d)*s)*
      (-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2)) - 
       gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*s^2) - (gAl^2*(gZlL + gZlR)*(2*Pi)^(3*d)*(4*ml^2 + (-2 + d)*s)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*(mz^2 - s)*s) - (gAl*gAu*(gZlL + gZlR)*(2*Pi)^(3*d)*
      (4*ml^2 + (-2 + d)*s)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*(mz^2 - s)*s) - 
    (-((2^(1 + 3*d)*(gZlL^2 + gZlR^2)*(gZlL*gZlLC + gZlR*gZlRC)*
         (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*s*(4*(-1 + d)*ml^4 - 4*d*ml^2*s + 
          d*s^2))/(-1 + d)) + ((gZlL^2 + gZlR^2)*(2*Pi)^(3*d)*
        (4*(-1 + d)*ml^4 - 4*ml^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
           gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 
             2*t))))/(-1 + d) + gZlR^3*gZlRC*
       (gZuR*gZuRC*(-(2^(2 + 3*d)*ml^4*Pi^(3*d)*((-2 + d)*s - 2*t)) + 
          (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 - 2*(-4 + d)^2*s*t - 4*t^2) - 
          2^(1 + 3*d)*ml^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*
             s*t - 4*t^2)) + gZuL*gZuLC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*
           ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*ml^2*Pi^(3*d)*
           ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
          (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
            4*t^2))) - gZlL^3*gZlLC*
       (-(gZuR*gZuRC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
           2^(1 + 3*d)*ml^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
             2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
            ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2))) + 
        gZuL*gZuLC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
          2^(1 + 3*d)*ml^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*
             s*t - 4*t^2) + (2*Pi)^(3*d)*s*(-((8 - 6*d + d^2)*s^2) + 
            2*(-4 + d)^2*s*t + 4*t^2))) + 2^(1 + 3*d)*Pi^(3*d)*(ml^2 - s/2)*
       (gZlL*gZlLC*gZlR^2*(gZuR*gZuRC*((-4 + d)*s*((-2 + d)*s - 2*t) - 
            2*ml^2*((-4 + d)*s + 2*t)) + gZuL*gZuLC*
           (2*ml^2*((-2 + d)*s - 2*t) - s*((-2 + d)^2*s + 2*(-4 + d)*t))) - 
        gZlL^2*gZlR*gZlRC*(gZuL*gZuLC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
            2*ml^2*((-4 + d)*s + 2*t)) + gZuR*gZuRC*
           (ml^2*(-2*(-2 + d)*s + 4*t) + s*((-2 + d)^2*s + 2*(-4 + d)*t))) - 
        gZlR^3*gZlRC*(gZuR*gZuRC*(-((-2 + d)*s*((-4 + d)*s + 2*t)) + 
            ml^2*(-2*(-2 + d)*s + 4*t)) + gZuL*gZuLC*
           (2*ml^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t))) + 
        gZlL^3*gZlLC*(gZuL*gZuLC*(2*ml^2*((-2 + d)*s - 2*t) + 
            (-2 + d)*s*((-4 + d)*s + 2*t)) - gZuR*gZuRC*
           (2*ml^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t)))) - 
      gZlL*gZlR^2*(2^(2 + 3*d)*gZlRC*ml^2*Pi^(3*d)*
         (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
             4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
            4*t^2)) + gZlLC*(-(gZuR*gZuRC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*
              ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*ml^2*Pi^(3*d)*((8 - 6*d + d^2)*
                s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
              ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2))) + 
          gZuL*gZuLC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
            (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
              4*t^2) - 2^(1 + 3*d)*ml^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
              2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
      gZlL^2*gZlR*(-(2^(2 + 3*d)*gZlLC*ml^2*Pi^(3*d)*
          (-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
              4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
             4*t^2))) + gZlRC*(gZuL*gZuLC*(2^(2 + 3*d)*ml^4*Pi^(3*d)*
             ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*ml^2*Pi^(3*d)*
             ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
            (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
              4*t^2)) + gZuR*gZuRC*(-(2^(2 + 3*d)*ml^4*Pi^(3*d)*
              ((-2 + d)*s - 2*t)) - (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 
              2*(-2 + d)^2*s*t + 4*t^2) + 2^(1 + 3*d)*ml^2*Pi^(3*d)*
             ((16 - 14*d + 3*d^2)*s^2 + 2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
      2^(1 + 2*d)*Pi^(2*d)*(ml^2 - s/2)*(2^(2 + d)*(gZlL^2 + gZlR^2)*
         (gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*ml^2*Pi^d*s + 
        (gZlL^2 + gZlR^2)*ml^2*(2*Pi)^d*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - (gZlL^2 + gZlR^2)*(2*Pi)^d*s*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) + (gZlL^2 + gZlR^2)*ml^2*(2*Pi)^d*
         (-(gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
             2*gZuR*gZuRC*(3*s + t))) + gZlL*gZlLC*
           (gZuL*gZuLC*((-6 + d)*s - 2*t) - gZuR*gZuRC*(d*s + 2*t))) + 
        (gZlL^2 - gZlR^2)*s*(gZlL*gZlLC*(gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(3*s + (-3 + d)*t)) + gZuR*gZuRC*
             ((-5 + d)*d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*((-6 + d)*s + 
                (-3 + d)*t))) + gZlR*gZlRC*
           (-(gZuR*gZuRC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (3*s + (-3 + d)*t))) + gZuL*gZuLC*(-((-5 + d)*d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*((-6 + d)*s + (-3 + d)*t))))))/(mz^2 - s)^2))/
  (Pi^(4*d)*(-mzC^2 + s)), (((-3*I)/2)*(-2 + d)*EL^6*
   ((2^(1 - d)*gAl*gAu^3*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     (Pi^d*s^2) - (gAl*gAu*(gZuL + gZuR)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((2*Pi)^d*(mz^2 - s)*s) - (gAu^2*(gZuL + gZuR)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((2*Pi)^d*(mz^2 - s)*s) + 
    ((gZuL^2 + gZuR^2)*
      (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/((2*Pi)^d*(mz^2 - s)^2)))/((-1 + d)*(-mzC^2 + s)), 
 (I*4^(-1 - 2*d)*EL^6*((3*2^(1 + 3*d)*gAl*gAu^3*Pi^(3*d)*
      (4*mc^2 + (-2 + d)*s)*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*s^2) - (3*gAl*gAu*(gZuL + gZuR)*(2*Pi)^(3*d)*
      (4*mc^2 + (-2 + d)*s)*(-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuR*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*(mz^2 - s)*s) - (3*gAu^2*(gZuL + gZuR)*(2*Pi)^(3*d)*
      (4*mc^2 + (-2 + d)*s)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*(mz^2 - s)*s) - 
    ((-3*2^(1 + 3*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL^2 + gZuR^2)*
        (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*s*(4*(-1 + d)*mc^4 - 4*d*mc^2*s + 
         d*s^2))/(-1 + d) + (3*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
        (4*(-1 + d)*mc^4 - 4*mc^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
           gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 
             2*t))))/(-1 + d) + 3*2^(1 + 3*d)*Pi^(3*d)*(mc^2 - s/2)*
       (-(gZlR*gZlRC*(gZuL^3*gZuLC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
             2*mc^2*((-4 + d)*s + 2*t)) - gZuR^3*gZuRC*
            (2*mc^2*((-2 + d)*s - 2*t) + (-2 + d)*s*((-4 + d)*s + 2*t)) - 
           gZuL^2*gZuR*gZuRC*(2*mc^2*((-2 + d)*s - 2*t) - 
             s*((-2 + d)^2*s + 2*(-4 + d)*t)) + gZuL*gZuLC*gZuR^2*
            (2*mc^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t)))) + 
        gZlL*gZlLC*(-(gZuR^3*gZuRC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
             2*mc^2*((-4 + d)*s + 2*t))) + gZuL^3*gZuLC*
           (2*mc^2*((-2 + d)*s - 2*t) + (-2 + d)*s*((-4 + d)*s + 2*t)) + 
          gZuL*gZuLC*gZuR^2*(2*mc^2*((-2 + d)*s - 2*t) - 
            s*((-2 + d)^2*s + 2*(-4 + d)*t)) - gZuL^2*gZuR*gZuRC*
           (2*mc^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t)))) - 
      3*gZlL*gZlLC*(-(gZuR^3*gZuRC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*
            ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*mc^2*Pi^(3*d)*
            ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
           (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
             4*t^2))) + gZuL^3*gZuLC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*
           ((-2 + d)*s - 2*t) + 2^(1 + 3*d)*mc^2*Pi^(3*d)*
           ((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2) + 
          (2*Pi)^(3*d)*s*(-((8 - 6*d + d^2)*s^2) + 2*(-4 + d)^2*s*t + 
            4*t^2)) + gZuL^2*gZuR*(2^(2 + 3*d)*gZuLC*mc^2*Pi^(3*d)*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
          gZuRC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
            2^(1 + 3*d)*mc^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + 
                d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
              2*(8 - 6*d + d^2)*s*t - 4*t^2))) + gZuL*gZuR^2*
         (-(2^(2 + 3*d)*gZuRC*mc^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
          gZuLC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
            (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
              4*t^2) - 2^(1 + 3*d)*mc^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
              2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
      3*gZlR*gZlRC*(gZuR^3*gZuRC*(-(2^(2 + 3*d)*mc^4*Pi^(3*d)*
            ((-2 + d)*s - 2*t)) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 - 
            2*(-4 + d)^2*s*t - 4*t^2) - 2^(1 + 3*d)*mc^2*Pi^(3*d)*
           ((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2)) + 
        gZuL^3*gZuLC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
          2^(1 + 3*d)*mc^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*
             s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
            2*(8 - 6*d + d^2)*s*t - 4*t^2)) + gZuL*gZuR^2*
         (-(2^(2 + 3*d)*gZuRC*mc^2*Pi^(3*d)*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
          gZuLC*(2^(2 + 3*d)*mc^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
            2^(1 + 3*d)*mc^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + 
                d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
              2*(8 - 6*d + d^2)*s*t - 4*t^2))) + gZuL^2*gZuR*
         (2^(2 + 3*d)*gZuLC*mc^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
          gZuRC*(-(2^(2 + 3*d)*mc^4*Pi^(3*d)*((-2 + d)*s - 2*t)) - 
            (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
              4*t^2) + 2^(1 + 3*d)*mc^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
              2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 2^(1 + 2*d)*Pi^(2*d)*
       (mc^2 - s/2)*(3*2^(2 + d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL^2 + gZuR^2)*
         (gZuL*gZuLC + gZuR*gZuRC)*mc^2*Pi^d*s + 3*(gZuL^2 + gZuR^2)*mc^2*
         (2*Pi)^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZuL^2 + gZuR^2)*(2*Pi)^d*s*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZuL^2 + gZuR^2)*mc^2*(2*Pi)^d*
         (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
            2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
           (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))) + 
        (gZuL^2 - gZuR^2)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-5 + d)*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*((18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + 
            gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (9 - 5*d + d^2)*s + 3*(-3 + d)*t))) - 
          gZlR*gZlRC*(gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + gZuR*gZuRC*
             ((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((9 - 5*d + d^2)*s + 
                3*(-3 + d)*t))))))/(mz^2 - s)^2))/(Pi^(4*d)*(-mzC^2 + s)), 
 (((-3*I)/2)*(-2 + d)*EL^6*
   ((2^(1 - d)*gAl*gAu^3*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     (Pi^d*s^2) - (gAl*gAu*(gZuL + gZuR)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((2*Pi)^d*(mz^2 - s)*s) - (gAu^2*(gZuL + gZuR)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((2*Pi)^d*(mz^2 - s)*s) + 
    ((gZuL^2 + gZuR^2)*
      (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/((2*Pi)^d*(mz^2 - s)^2)))/((-1 + d)*(-mzC^2 + s)), 
 (I*4^(-1 - 2*d)*EL^6*((3*2^(1 + 3*d)*gAl*gAu^3*Pi^(3*d)*
      (4*mt^2 + (-2 + d)*s)*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*s^2) - (3*gAl*gAu*(gZuL + gZuR)*(2*Pi)^(3*d)*
      (4*mt^2 + (-2 + d)*s)*(-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuR*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((-1 + d)*(mz^2 - s)*s) - (3*gAu^2*(gZuL + gZuR)*(2*Pi)^(3*d)*
      (4*mt^2 + (-2 + d)*s)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((-1 + d)*(mz^2 - s)*s) - 
    ((-3*2^(1 + 3*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL^2 + gZuR^2)*
        (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*s*(4*(-1 + d)*mt^4 - 4*d*mt^2*s + 
         d*s^2))/(-1 + d) + (3*(gZuL^2 + gZuR^2)*(2*Pi)^(3*d)*
        (4*(-1 + d)*mt^4 - 4*mt^2*(d*s + 2*t) + s*(d*s + 2*t))*
        (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
           gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
          (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 
             2*t))))/(-1 + d) + 3*2^(1 + 3*d)*Pi^(3*d)*(mt^2 - s/2)*
       (-(gZlR*gZlRC*(gZuL^3*gZuLC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
             2*mt^2*((-4 + d)*s + 2*t)) - gZuR^3*gZuRC*
            (2*mt^2*((-2 + d)*s - 2*t) + (-2 + d)*s*((-4 + d)*s + 2*t)) - 
           gZuL^2*gZuR*gZuRC*(2*mt^2*((-2 + d)*s - 2*t) - 
             s*((-2 + d)^2*s + 2*(-4 + d)*t)) + gZuL*gZuLC*gZuR^2*
            (2*mt^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t)))) + 
        gZlL*gZlLC*(-(gZuR^3*gZuRC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
             2*mt^2*((-4 + d)*s + 2*t))) + gZuL^3*gZuLC*
           (2*mt^2*((-2 + d)*s - 2*t) + (-2 + d)*s*((-4 + d)*s + 2*t)) + 
          gZuL*gZuLC*gZuR^2*(2*mt^2*((-2 + d)*s - 2*t) - 
            s*((-2 + d)^2*s + 2*(-4 + d)*t)) - gZuL^2*gZuR*gZuRC*
           (2*mt^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*t)))) - 
      3*gZlL*gZlLC*(-(gZuR^3*gZuRC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*
            ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*mt^2*Pi^(3*d)*
            ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
           (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
             4*t^2))) + gZuL^3*gZuLC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*
           ((-2 + d)*s - 2*t) + 2^(1 + 3*d)*mt^2*Pi^(3*d)*
           ((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2) + 
          (2*Pi)^(3*d)*s*(-((8 - 6*d + d^2)*s^2) + 2*(-4 + d)^2*s*t + 
            4*t^2)) + gZuL^2*gZuR*(2^(2 + 3*d)*gZuLC*mt^2*Pi^(3*d)*
           ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
          gZuRC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
            2^(1 + 3*d)*mt^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + 
                d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
              2*(8 - 6*d + d^2)*s*t - 4*t^2))) + gZuL*gZuR^2*
         (-(2^(2 + 3*d)*gZuRC*mt^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
             2*(4 - 5*d + d^2)*s*t - 4*t^2)) + 
          gZuLC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
            (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
              4*t^2) - 2^(1 + 3*d)*mt^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
              2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
      3*gZlR*gZlRC*(gZuR^3*gZuRC*(-(2^(2 + 3*d)*mt^4*Pi^(3*d)*
            ((-2 + d)*s - 2*t)) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 - 
            2*(-4 + d)^2*s*t - 4*t^2) - 2^(1 + 3*d)*mt^2*Pi^(3*d)*
           ((8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2)) + 
        gZuL^3*gZuLC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
          2^(1 + 3*d)*mt^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*
             s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
            2*(8 - 6*d + d^2)*s*t - 4*t^2)) + gZuL*gZuR^2*
         (-(2^(2 + 3*d)*gZuRC*mt^2*Pi^(3*d)*((-2 + d)^2*s^2 + 
             2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
          gZuLC*(2^(2 + 3*d)*mt^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
            2^(1 + 3*d)*mt^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + 
                d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 
              2*(8 - 6*d + d^2)*s*t - 4*t^2))) + gZuL^2*gZuR*
         (2^(2 + 3*d)*gZuLC*mt^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
          gZuRC*(-(2^(2 + 3*d)*mt^4*Pi^(3*d)*((-2 + d)*s - 2*t)) - 
            (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
              4*t^2) + 2^(1 + 3*d)*mt^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
              2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 2^(1 + 2*d)*Pi^(2*d)*
       (mt^2 - s/2)*(3*2^(2 + d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL^2 + gZuR^2)*
         (gZuL*gZuLC + gZuR*gZuRC)*mt^2*Pi^d*s + 3*(gZuL^2 + gZuR^2)*mt^2*
         (2*Pi)^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZuL^2 + gZuR^2)*(2*Pi)^d*s*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZuL^2 + gZuR^2)*mt^2*(2*Pi)^d*
         (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
            2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
           (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))) + 
        (gZuL^2 - gZuR^2)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-5 + d)*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*((18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + 
            gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (9 - 5*d + d^2)*s + 3*(-3 + d)*t))) - 
          gZlR*gZlRC*(gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + gZuR*gZuRC*
             ((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((9 - 5*d + d^2)*s + 
                3*(-3 + d)*t))))))/(mz^2 - s)^2))/(Pi^(4*d)*(-mzC^2 + s)), 
 (((-3*I)/2)*(-2 + d)*EL^6*
   ((2^(1 - d)*gAd^2*gAl*gAu*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     (Pi^d*s^2) - (gAd*gAl*(gZdL + gZdR)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((2*Pi)^d*(mz^2 - s)*s) - (gAd*gAu*(gZdL + gZdR)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((2*Pi)^d*(mz^2 - s)*s) + 
    ((gZdL^2 + gZdR^2)*
      (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/((2*Pi)^d*(mz^2 - s)^2)))/((-1 + d)*(-mzC^2 + s)), 
 (I*4^(-1 - 2*d)*EL^6*(3*2^(1 + 3*d)*gAd^2*gAl*gAu*Pi^(3*d)*(mz^2 - s)^2*
     (4*ms^2 + (-2 + d)*s)*(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*gZuLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2) - gZlRC*gZuRC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2)) - 3*gAd*gAl*(gZdL + gZdR)*
     (2*Pi)^(3*d)*(mz^2 - s)*s*(4*ms^2 + (-2 + d)*s)*
     (gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) + gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*gZuL*gZuLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
    3*gAd*gAu*(gZdL + gZdR)*(2*Pi)^(3*d)*(mz^2 - s)*s*(4*ms^2 + (-2 + d)*s)*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))) - 
    s^2*(3*2^(1 + 3*d)*(gZdL^2 + gZdR^2)*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*s*(4*(-1 + d)*ms^4 - 4*d*ms^2*s + 
        d*s^2) - 3*(gZdL^2 + gZdR^2)*(2*Pi)^(3*d)*(4*(-1 + d)*ms^4 - 
        4*ms^2*(d*s + 2*t) + s*(d*s + 2*t))*
       (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
          gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
         (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 
            2*t))) + 2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(ms^2 - s/2)*
       (3*2^(2 + d)*(gZdL^2 + gZdR^2)*(gZlL*gZlLC + gZlR*gZlRC)*
         (gZuL*gZuLC + gZuR*gZuRC)*ms^2*Pi^d*s + 3*(gZdL^2 + gZdR^2)*ms^2*
         (2*Pi)^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZdL^2 + gZdR^2)*(2*Pi)^d*s*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZdL^2 + gZdR^2)*ms^2*(2*Pi)^d*
         (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
            2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
           (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))) + 
        (gZdL^2 - gZdR^2)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-5 + d)*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*((18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + 
            gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (9 - 5*d + d^2)*s + 3*(-3 + d)*t))) - 
          gZlR*gZlRC*(gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + gZuR*gZuRC*
             ((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((9 - 5*d + d^2)*s + 
                3*(-3 + d)*t))))) + 3*2^(1 + 3*d)*(1 - d)*Pi^(3*d)*
       (ms^2 - s/2)*(gZdR^2*(gZlL*gZlLC*gZuR*gZuRC*
           ((-4 + d)*s*((-2 + d)*s - 2*t) - 2*ms^2*((-4 + d)*s + 2*t)) + 
          gZlR*gZlRC*gZuR*gZuRC*(2*ms^2*((-2 + d)*s - 2*t) + 
            (-2 + d)*s*((-4 + d)*s + 2*t)) + gZlL*gZlLC*gZuL*gZuLC*
           (2*ms^2*((-2 + d)*s - 2*t) - s*((-2 + d)^2*s + 2*(-4 + d)*t)) - 
          gZlR*gZlRC*gZuL*gZuLC*(2*ms^2*((-4 + d)*s + 2*t) + 
            s*((-4 + d)^2*s - 2*(-2 + d)*t))) + 
        gZdL^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
               2*ms^2*((-4 + d)*s + 2*t)) + gZuR*gZuRC*(ms^2*(-2*(-2 + d)*s + 
                 4*t) + s*((-2 + d)^2*s + 2*(-4 + d)*t)))) + 
          gZlL*gZlLC*(gZuL*gZuLC*(2*ms^2*((-2 + d)*s - 2*t) + 
              (-2 + d)*s*((-4 + d)*s + 2*t)) - gZuR*gZuRC*
             (2*ms^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*
                 t))))) - 3*(1 - d)*(2^(2 + 3*d)*gZdL*gZdR*ms^2*Pi^(3*d)*
         (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
                t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
               s*t + 4*t^2)) + gZlR*gZlRC*
           (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*
                t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
              4*t^2))) + gZdR^2*
         (-(gZlR*gZlRC*(gZuR*gZuRC*(-(2^(2 + 3*d)*ms^4*Pi^(3*d)*((-2 + d)*s - 
                  2*t)) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 - 2*(-4 + d)^2*
                  s*t - 4*t^2) - 2^(1 + 3*d)*ms^2*Pi^(3*d)*((8 - 6*d + d^2)*
                  s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2)) + 
             gZuL*gZuLC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
               2^(1 + 3*d)*ms^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
                 2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
                ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2)))) + 
          gZlL*gZlLC*(-(gZuR*gZuRC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*((-4 + d)*s + 
                 2*t) - 2^(1 + 3*d)*ms^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
                 2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
                ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2))) + 
            gZuL*gZuLC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
              (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
                4*t^2) - 2^(1 + 3*d)*ms^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
                2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
        gZdL^2*(gZlL*gZlLC*(-(gZuR*gZuRC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*
                ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*ms^2*Pi^(3*d)*
                ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
               (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
                 4*t^2))) + gZuL*gZuLC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*(
                (-2 + d)*s - 2*t) + 2^(1 + 3*d)*ms^2*Pi^(3*d)*(
                (8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2) + 
              (2*Pi)^(3*d)*s*(-((8 - 6*d + d^2)*s^2) + 2*(-4 + d)^2*s*t + 
                4*t^2))) - gZlR*gZlRC*(gZuL*gZuLC*(2^(2 + 3*d)*ms^4*Pi^(3*d)*(
                (-4 + d)*s + 2*t) - 2^(1 + 3*d)*ms^2*Pi^(3*d)*(
                (8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
              (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
                4*t^2)) + gZuR*gZuRC*(-(2^(2 + 3*d)*ms^4*Pi^(3*d)*
                ((-2 + d)*s - 2*t)) - (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*
                 s^2 + 2*(-2 + d)^2*s*t + 4*t^2) + 2^(1 + 3*d)*ms^2*Pi^(3*d)*(
                (16 - 14*d + 3*d^2)*s^2 + 2*(6 - 5*d + d^2)*s*t + 
                4*t^2))))))))/((-1 + d)*Pi^(4*d)*(mz^2 - s)^2*(mzC^2 - s)*
   s^2), (((-3*I)/2)*(-2 + d)*EL^6*
   ((2^(1 - d)*gAd^2*gAl*gAu*(-(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
          2*(4 - 5*d + d^2)*s*t - 4*t^2)) - gZlLC*gZuRC*
        ((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*t^2) + 
       gZlLC*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     (Pi^d*s^2) - (gAd*gAl*(gZdL + gZdR)*
      (-(gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
          4*t^2)) - gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
         2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuL*gZuLC*
        ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) + 
       gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)))/
     ((2*Pi)^d*(mz^2 - s)*s) - (gAd*gAu*(gZdL + gZdR)*
      (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
            2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
           2*(8 - 5*d + d^2)*s*t + 4*t^2))))/((2*Pi)^d*(mz^2 - s)*s) + 
    ((gZdL^2 + gZdR^2)*
      (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
             t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*
            t + 4*t^2)) + gZlR*gZlRC*
        (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
            4*t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
           4*t^2))))/((2*Pi)^d*(mz^2 - s)^2)))/((-1 + d)*(-mzC^2 + s)), 
 (I*4^(-1 - 2*d)*EL^6*(3*2^(1 + 3*d)*gAd^2*gAl*gAu*Pi^(3*d)*(mz^2 - s)^2*
     (4*mb^2 + (-2 + d)*s)*(gZlRC*gZuLC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) + gZlLC*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*gZuLC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2) - gZlRC*gZuRC*((-2 + d)^2*s^2 + 
        2*(8 - 5*d + d^2)*s*t + 4*t^2)) - 3*gAd*gAl*(gZdL + gZdR)*
     (2*Pi)^(3*d)*(mz^2 - s)*s*(4*mb^2 + (-2 + d)*s)*
     (gZlRC*gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
        4*t^2) + gZlLC*gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 
        2*(4 - 5*d + d^2)*s*t - 4*t^2) - gZlLC*gZuL*gZuLC*
       ((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2) - 
      gZlRC*gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 4*t^2)) + 
    3*gAd*gAu*(gZdL + gZdR)*(2*Pi)^(3*d)*(mz^2 - s)*s*(4*mb^2 + (-2 + d)*s)*
     (gZlL*gZlLC*(-(gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 
           4*t^2)) + gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
          4*t^2)) + gZlR*gZlRC*(-(gZuLC*((8 - 6*d + d^2)*s^2 + 
           2*(4 - 5*d + d^2)*s*t - 4*t^2)) + gZuRC*((-2 + d)^2*s^2 + 
          2*(8 - 5*d + d^2)*s*t + 4*t^2))) - 
    s^2*(3*2^(1 + 3*d)*(gZdL^2 + gZdR^2)*(gZlL*gZlLC + gZlR*gZlRC)*
       (gZuL*gZuLC + gZuR*gZuRC)*Pi^(3*d)*s*(4*(-1 + d)*mb^4 - 4*d*mb^2*s + 
        d*s^2) - 3*(gZdL^2 + gZdR^2)*(2*Pi)^(3*d)*(4*(-1 + d)*mb^4 - 
        4*mb^2*(d*s + 2*t) + s*(d*s + 2*t))*
       (gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
          gZuL*gZuLC*((-2 + d)*s + 2*t)) + gZlL*gZlLC*
         (gZuL*gZuLC*(-((-4 + d)*s) + 2*t) + gZuR*gZuRC*((-2 + d)*s + 
            2*t))) + 2^(1 + 2*d)*(1 - d)*Pi^(2*d)*(mb^2 - s/2)*
       (3*2^(2 + d)*(gZdL^2 + gZdR^2)*(gZlL*gZlLC + gZlR*gZlRC)*
         (gZuL*gZuLC + gZuR*gZuRC)*mb^2*Pi^d*s + 3*(gZdL^2 + gZdR^2)*mb^2*
         (2*Pi)^d*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
            gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZdL^2 + gZdR^2)*(2*Pi)^d*s*
         (gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
             ((-4 + d)*s + 2*t)) - gZlR*gZlRC*
           (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 
              2*t))) - 3*(gZdL^2 + gZdR^2)*mb^2*(2*Pi)^d*
         (gZlR*gZlRC*(d*(gZuL*gZuLC - gZuR*gZuRC)*s + 2*gZuL*gZuLC*t + 
            2*gZuR*gZuRC*(3*s + t)) + gZlL*gZlLC*
           (gZuL*gZuLC*(-((-6 + d)*s) + 2*t) + gZuR*gZuRC*(d*s + 2*t))) + 
        (gZdL^2 - gZdR^2)*s*(gZlL*gZlLC*(gZuR*gZuRC*((-5 + d)*d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*((18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + 
            gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (9 - 5*d + d^2)*s + 3*(-3 + d)*t))) - 
          gZlR*gZlRC*(gZuL*gZuLC*((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(
                (18 - 8*d + d^2)*s - 3*(-3 + d)*t)) + gZuR*gZuRC*
             ((-5 + d)*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((9 - 5*d + d^2)*s + 
                3*(-3 + d)*t))))) + 3*2^(1 + 3*d)*(1 - d)*Pi^(3*d)*
       (mb^2 - s/2)*(gZdR^2*(gZlL*gZlLC*gZuR*gZuRC*
           ((-4 + d)*s*((-2 + d)*s - 2*t) - 2*mb^2*((-4 + d)*s + 2*t)) + 
          gZlR*gZlRC*gZuR*gZuRC*(2*mb^2*((-2 + d)*s - 2*t) + 
            (-2 + d)*s*((-4 + d)*s + 2*t)) + gZlL*gZlLC*gZuL*gZuLC*
           (2*mb^2*((-2 + d)*s - 2*t) - s*((-2 + d)^2*s + 2*(-4 + d)*t)) - 
          gZlR*gZlRC*gZuL*gZuLC*(2*mb^2*((-4 + d)*s + 2*t) + 
            s*((-4 + d)^2*s - 2*(-2 + d)*t))) + 
        gZdL^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-((-4 + d)*s*((-2 + d)*s - 2*t)) + 
               2*mb^2*((-4 + d)*s + 2*t)) + gZuR*gZuRC*(mb^2*(-2*(-2 + d)*s + 
                 4*t) + s*((-2 + d)^2*s + 2*(-4 + d)*t)))) + 
          gZlL*gZlLC*(gZuL*gZuLC*(2*mb^2*((-2 + d)*s - 2*t) + 
              (-2 + d)*s*((-4 + d)*s + 2*t)) - gZuR*gZuRC*
             (2*mb^2*((-4 + d)*s + 2*t) + s*((-4 + d)^2*s - 2*(-2 + d)*
                 t))))) - 3*(1 - d)*(2^(2 + 3*d)*gZdL*gZdR*mb^2*Pi^(3*d)*
         (gZlL*gZlLC*(-(gZuR*gZuRC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*
                t - 4*t^2)) + gZuL*gZuLC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*
               s*t + 4*t^2)) + gZlR*gZlRC*
           (-(gZuL*gZuLC*((8 - 6*d + d^2)*s^2 + 2*(4 - 5*d + d^2)*s*t - 4*
                t^2)) + gZuR*gZuRC*((-2 + d)^2*s^2 + 2*(8 - 5*d + d^2)*s*t + 
              4*t^2))) + gZdR^2*
         (-(gZlR*gZlRC*(gZuR*gZuRC*(-(2^(2 + 3*d)*mb^4*Pi^(3*d)*((-2 + d)*s - 
                  2*t)) + (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 - 2*(-4 + d)^2*
                  s*t - 4*t^2) - 2^(1 + 3*d)*mb^2*Pi^(3*d)*((8 - 6*d + d^2)*
                  s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2)) + 
             gZuL*gZuLC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*((-4 + d)*s + 2*t) - 
               2^(1 + 3*d)*mb^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
                 2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
                ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2)))) + 
          gZlL*gZlLC*(-(gZuR*gZuRC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*((-4 + d)*s + 
                 2*t) - 2^(1 + 3*d)*mb^2*Pi^(3*d)*((8 - 6*d + d^2)*s^2 + 
                 2*(12 - 7*d + d^2)*s*t - 4*t^2) + (2*Pi)^(3*d)*s*
                ((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 4*t^2))) + 
            gZuL*gZuLC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*((-2 + d)*s - 2*t) + 
              (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*s^2 + 2*(-2 + d)^2*s*t + 
                4*t^2) - 2^(1 + 3*d)*mb^2*Pi^(3*d)*((16 - 14*d + 3*d^2)*s^2 + 
                2*(6 - 5*d + d^2)*s*t + 4*t^2)))) + 
        gZdL^2*(gZlL*gZlLC*(-(gZuR*gZuRC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*
                ((-4 + d)*s + 2*t) - 2^(1 + 3*d)*mb^2*Pi^(3*d)*
                ((8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
               (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
                 4*t^2))) + gZuL*gZuLC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*(
                (-2 + d)*s - 2*t) + 2^(1 + 3*d)*mb^2*Pi^(3*d)*(
                (8 - 6*d + d^2)*s^2 - 2*(18 - 9*d + d^2)*s*t - 4*t^2) + 
              (2*Pi)^(3*d)*s*(-((8 - 6*d + d^2)*s^2) + 2*(-4 + d)^2*s*t + 
                4*t^2))) - gZlR*gZlRC*(gZuL*gZuLC*(2^(2 + 3*d)*mb^4*Pi^(3*d)*(
                (-4 + d)*s + 2*t) - 2^(1 + 3*d)*mb^2*Pi^(3*d)*(
                (8 - 6*d + d^2)*s^2 + 2*(12 - 7*d + d^2)*s*t - 4*t^2) + 
              (2*Pi)^(3*d)*s*((8 - 6*d + d^2)*s^2 + 2*(8 - 6*d + d^2)*s*t - 
                4*t^2)) + gZuR*gZuRC*(-(2^(2 + 3*d)*mb^4*Pi^(3*d)*
                ((-2 + d)*s - 2*t)) - (2*Pi)^(3*d)*s*((16 - 14*d + 3*d^2)*
                 s^2 + 2*(-2 + d)^2*s*t + 4*t^2) + 2^(1 + 3*d)*mb^2*Pi^(3*d)*(
                (16 - 14*d + 3*d^2)*s^2 + 2*(6 - 5*d + d^2)*s*t + 
                4*t^2))))))))/((-1 + d)*Pi^(4*d)*(mz^2 - s)^2*(mzC^2 - s)*
   s^2), (-I/16)*EL^6*
  ((gHZZ^2*(gZlL*gZlLC*(gZuR*gZuRC*(-(d^2*(2*Pi)^d*s^2) + 
          2^(1 + d)*Pi^d*((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuL*gZuLC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))) + 
      gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
           ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
        gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
            (8 - 5*d + d^2)*s*t + 2*t^2))))*(-mh^2 + s + mz^2*GaugeXi[Q]))/
    ((-1 + d)*(2*Pi)^(2*d)*(mzC^2 - s)*s*(mz^3 - mz*s)^2) + 
   (4*gHXZ^2*((2^(1 - 2*d)*mz^2*(gZlL*gZlLC*(-3*d*gZuL*gZuLC*(2*Pi)^d*s + 
           3*d*gZuR*gZuRC*(2*Pi)^d*s - 2^(1 + d)*gZuR*gZuRC*Pi^d*
            ((2 + d)*s - t) + 2^(1 + d)*gZuL*gZuLC*Pi^d*(s + d*s + t)) - 
         gZlR*gZlRC*(-3*d*gZuL*gZuLC*(2*Pi)^d*s + 3*d*gZuR*gZuRC*(2*Pi)^d*s + 
           2^(1 + d)*gZuL*gZuLC*Pi^d*((2 + d)*s - t) - 2^(1 + d)*gZuR*gZuRC*
            Pi^d*(s + d*s + t)))*GaugeXi[Q])/Pi^(2*d) - 
      (2^(1 - d)*mz^2*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        GaugeXi[Q])/Pi^d - 
      ((gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - gZuR*gZuRC*
            ((-4 + d)*s + 2*t)) - gZlR*gZlRC*(gZuL*gZuLC*((-4 + d)*s + 2*t) + 
           gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*(mh^2 - s + mz^2*GaugeXi[Q]))/
       (2*Pi)^d - (2^(1 - 2*d)*(gZlR*gZlRC*(gZuL*gZuLC*(2^(2 + d)*Pi^d - 
             d*(2*Pi)^d) + gZuR*gZuRC*(-(2^(1 + d)*Pi^d) + d*(2*Pi)^d)) - 
         gZlL*gZlLC*(gZuL*gZuLC*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
           gZuR*gZuRC*(-(2^(2 + d)*Pi^d) + d*(2*Pi)^d)))*t*
        (-mh^2 + s + mz^2*GaugeXi[Q]))/Pi^(2*d) + 
      (2^(1 - d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*s*
        (d*(mh^2 - s) + (-4 + 3*d)*mz^2*GaugeXi[Q]))/((-1 + d)*Pi^d) + 
      ((-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
            gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
          (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
        ((mh^2 - s)*(d*s + 2*t) + mz^2*((-4 + 3*d)*s - 2*t)*GaugeXi[Q]))/
       ((-1 + d)*(2*Pi)^d*s) + 
      (2^(2 - d)*(-((gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
            gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*
           (mh^2 - s)*t) + mz^2*(gZlR*gZlRC*(gZuR*gZuRC*((-2 + d)*s + 
               (-4 + d)*t) - gZuL*gZuLC*((-4 + d)*s + (-2 + d)*t)) + 
           gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s + (-4 + d)*t) - 
             gZuR*gZuRC*((-4 + d)*s + (-2 + d)*t)))*GaugeXi[Q]))/Pi^d + 
      (gZlL*gZlLC*(-(gZuR*gZuRC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((2 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + t)))) + gZuL*gZuLC*
           (s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
            mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
        gZlR*gZlRC*(-(gZuL*gZuLC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                ((2 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (-2*s + t)))) + gZuR*gZuRC*
           (s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
            mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
        mz^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                (2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + t)))) + gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
              2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
              2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q])/(2*Pi)^(2*d)))/
    ((mz^2 - s)^2*(-mzC^2 + s))), 
 (I*2^(-4 - 3*d)*EL^6*
   ((4*gHXZ^2*((2*Pi)^(2*d)*(gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s - 2*t) - 
           gZuR*gZuRC*((-4 + d)*s + 2*t)) - gZlR*gZlRC*
          (gZuL*gZuLC*((-4 + d)*s + 2*t) + gZuR*gZuRC*(-((-2 + d)*s) + 2*t)))*
        (mh^2 - s + mz^2*GaugeXi[Q])^2 - (2*Pi)^d*(mh^2 - s + 
         mz^2*GaugeXi[Q])*(gZlL*gZlLC*
          (-(gZuR*gZuRC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*((2 + d)*s - 
                  t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)))) + 
           gZuL*gZuLC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)) + 
             mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(s + d*s + t)))) + 
         gZlR*gZlRC*(-(gZuL*gZuLC*(mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                 ((2 + d)*s - t)) + s*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                 (-2*s + t)))) + gZuR*gZuRC*(s*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                (s + t)) + mh^2*(-3*d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*
                (s + d*s + t)))) + 
         mz^2*(-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
                 (2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
                 (s + t)))) + gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
               2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
               2^(1 + d)*Pi^d*(s + t))))*GaugeXi[Q]) - 
       (2^(1 + 2*d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*
         Pi^(2*d)*s*(d*(mh^2 - s)^2 + 2*mz^2*((-2 + d)*mh^2 - d*s)*
           GaugeXi[Q] + d*mz^4*GaugeXi[Q]^2))/(-1 + d) - 
       2*((gZlL*gZlLC*(-((-2 + d)*gZuL*gZuLC) + (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*((-4 + d)*gZuL*gZuLC - (-2 + d)*gZuR*gZuRC))*
          (2*Pi)^(2*d)*(mh^2 - s)^2*t + 2^(1 + 2*d)*mz^2*Pi^(2*d)*
          (gZlR*gZlRC*(gZuR*gZuRC*((-2 + d)*s*t + mh^2*((-2 + d)*s + 
                 (-4 + d)*t)) - gZuL*gZuLC*((-4 + d)*s*t + mh^2*((-4 + d)*s + 
                 (-2 + d)*t))) + gZlL*gZlLC*(gZuL*gZuLC*((-2 + d)*s*t + mh^2*
                ((-2 + d)*s + (-4 + d)*t)) - gZuR*gZuRC*((-4 + d)*s*t + mh^2*
                ((-4 + d)*s + (-2 + d)*t))))*GaugeXi[Q] - 
         (gZlL*gZlLC*((-2 + d)*gZuL*gZuLC - (-4 + d)*gZuR*gZuRC) + 
           gZlR*gZlRC*(-((-4 + d)*gZuL*gZuLC) + (-2 + d)*gZuR*gZuRC))*mz^4*
          (2*Pi)^(2*d)*t*GaugeXi[Q]^2) - 
       ((2*Pi)^(2*d)*(-(gZlR*gZlRC*(gZuR*gZuRC*(-((-4 + d)*s) + 2*t) + 
             gZuL*gZuLC*((-2 + d)*s + 2*t))) + gZlL*gZlLC*
           (gZuL*gZuLC*((-4 + d)*s - 2*t) - gZuR*gZuRC*((-2 + d)*s + 2*t)))*
         ((mh^2 - s)^2*(d*s + 2*t) + 2*mz^2*(mh^2*((-2 + d)*s - 2*t) - 
            s*(d*s + 2*t))*GaugeXi[Q] + mz^4*(d*s + 2*t)*GaugeXi[Q]^2))/
        ((-1 + d)*s)))/((mz^2 - s)^2*(-mzC^2 + s)) - 
    (gHZZ^2*(2*Pi)^d*(2*(1 - d)*s*
        (gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*
              (2*s - t)) + gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*
              (s + t))) - gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 
             2^(1 + d)*Pi^d*(-2*s + t)) + gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 
             2^(1 + d)*Pi^d*(s + t))))*(mh^2 - s + mz^2*GaugeXi[Q])^2 + 
       2^(1 + d)*(gZlL*gZlLC + gZlR*gZlRC)*(gZuL*gZuLC + gZuR*gZuRC)*Pi^d*s^2*
        (d*(mh^2 - s)^2 + 2*mz^2*((-2 + d)*mh^2 - d*s)*GaugeXi[Q] + 
         d*mz^4*GaugeXi[Q]^2) - 2*(1 - d)*s*
        ((gZlR*gZlRC*(gZuR*gZuRC*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d) + 
               2^(1 + d)*(-2 + d)*mh^2*Pi^d*s + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*
                s^2) - gZuL*gZuLC*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 
               2^(1 + d)*(-4 + d)*mh^2*Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*
                s^2)) + gZlL*gZlLC*(gZuL*gZuLC*(mh^4*(2^(1 + d)*Pi^d - 
                 d*(2*Pi)^d) + 2^(1 + d)*(-2 + d)*mh^2*Pi^d*s + 
               (2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2) - gZuR*gZuRC*
              (mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d) + 2^(1 + d)*(-4 + d)*mh^2*
                Pi^d*s + (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2)))*t + 
         2*mz^2*(gZlL*gZlLC*(gZuR*gZuRC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + 
               mh^2*(-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t))) - 
             gZuL*gZuLC*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + mh^2*
                (-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))) + 
           gZlR*gZlRC*(gZuL*gZuLC*((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s*t + mh^2*
                (-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(2*s + t))) - 
             gZuR*gZuRC*((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s*t + mh^2*
                (-(d*(2*Pi)^d*(s + t)) + 2^(1 + d)*Pi^d*(s + 2*t)))))*
          GaugeXi[Q] + mz^4*(-(gZlR*gZlRC*(2^(2 + d)*gZuL*gZuLC*Pi^d - 
              2^(1 + d)*gZuR*gZuRC*Pi^d - d*gZuL*gZuLC*(2*Pi)^d + 
              d*gZuR*gZuRC*(2*Pi)^d)) + gZlL*gZlLC*(2^(1 + d)*gZuL*gZuLC*
              Pi^d - 2^(2 + d)*gZuR*gZuRC*Pi^d - d*gZuL*gZuLC*(2*Pi)^d + 
             d*gZuR*gZuRC*(2*Pi)^d))*t*GaugeXi[Q]^2) + 
       (gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) + 
           gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t))) - 
         gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
           gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t))))*
        ((mh^2 - s)^2*(d*s + 2*t) + 2*mz^2*(mh^2*((-2 + d)*s - 2*t) - 
           s*(d*s + 2*t))*GaugeXi[Q] + mz^4*(d*s + 2*t)*GaugeXi[Q]^2)))/
     ((-1 + d)*(mzC^2 - s)*s*(mz^3 - mz*s)^2)))/Pi^(3*d), 
 ((-I)*4^(-2 - d)*EL^6*gHZZ^2*(mh^2 - mz^2 - s)*
   (gZlL*gZlLC*(gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*
         ((4 - 3*d)*s^2 + (4 - 5*d + d^2)*s*t - 2*t^2)) + 
      gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*(2*(-1 + d)*s^2 - 
          (8 - 5*d + d^2)*s*t - 2*t^2))) - 
    gZlR*gZlRC*(gZuL*gZuLC*(-(d^2*(2*Pi)^d*s^2) + 2^(1 + d)*Pi^d*
         ((-4 + 3*d)*s^2 - (4 - 5*d + d^2)*s*t + 2*t^2)) + 
      gZuR*gZuRC*(d^2*(2*Pi)^d*s^2 + 2^(1 + d)*Pi^d*(-2*(-1 + d)*s^2 + 
          (8 - 5*d + d^2)*s*t + 2*t^2)))))/((-1 + d)*Pi^(2*d)*s*(-mzC^2 + s)*
   (mz^3 - mz*s)^2), 
 ((-I)*EL^6*gHZZ^2*((2^(1 + d)*(gZlL*gZlLC + gZlR*gZlRC)*
      (gZuL*gZuLC + gZuR*gZuRC)*Pi^d*(-4*mh^2*mz^2 + d*(mh^2 + mz^2 - s)^2)*
      s)/(-1 + d) + 2*(mh^2 + mz^2 - s)^2*
     (-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s - t)) + 
         gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(s + t)))) + 
      gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-2*s + t)) + 
        gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s + t)))) - 
    ((d*(mh^2 + mz^2 - s)^2*s + 2*mh^4*t + 2*(mz^2 - s)^2*t - 
       4*mh^2*(s*t + mz^2*(s + t)))*
      (-(gZlR*gZlRC*(gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(s - t)) + 
          gZuR*gZuRC*(d*(2*Pi)^d*s - 2^(1 + d)*Pi^d*(2*s + t)))) + 
       gZlL*gZlLC*(gZuR*gZuRC*(d*(2*Pi)^d*s + 2^(1 + d)*Pi^d*(-s + t)) + 
         gZuL*gZuLC*(-(d*(2*Pi)^d*s) + 2^(1 + d)*Pi^d*(2*s + t)))))/
     ((-1 + d)*s) + 2*gZlL*gZlLC*
     (gZuL*gZuLC*(mh^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*t + 
        mz^4*(2^(1 + d)*Pi^d - d*(2*Pi)^d)*t + (2^(1 + d)*Pi^d - d*(2*Pi)^d)*
         s^2*t - 2^(1 + d)*mz^2*Pi^d*((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*
           t + 4*t^2) + 2^(1 + d)*mh^2*Pi^d*((-2 + d)*s*t + 
          mz^2*((-2 + d)*s + (-4 + d)*t))) + 
      gZuR*gZuRC*(-((2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
        mh^4*(-(2^(2 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 
        mz^4*(-(2^(2 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 2^(1 + d)*mz^2*Pi^d*
         ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2) - 
        2^(1 + d)*mh^2*Pi^d*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
            (-2 + d)*t)))) - 2*gZlR*gZlRC*
     (gZuR*gZuRC*(-((2^(1 + d)*Pi^d - d*(2*Pi)^d)*s^2*t) + 
        mh^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 
        mz^4*(-(2^(1 + d)*Pi^d*t) + d*(2*Pi)^d*t) + 2^(1 + d)*mz^2*Pi^d*
         ((-2 + d)^2*s^2 + (18 - 11*d + 2*d^2)*s*t + 4*t^2) - 
        2^(1 + d)*mh^2*Pi^d*((-2 + d)*s*t + mz^2*((-2 + d)*s + 
            (-4 + d)*t))) + gZuL*gZuLC*(mh^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*
         t + mz^4*(2^(2 + d)*Pi^d - d*(2*Pi)^d)*t + 
        (2^(2 + d)*Pi^d - d*(2*Pi)^d)*s^2*t - 2^(1 + d)*mz^2*Pi^d*
         ((8 - 6*d + d^2)*s^2 + (12 - 11*d + 2*d^2)*s*t - 4*t^2) + 
        2^(1 + d)*mh^2*Pi^d*((-4 + d)*s*t + mz^2*((-4 + d)*s + 
            (-2 + d)*t))))))/(2^(2*(2 + d))*Pi^(2*d)*(-mzC^2 + s)*
   (mz^3 - mz*s)^2)}
