(* Created with the Wolfram Language : www.wolfram.com *)
(-3*EL^8*gAd^2*gAl^6*KiraPropagator[q1, mm]*KiraPropagator[-p1 - p2 + q1, mm]*
  KiraPropagator[-p3 + q1, 0]*KiraPropagator[q2, md]*
  KiraPropagator[p1 + p2 + q2, md]*(-16*md^2*me^2*mm^4 + 8*d*md^2*me^2*mm^4 - 
   8*md^2*mm^6 + 4*d*md^2*mm^6 - 8*md^2*me^2*mm^2*s + 12*d*md^2*me^2*mm^2*s - 
   2*d^2*md^2*me^2*mm^2*s - 12*md^2*mm^2*s^2 + 8*d*md^2*mm^2*s^2 - 
   d^2*md^2*mm^2*s^2 + 16*md^2*mm^4*t - 8*d*md^2*mm^4*t - 8*md^2*mm^2*s*t + 
   4*d*md^2*mm^2*s*t - 8*md^2*mm^2*t^2 + 4*d*md^2*mm^2*t^2 - 
   16*md^2*me^2*mm^2*SP[p2, q1] + 16*d*md^2*me^2*mm^2*SP[p2, q1] - 
   8*md^2*mm^4*SP[p2, q1] + 12*d*md^2*mm^4*SP[p2, q1] - 
   16*md^2*me^2*s*SP[p2, q1] + 8*d*md^2*me^2*s*SP[p2, q1] - 
   12*md^2*mm^2*s*SP[p2, q1] + 2*d*md^2*mm^2*s*SP[p2, q1] - 
   8*md^2*s^2*SP[p2, q1] + 4*d*md^2*s^2*SP[p2, q1] + 
   16*md^2*mm^2*t*SP[p2, q1] - 16*d*md^2*mm^2*t*SP[p2, q1] + 
   4*md^2*s*t*SP[p2, q1] + 2*d*md^2*s*t*SP[p2, q1] - 8*md^2*t^2*SP[p2, q1] + 
   4*d*md^2*t^2*SP[p2, q1] - 8*md^2*mm^2*SP[p2, q1]^2 + 
   4*d*md^2*mm^2*SP[p2, q1]^2 + 8*md^2*t*SP[p2, q1]^2 - 
   4*d*md^2*t*SP[p2, q1]^2 + 16*me^2*mm^4*SP[p2, q2] - 
   8*d*me^2*mm^4*SP[p2, q2] + 8*mm^6*SP[p2, q2] - 4*d*mm^6*SP[p2, q2] + 
   8*me^2*mm^2*s*SP[p2, q2] - 16*d*me^2*mm^2*s*SP[p2, q2] + 
   2*d^2*me^2*mm^2*s*SP[p2, q2] - 4*d*mm^4*s*SP[p2, q2] + 
   12*mm^2*s^2*SP[p2, q2] - 8*d*mm^2*s^2*SP[p2, q2] + 
   d^2*mm^2*s^2*SP[p2, q2] - 16*mm^4*t*SP[p2, q2] + 8*d*mm^4*t*SP[p2, q2] + 
   8*mm^2*s*t*SP[p2, q2] + 8*mm^2*t^2*SP[p2, q2] - 4*d*mm^2*t^2*SP[p2, q2] + 
   16*me^2*mm^2*SP[p2, q1]*SP[p2, q2] - 8*d*me^2*mm^2*SP[p2, q1]*SP[p2, q2] + 
   8*mm^4*SP[p2, q1]*SP[p2, q2] - 4*d*mm^4*SP[p2, q1]*SP[p2, q2] + 
   16*me^2*s*SP[p2, q1]*SP[p2, q2] - 8*d*me^2*s*SP[p2, q1]*SP[p2, q2] + 
   16*mm^2*s*SP[p2, q1]*SP[p2, q2] - 4*d*mm^2*s*SP[p2, q1]*SP[p2, q2] + 
   8*s^2*SP[p2, q1]*SP[p2, q2] - 4*d*s^2*SP[p2, q1]*SP[p2, q2] - 
   16*mm^2*t*SP[p2, q1]*SP[p2, q2] + 8*d*mm^2*t*SP[p2, q1]*SP[p2, q2] - 
   8*s*t*SP[p2, q1]*SP[p2, q2] + 8*t^2*SP[p2, q1]*SP[p2, q2] - 
   4*d*t^2*SP[p2, q1]*SP[p2, q2] - 32*me^2*mm^2*SP[p2, q2]^2 - 
   8*mm^4*SP[p2, q2]^2 - 4*d*mm^4*SP[p2, q2]^2 + 8*mm^2*t*SP[p2, q2]^2 + 
   4*d*mm^2*t*SP[p2, q2]^2 - 16*d*md^2*me^2*mm^2*SP[p3, q1] + 
   48*md^2*me^2*s*SP[p3, q1] - 32*d*md^2*me^2*s*SP[p3, q1] + 
   4*d^2*md^2*me^2*s*SP[p3, q1] - 8*d*md^2*mm^2*s*SP[p3, q1] + 
   36*md^2*s^2*SP[p3, q1] - 18*d*md^2*s^2*SP[p3, q1] + 
   2*d^2*md^2*s^2*SP[p3, q1] + 32*md^2*me^2*SP[p2, q1]*SP[p3, q1] - 
   16*d*md^2*me^2*SP[p2, q1]*SP[p3, q1] + 16*md^2*mm^2*SP[p2, q1]*
    SP[p3, q1] - 8*d*md^2*mm^2*SP[p2, q1]*SP[p3, q1] + 
   8*md^2*s*SP[p2, q1]*SP[p3, q1] - 4*d*md^2*s*SP[p2, q1]*SP[p3, q1] - 
   16*md^2*t*SP[p2, q1]*SP[p3, q1] + 8*d*md^2*t*SP[p2, q1]*SP[p3, q1] + 
   16*d*me^2*mm^2*SP[p2, q2]*SP[p3, q1] - 56*me^2*s*SP[p2, q2]*SP[p3, q1] + 
   36*d*me^2*s*SP[p2, q2]*SP[p3, q1] - 4*d^2*me^2*s*SP[p2, q2]*SP[p3, q1] - 
   8*mm^2*s*SP[p2, q2]*SP[p3, q1] + 12*d*mm^2*s*SP[p2, q2]*SP[p3, q1] - 
   36*s^2*SP[p2, q2]*SP[p3, q1] + 18*d*s^2*SP[p2, q2]*SP[p3, q1] - 
   2*d^2*s^2*SP[p2, q2]*SP[p3, q1] + 8*s*t*SP[p2, q2]*SP[p3, q1] - 
   4*d*s*t*SP[p2, q2]*SP[p3, q1] - 16*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
   8*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 8*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] + 4*d*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
   32*me^2*SP[p2, q2]^2*SP[p3, q1] - 16*mm^2*SP[p2, q2]^2*SP[p3, q1] + 
   8*d*mm^2*SP[p2, q2]^2*SP[p3, q1] + 16*t*SP[p2, q2]^2*SP[p3, q1] - 
   8*d*t*SP[p2, q2]^2*SP[p3, q1] - 32*md^2*me^2*SP[p3, q1]^2 + 
   16*d*md^2*me^2*SP[p3, q1]^2 - 16*md^2*s*SP[p3, q1]^2 + 
   8*d*md^2*s*SP[p3, q1]^2 + 32*me^2*SP[p2, q2]*SP[p3, q1]^2 - 
   16*d*me^2*SP[p2, q2]*SP[p3, q1]^2 + 16*s*SP[p2, q2]*SP[p3, q1]^2 - 
   8*d*s*SP[p2, q2]*SP[p3, q1]^2 + 8*d*me^2*mm^2*s*SP[p3, q2] + 
   4*d*mm^2*s^2*SP[p3, q2] - 16*d*me^2*mm^2*SP[p2, q1]*SP[p3, q2] - 
   8*me^2*s*SP[p2, q1]*SP[p3, q2] + 4*d*me^2*s*SP[p2, q1]*SP[p3, q2] - 
   8*d*mm^2*s*SP[p2, q1]*SP[p3, q2] - 4*s^2*SP[p2, q1]*SP[p3, q2] + 
   2*d*s^2*SP[p2, q1]*SP[p3, q2] + 16*me^2*SP[p2, q1]^2*SP[p3, q2] - 
   8*d*me^2*SP[p2, q1]^2*SP[p3, q2] + 8*s*SP[p2, q1]^2*SP[p3, q2] - 
   4*d*s*SP[p2, q1]^2*SP[p3, q2] + 32*me^2*mm^2*SP[p2, q2]*SP[p3, q2] + 
   16*mm^4*SP[p2, q2]*SP[p3, q2] - 8*d*mm^4*SP[p2, q2]*SP[p3, q2] + 
   8*mm^2*s*SP[p2, q2]*SP[p3, q2] + 4*d*mm^2*s*SP[p2, q2]*SP[p3, q2] - 
   16*mm^2*t*SP[p2, q2]*SP[p3, q2] + 8*d*mm^2*t*SP[p2, q2]*SP[p3, q2] - 
   32*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 16*mm^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] - 8*d*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 
   16*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 8*d*t*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] + 16*me^2*s*SP[p3, q1]*SP[p3, q2] - 
   8*d*me^2*s*SP[p3, q1]*SP[p3, q2] + 8*s^2*SP[p3, q1]*SP[p3, q2] - 
   4*d*s^2*SP[p3, q1]*SP[p3, q2] - 32*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 
   16*d*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 16*s*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] + 8*d*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 
   32*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 16*d*me^2*SP[p2, q2]*SP[p3, q1]*
    SP[p3, q2] + 16*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 
   8*d*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 32*me^2*mm^2*SP[p3, q2]^2 + 
   16*d*me^2*mm^2*SP[p3, q2]^2 - 16*mm^2*s*SP[p3, q2]^2 + 
   8*d*mm^2*s*SP[p3, q2]^2 - 32*me^2*SP[p2, q1]*SP[p3, q2]^2 + 
   16*d*me^2*SP[p2, q1]*SP[p3, q2]^2 - 16*s*SP[p2, q1]*SP[p3, q2]^2 + 
   8*d*s*SP[p2, q1]*SP[p3, q2]^2 + 16*md^2*me^2*mm^2*SP[q1, q1] - 
   8*d*md^2*me^2*mm^2*SP[q1, q1] + 8*md^2*mm^4*SP[q1, q1] - 
   4*d*md^2*mm^4*SP[q1, q1] - 16*md^2*me^2*s*SP[q1, q1] + 
   12*d*md^2*me^2*s*SP[q1, q1] - 2*d^2*md^2*me^2*s*SP[q1, q1] - 
   8*md^2*s^2*SP[q1, q1] + 6*d*md^2*s^2*SP[q1, q1] - 
   d^2*md^2*s^2*SP[q1, q1] - 16*md^2*mm^2*t*SP[q1, q1] + 
   8*d*md^2*mm^2*t*SP[q1, q1] + 8*md^2*s*t*SP[q1, q1] - 
   4*d*md^2*s*t*SP[q1, q1] + 8*md^2*t^2*SP[q1, q1] - 
   4*d*md^2*t^2*SP[q1, q1] - 16*me^2*mm^2*SP[p2, q2]*SP[q1, q1] + 
   8*d*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 8*mm^4*SP[p2, q2]*SP[q1, q1] + 
   4*d*mm^4*SP[p2, q2]*SP[q1, q1] + 16*me^2*s*SP[p2, q2]*SP[q1, q1] - 
   12*d*me^2*s*SP[p2, q2]*SP[q1, q1] + 2*d^2*me^2*s*SP[p2, q2]*SP[q1, q1] + 
   8*s^2*SP[p2, q2]*SP[q1, q1] - 6*d*s^2*SP[p2, q2]*SP[q1, q1] + 
   d^2*s^2*SP[p2, q2]*SP[q1, q1] + 16*mm^2*t*SP[p2, q2]*SP[q1, q1] - 
   8*d*mm^2*t*SP[p2, q2]*SP[q1, q1] - 8*s*t*SP[p2, q2]*SP[q1, q1] + 
   4*d*s*t*SP[p2, q2]*SP[q1, q1] - 8*t^2*SP[p2, q2]*SP[q1, q1] + 
   4*d*t^2*SP[p2, q2]*SP[q1, q1] + 8*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   4*d*mm^2*SP[p2, q2]^2*SP[q1, q1] - 8*t*SP[p2, q2]^2*SP[q1, q1] + 
   4*d*t*SP[p2, q2]^2*SP[q1, q1] - 32*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   16*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 16*mm^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 8*d*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   8*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 4*d*s*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 16*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   8*d*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 32*me^2*SP[p3, q2]^2*SP[q1, q1] - 
   16*d*me^2*SP[p3, q2]^2*SP[q1, q1] + 16*s*SP[p3, q2]^2*SP[q1, q1] - 
   8*d*s*SP[p3, q2]^2*SP[q1, q1] - 4*SP[p1, q2]^2*(8*me^2*mm^2 - 2*mm^4 - 
     d*mm^4 + 2*mm^2*s + d*mm^2*s + 2*mm^2*t + d*mm^2*t - 4*s*SP[p2, q1] - 
     8*me^2*SP[p3, q1] + 2*(-2 + d)*(mm^2 - s - t)*SP[p3, q1] + 
     2*mm^2*SP[q1, q1] - d*mm^2*SP[q1, q1] - 2*s*SP[q1, q1] + 
     d*s*SP[q1, q1] - 2*t*SP[q1, q1] + d*t*SP[q1, q1]) + 
   4*me^2*s^2*SP[q1, q2] - 2*d*me^2*s^2*SP[q1, q2] + 2*s^3*SP[q1, q2] - 
   d*s^3*SP[q1, q2] - 8*me^2*s*SP[p2, q1]*SP[q1, q2] + 
   4*d*me^2*s*SP[p2, q1]*SP[q1, q2] - 4*s^2*SP[p2, q1]*SP[q1, q2] + 
   2*d*s^2*SP[p2, q1]*SP[q1, q2] + 16*d*me^2*mm^2*SP[p2, q2]*SP[q1, q2] + 
   16*d*mm^4*SP[p2, q2]*SP[q1, q2] - 16*me^2*s*SP[p2, q2]*SP[q1, q2] - 
   8*s^2*SP[p2, q2]*SP[q1, q2] - 16*d*mm^2*t*SP[p2, q2]*SP[q1, q2] - 
   16*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 8*d*mm^2*SP[p2, q1]*SP[p2, q2]*
    SP[q1, q2] + 16*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 
   8*d*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 32*me^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] - 16*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   32*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 16*d*mm^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] - 32*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   16*d*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 32*d*me^2*mm^2*SP[p3, q2]*
    SP[q1, q2] + 48*me^2*s*SP[p3, q2]*SP[q1, q2] - 
   8*d*me^2*s*SP[p3, q2]*SP[q1, q2] - 16*d*mm^2*s*SP[p3, q2]*SP[q1, q2] + 
   24*s^2*SP[p3, q2]*SP[q1, q2] - 4*d*s^2*SP[p3, q2]*SP[q1, q2] + 
   32*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 16*d*me^2*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] + 16*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   8*d*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 64*me^2*SP[p3, q1]*SP[p3, q2]*
    SP[q1, q2] + 32*d*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
   32*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 16*d*s*SP[p3, q1]*SP[p3, q2]*
    SP[q1, q2] - 16*me^2*s*SP[q1, q2]^2 + 8*d*me^2*s*SP[q1, q2]^2 - 
   8*s^2*SP[q1, q2]^2 + 4*d*s^2*SP[q1, q2]^2 + 
   SP[p1, q2]*(16*me^2*mm^4 - 8*d*me^2*mm^4 + 8*mm^6 - 4*d*mm^6 + 
     8*me^2*mm^2*s - 16*d*me^2*mm^2*s + 2*d^2*me^2*mm^2*s + 4*d*mm^4*s + 
     12*mm^2*s^2 - 12*d*mm^2*s^2 + d^2*mm^2*s^2 - 16*mm^4*t + 8*d*mm^4*t + 
     8*mm^2*s*t - 8*d*mm^2*s*t + 8*mm^2*t^2 - 4*d*mm^2*t^2 - 
     8*(-2 + d)*(mm^2 - t)*SP[p2, q1]^2 - 64*me^2*mm^2*SP[p2, q2] - 
     56*mm^2*s*SP[p2, q2] + 4*d*mm^2*s*SP[p2, q2] + 
     16*d*me^2*mm^2*SP[p3, q1] - 56*me^2*s*SP[p3, q1] + 
     36*d*me^2*s*SP[p3, q1] - 4*d^2*me^2*s*SP[p3, q1] + 8*mm^2*s*SP[p3, q1] + 
     4*d*mm^2*s*SP[p3, q1] - 44*s^2*SP[p3, q1] + 22*d*s^2*SP[p3, q1] - 
     2*d^2*s^2*SP[p3, q1] - 8*s*t*SP[p3, q1] + 4*d*s*t*SP[p3, q1] + 
     64*me^2*SP[p2, q2]*SP[p3, q1] + 80*s*SP[p2, q2]*SP[p3, q1] - 
     8*d*s*SP[p2, q2]*SP[p3, q1] + 32*me^2*SP[p3, q1]^2 - 
     16*d*me^2*SP[p3, q1]^2 + 16*s*SP[p3, q1]^2 - 8*d*s*SP[p3, q1]^2 + 
     32*me^2*mm^2*SP[p3, q2] - 16*mm^4*SP[p3, q2] + 8*d*mm^4*SP[p3, q2] + 
     24*mm^2*s*SP[p3, q2] - 4*d*mm^2*s*SP[p3, q2] + 16*mm^2*t*SP[p3, q2] - 
     8*d*mm^2*t*SP[p3, q2] + 32*me^2*SP[p3, q1]*SP[p3, q2] - 
     16*d*me^2*SP[p3, q1]*SP[p3, q2] + 16*s*SP[p3, q1]*SP[p3, q2] - 
     8*d*s*SP[p3, q1]*SP[p3, q2] - 16*me^2*mm^2*SP[q1, q1] + 
     8*d*me^2*mm^2*SP[q1, q1] - 8*mm^4*SP[q1, q1] + 4*d*mm^4*SP[q1, q1] + 
     16*me^2*s*SP[q1, q1] - 12*d*me^2*s*SP[q1, q1] + 
     2*d^2*me^2*s*SP[q1, q1] + 8*s^2*SP[q1, q1] - 6*d*s^2*SP[q1, q1] + 
     d^2*s^2*SP[q1, q1] + 16*mm^2*t*SP[q1, q1] - 8*d*mm^2*t*SP[q1, q1] - 
     8*s*t*SP[q1, q1] + 4*d*s*t*SP[q1, q1] - 8*t^2*SP[q1, q1] + 
     4*d*t^2*SP[q1, q1] - 8*s*SP[p2, q2]*SP[q1, q1] + 
     4*d*s*SP[p2, q2]*SP[q1, q1] - 32*me^2*SP[p3, q2]*SP[q1, q1] + 
     16*d*me^2*SP[p3, q2]*SP[q1, q1] + 16*mm^2*SP[p3, q2]*SP[q1, q1] - 
     8*d*mm^2*SP[p3, q2]*SP[q1, q1] - 24*s*SP[p3, q2]*SP[q1, q1] + 
     12*d*s*SP[p3, q2]*SP[q1, q1] - 16*t*SP[p3, q2]*SP[q1, q1] + 
     8*d*t*SP[p3, q2]*SP[q1, q1] + 16*d*me^2*mm^2*SP[q1, q2] - 
     16*d*mm^4*SP[q1, q2] - 16*me^2*s*SP[q1, q2] + 16*d*mm^2*s*SP[q1, q2] - 
     8*s^2*SP[q1, q2] + 16*d*mm^2*t*SP[q1, q2] + 32*me^2*SP[p3, q1]*
      SP[q1, q2] - 16*d*me^2*SP[p3, q1]*SP[q1, q2] - 
     32*mm^2*SP[p3, q1]*SP[q1, q2] + 16*d*mm^2*SP[p3, q1]*SP[q1, q2] + 
     32*s*SP[p3, q1]*SP[q1, q2] - 16*d*s*SP[p3, q1]*SP[q1, q2] + 
     32*t*SP[p3, q1]*SP[q1, q2] - 16*d*t*SP[p3, q1]*SP[q1, q2] - 
     4*SP[p2, q1]*(-4*me^2*mm^2 + 2*d*me^2*mm^2 - 2*mm^4 + 5*d*mm^4 - 
       4*me^2*s + 2*d*me^2*s - 2*mm^2*s - 2*d*mm^2*s - 2*s^2 + d*s^2 + 
       4*mm^2*t - 6*d*mm^2*t + d*s*t - 2*t^2 + d*t^2 + 4*s*SP[p2, q2] - 
       (-2 + d)*(2*me^2 + 4*mm^2 - s - 4*t)*SP[p3, q1] + 8*me^2*SP[p3, q2] + 
       4*mm^2*SP[p3, q2] - 2*d*mm^2*SP[p3, q2] + 8*s*SP[p3, q2] - 
       4*t*SP[p3, q2] + 2*d*t*SP[p3, q2] - 4*mm^2*SP[q1, q2] + 
       2*d*mm^2*SP[q1, q2] + 4*t*SP[q1, q2] - 2*d*t*SP[q1, q2])) - 
   4*(-2 + d)*SP[p1, q1]^2*(2*(-mm^2 + s + t)*SP[p2, q2] + 
     (2*me^2 + s)*SP[p3, q2] + (mm^2 - s - t)*(md^2 - SP[q2, q2])) + 
   16*me^2*mm^4*SP[q2, q2] - 8*d*me^2*mm^4*SP[q2, q2] + 8*mm^6*SP[q2, q2] - 
   4*d*mm^6*SP[q2, q2] + 32*me^2*mm^2*s*SP[q2, q2] - 
   16*d*me^2*mm^2*s*SP[q2, q2] + 2*d^2*me^2*mm^2*s*SP[q2, q2] + 
   24*mm^2*s^2*SP[q2, q2] - 10*d*mm^2*s^2*SP[q2, q2] + 
   d^2*mm^2*s^2*SP[q2, q2] - 16*mm^4*t*SP[q2, q2] + 8*d*mm^4*t*SP[q2, q2] + 
   8*mm^2*s*t*SP[q2, q2] - 4*d*mm^2*s*t*SP[q2, q2] + 8*mm^2*t^2*SP[q2, q2] - 
   4*d*mm^2*t^2*SP[q2, q2] + 16*me^2*mm^2*SP[p2, q1]*SP[q2, q2] - 
   16*d*me^2*mm^2*SP[p2, q1]*SP[q2, q2] + 8*mm^4*SP[p2, q1]*SP[q2, q2] - 
   12*d*mm^4*SP[p2, q1]*SP[q2, q2] + 32*me^2*s*SP[p2, q1]*SP[q2, q2] - 
   8*d*me^2*s*SP[p2, q1]*SP[q2, q2] + 12*mm^2*s*SP[p2, q1]*SP[q2, q2] - 
   2*d*mm^2*s*SP[p2, q1]*SP[q2, q2] + 16*s^2*SP[p2, q1]*SP[q2, q2] - 
   4*d*s^2*SP[p2, q1]*SP[q2, q2] - 16*mm^2*t*SP[p2, q1]*SP[q2, q2] + 
   16*d*mm^2*t*SP[p2, q1]*SP[q2, q2] - 4*s*t*SP[p2, q1]*SP[q2, q2] - 
   2*d*s*t*SP[p2, q1]*SP[q2, q2] + 8*t^2*SP[p2, q1]*SP[q2, q2] - 
   4*d*t^2*SP[p2, q1]*SP[q2, q2] + 8*mm^2*SP[p2, q1]^2*SP[q2, q2] - 
   4*d*mm^2*SP[p2, q1]^2*SP[q2, q2] - 8*t*SP[p2, q1]^2*SP[q2, q2] + 
   4*d*t*SP[p2, q1]^2*SP[q2, q2] + 16*d*me^2*mm^2*SP[p3, q1]*SP[q2, q2] - 
   96*me^2*s*SP[p3, q1]*SP[q2, q2] + 40*d*me^2*s*SP[p3, q1]*SP[q2, q2] - 
   4*d^2*me^2*s*SP[p3, q1]*SP[q2, q2] + 8*d*mm^2*s*SP[p3, q1]*SP[q2, q2] - 
   60*s^2*SP[p3, q1]*SP[q2, q2] + 22*d*s^2*SP[p3, q1]*SP[q2, q2] - 
   2*d^2*s^2*SP[p3, q1]*SP[q2, q2] - 32*me^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] + 16*d*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   16*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 8*d*mm^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 8*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   4*d*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 16*t*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 8*d*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   32*me^2*SP[p3, q1]^2*SP[q2, q2] - 16*d*me^2*SP[p3, q1]^2*SP[q2, q2] + 
   16*s*SP[p3, q1]^2*SP[q2, q2] - 8*d*s*SP[p3, q1]^2*SP[q2, q2] - 
   16*me^2*mm^2*SP[q1, q1]*SP[q2, q2] + 8*d*me^2*mm^2*SP[q1, q1]*SP[q2, q2] - 
   8*mm^4*SP[q1, q1]*SP[q2, q2] + 4*d*mm^4*SP[q1, q1]*SP[q2, q2] + 
   24*me^2*s*SP[q1, q1]*SP[q2, q2] - 16*d*me^2*s*SP[q1, q1]*SP[q2, q2] + 
   2*d^2*me^2*s*SP[q1, q1]*SP[q2, q2] + 12*s^2*SP[q1, q1]*SP[q2, q2] - 
   8*d*s^2*SP[q1, q1]*SP[q2, q2] + d^2*s^2*SP[q1, q1]*SP[q2, q2] + 
   16*mm^2*t*SP[q1, q1]*SP[q2, q2] - 8*d*mm^2*t*SP[q1, q1]*SP[q2, q2] - 
   8*s*t*SP[q1, q1]*SP[q2, q2] + 4*d*s*t*SP[q1, q1]*SP[q2, q2] - 
   8*t^2*SP[q1, q1]*SP[q2, q2] + 4*d*t^2*SP[q1, q1]*SP[q2, q2] + 
   2*SP[p1, q1]*(-8*md^2*me^2*mm^2 + 8*d*md^2*me^2*mm^2 - 4*md^2*mm^4 - 
     2*d*md^2*mm^4 - 8*md^2*me^2*s + 4*d*md^2*me^2*s + 6*md^2*mm^2*s + 
     3*d*md^2*mm^2*s - 10*md^2*s^2 + 3*d*md^2*s^2 + 8*md^2*mm^2*t - 
     10*md^2*s*t + 3*d*md^2*s*t - 4*md^2*t^2 + 2*d*md^2*t^2 + 
     8*me^2*mm^2*SP[p2, q2] - 4*d*me^2*mm^2*SP[p2, q2] + 4*mm^4*SP[p2, q2] + 
     6*d*mm^4*SP[p2, q2] + 8*me^2*s*SP[p2, q2] - 4*d*me^2*s*SP[p2, q2] - 
     4*mm^2*s*SP[p2, q2] - 4*d*mm^2*s*SP[p2, q2] + 8*s^2*SP[p2, q2] - 
     2*d*s^2*SP[p2, q2] - 8*mm^2*t*SP[p2, q2] - 4*d*mm^2*t*SP[p2, q2] + 
     8*s*t*SP[p2, q2] - 2*d*s*t*SP[p2, q2] + 4*t^2*SP[p2, q2] - 
     2*d*t^2*SP[p2, q2] + 8*s*SP[p2, q2]^2 + 16*md^2*me^2*SP[p3, q1] - 
     8*d*md^2*me^2*SP[p3, q1] - 8*md^2*mm^2*SP[p3, q1] + 
     4*d*md^2*mm^2*SP[p3, q1] + 12*md^2*s*SP[p3, q1] - 
     6*d*md^2*s*SP[p3, q1] + 8*md^2*t*SP[p3, q1] - 4*d*md^2*t*SP[p3, q1] - 
     8*me^2*SP[p2, q2]*SP[p3, q1] + 4*d*me^2*SP[p2, q2]*SP[p3, q1] + 
     16*mm^2*SP[p2, q2]*SP[p3, q1] - 8*d*mm^2*SP[p2, q2]*SP[p3, q1] - 
     12*s*SP[p2, q2]*SP[p3, q1] + 6*d*s*SP[p2, q2]*SP[p3, q1] - 
     16*t*SP[p2, q2]*SP[p3, q1] + 8*d*t*SP[p2, q2]*SP[p3, q1] - 
     8*d*me^2*mm^2*SP[p3, q2] - 4*me^2*s*SP[p3, q2] + 2*d*me^2*s*SP[p3, q2] - 
     4*d*mm^2*s*SP[p3, q2] - 2*s^2*SP[p3, q2] + d*s^2*SP[p3, q2] - 
     16*me^2*SP[p2, q2]*SP[p3, q2] + 8*mm^2*SP[p2, q2]*SP[p3, q2] - 
     4*d*mm^2*SP[p2, q2]*SP[p3, q2] - 24*s*SP[p2, q2]*SP[p3, q2] + 
     4*d*s*SP[p2, q2]*SP[p3, q2] - 8*t*SP[p2, q2]*SP[p3, q2] + 
     4*d*t*SP[p2, q2]*SP[p3, q2] - 16*me^2*SP[p3, q1]*SP[p3, q2] + 
     8*d*me^2*SP[p3, q1]*SP[p3, q2] - 8*s*SP[p3, q1]*SP[p3, q2] + 
     4*d*s*SP[p3, q1]*SP[p3, q2] - 16*me^2*SP[p3, q2]^2 + 
     8*d*me^2*SP[p3, q2]^2 - 8*s*SP[p3, q2]^2 + 4*d*s*SP[p3, q2]^2 - 
     4*me^2*s*SP[q1, q2] + 2*d*me^2*s*SP[q1, q2] - 2*s^2*SP[q1, q2] + 
     d*s^2*SP[q1, q2] - 8*mm^2*SP[p2, q2]*SP[q1, q2] + 
     4*d*mm^2*SP[p2, q2]*SP[q1, q2] + 8*s*SP[p2, q2]*SP[q1, q2] - 
     4*d*s*SP[p2, q2]*SP[q1, q2] + 8*t*SP[p2, q2]*SP[q1, q2] - 
     4*d*t*SP[p2, q2]*SP[q1, q2] + 16*me^2*SP[p3, q2]*SP[q1, q2] - 
     8*d*me^2*SP[p3, q2]*SP[q1, q2] + 8*s*SP[p3, q2]*SP[q1, q2] - 
     4*d*s*SP[p3, q2]*SP[q1, q2] - 2*SP[p1, q2]*(-4*me^2*mm^2 + 
       2*d*me^2*mm^2 - 2*mm^4 + d*mm^4 - 4*me^2*s + 2*d*me^2*s + 4*mm^2*s - 
       d*mm^2*s - 6*s^2 + 2*d*s^2 + 4*mm^2*t - 2*d*mm^2*t - 6*s*t + 2*d*s*t - 
       2*t^2 + d*t^2 + 2*(-2 + d)*(mm^2 - s - t)*SP[p2, q1] + 
       4*s*SP[p2, q2] + 4*me^2*SP[p3, q1] - 2*d*me^2*SP[p3, q1] + 
       2*s*SP[p3, q1] - d*s*SP[p3, q1] + 8*me^2*SP[p3, q2] + 
       4*mm^2*SP[p3, q2] - 2*d*mm^2*SP[p3, q2] - 4*s*SP[p3, q2] + 
       2*d*s*SP[p3, q2] - 4*t*SP[p3, q2] + 2*d*t*SP[p3, q2] - 
       4*mm^2*SP[q1, q2] + 2*d*mm^2*SP[q1, q2] + 4*s*SP[q1, q2] - 
       2*d*s*SP[q1, q2] + 4*t*SP[q1, q2] - 2*d*t*SP[q1, q2]) - 
     2*(-2 + d)*SP[p2, q1]*(-2*(mm^2 - t)*SP[p2, q2] + 
       2*(2*me^2 + s)*SP[p3, q2] + s*(md^2 - SP[q2, q2])) + 
     8*me^2*mm^2*SP[q2, q2] - 8*d*me^2*mm^2*SP[q2, q2] + 4*mm^4*SP[q2, q2] + 
     2*d*mm^4*SP[q2, q2] + 16*me^2*s*SP[q2, q2] - 4*d*me^2*s*SP[q2, q2] - 
     6*mm^2*s*SP[q2, q2] - 3*d*mm^2*s*SP[q2, q2] + 14*s^2*SP[q2, q2] - 
     3*d*s^2*SP[q2, q2] - 8*mm^2*t*SP[q2, q2] + 10*s*t*SP[q2, q2] - 
     3*d*s*t*SP[q2, q2] + 4*t^2*SP[q2, q2] - 2*d*t^2*SP[q2, q2] - 
     16*me^2*SP[p3, q1]*SP[q2, q2] + 8*d*me^2*SP[p3, q1]*SP[q2, q2] + 
     8*mm^2*SP[p3, q1]*SP[q2, q2] - 4*d*mm^2*SP[p3, q1]*SP[q2, q2] - 
     12*s*SP[p3, q1]*SP[q2, q2] + 6*d*s*SP[p3, q1]*SP[q2, q2] - 
     8*t*SP[p3, q1]*SP[q2, q2] + 4*d*t*SP[p3, q1]*SP[q2, q2])))/(64*Pi^8*s^3)
