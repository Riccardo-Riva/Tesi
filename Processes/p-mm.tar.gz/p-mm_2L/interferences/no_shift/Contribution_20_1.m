(* Created with the Wolfram Language : www.wolfram.com *)
(EL^8*gAl^8*KiraPropagator[q1, 0]*KiraPropagator[p3 + q1, mm]*
  KiraPropagator[-p1 - p2 + p3 + q1, mm]*KiraPropagator[q2, mm]*
  KiraPropagator[p1 + p2 + q2, mm]*KiraPropagator[p3 + q1 + q2, 0]*
  (-64*me^2*mm^6 + 32*d*me^2*mm^6 - 32*mm^8 + 16*d*mm^8 + 32*d*me^2*mm^4*s - 
   8*d^2*me^2*mm^4*s + 16*mm^6*s - 8*d*mm^6*s + 16*me^2*mm^2*s^2 - 
   24*d*me^2*mm^2*s^2 + 4*d^2*me^2*mm^2*s^2 - 48*mm^4*s^2 + 32*d*mm^4*s^2 - 
   4*d^2*mm^4*s^2 + 24*mm^2*s^3 - 16*d*mm^2*s^3 + 2*d^2*mm^2*s^3 + 
   64*mm^6*t - 32*d*mm^6*t - 64*mm^4*s*t + 32*d*mm^4*s*t + 16*mm^2*s^2*t - 
   8*d*mm^2*s^2*t - 32*mm^4*t^2 + 16*d*mm^4*t^2 + 16*mm^2*s*t^2 - 
   8*d*mm^2*s*t^2 + 32*me^2*mm^4*SP[p2, q1] - 16*d*me^2*mm^4*SP[p2, q1] + 
   32*mm^6*SP[p2, q1] - 16*d*mm^6*SP[p2, q1] - 32*me^2*mm^2*s*SP[p2, q1] - 
   48*mm^4*s*SP[p2, q1] + 16*d*mm^4*s*SP[p2, q1] + 16*mm^2*s^2*SP[p2, q1] - 
   8*d*mm^2*s^2*SP[p2, q1] - 32*mm^4*t*SP[p2, q1] + 16*d*mm^4*t*SP[p2, q1] + 
   48*mm^2*s*t*SP[p2, q1] - 16*d*mm^2*s*t*SP[p2, q1] - 
   256*me^2*mm^2*SP[p2, q1]^2 + 256*d*me^2*mm^2*SP[p2, q1]^2 - 
   80*d^2*me^2*mm^2*SP[p2, q1]^2 + 8*d^3*me^2*mm^2*SP[p2, q1]^2 - 
   16*mm^4*SP[p2, q1]^2 + 16*d*mm^4*SP[p2, q1]^2 - 4*d^2*mm^4*SP[p2, q1]^2 - 
   128*mm^2*s*SP[p2, q1]^2 + 128*d*mm^2*s*SP[p2, q1]^2 - 
   40*d^2*mm^2*s*SP[p2, q1]^2 + 4*d^3*mm^2*s*SP[p2, q1]^2 + 
   16*mm^2*t*SP[p2, q1]^2 - 16*d*mm^2*t*SP[p2, q1]^2 + 
   4*d^2*mm^2*t*SP[p2, q1]^2 + 64*me^2*mm^4*SP[p2, q2] - 
   64*d*me^2*mm^4*SP[p2, q2] + 32*mm^6*SP[p2, q2] - 48*d*mm^6*SP[p2, q2] + 
   32*me^2*mm^2*s*SP[p2, q2] + 32*mm^4*s*SP[p2, q2] + 
   16*d*mm^4*s*SP[p2, q2] - 32*me^2*s^2*SP[p2, q2] + 
   16*d*me^2*s^2*SP[p2, q2] + 8*mm^2*s^2*SP[p2, q2] - 
   12*d*mm^2*s^2*SP[p2, q2] - 16*s^3*SP[p2, q2] + 8*d*s^3*SP[p2, q2] - 
   64*mm^4*t*SP[p2, q2] + 64*d*mm^4*t*SP[p2, q2] + 16*mm^2*s*t*SP[p2, q2] - 
   40*d*mm^2*s*t*SP[p2, q2] + 8*s^2*t*SP[p2, q2] + 4*d*s^2*t*SP[p2, q2] + 
   32*mm^2*t^2*SP[p2, q2] - 16*d*mm^2*t^2*SP[p2, q2] - 16*s*t^2*SP[p2, q2] + 
   8*d*s*t^2*SP[p2, q2] + 384*me^2*mm^2*SP[p2, q1]*SP[p2, q2] - 
   128*d*me^2*mm^2*SP[p2, q1]*SP[p2, q2] + 16*d^2*me^2*mm^2*SP[p2, q1]*
    SP[p2, q2] + 96*mm^4*SP[p2, q1]*SP[p2, q2] - 
   64*me^2*s*SP[p2, q1]*SP[p2, q2] + 32*d*me^2*s*SP[p2, q1]*SP[p2, q2] + 
   160*mm^2*s*SP[p2, q1]*SP[p2, q2] - 80*d*mm^2*s*SP[p2, q1]*SP[p2, q2] + 
   8*d^2*mm^2*s*SP[p2, q1]*SP[p2, q2] - 32*s^2*SP[p2, q1]*SP[p2, q2] + 
   16*d*s^2*SP[p2, q1]*SP[p2, q2] - 192*mm^2*t*SP[p2, q1]*SP[p2, q2] + 
   16*d*mm^2*t*SP[p2, q1]*SP[p2, q2] + 32*s*t*SP[p2, q1]*SP[p2, q2] + 
   96*t^2*SP[p2, q1]*SP[p2, q2] - 16*d*t^2*SP[p2, q1]*SP[p2, q2] - 
   32*mm^4*SP[p2, q2]^2 + 16*d*mm^4*SP[p2, q2]^2 + 16*mm^2*s*SP[p2, q2]^2 - 
   8*d*mm^2*s*SP[p2, q2]^2 + 32*mm^2*t*SP[p2, q2]^2 - 
   16*d*mm^2*t*SP[p2, q2]^2 - 16*s*t*SP[p2, q2]^2 + 8*d*s*t*SP[p2, q2]^2 - 
   64*me^2*mm^4*SP[p3, q1] + 32*d*me^2*mm^4*SP[p3, q1] + 
   64*me^2*mm^2*s*SP[p3, q1] - 32*mm^4*s*SP[p3, q1] + 
   16*d*mm^4*s*SP[p3, q1] + 16*mm^2*s^2*SP[p3, q1] + 
   64*me^2*mm^2*SP[p2, q1]*SP[p3, q1] - 64*d*me^2*mm^2*SP[p2, q1]*
    SP[p3, q1] + 16*d^2*me^2*mm^2*SP[p2, q1]*SP[p3, q1] + 
   32*mm^4*SP[p2, q1]*SP[p3, q1] - 32*d*mm^4*SP[p2, q1]*SP[p3, q1] + 
   8*d^2*mm^4*SP[p2, q1]*SP[p3, q1] + 16*mm^2*s*SP[p2, q1]*SP[p3, q1] - 
   16*d*mm^2*s*SP[p2, q1]*SP[p3, q1] + 4*d^2*mm^2*s*SP[p2, q1]*SP[p3, q1] - 
   32*mm^2*t*SP[p2, q1]*SP[p3, q1] + 32*d*mm^2*t*SP[p2, q1]*SP[p3, q1] - 
   8*d^2*mm^2*t*SP[p2, q1]*SP[p3, q1] + 64*me^2*mm^2*SP[p2, q2]*SP[p3, q1] - 
   64*d*me^2*mm^2*SP[p2, q2]*SP[p3, q1] - 32*d*mm^4*SP[p2, q2]*SP[p3, q1] - 
   160*me^2*s*SP[p2, q2]*SP[p3, q1] + 80*d*me^2*s*SP[p2, q2]*SP[p3, q1] - 
   16*d^2*me^2*s*SP[p2, q2]*SP[p3, q1] + 32*mm^2*s*SP[p2, q2]*SP[p3, q1] - 
   16*d*mm^2*s*SP[p2, q2]*SP[p3, q1] - 96*s^2*SP[p2, q2]*SP[p3, q1] + 
   48*d*s^2*SP[p2, q2]*SP[p3, q1] - 8*d^2*s^2*SP[p2, q2]*SP[p3, q1] + 
   32*d*mm^2*t*SP[p2, q2]*SP[p3, q1] + 832*me^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] - 544*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
   112*d^2*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
   8*d^3*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 416*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] - 272*d*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
   56*d^2*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 4*d^3*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] + 64*me^2*SP[p2, q2]^2*SP[p3, q1] - 
   32*d*me^2*SP[p2, q2]^2*SP[p3, q1] - 64*me^2*mm^2*SP[p3, q1]^2 + 
   64*d*me^2*mm^2*SP[p3, q1]^2 - 16*d^2*me^2*mm^2*SP[p3, q1]^2 - 
   32*mm^2*s*SP[p3, q1]^2 + 32*d*mm^2*s*SP[p3, q1]^2 - 
   8*d^2*mm^2*s*SP[p3, q1]^2 + 64*me^2*SP[p2, q2]*SP[p3, q1]^2 - 
   64*d*me^2*SP[p2, q2]*SP[p3, q1]^2 + 16*d^2*me^2*SP[p2, q2]*SP[p3, q1]^2 + 
   32*s*SP[p2, q2]*SP[p3, q1]^2 - 32*d*s*SP[p2, q2]*SP[p3, q1]^2 + 
   8*d^2*s*SP[p2, q2]*SP[p3, q1]^2 + 64*d*me^2*mm^4*SP[p3, q2] - 
   192*me^2*mm^2*s*SP[p3, q2] + 96*d*me^2*mm^2*s*SP[p3, q2] - 
   16*d^2*me^2*mm^2*s*SP[p3, q2] + 32*d*mm^4*s*SP[p3, q2] + 
   96*me^2*s^2*SP[p3, q2] - 64*d*me^2*s^2*SP[p3, q2] + 
   8*d^2*me^2*s^2*SP[p3, q2] - 144*mm^2*s^2*SP[p3, q2] + 
   56*d*mm^2*s^2*SP[p3, q2] - 8*d^2*mm^2*s^2*SP[p3, q2] + 72*s^3*SP[p3, q2] - 
   36*d*s^3*SP[p3, q2] + 4*d^2*s^3*SP[p3, q2] - 64*me^2*mm^2*SP[p2, q1]*
    SP[p3, q2] - 96*me^2*s*SP[p2, q1]*SP[p3, q2] + 
   16*d*me^2*s*SP[p2, q1]*SP[p3, q2] - 128*mm^2*s*SP[p2, q1]*SP[p3, q2] + 
   16*d*mm^2*s*SP[p2, q1]*SP[p3, q2] + 96*s*t*SP[p2, q1]*SP[p3, q2] - 
   16*d*s*t*SP[p2, q1]*SP[p3, q2] - 832*me^2*SP[p2, q1]^2*SP[p3, q2] + 
   544*d*me^2*SP[p2, q1]^2*SP[p3, q2] - 112*d^2*me^2*SP[p2, q1]^2*
    SP[p3, q2] + 8*d^3*me^2*SP[p2, q1]^2*SP[p3, q2] - 
   416*s*SP[p2, q1]^2*SP[p3, q2] + 272*d*s*SP[p2, q1]^2*SP[p3, q2] - 
   56*d^2*s*SP[p2, q1]^2*SP[p3, q2] + 4*d^3*s*SP[p2, q1]^2*SP[p3, q2] + 
   128*me^2*mm^2*SP[p2, q2]*SP[p3, q2] - 64*d*me^2*mm^2*SP[p2, q2]*
    SP[p3, q2] + 64*mm^4*SP[p2, q2]*SP[p3, q2] - 
   32*d*mm^4*SP[p2, q2]*SP[p3, q2] - 64*me^2*s*SP[p2, q2]*SP[p3, q2] + 
   32*d*me^2*s*SP[p2, q2]*SP[p3, q2] - 16*s^2*SP[p2, q2]*SP[p3, q2] + 
   8*d*s^2*SP[p2, q2]*SP[p3, q2] - 64*mm^2*t*SP[p2, q2]*SP[p3, q2] + 
   32*d*mm^2*t*SP[p2, q2]*SP[p3, q2] + 32*s*t*SP[p2, q2]*SP[p3, q2] - 
   16*d*s*t*SP[p2, q2]*SP[p3, q2] - 64*me^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] + 32*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
   64*d*me^2*mm^2*SP[p3, q1]*SP[p3, q2] + 192*me^2*s*SP[p3, q1]*SP[p3, q2] - 
   32*d*me^2*s*SP[p3, q1]*SP[p3, q2] + 32*d*mm^2*s*SP[p3, q1]*SP[p3, q2] + 
   96*s^2*SP[p3, q1]*SP[p3, q2] - 16*d*s^2*SP[p3, q1]*SP[p3, q2] - 
   64*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 64*d*me^2*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] - 16*d^2*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 
   32*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 32*d*s*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] - 8*d^2*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 
   128*me^2*mm^2*SP[p3, q2]^2 + 64*d*me^2*mm^2*SP[p3, q2]^2 + 
   64*me^2*s*SP[p3, q2]^2 - 32*d*me^2*s*SP[p3, q2]^2 - 
   64*mm^2*s*SP[p3, q2]^2 + 32*d*mm^2*s*SP[p3, q2]^2 + 32*s^2*SP[p3, q2]^2 - 
   16*d*s^2*SP[p3, q2]^2 + 32*me^2*mm^4*SP[q1, q1] - 
   32*d*me^2*mm^4*SP[q1, q1] + 8*d^2*me^2*mm^4*SP[q1, q1] + 
   16*mm^6*SP[q1, q1] - 16*d*mm^6*SP[q1, q1] + 4*d^2*mm^6*SP[q1, q1] + 
   160*me^2*mm^2*s*SP[q1, q1] - 120*d*me^2*mm^2*s*SP[q1, q1] + 
   28*d^2*me^2*mm^2*s*SP[q1, q1] - 2*d^3*me^2*mm^2*s*SP[q1, q1] + 
   112*mm^2*s^2*SP[q1, q1] - 76*d*mm^2*s^2*SP[q1, q1] + 
   16*d^2*mm^2*s^2*SP[q1, q1] - d^3*mm^2*s^2*SP[q1, q1] - 
   32*mm^4*t*SP[q1, q1] + 32*d*mm^4*t*SP[q1, q1] - 8*d^2*mm^4*t*SP[q1, q1] + 
   16*mm^2*s*t*SP[q1, q1] - 16*d*mm^2*s*t*SP[q1, q1] + 
   4*d^2*mm^2*s*t*SP[q1, q1] + 16*mm^2*t^2*SP[q1, q1] - 
   16*d*mm^2*t^2*SP[q1, q1] + 4*d^2*mm^2*t^2*SP[q1, q1] - 
   32*me^2*mm^2*SP[p2, q2]*SP[q1, q1] + 32*d*me^2*mm^2*SP[p2, q2]*
    SP[q1, q1] - 16*d^2*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 
   16*mm^4*SP[p2, q2]*SP[q1, q1] + 16*d*mm^4*SP[p2, q2]*SP[q1, q1] - 
   12*d^2*mm^4*SP[p2, q2]*SP[q1, q1] - 256*me^2*s*SP[p2, q2]*SP[q1, q1] + 
   128*d*me^2*s*SP[p2, q2]*SP[q1, q1] - 16*d^2*me^2*s*SP[p2, q2]*SP[q1, q1] - 
   72*mm^2*s*SP[p2, q2]*SP[q1, q1] + 24*d*mm^2*s*SP[p2, q2]*SP[q1, q1] - 
   2*d^2*mm^2*s*SP[p2, q2]*SP[q1, q1] - 128*s^2*SP[p2, q2]*SP[q1, q1] + 
   64*d*s^2*SP[p2, q2]*SP[q1, q1] - 8*d^2*s^2*SP[p2, q2]*SP[q1, q1] + 
   32*mm^2*t*SP[p2, q2]*SP[q1, q1] - 32*d*mm^2*t*SP[p2, q2]*SP[q1, q1] + 
   16*d^2*mm^2*t*SP[p2, q2]*SP[q1, q1] + 56*s*t*SP[p2, q2]*SP[q1, q1] - 
   8*d*s*t*SP[p2, q2]*SP[q1, q1] - 2*d^2*s*t*SP[p2, q2]*SP[q1, q1] - 
   16*t^2*SP[p2, q2]*SP[q1, q1] + 16*d*t^2*SP[p2, q2]*SP[q1, q1] - 
   4*d^2*t^2*SP[p2, q2]*SP[q1, q1] + 16*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   16*d*mm^2*SP[p2, q2]^2*SP[q1, q1] + 4*d^2*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   16*t*SP[p2, q2]^2*SP[q1, q1] + 16*d*t*SP[p2, q2]^2*SP[q1, q1] - 
   4*d^2*t*SP[p2, q2]^2*SP[q1, q1] + 16*d^2*me^2*mm^2*SP[p3, q2]*SP[q1, q1] + 
   576*me^2*s*SP[p3, q2]*SP[q1, q1] - 336*d*me^2*s*SP[p3, q2]*SP[q1, q1] + 
   64*d^2*me^2*s*SP[p3, q2]*SP[q1, q1] - 4*d^3*me^2*s*SP[p3, q2]*SP[q1, q1] + 
   8*d^2*mm^2*s*SP[p3, q2]*SP[q1, q1] + 360*s^2*SP[p3, q2]*SP[q1, q1] - 
   192*d*s^2*SP[p3, q2]*SP[q1, q1] + 34*d^2*s^2*SP[p3, q2]*SP[q1, q1] - 
   2*d^3*s^2*SP[p3, q2]*SP[q1, q1] - 64*me^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 64*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   16*d^2*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   32*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 32*d*mm^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] - 8*d^2*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   16*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 16*d*s*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] - 4*d^2*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   32*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 32*d*t*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 8*d^2*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   64*me^2*SP[p3, q2]^2*SP[q1, q1] - 64*d*me^2*SP[p3, q2]^2*SP[q1, q1] + 
   16*d^2*me^2*SP[p3, q2]^2*SP[q1, q1] + 32*s*SP[p3, q2]^2*SP[q1, q1] - 
   32*d*s*SP[p3, q2]^2*SP[q1, q1] + 8*d^2*s*SP[p3, q2]^2*SP[q1, q1] - 
   4*(-2 + d)*SP[p1, q2]^2*(4*s*SP[p2, q1] + 8*me^2*SP[p3, q1] + 
     (mm^2 - s - t)*(4*mm^2 - 2*s + (-2 + d)*SP[q1, q1])) - 
   384*me^2*mm^2*s*SP[q1, q2] + 144*d*me^2*mm^2*s*SP[q1, q2] - 
   16*d^2*me^2*mm^2*s*SP[q1, q2] - 96*mm^4*s*SP[q1, q2] + 
   16*d*mm^4*s*SP[q1, q2] + 144*me^2*s^2*SP[q1, q2] - 
   72*d*me^2*s^2*SP[q1, q2] + 8*d^2*me^2*s^2*SP[q1, q2] - 
   144*mm^2*s^2*SP[q1, q2] + 64*d*mm^2*s^2*SP[q1, q2] - 
   8*d^2*mm^2*s^2*SP[q1, q2] + 72*s^3*SP[q1, q2] - 36*d*s^3*SP[q1, q2] + 
   4*d^2*s^3*SP[q1, q2] + 192*mm^2*s*t*SP[q1, q2] - 
   32*d*mm^2*s*t*SP[q1, q2] - 96*s^2*t*SP[q1, q2] + 16*d*s^2*t*SP[q1, q2] - 
   96*s*t^2*SP[q1, q2] + 16*d*s*t^2*SP[q1, q2] + 
   416*me^2*s*SP[p2, q1]*SP[q1, q2] - 272*d*me^2*s*SP[p2, q1]*SP[q1, q2] + 
   56*d^2*me^2*s*SP[p2, q1]*SP[q1, q2] - 4*d^3*me^2*s*SP[p2, q1]*SP[q1, q2] + 
   144*mm^2*s*SP[p2, q1]*SP[q1, q2] - 48*d*mm^2*s*SP[p2, q1]*SP[q1, q2] + 
   4*d^2*mm^2*s*SP[p2, q1]*SP[q1, q2] + 208*s^2*SP[p2, q1]*SP[q1, q2] - 
   136*d*s^2*SP[p2, q1]*SP[q1, q2] + 28*d^2*s^2*SP[p2, q1]*SP[q1, q2] - 
   2*d^3*s^2*SP[p2, q1]*SP[q1, q2] - 144*s*t*SP[p2, q1]*SP[q1, q2] + 
   48*d*s*t*SP[p2, q1]*SP[q1, q2] - 4*d^2*s*t*SP[p2, q1]*SP[q1, q2] + 
   64*me^2*mm^2*SP[p2, q2]*SP[q1, q2] - 32*d*me^2*mm^2*SP[p2, q2]*
    SP[q1, q2] + 64*mm^4*SP[p2, q2]*SP[q1, q2] - 
   32*d*mm^4*SP[p2, q2]*SP[q1, q2] - 32*me^2*s*SP[p2, q2]*SP[q1, q2] + 
   16*d*me^2*s*SP[p2, q2]*SP[q1, q2] - 16*s^2*SP[p2, q2]*SP[q1, q2] + 
   8*d*s^2*SP[p2, q2]*SP[q1, q2] - 64*mm^2*t*SP[p2, q2]*SP[q1, q2] + 
   32*d*mm^2*t*SP[p2, q2]*SP[q1, q2] - 32*mm^2*SP[p2, q1]*SP[p2, q2]*
    SP[q1, q2] + 32*d*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 
   8*d^2*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 32*t*SP[p2, q1]*SP[p2, q2]*
    SP[q1, q2] - 32*d*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 
   8*d^2*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 864*me^2*s*SP[p3, q1]*
    SP[q1, q2] + 576*d*me^2*s*SP[p3, q1]*SP[q1, q2] - 
   120*d^2*me^2*s*SP[p3, q1]*SP[q1, q2] + 8*d^3*me^2*s*SP[p3, q1]*
    SP[q1, q2] - 576*s^2*SP[p3, q1]*SP[q1, q2] + 
   336*d*s^2*SP[p3, q1]*SP[q1, q2] - 64*d^2*s^2*SP[p3, q1]*SP[q1, q2] + 
   4*d^3*s^2*SP[p3, q1]*SP[q1, q2] + 64*me^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] - 64*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   16*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   64*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 64*d*mm^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] + 16*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   64*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 64*d*t*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] - 16*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   128*me^2*mm^2*SP[p3, q2]*SP[q1, q2] + 64*d*me^2*mm^2*SP[p3, q2]*
    SP[q1, q2] + 64*me^2*s*SP[p3, q2]*SP[q1, q2] - 
   32*d*me^2*s*SP[p3, q2]*SP[q1, q2] - 64*mm^2*s*SP[p3, q2]*SP[q1, q2] + 
   32*d*mm^2*s*SP[p3, q2]*SP[q1, q2] + 32*s^2*SP[p3, q2]*SP[q1, q2] - 
   16*d*s^2*SP[p3, q2]*SP[q1, q2] + 64*me^2*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] - 64*d*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 
   16*d^2*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 
   32*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 32*d*s*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] + 8*d^2*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   128*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 128*d*me^2*SP[p3, q1]*
    SP[p3, q2]*SP[q1, q2] - 32*d^2*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
   64*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 64*d*s*SP[p3, q1]*SP[p3, q2]*
    SP[q1, q2] - 16*d^2*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
   32*me^2*s*SP[q1, q2]^2 + 32*d*me^2*s*SP[q1, q2]^2 - 
   8*d^2*me^2*s*SP[q1, q2]^2 - 16*s^2*SP[q1, q2]^2 + 16*d*s^2*SP[q1, q2]^2 - 
   4*d^2*s^2*SP[q1, q2]^2 - 2*SP[p1, q2]*(-32*me^2*mm^4 + 32*d*me^2*mm^4 - 
     16*mm^6 - 8*d*mm^6 - 16*me^2*mm^2*s + 32*mm^4*s + 16*d*mm^4*s + 
     16*me^2*s^2 - 8*d*me^2*s^2 - 52*mm^2*s^2 + 6*d*mm^2*s^2 + 20*s^3 - 
     6*d*s^3 + 32*mm^4*t - 56*mm^2*s*t + 12*d*mm^2*s*t + 20*s^2*t - 
     6*d*s^2*t - 16*mm^2*t^2 + 8*d*mm^2*t^2 + 8*s*t^2 - 4*d*s*t^2 - 
     32*(-4 + d)*(mm^2 - t)*SP[p2, q1]^2 - 16*mm^2*s*SP[p2, q2] + 
     8*d*mm^2*s*SP[p2, q2] + 8*s^2*SP[p2, q2] - 4*d*s^2*SP[p2, q2] - 
     32*me^2*mm^2*SP[p3, q1] + 32*d*me^2*mm^2*SP[p3, q1] - 
     16*d*mm^4*SP[p3, q1] + 80*me^2*s*SP[p3, q1] - 40*d*me^2*s*SP[p3, q1] + 
     8*d^2*me^2*s*SP[p3, q1] - 16*mm^2*s*SP[p3, q1] + 
     24*d*mm^2*s*SP[p3, q1] + 48*s^2*SP[p3, q1] - 24*d*s^2*SP[p3, q1] + 
     4*d^2*s^2*SP[p3, q1] + 16*d*mm^2*t*SP[p3, q1] - 
     64*me^2*SP[p2, q2]*SP[p3, q1] + 32*d*me^2*SP[p2, q2]*SP[p3, q1] - 
     64*s*SP[p2, q2]*SP[p3, q1] + 32*d*s*SP[p2, q2]*SP[p3, q1] - 
     32*me^2*SP[p3, q1]^2 + 32*d*me^2*SP[p3, q1]^2 - 
     8*d^2*me^2*SP[p3, q1]^2 - 16*s*SP[p3, q1]^2 + 16*d*s*SP[p3, q1]^2 - 
     4*d^2*s*SP[p3, q1]^2 - 64*me^2*mm^2*SP[p3, q2] + 
     32*d*me^2*mm^2*SP[p3, q2] + 32*mm^4*SP[p3, q2] - 16*d*mm^4*SP[p3, q2] + 
     32*me^2*s*SP[p3, q2] - 16*d*me^2*s*SP[p3, q2] - 64*mm^2*s*SP[p3, q2] + 
     32*d*mm^2*s*SP[p3, q2] + 24*s^2*SP[p3, q2] - 12*d*s^2*SP[p3, q2] - 
     32*mm^2*t*SP[p3, q2] + 16*d*mm^2*t*SP[p3, q2] + 16*s*t*SP[p3, q2] - 
     8*d*s*t*SP[p3, q2] + 16*me^2*mm^2*SP[q1, q1] - 
     16*d*me^2*mm^2*SP[q1, q1] + 8*d^2*me^2*mm^2*SP[q1, q1] + 
     8*mm^4*SP[q1, q1] - 8*d*mm^4*SP[q1, q1] - 2*d^2*mm^4*SP[q1, q1] + 
     128*me^2*s*SP[q1, q1] - 64*d*me^2*s*SP[q1, q1] + 
     8*d^2*me^2*s*SP[q1, q1] - 36*mm^2*s*SP[q1, q1] + 
     12*d*mm^2*s*SP[q1, q1] + 3*d^2*mm^2*s*SP[q1, q1] + 100*s^2*SP[q1, q1] - 
     44*d*s^2*SP[q1, q1] + 5*d^2*s^2*SP[q1, q1] - 16*mm^2*t*SP[q1, q1] + 
     16*d*mm^2*t*SP[q1, q1] + 44*s*t*SP[q1, q1] - 20*d*s*t*SP[q1, q1] + 
     3*d^2*s*t*SP[q1, q1] + 8*t^2*SP[q1, q1] - 8*d*t^2*SP[q1, q1] + 
     2*d^2*t^2*SP[q1, q1] + 8*s*SP[p2, q2]*SP[q1, q1] - 
     8*d*s*SP[p2, q2]*SP[q1, q1] + 2*d^2*s*SP[p2, q2]*SP[q1, q1] + 
     32*me^2*SP[p3, q2]*SP[q1, q1] - 32*d*me^2*SP[p3, q2]*SP[q1, q1] + 
     8*d^2*me^2*SP[p3, q2]*SP[q1, q1] - 16*mm^2*SP[p3, q2]*SP[q1, q1] + 
     16*d*mm^2*SP[p3, q2]*SP[q1, q1] - 4*d^2*mm^2*SP[p3, q2]*SP[q1, q1] + 
     24*s*SP[p3, q2]*SP[q1, q1] - 24*d*s*SP[p3, q2]*SP[q1, q1] + 
     6*d^2*s*SP[p3, q2]*SP[q1, q1] + 16*t*SP[p3, q2]*SP[q1, q1] - 
     16*d*t*SP[p3, q2]*SP[q1, q1] + 4*d^2*t*SP[p3, q2]*SP[q1, q1] - 
     32*me^2*mm^2*SP[q1, q2] + 16*d*me^2*mm^2*SP[q1, q2] + 
     32*mm^4*SP[q1, q2] - 16*d*mm^4*SP[q1, q2] + 16*me^2*s*SP[q1, q2] - 
     8*d*me^2*s*SP[q1, q2] - 32*mm^2*s*SP[q1, q2] + 16*d*mm^2*s*SP[q1, q2] + 
     8*s^2*SP[q1, q2] - 4*d*s^2*SP[q1, q2] - 32*mm^2*t*SP[q1, q2] + 
     16*d*mm^2*t*SP[q1, q2] - 32*me^2*SP[p3, q1]*SP[q1, q2] + 
     32*d*me^2*SP[p3, q1]*SP[q1, q2] - 8*d^2*me^2*SP[p3, q1]*SP[q1, q2] + 
     32*mm^2*SP[p3, q1]*SP[q1, q2] - 32*d*mm^2*SP[p3, q1]*SP[q1, q2] + 
     8*d^2*mm^2*SP[p3, q1]*SP[q1, q2] - 32*s*SP[p3, q1]*SP[q1, q2] + 
     32*d*s*SP[p3, q1]*SP[q1, q2] - 8*d^2*s*SP[p3, q1]*SP[q1, q2] - 
     32*t*SP[p3, q1]*SP[q1, q2] + 32*d*t*SP[p3, q1]*SP[q1, q2] - 
     8*d^2*t*SP[p3, q1]*SP[q1, q2] - 2*SP[p2, q1]*(4*(-2 + d)*s*SP[p2, q2] + 
       (-2*(-104 + 68*d - 14*d^2 + d^3)*me^2 - 4*(-2 + d)^2*mm^2 + 184*s - 
         100*d*s + 18*d^2*s - d^3*s + 16*t - 16*d*t + 4*d^2*t)*SP[p3, q1] + 
       2*(48*me^2*mm^2 - 16*d*me^2*mm^2 + 2*d^2*me^2*mm^2 + 4*mm^4 - 
         8*me^2*s + 4*d*me^2*s + 36*mm^2*s - 10*d*mm^2*s + d^2*mm^2*s - 
         10*s^2 + 3*d*s^2 - 16*mm^2*t + 2*d*mm^2*t + 4*s*t + 12*t^2 - 
         2*d*t^2 + 4*(-2 + d)*(me^2 + s)*SP[p3, q2] + (-2 + d)^2*(mm^2 - t)*
          SP[q1, q2]))) + 64*me^2*mm^4*SP[q2, q2] - 
   32*d*me^2*mm^4*SP[q2, q2] + 32*mm^6*SP[q2, q2] - 16*d*mm^6*SP[q2, q2] - 
   96*me^2*mm^2*s*SP[q2, q2] + 64*d*me^2*mm^2*s*SP[q2, q2] - 
   8*d^2*me^2*mm^2*s*SP[q2, q2] - 16*mm^4*s*SP[q2, q2] + 
   8*d*mm^4*s*SP[q2, q2] + 32*me^2*s^2*SP[q2, q2] - 
   24*d*me^2*s^2*SP[q2, q2] + 4*d^2*me^2*s^2*SP[q2, q2] - 
   32*mm^2*s^2*SP[q2, q2] + 24*d*mm^2*s^2*SP[q2, q2] - 
   4*d^2*mm^2*s^2*SP[q2, q2] + 16*s^3*SP[q2, q2] - 12*d*s^3*SP[q2, q2] + 
   2*d^2*s^3*SP[q2, q2] - 64*mm^4*t*SP[q2, q2] + 32*d*mm^4*t*SP[q2, q2] + 
   64*mm^2*s*t*SP[q2, q2] - 32*d*mm^2*s*t*SP[q2, q2] - 16*s^2*t*SP[q2, q2] + 
   8*d*s^2*t*SP[q2, q2] + 32*mm^2*t^2*SP[q2, q2] - 16*d*mm^2*t^2*SP[q2, q2] - 
   16*s*t^2*SP[q2, q2] + 8*d*s*t^2*SP[q2, q2] - 32*me^2*mm^2*SP[p2, q1]*
    SP[q2, q2] + 16*d*me^2*mm^2*SP[p2, q1]*SP[q2, q2] - 
   32*mm^4*SP[p2, q1]*SP[q2, q2] + 16*d*mm^4*SP[p2, q1]*SP[q2, q2] + 
   64*me^2*s*SP[p2, q1]*SP[q2, q2] - 48*d*me^2*s*SP[p2, q1]*SP[q2, q2] + 
   8*d^2*me^2*s*SP[p2, q1]*SP[q2, q2] + 16*mm^2*s*SP[p2, q1]*SP[q2, q2] - 
   8*d*mm^2*s*SP[p2, q1]*SP[q2, q2] + 32*s^2*SP[p2, q1]*SP[q2, q2] - 
   24*d*s^2*SP[p2, q1]*SP[q2, q2] + 4*d^2*s^2*SP[p2, q1]*SP[q2, q2] + 
   32*mm^2*t*SP[p2, q1]*SP[q2, q2] - 16*d*mm^2*t*SP[p2, q1]*SP[q2, q2] - 
   16*s*t*SP[p2, q1]*SP[q2, q2] + 8*d*s*t*SP[p2, q1]*SP[q2, q2] + 
   16*mm^2*SP[p2, q1]^2*SP[q2, q2] - 16*d*mm^2*SP[p2, q1]^2*SP[q2, q2] + 
   4*d^2*mm^2*SP[p2, q1]^2*SP[q2, q2] - 16*t*SP[p2, q1]^2*SP[q2, q2] + 
   16*d*t*SP[p2, q1]^2*SP[q2, q2] - 4*d^2*t*SP[p2, q1]^2*SP[q2, q2] + 
   64*me^2*mm^2*SP[p3, q1]*SP[q2, q2] - 32*d*me^2*mm^2*SP[p3, q1]*
    SP[q2, q2] - 128*me^2*s*SP[p3, q1]*SP[q2, q2] + 
   96*d*me^2*s*SP[p3, q1]*SP[q2, q2] - 16*d^2*me^2*s*SP[p3, q1]*SP[q2, q2] + 
   32*mm^2*s*SP[p3, q1]*SP[q2, q2] - 16*d*mm^2*s*SP[p3, q1]*SP[q2, q2] - 
   80*s^2*SP[p3, q1]*SP[q2, q2] + 56*d*s^2*SP[p3, q1]*SP[q2, q2] - 
   8*d^2*s^2*SP[p3, q1]*SP[q2, q2] - 64*me^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] + 64*d*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   16*d^2*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   32*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 32*d*mm^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 8*d^2*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   16*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 16*d*s*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 4*d^2*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   32*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 32*d*t*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] + 8*d^2*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   64*me^2*SP[p3, q1]^2*SP[q2, q2] - 64*d*me^2*SP[p3, q1]^2*SP[q2, q2] + 
   16*d^2*me^2*SP[p3, q1]^2*SP[q2, q2] + 32*s*SP[p3, q1]^2*SP[q2, q2] - 
   32*d*s*SP[p3, q1]^2*SP[q2, q2] + 8*d^2*s*SP[p3, q1]^2*SP[q2, q2] - 
   32*me^2*mm^2*SP[q1, q1]*SP[q2, q2] + 32*d*me^2*mm^2*SP[q1, q1]*
    SP[q2, q2] - 8*d^2*me^2*mm^2*SP[q1, q1]*SP[q2, q2] - 
   16*mm^4*SP[q1, q1]*SP[q2, q2] + 16*d*mm^4*SP[q1, q1]*SP[q2, q2] - 
   4*d^2*mm^4*SP[q1, q1]*SP[q2, q2] + 48*me^2*s*SP[q1, q1]*SP[q2, q2] - 
   56*d*me^2*s*SP[q1, q1]*SP[q2, q2] + 20*d^2*me^2*s*SP[q1, q1]*SP[q2, q2] - 
   2*d^3*me^2*s*SP[q1, q1]*SP[q2, q2] + 24*s^2*SP[q1, q1]*SP[q2, q2] - 
   28*d*s^2*SP[q1, q1]*SP[q2, q2] + 10*d^2*s^2*SP[q1, q1]*SP[q2, q2] - 
   d^3*s^2*SP[q1, q1]*SP[q2, q2] + 32*mm^2*t*SP[q1, q1]*SP[q2, q2] - 
   32*d*mm^2*t*SP[q1, q1]*SP[q2, q2] + 8*d^2*mm^2*t*SP[q1, q1]*SP[q2, q2] - 
   16*s*t*SP[q1, q1]*SP[q2, q2] + 16*d*s*t*SP[q1, q1]*SP[q2, q2] - 
   4*d^2*s*t*SP[q1, q1]*SP[q2, q2] - 16*t^2*SP[q1, q1]*SP[q2, q2] + 
   16*d*t^2*SP[q1, q1]*SP[q2, q2] - 4*d^2*t^2*SP[q1, q1]*SP[q2, q2] - 
   2*SP[p1, q1]*(-16*me^2*mm^4 + 8*d*me^2*mm^4 + 16*mm^6 - 8*d*mm^6 + 
     16*me^2*mm^2*s - 40*mm^4*s + 16*d*mm^4*s + 16*mm^2*s^2 - 4*d*mm^2*s^2 - 
     16*mm^4*t + 8*d*mm^4*t + 24*mm^2*s*t - 8*d*mm^2*s*t - 
     192*me^2*mm^2*SP[p2, q2] + 64*d*me^2*mm^2*SP[p2, q2] - 
     8*d^2*me^2*mm^2*SP[p2, q2] - 80*mm^4*SP[p2, q2] + 16*d*mm^4*SP[p2, q2] + 
     32*me^2*s*SP[p2, q2] - 16*d*me^2*s*SP[p2, q2] - 48*mm^2*s*SP[p2, q2] + 
     16*d*mm^2*s*SP[p2, q2] - 4*d^2*mm^2*s*SP[p2, q2] + 8*s^2*SP[p2, q2] - 
     4*d*s^2*SP[p2, q2] + 128*mm^2*t*SP[p2, q2] - 24*d*mm^2*t*SP[p2, q2] - 
     80*s*t*SP[p2, q2] + 16*d*s*t*SP[p2, q2] - 48*t^2*SP[p2, q2] + 
     8*d*t^2*SP[p2, q2] - 16*s*SP[p2, q2]^2 + 8*d*s*SP[p2, q2]^2 - 
     32*me^2*mm^2*SP[p3, q1] + 32*d*me^2*mm^2*SP[p3, q1] - 
     8*d^2*me^2*mm^2*SP[p3, q1] + 16*mm^4*SP[p3, q1] - 16*d*mm^4*SP[p3, q1] + 
     4*d^2*mm^4*SP[p3, q1] - 24*mm^2*s*SP[p3, q1] + 24*d*mm^2*s*SP[p3, q1] - 
     6*d^2*mm^2*s*SP[p3, q1] - 16*mm^2*t*SP[p3, q1] + 
     16*d*mm^2*t*SP[p3, q1] - 4*d^2*mm^2*t*SP[p3, q1] - 
     416*me^2*SP[p2, q2]*SP[p3, q1] + 272*d*me^2*SP[p2, q2]*SP[p3, q1] - 
     56*d^2*me^2*SP[p2, q2]*SP[p3, q1] + 4*d^3*me^2*SP[p2, q2]*SP[p3, q1] - 
     32*mm^2*SP[p2, q2]*SP[p3, q1] + 32*d*mm^2*SP[p2, q2]*SP[p3, q1] - 
     8*d^2*mm^2*SP[p2, q2]*SP[p3, q1] - 336*s*SP[p2, q2]*SP[p3, q1] + 
     168*d*s*SP[p2, q2]*SP[p3, q1] - 28*d^2*s*SP[p2, q2]*SP[p3, q1] + 
     2*d^3*s*SP[p2, q2]*SP[p3, q1] + 32*t*SP[p2, q2]*SP[p3, q1] - 
     32*d*t*SP[p2, q2]*SP[p3, q1] + 8*d^2*t*SP[p2, q2]*SP[p3, q1] + 
     32*me^2*mm^2*SP[p3, q2] + 48*me^2*s*SP[p3, q2] - 8*d*me^2*s*SP[p3, q2] - 
     32*mm^2*s*SP[p3, q2] + 8*d*mm^2*s*SP[p3, q2] + 48*s^2*SP[p3, q2] - 
     8*d*s^2*SP[p3, q2] + 48*s*t*SP[p3, q2] - 8*d*s*t*SP[p3, q2] + 
     32*me^2*SP[p2, q2]*SP[p3, q2] - 16*d*me^2*SP[p2, q2]*SP[p3, q2] + 
     32*s*SP[p2, q2]*SP[p3, q2] - 16*d*s*SP[p2, q2]*SP[p3, q2] + 
     32*me^2*SP[p3, q1]*SP[p3, q2] - 32*d*me^2*SP[p3, q1]*SP[p3, q2] + 
     8*d^2*me^2*SP[p3, q1]*SP[p3, q2] + 16*s*SP[p3, q1]*SP[p3, q2] - 
     16*d*s*SP[p3, q1]*SP[p3, q2] + 4*d^2*s*SP[p3, q1]*SP[p3, q2] - 
     208*me^2*s*SP[q1, q2] + 136*d*me^2*s*SP[q1, q2] - 
     28*d^2*me^2*s*SP[q1, q2] + 2*d^3*me^2*s*SP[q1, q2] + 
     72*mm^2*s*SP[q1, q2] - 24*d*mm^2*s*SP[q1, q2] + 
     2*d^2*mm^2*s*SP[q1, q2] - 176*s^2*SP[q1, q2] + 92*d*s^2*SP[q1, q2] - 
     16*d^2*s^2*SP[q1, q2] + d^3*s^2*SP[q1, q2] - 72*s*t*SP[q1, q2] + 
     24*d*s*t*SP[q1, q2] - 2*d^2*s*t*SP[q1, q2] + 16*mm^2*SP[p2, q2]*
      SP[q1, q2] - 16*d*mm^2*SP[p2, q2]*SP[q1, q2] + 
     4*d^2*mm^2*SP[p2, q2]*SP[q1, q2] - 16*s*SP[p2, q2]*SP[q1, q2] + 
     16*d*s*SP[p2, q2]*SP[q1, q2] - 4*d^2*s*SP[p2, q2]*SP[q1, q2] - 
     16*t*SP[p2, q2]*SP[q1, q2] + 16*d*t*SP[p2, q2]*SP[q1, q2] - 
     4*d^2*t*SP[p2, q2]*SP[q1, q2] - 32*me^2*SP[p3, q2]*SP[q1, q2] + 
     32*d*me^2*SP[p3, q2]*SP[q1, q2] - 8*d^2*me^2*SP[p3, q2]*SP[q1, q2] - 
     16*s*SP[p3, q2]*SP[q1, q2] + 16*d*s*SP[p3, q2]*SP[q1, q2] - 
     4*d^2*s*SP[p3, q2]*SP[q1, q2] - 2*SP[p1, q2]*(96*me^2*mm^2 - 
       32*d*me^2*mm^2 + 4*d^2*me^2*mm^2 + 24*mm^4 - 8*d*mm^4 - 16*me^2*s + 
       8*d*me^2*s + 8*mm^2*s - 8*d*mm^2*s + 2*d^2*mm^2*s + 8*s^2 - 
       48*mm^2*t + 12*d*mm^2*t + 40*s*t - 8*d*s*t + 24*t^2 - 4*d*t^2 + 
       16*(-4 + d)*(mm^2 - s - t)*SP[p2, q1] + 4*(-2 + d)*s*SP[p2, q2] + 
       208*me^2*SP[p3, q1] - 136*d*me^2*SP[p3, q1] + 28*d^2*me^2*SP[p3, q1] - 
       2*d^3*me^2*SP[p3, q1] + 104*s*SP[p3, q1] - 68*d*s*SP[p3, q1] + 
       14*d^2*s*SP[p3, q1] - d^3*s*SP[p3, q1] - 16*me^2*SP[p3, q2] + 
       8*d*me^2*SP[p3, q2] + 8*mm^2*SP[q1, q2] - 8*d*mm^2*SP[q1, q2] + 
       2*d^2*mm^2*SP[q1, q2] - 8*s*SP[q1, q2] + 8*d*s*SP[q1, q2] - 
       2*d^2*s*SP[q1, q2] - 8*t*SP[q1, q2] + 8*d*t*SP[q1, q2] - 
       2*d^2*t*SP[q1, q2]) + 16*me^2*mm^2*SP[q2, q2] - 
     8*d*me^2*mm^2*SP[q2, q2] - 16*mm^4*SP[q2, q2] + 8*d*mm^4*SP[q2, q2] - 
     32*me^2*s*SP[q2, q2] + 24*d*me^2*s*SP[q2, q2] - 
     4*d^2*me^2*s*SP[q2, q2] + 24*mm^2*s*SP[q2, q2] - 
     12*d*mm^2*s*SP[q2, q2] - 24*s^2*SP[q2, q2] + 16*d*s^2*SP[q2, q2] - 
     2*d^2*s^2*SP[q2, q2] + 16*mm^2*t*SP[q2, q2] - 8*d*mm^2*t*SP[q2, q2] - 
     8*s*t*SP[q2, q2] + 4*d*s*t*SP[q2, q2] + 32*me^2*SP[p3, q1]*SP[q2, q2] - 
     32*d*me^2*SP[p3, q1]*SP[q2, q2] + 8*d^2*me^2*SP[p3, q1]*SP[q2, q2] - 
     16*mm^2*SP[p3, q1]*SP[q2, q2] + 16*d*mm^2*SP[p3, q1]*SP[q2, q2] - 
     4*d^2*mm^2*SP[p3, q1]*SP[q2, q2] + 24*s*SP[p3, q1]*SP[q2, q2] - 
     24*d*s*SP[p3, q1]*SP[q2, q2] + 6*d^2*s*SP[p3, q1]*SP[q2, q2] + 
     16*t*SP[p3, q1]*SP[q2, q2] - 16*d*t*SP[p3, q1]*SP[q2, q2] + 
     4*d^2*t*SP[p3, q1]*SP[q2, q2] - 2*SP[p2, q1]*(-128*me^2*mm^2 + 
       128*d*me^2*mm^2 - 40*d^2*me^2*mm^2 + 4*d^3*me^2*mm^2 - 124*mm^2*s + 
       92*d*mm^2*s - 23*d^2*mm^2*s + 2*d^3*mm^2*s - 16*(-4 + d)*(mm^2 - t)*
        SP[p2, q2] + 2*(2*(-104 + 68*d - 14*d^2 + d^3)*me^2 + 
         (-176 + 92*d - 16*d^2 + d^3)*s)*SP[p3, q2] - 4*s*SP[q2, q2] + 
       4*d*s*SP[q2, q2] - d^2*s*SP[q2, q2])) + 
   4*SP[p1, q1]^2*(-16*(-4 + d)*(mm^2 - s - t)*SP[p2, q2] + 
     (-104 + 68*d - 14*d^2 + d^3)*(2*me^2 + s)*SP[p3, q2] + 
     (-2 + d)*(mm^2*(2*(-4 + d)^2*me^2 + (-2 + d)*mm^2 + 18*s - 9*d*s + 
         d^2*s + 2*t - d*t) - (-2 + d)*(mm^2 - s - t)*SP[q2, q2]))))/
 (256*Pi^8*s^2)
