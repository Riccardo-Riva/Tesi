TopologyList[Process -> {F[3, {1, o}], -F[3, {1, o}]} -> 
    {F[2, {2}], -F[2, {2}]}, Model -> {"SMbgf_Anglerfish_NoUDm"}, 
  GenericModel -> {"Lorentzbgf"}, InsertionLevel -> {Particles}, 
  ExcludeParticles -> {}, ExcludeFieldPoints -> {}, LastSelections -> {}][]
