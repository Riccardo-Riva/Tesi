(* Created with the Wolfram Language : www.wolfram.com *)
(3*EL^8*gAl^6*gAu^2*KiraPropagator[q1, mu]*KiraPropagator[-p1 - p2 + q1, mu]*
  KiraPropagator[q2, me]*KiraPropagator[p1 + p2 + q2, me]*
  (-8*me^4*mm^2*mu^2 - 4*me^2*mm^4*mu^2 + 4*me^4*mu^2*s - 2*d*me^4*mu^2*s + 
   2*me^2*mu^2*s^2 - d*me^2*mu^2*s^2 + 8*me^2*mm^2*mu^2*t - 4*me^2*mu^2*s*t - 
   4*me^2*mu^2*t^2 - 8*me^4*mm^2*SP[p2, q1] - 4*me^2*mm^4*SP[p2, q1] + 
   4*me^4*s*SP[p2, q1] - 2*d*me^4*s*SP[p2, q1] + 2*me^2*s^2*SP[p2, q1] - 
   d*me^2*s^2*SP[p2, q1] + 8*me^2*mm^2*t*SP[p2, q1] - 4*me^2*s*t*SP[p2, q1] - 
   4*me^2*t^2*SP[p2, q1] - 4*me^2*mm^2*SP[p2, q1]^2 + 4*me^2*t*SP[p2, q1]^2 + 
   8*me^2*mm^2*mu^2*SP[p2, q2] + 4*mm^4*mu^2*SP[p2, q2] - 
   4*me^2*mu^2*s*SP[p2, q2] + 2*d*me^2*mu^2*s*SP[p2, q2] - 
   2*mu^2*s^2*SP[p2, q2] + d*mu^2*s^2*SP[p2, q2] - 8*mm^2*mu^2*t*SP[p2, q2] + 
   4*mu^2*s*t*SP[p2, q2] + 4*mu^2*t^2*SP[p2, q2] + 
   8*me^2*mm^2*SP[p2, q1]*SP[p2, q2] + 4*mm^4*SP[p2, q1]*SP[p2, q2] - 
   4*me^2*s*SP[p2, q1]*SP[p2, q2] + 2*d*me^2*s*SP[p2, q1]*SP[p2, q2] + 
   2*mm^2*s*SP[p2, q1]*SP[p2, q2] - 2*s^2*SP[p2, q1]*SP[p2, q2] + 
   d*s^2*SP[p2, q1]*SP[p2, q2] - 8*mm^2*t*SP[p2, q1]*SP[p2, q2] + 
   2*s*t*SP[p2, q1]*SP[p2, q2] + 4*t^2*SP[p2, q1]*SP[p2, q2] - 
   4*mm^2*mu^2*SP[p2, q2]^2 + 4*mu^2*t*SP[p2, q2]^2 + 
   16*me^4*SP[p2, q1]*SP[p3, q1] + 8*me^2*mm^2*SP[p2, q1]*SP[p3, q1] + 
   4*me^2*s*SP[p2, q1]*SP[p3, q1] - 8*me^2*t*SP[p2, q1]*SP[p3, q1] - 
   4*me^2*s*SP[p2, q2]*SP[p3, q1] - 4*mm^2*s*SP[p2, q2]*SP[p3, q1] + 
   4*s*t*SP[p2, q2]*SP[p3, q1] - 8*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
   4*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 8*me^2*SP[p2, q2]^2*SP[p3, q1] - 
   8*mm^2*SP[p2, q2]^2*SP[p3, q1] + 8*t*SP[p2, q2]^2*SP[p3, q1] - 
   16*me^4*SP[p3, q1]^2 - 8*me^2*s*SP[p3, q1]^2 + 
   16*me^2*SP[p2, q2]*SP[p3, q1]^2 + 8*s*SP[p2, q2]*SP[p3, q1]^2 - 
   4*me^2*s*SP[p2, q1]*SP[p3, q2] - 2*s^2*SP[p2, q1]*SP[p3, q2] + 
   8*me^2*SP[p2, q1]^2*SP[p3, q2] + 4*s*SP[p2, q1]^2*SP[p3, q2] + 
   16*me^2*mu^2*SP[p2, q2]*SP[p3, q2] + 8*mm^2*mu^2*SP[p2, q2]*SP[p3, q2] + 
   4*mu^2*s*SP[p2, q2]*SP[p3, q2] - 8*mu^2*t*SP[p2, q2]*SP[p3, q2] + 
   8*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 8*mm^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] - 8*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
   8*me^2*s*SP[p3, q1]*SP[p3, q2] + 4*s^2*SP[p3, q1]*SP[p3, q2] - 
   16*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 8*s*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] + 16*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
   8*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 16*me^2*mu^2*SP[p3, q2]^2 - 
   8*mu^2*s*SP[p3, q2]^2 - 16*me^2*SP[p2, q1]*SP[p3, q2]^2 - 
   8*s*SP[p2, q1]*SP[p3, q2]^2 + 4*SP[p1, q2]^2*(-(s*SP[p2, q1]) - 
     2*(me^2 - mm^2 + s + t)*SP[p3, q1] + (mm^2 - s - t)*
      (mu^2 - SP[q1, q1])) + 8*me^4*mm^2*SP[q1, q1] + 
   4*me^2*mm^4*SP[q1, q1] - 8*me^4*s*SP[q1, q1] + 2*d*me^4*s*SP[q1, q1] - 
   4*me^2*s^2*SP[q1, q1] + d*me^2*s^2*SP[q1, q1] - 8*me^2*mm^2*t*SP[q1, q1] + 
   4*me^2*s*t*SP[q1, q1] + 4*me^2*t^2*SP[q1, q1] - 
   8*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 4*mm^4*SP[p2, q2]*SP[q1, q1] + 
   8*me^2*s*SP[p2, q2]*SP[q1, q1] - 2*d*me^2*s*SP[p2, q2]*SP[q1, q1] + 
   4*s^2*SP[p2, q2]*SP[q1, q1] - d*s^2*SP[p2, q2]*SP[q1, q1] + 
   8*mm^2*t*SP[p2, q2]*SP[q1, q1] - 4*s*t*SP[p2, q2]*SP[q1, q1] - 
   4*t^2*SP[p2, q2]*SP[q1, q1] + 4*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   4*t*SP[p2, q2]^2*SP[q1, q1] - 16*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   8*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 4*s*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 8*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   16*me^2*SP[p3, q2]^2*SP[q1, q1] + 8*s*SP[p3, q2]^2*SP[q1, q1] + 
   2*me^2*s^2*SP[q1, q2] + s^3*SP[q1, q2] - 4*me^2*s*SP[p2, q1]*SP[q1, q2] - 
   2*s^2*SP[p2, q1]*SP[q1, q2] + 4*me^2*s*SP[p2, q2]*SP[q1, q2] + 
   2*s^2*SP[p2, q2]*SP[q1, q2] - 8*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 
   8*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 16*me^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] + 16*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   16*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 16*me^2*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] + 8*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   32*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 16*s*SP[p3, q1]*SP[p3, q2]*
    SP[q1, q2] - 8*me^2*s*SP[q1, q2]^2 - 4*s^2*SP[q1, q2]^2 + 
   SP[p1, q2]*(8*me^2*mm^2*mu^2 + 4*mm^4*mu^2 - 4*me^2*mu^2*s + 
     2*d*me^2*mu^2*s - 2*mu^2*s^2 + d*mu^2*s^2 - 8*mm^2*mu^2*t + 4*mu^2*s*t + 
     4*mu^2*t^2 + 8*(mm^2 - t)*SP[p2, q1]^2 - 4*me^2*s*SP[p3, q1] + 
     4*mm^2*s*SP[p3, q1] - 4*s^2*SP[p3, q1] - 4*s*t*SP[p3, q1] + 
     16*me^2*SP[p3, q1]^2 + 8*s*SP[p3, q1]^2 + 16*me^2*mu^2*SP[p3, q2] - 
     8*mm^2*mu^2*SP[p3, q2] + 12*mu^2*s*SP[p3, q2] + 8*mu^2*t*SP[p3, q2] + 
     16*me^2*SP[p3, q1]*SP[p3, q2] + 8*s*SP[p3, q1]*SP[p3, q2] + 
     4*SP[p2, q2]*(-2*(2*me^2 + s)*SP[p3, q1] + s*(mu^2 - SP[q1, q1])) - 
     8*me^2*mm^2*SP[q1, q1] - 4*mm^4*SP[q1, q1] + 8*me^2*s*SP[q1, q1] - 
     2*d*me^2*s*SP[q1, q1] + 4*s^2*SP[q1, q1] - d*s^2*SP[q1, q1] + 
     8*mm^2*t*SP[q1, q1] - 4*s*t*SP[q1, q1] - 4*t^2*SP[q1, q1] - 
     16*me^2*SP[p3, q2]*SP[q1, q1] + 8*mm^2*SP[p3, q2]*SP[q1, q1] - 
     12*s*SP[p3, q2]*SP[q1, q1] - 8*t*SP[p3, q2]*SP[q1, q1] + 
     4*me^2*s*SP[q1, q2] + 2*s^2*SP[q1, q2] + 16*me^2*SP[p3, q1]*SP[q1, q2] - 
     16*mm^2*SP[p3, q1]*SP[q1, q2] + 16*s*SP[p3, q1]*SP[q1, q2] + 
     16*t*SP[p3, q1]*SP[q1, q2] + SP[p2, q1]*(8*me^2*mm^2 + 4*mm^4 - 
       4*me^2*s + 2*d*me^2*s - 2*mm^2*s - 2*s^2 + d*s^2 - 8*mm^2*t + 6*s*t + 
       4*t^2 + 4*s*SP[p2, q2] - 4*(2*me^2 + 4*mm^2 - s - 4*t)*SP[p3, q1] + 
       8*me^2*SP[p3, q2] - 8*mm^2*SP[p3, q2] + 8*s*SP[p3, q2] + 
       8*t*SP[p3, q2] + 8*mm^2*SP[q1, q2] - 8*t*SP[q1, q2])) + 
   4*SP[p1, q1]^2*(2*(-mm^2 + s + t)*SP[p2, q2] + (2*me^2 + s)*SP[p3, q2] + 
     (mm^2 - s - t)*(me^2 - SP[q2, q2])) + 8*me^2*mm^2*mu^2*SP[q2, q2] + 
   4*mm^4*mu^2*SP[q2, q2] - 8*me^2*mu^2*s*SP[q2, q2] + 
   2*d*me^2*mu^2*s*SP[q2, q2] - 4*mu^2*s^2*SP[q2, q2] + 
   d*mu^2*s^2*SP[q2, q2] - 8*mm^2*mu^2*t*SP[q2, q2] + 4*mu^2*s*t*SP[q2, q2] + 
   4*mu^2*t^2*SP[q2, q2] + 8*me^2*mm^2*SP[p2, q1]*SP[q2, q2] + 
   4*mm^4*SP[p2, q1]*SP[q2, q2] - 8*me^2*s*SP[p2, q1]*SP[q2, q2] + 
   2*d*me^2*s*SP[p2, q1]*SP[q2, q2] - 4*s^2*SP[p2, q1]*SP[q2, q2] + 
   d*s^2*SP[p2, q1]*SP[q2, q2] - 8*mm^2*t*SP[p2, q1]*SP[q2, q2] + 
   4*s*t*SP[p2, q1]*SP[q2, q2] + 4*t^2*SP[p2, q1]*SP[q2, q2] + 
   4*mm^2*SP[p2, q1]^2*SP[q2, q2] - 4*t*SP[p2, q1]^2*SP[q2, q2] - 
   16*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 8*mm^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 4*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   8*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 16*me^2*SP[p3, q1]^2*SP[q2, q2] + 
   8*s*SP[p3, q1]^2*SP[q2, q2] - 8*me^2*mm^2*SP[q1, q1]*SP[q2, q2] - 
   4*mm^4*SP[q1, q1]*SP[q2, q2] + 12*me^2*s*SP[q1, q1]*SP[q2, q2] - 
   2*d*me^2*s*SP[q1, q1]*SP[q2, q2] + 6*s^2*SP[q1, q1]*SP[q2, q2] - 
   d*s^2*SP[q1, q1]*SP[q2, q2] + 8*mm^2*t*SP[q1, q1]*SP[q2, q2] - 
   4*s*t*SP[q1, q1]*SP[q2, q2] - 4*t^2*SP[q1, q1]*SP[q2, q2] + 
   SP[p1, q1]*(-8*me^4*mm^2 - 4*me^2*mm^4 + 4*me^4*s - 2*d*me^4*s + 
     2*me^2*s^2 - d*me^2*s^2 + 8*me^2*mm^2*t - 4*me^2*s*t - 4*me^2*t^2 + 
     8*me^2*mm^2*SP[p2, q2] + 4*mm^4*SP[p2, q2] - 4*me^2*s*SP[p2, q2] + 
     2*d*me^2*s*SP[p2, q2] + 2*mm^2*s*SP[p2, q2] - 4*s^2*SP[p2, q2] + 
     d*s^2*SP[p2, q2] - 8*mm^2*t*SP[p2, q2] + 2*s*t*SP[p2, q2] + 
     4*t^2*SP[p2, q2] - 4*s*SP[p2, q2]^2 + 16*me^4*SP[p3, q1] - 
     8*me^2*mm^2*SP[p3, q1] + 12*me^2*s*SP[p3, q1] + 8*me^2*t*SP[p3, q1] - 
     8*me^2*SP[p2, q2]*SP[p3, q1] + 16*mm^2*SP[p2, q2]*SP[p3, q1] - 
     12*s*SP[p2, q2]*SP[p3, q1] - 16*t*SP[p2, q2]*SP[p3, q1] - 
     4*me^2*s*SP[p3, q2] - 2*s^2*SP[p3, q2] + 8*me^2*SP[p2, q2]*SP[p3, q2] + 
     8*mm^2*SP[p2, q2]*SP[p3, q2] - 8*t*SP[p2, q2]*SP[p3, q2] - 
     16*me^2*SP[p3, q1]*SP[p3, q2] - 8*s*SP[p3, q1]*SP[p3, q2] - 
     16*me^2*SP[p3, q2]^2 - 8*s*SP[p3, q2]^2 - 4*me^2*s*SP[q1, q2] - 
     2*s^2*SP[q1, q2] - 8*mm^2*SP[p2, q2]*SP[q1, q2] + 
     8*s*SP[p2, q2]*SP[q1, q2] + 8*t*SP[p2, q2]*SP[q1, q2] + 
     16*me^2*SP[p3, q2]*SP[q1, q2] + 8*s*SP[p3, q2]*SP[q1, q2] + 
     SP[p1, q2]*(8*me^2*mm^2 + 4*mm^4 - 4*me^2*s + 2*d*me^2*s - 2*mm^2*s + 
       d*s^2 - 8*mm^2*t + 6*s*t + 4*t^2 + 8*(mm^2 - s - t)*SP[p2, q1] + 
       4*s*SP[p2, q2] - 8*me^2*SP[p3, q1] - 4*s*SP[p3, q1] + 
       8*me^2*SP[p3, q2] - 8*mm^2*SP[p3, q2] + 8*s*SP[p3, q2] + 
       8*t*SP[p3, q2] + 8*mm^2*SP[q1, q2] - 8*s*SP[q1, q2] - 
       8*t*SP[q1, q2]) + 4*SP[p2, q1]*(-2*(mm^2 - t)*SP[p2, q2] + 
       2*(2*me^2 + s)*SP[p3, q2] + s*(me^2 - SP[q2, q2])) + 
     8*me^2*mm^2*SP[q2, q2] + 4*mm^4*SP[q2, q2] - 8*me^2*s*SP[q2, q2] + 
     2*d*me^2*s*SP[q2, q2] - 4*s^2*SP[q2, q2] + d*s^2*SP[q2, q2] - 
     8*mm^2*t*SP[q2, q2] + 4*s*t*SP[q2, q2] + 4*t^2*SP[q2, q2] - 
     16*me^2*SP[p3, q1]*SP[q2, q2] + 8*mm^2*SP[p3, q1]*SP[q2, q2] - 
     12*s*SP[p3, q1]*SP[q2, q2] - 8*t*SP[p3, q1]*SP[q2, q2])))/(16*Pi^8*s^4)
