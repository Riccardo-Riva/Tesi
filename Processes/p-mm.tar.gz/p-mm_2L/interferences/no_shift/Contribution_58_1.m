(* Created with the Wolfram Language : www.wolfram.com *)
(EL^8*gAl^8*KiraPropagator[q1, mm]*KiraPropagator[-p3 + q1, 0]*
  KiraPropagator[q2, 0]*KiraPropagator[-p1 - p2 + p3 + q2, mm]*
  KiraPropagator[q1 + q2, mm]*KiraPropagator[-p1 - p2 + q1 + q2, mm]*
  (-16*d*me^2*mm^6 - 8*d*mm^8 + 128*me^2*mm^4*s - 88*d*me^2*mm^4*s + 
   12*d^2*me^2*mm^4*s + 32*mm^6*s - 8*d*mm^6*s - 32*me^2*mm^2*s^2 + 
   24*d*me^2*mm^2*s^2 - 4*d^2*me^2*mm^2*s^2 + 64*mm^4*s^2 - 44*d*mm^4*s^2 + 
   6*d^2*mm^4*s^2 - 16*mm^2*s^3 + 12*d*mm^2*s^3 - 2*d^2*mm^2*s^3 + 
   16*d*mm^6*t - 64*mm^4*s*t + 8*d*mm^4*s*t + 32*mm^2*s^2*t - 
   8*d*mm^2*s^2*t - 8*d*mm^4*t^2 + 32*mm^2*s*t^2 - 8*d*mm^2*s*t^2 + 
   16*(-2 + d)*(mm^2 - s - t)*SP[p1, q1]^3 - 32*me^2*mm^4*SP[p2, q1] + 
   32*d*me^2*mm^4*SP[p2, q1] - 8*d^2*me^2*mm^4*SP[p2, q1] + 
   16*mm^6*SP[p2, q1] - 16*d*mm^6*SP[p2, q1] + 96*me^2*mm^2*s*SP[p2, q1] - 
   96*d*me^2*mm^2*s*SP[p2, q1] + 16*d^2*me^2*mm^2*s*SP[p2, q1] - 
   32*mm^4*s*SP[p2, q1] + 28*d*mm^4*s*SP[p2, q1] - 4*d^2*mm^4*s*SP[p2, q1] + 
   80*mm^2*s^2*SP[p2, q1] - 56*d*mm^2*s^2*SP[p2, q1] + 
   8*d^2*mm^2*s^2*SP[p2, q1] - 16*mm^4*t*SP[p2, q1] + 
   24*d*mm^4*t*SP[p2, q1] - 16*mm^2*s*t*SP[p2, q1] - 
   4*d*mm^2*s*t*SP[p2, q1] - 8*d*mm^2*t^2*SP[p2, q1] + 
   64*me^2*mm^2*SP[p2, q1]^2 - 64*d*me^2*mm^2*SP[p2, q1]^2 + 
   32*mm^4*SP[p2, q1]^2 - 48*d*mm^4*SP[p2, q1]^2 + 64*me^2*s*SP[p2, q1]^2 - 
   32*d*me^2*s*SP[p2, q1]^2 + 48*mm^2*s*SP[p2, q1]^2 - 
   8*d*mm^2*s*SP[p2, q1]^2 + 32*s^2*SP[p2, q1]^2 - 16*d*s^2*SP[p2, q1]^2 - 
   64*mm^2*t*SP[p2, q1]^2 + 64*d*mm^2*t*SP[p2, q1]^2 - 16*s*t*SP[p2, q1]^2 - 
   8*d*s*t*SP[p2, q1]^2 + 32*t^2*SP[p2, q1]^2 - 16*d*t^2*SP[p2, q1]^2 + 
   32*mm^2*SP[p2, q1]^3 - 16*d*mm^2*SP[p2, q1]^3 - 32*t*SP[p2, q1]^3 + 
   16*d*t*SP[p2, q1]^3 + 96*me^2*mm^4*SP[p2, q2] - 
   32*d*me^2*mm^4*SP[p2, q2] - 24*d^2*me^2*mm^4*SP[p2, q2] + 
   4*d^3*me^2*mm^4*SP[p2, q2] + 96*mm^6*SP[p2, q2] - 72*d*mm^6*SP[p2, q2] + 
   8*d^2*mm^6*SP[p2, q2] - 128*me^2*mm^2*s*SP[p2, q2] + 
   128*d*me^2*mm^2*s*SP[p2, q2] - 40*d^2*me^2*mm^2*s*SP[p2, q2] + 
   4*d^3*me^2*mm^2*s*SP[p2, q2] - 104*mm^4*s*SP[p2, q2] + 
   84*d*mm^4*s*SP[p2, q2] - 22*d^2*mm^4*s*SP[p2, q2] + 
   2*d^3*mm^4*s*SP[p2, q2] - 48*mm^2*s^2*SP[p2, q2] + 
   56*d*mm^2*s^2*SP[p2, q2] - 20*d^2*mm^2*s^2*SP[p2, q2] + 
   2*d^3*mm^2*s^2*SP[p2, q2] - 144*mm^4*t*SP[p2, q2] + 
   112*d*mm^4*t*SP[p2, q2] - 12*d^2*mm^4*t*SP[p2, q2] + 
   104*mm^2*s*t*SP[p2, q2] - 68*d*mm^2*s*t*SP[p2, q2] + 
   6*d^2*mm^2*s*t*SP[p2, q2] + 48*mm^2*t^2*SP[p2, q2] - 
   40*d*mm^2*t^2*SP[p2, q2] + 4*d^2*mm^2*t^2*SP[p2, q2] + 
   128*me^2*mm^2*SP[p2, q1]*SP[p2, q2] - 96*d*me^2*mm^2*SP[p2, q1]*
    SP[p2, q2] + 80*mm^4*SP[p2, q1]*SP[p2, q2] - 
   80*d*mm^4*SP[p2, q1]*SP[p2, q2] + 64*me^2*s*SP[p2, q1]*SP[p2, q2] - 
   32*d*me^2*s*SP[p2, q1]*SP[p2, q2] + 48*mm^2*s*SP[p2, q1]*SP[p2, q2] - 
   8*d*mm^2*s*SP[p2, q1]*SP[p2, q2] + 32*s^2*SP[p2, q1]*SP[p2, q2] - 
   16*d*s^2*SP[p2, q1]*SP[p2, q2] - 112*mm^2*t*SP[p2, q1]*SP[p2, q2] + 
   96*d*mm^2*t*SP[p2, q1]*SP[p2, q2] - 16*s*t*SP[p2, q1]*SP[p2, q2] - 
   8*d*s*t*SP[p2, q1]*SP[p2, q2] + 32*t^2*SP[p2, q1]*SP[p2, q2] - 
   16*d*t^2*SP[p2, q1]*SP[p2, q2] + 64*mm^2*SP[p2, q1]^2*SP[p2, q2] - 
   32*d*mm^2*SP[p2, q1]^2*SP[p2, q2] - 64*t*SP[p2, q1]^2*SP[p2, q2] + 
   32*d*t*SP[p2, q1]^2*SP[p2, q2] - 256*me^2*mm^2*SP[p2, q2]^2 + 
   288*d*me^2*mm^2*SP[p2, q2]^2 - 96*d^2*me^2*mm^2*SP[p2, q2]^2 + 
   8*d^3*me^2*mm^2*SP[p2, q2]^2 + 16*mm^4*SP[p2, q2]^2 - 
   8*d*mm^4*SP[p2, q2]^2 - 4*d^2*mm^4*SP[p2, q2]^2 - 
   160*mm^2*s*SP[p2, q2]^2 + 160*d*mm^2*s*SP[p2, q2]^2 - 
   48*d^2*mm^2*s*SP[p2, q2]^2 + 4*d^3*mm^2*s*SP[p2, q2]^2 - 
   16*mm^2*t*SP[p2, q2]^2 + 8*d*mm^2*t*SP[p2, q2]^2 + 
   4*d^2*mm^2*t*SP[p2, q2]^2 + 32*mm^2*SP[p2, q1]*SP[p2, q2]^2 - 
   16*d*mm^2*SP[p2, q1]*SP[p2, q2]^2 - 32*t*SP[p2, q1]*SP[p2, q2]^2 + 
   16*d*t*SP[p2, q1]*SP[p2, q2]^2 - 96*me^2*mm^4*SP[p3, q1] + 
   48*d*me^2*mm^4*SP[p3, q1] - 32*mm^6*SP[p3, q1] + 16*d*mm^6*SP[p3, q1] - 
   96*me^2*mm^2*s*SP[p3, q1] + 96*d*me^2*mm^2*s*SP[p3, q1] - 
   16*d^2*me^2*mm^2*s*SP[p3, q1] - 16*mm^4*s*SP[p3, q1] + 
   8*d*mm^4*s*SP[p3, q1] - 96*mm^2*s^2*SP[p3, q1] + 
   60*d*mm^2*s^2*SP[p3, q1] - 8*d^2*mm^2*s^2*SP[p3, q1] + 
   64*mm^4*t*SP[p3, q1] - 32*d*mm^4*t*SP[p3, q1] - 32*mm^2*s*t*SP[p3, q1] + 
   16*d*mm^2*s*t*SP[p3, q1] - 32*mm^2*t^2*SP[p3, q1] + 
   16*d*mm^2*t^2*SP[p3, q1] - 64*me^2*mm^2*SP[p2, q1]*SP[p3, q1] + 
   128*d*me^2*mm^2*SP[p2, q1]*SP[p3, q1] - 32*mm^4*SP[p2, q1]*SP[p3, q1] + 
   48*d*mm^4*SP[p2, q1]*SP[p3, q1] - 256*me^2*s*SP[p2, q1]*SP[p3, q1] + 
   160*d*me^2*s*SP[p2, q1]*SP[p3, q1] - 16*d^2*me^2*s*SP[p2, q1]*SP[p3, q1] - 
   48*mm^2*s*SP[p2, q1]*SP[p3, q1] + 40*d*mm^2*s*SP[p2, q1]*SP[p3, q1] - 
   176*s^2*SP[p2, q1]*SP[p3, q1] + 88*d*s^2*SP[p2, q1]*SP[p3, q1] - 
   8*d^2*s^2*SP[p2, q1]*SP[p3, q1] + 64*mm^2*t*SP[p2, q1]*SP[p3, q1] - 
   64*d*mm^2*t*SP[p2, q1]*SP[p3, q1] + 16*s*t*SP[p2, q1]*SP[p3, q1] + 
   8*d*s*t*SP[p2, q1]*SP[p3, q1] - 32*t^2*SP[p2, q1]*SP[p3, q1] + 
   16*d*t^2*SP[p2, q1]*SP[p3, q1] - 128*me^2*SP[p2, q1]^2*SP[p3, q1] + 
   64*d*me^2*SP[p2, q1]^2*SP[p3, q1] - 96*mm^2*SP[p2, q1]^2*SP[p3, q1] + 
   48*d*mm^2*SP[p2, q1]^2*SP[p3, q1] - 32*s*SP[p2, q1]^2*SP[p3, q1] + 
   16*d*s*SP[p2, q1]^2*SP[p3, q1] + 96*t*SP[p2, q1]^2*SP[p3, q1] - 
   48*d*t*SP[p2, q1]^2*SP[p3, q1] - 48*d*me^2*mm^2*SP[p2, q2]*SP[p3, q1] + 
   48*d^2*me^2*mm^2*SP[p2, q2]*SP[p3, q1] - 4*d^3*me^2*mm^2*SP[p2, q2]*
    SP[p3, q1] - 64*mm^4*SP[p2, q2]*SP[p3, q1] + 
   72*d*mm^4*SP[p2, q2]*SP[p3, q1] - 4*d^2*mm^4*SP[p2, q2]*SP[p3, q1] - 
   128*me^2*s*SP[p2, q2]*SP[p3, q1] + 80*d*me^2*s*SP[p2, q2]*SP[p3, q1] - 
   8*d^2*me^2*s*SP[p2, q2]*SP[p3, q1] + 80*mm^2*s*SP[p2, q2]*SP[p3, q1] - 
   88*d*mm^2*s*SP[p2, q2]*SP[p3, q1] + 28*d^2*mm^2*s*SP[p2, q2]*SP[p3, q1] - 
   2*d^3*mm^2*s*SP[p2, q2]*SP[p3, q1] - 96*s^2*SP[p2, q2]*SP[p3, q1] + 
   48*d*s^2*SP[p2, q2]*SP[p3, q1] - 4*d^2*s^2*SP[p2, q2]*SP[p3, q1] + 
   96*mm^2*t*SP[p2, q2]*SP[p3, q1] - 88*d*mm^2*t*SP[p2, q2]*SP[p3, q1] + 
   4*d^2*mm^2*t*SP[p2, q2]*SP[p3, q1] - 16*s*t*SP[p2, q2]*SP[p3, q1] + 
   16*d*s*t*SP[p2, q2]*SP[p3, q1] - 32*t^2*SP[p2, q2]*SP[p3, q1] + 
   16*d*t^2*SP[p2, q2]*SP[p3, q1] - 512*me^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] + 224*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
   16*d^2*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
   192*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 80*d*mm^2*SP[p2, q1]*
    SP[p2, q2]*SP[p3, q1] - 160*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
   80*d*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 8*d^2*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q1] + 192*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
   80*d*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 512*me^2*SP[p2, q2]^2*
    SP[p3, q1] - 448*d*me^2*SP[p2, q2]^2*SP[p3, q1] + 
   112*d^2*me^2*SP[p2, q2]^2*SP[p3, q1] - 8*d^3*me^2*SP[p2, q2]^2*
    SP[p3, q1] - 96*mm^2*SP[p2, q2]^2*SP[p3, q1] + 
   32*d*mm^2*SP[p2, q2]^2*SP[p3, q1] + 320*s*SP[p2, q2]^2*SP[p3, q1] - 
   240*d*s*SP[p2, q2]^2*SP[p3, q1] + 56*d^2*s*SP[p2, q2]^2*SP[p3, q1] - 
   4*d^3*s*SP[p2, q2]^2*SP[p3, q1] + 96*t*SP[p2, q2]^2*SP[p3, q1] - 
   32*d*t*SP[p2, q2]^2*SP[p3, q1] - 64*d*me^2*mm^2*SP[p3, q1]^2 + 
   192*me^2*s*SP[p3, q1]^2 - 128*d*me^2*s*SP[p3, q1]^2 + 
   16*d^2*me^2*s*SP[p3, q1]^2 - 32*d*mm^2*s*SP[p3, q1]^2 + 
   144*s^2*SP[p3, q1]^2 - 72*d*s^2*SP[p3, q1]^2 + 8*d^2*s^2*SP[p3, q1]^2 + 
   256*me^2*SP[p2, q1]*SP[p3, q1]^2 - 128*d*me^2*SP[p2, q1]*SP[p3, q1]^2 + 
   64*mm^2*SP[p2, q1]*SP[p3, q1]^2 - 32*d*mm^2*SP[p2, q1]*SP[p3, q1]^2 + 
   96*s*SP[p2, q1]*SP[p3, q1]^2 - 48*d*s*SP[p2, q1]*SP[p3, q1]^2 - 
   64*t*SP[p2, q1]*SP[p3, q1]^2 + 32*d*t*SP[p2, q1]*SP[p3, q1]^2 + 
   384*me^2*SP[p2, q2]*SP[p3, q1]^2 - 128*d*me^2*SP[p2, q2]*SP[p3, q1]^2 + 
   64*mm^2*SP[p2, q2]*SP[p3, q1]^2 - 32*d*mm^2*SP[p2, q2]*SP[p3, q1]^2 + 
   160*s*SP[p2, q2]*SP[p3, q1]^2 - 48*d*s*SP[p2, q2]*SP[p3, q1]^2 - 
   64*t*SP[p2, q2]*SP[p3, q1]^2 + 32*d*t*SP[p2, q2]*SP[p3, q1]^2 - 
   128*me^2*SP[p3, q1]^3 + 64*d*me^2*SP[p3, q1]^3 - 64*s*SP[p3, q1]^3 + 
   32*d*s*SP[p3, q1]^3 - 96*me^2*mm^4*SP[p3, q2] + 
   64*d*me^2*mm^4*SP[p3, q2] - 8*d^2*me^2*mm^4*SP[p3, q2] + 
   192*me^2*mm^2*s*SP[p3, q2] - 176*d*me^2*mm^2*s*SP[p3, q2] + 
   48*d^2*me^2*mm^2*s*SP[p3, q2] - 4*d^3*me^2*mm^2*s*SP[p3, q2] - 
   48*mm^4*s*SP[p3, q2] + 32*d*mm^4*s*SP[p3, q2] - 4*d^2*mm^4*s*SP[p3, q2] + 
   136*mm^2*s^2*SP[p3, q2] - 108*d*mm^2*s^2*SP[p3, q2] + 
   26*d^2*mm^2*s^2*SP[p3, q2] - 2*d^3*mm^2*s^2*SP[p3, q2] - 
   192*me^2*mm^2*SP[p2, q1]*SP[p3, q2] + 272*d*me^2*mm^2*SP[p2, q1]*
    SP[p3, q2] - 48*d^2*me^2*mm^2*SP[p2, q1]*SP[p3, q2] + 
   4*d^3*me^2*mm^2*SP[p2, q1]*SP[p3, q2] + 8*d*mm^4*SP[p2, q1]*SP[p3, q2] + 
   4*d^2*mm^4*SP[p2, q1]*SP[p3, q2] - 128*me^2*s*SP[p2, q1]*SP[p3, q2] + 
   80*d*me^2*s*SP[p2, q1]*SP[p3, q2] - 8*d^2*me^2*s*SP[p2, q1]*SP[p3, q2] - 
   176*mm^2*s*SP[p2, q1]*SP[p3, q2] + 160*d*mm^2*s*SP[p2, q1]*SP[p3, q2] - 
   28*d^2*mm^2*s*SP[p2, q1]*SP[p3, q2] + 2*d^3*mm^2*s*SP[p2, q1]*SP[p3, q2] - 
   80*s^2*SP[p2, q1]*SP[p3, q2] + 40*d*s^2*SP[p2, q1]*SP[p3, q2] - 
   4*d^2*s^2*SP[p2, q1]*SP[p3, q2] - 8*d*mm^2*t*SP[p2, q1]*SP[p3, q2] - 
   4*d^2*mm^2*t*SP[p2, q1]*SP[p3, q2] + 32*s*t*SP[p2, q1]*SP[p3, q2] - 
   8*d*s*t*SP[p2, q1]*SP[p3, q2] + 256*me^2*SP[p2, q1]^2*SP[p3, q2] - 
   96*d*me^2*SP[p2, q1]^2*SP[p3, q2] + 16*d^2*me^2*SP[p2, q1]^2*SP[p3, q2] + 
   16*d*mm^2*SP[p2, q1]^2*SP[p3, q2] + 96*s*SP[p2, q1]^2*SP[p3, q2] - 
   48*d*s*SP[p2, q1]^2*SP[p3, q2] + 8*d^2*s*SP[p2, q1]^2*SP[p3, q2] - 
   16*d*t*SP[p2, q1]^2*SP[p3, q2] + 16*d^2*me^2*mm^2*SP[p2, q2]*SP[p3, q2] + 
   32*mm^4*SP[p2, q2]*SP[p3, q2] - 16*d*mm^4*SP[p2, q2]*SP[p3, q2] + 
   8*d^2*mm^4*SP[p2, q2]*SP[p3, q2] - 16*mm^2*s*SP[p2, q2]*SP[p3, q2] + 
   8*d*mm^2*s*SP[p2, q2]*SP[p3, q2] + 4*d^2*mm^2*s*SP[p2, q2]*SP[p3, q2] - 
   32*mm^2*t*SP[p2, q2]*SP[p3, q2] + 16*d*mm^2*t*SP[p2, q2]*SP[p3, q2] - 
   8*d^2*mm^2*t*SP[p2, q2]*SP[p3, q2] - 640*me^2*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] + 512*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 
   112*d^2*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
   8*d^3*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
   16*d*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 352*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] + 256*d*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 
   56*d^2*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 4*d^3*s*SP[p2, q1]*SP[p2, q2]*
    SP[p3, q2] - 16*d*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
   64*me^2*mm^2*SP[p3, q1]*SP[p3, q2] - 128*d*me^2*mm^2*SP[p3, q1]*
    SP[p3, q2] + 192*me^2*s*SP[p3, q1]*SP[p3, q2] - 
   128*d*me^2*s*SP[p3, q1]*SP[p3, q2] + 16*d^2*me^2*s*SP[p3, q1]*SP[p3, q2] + 
   32*mm^2*s*SP[p3, q1]*SP[p3, q2] - 64*d*mm^2*s*SP[p3, q1]*SP[p3, q2] + 
   144*s^2*SP[p3, q1]*SP[p3, q2] - 72*d*s^2*SP[p3, q1]*SP[p3, q2] + 
   8*d^2*s^2*SP[p3, q1]*SP[p3, q2] + 128*me^2*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] - 128*d*me^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 
   64*mm^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 32*d*mm^2*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] + 32*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 
   48*d*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 64*t*SP[p2, q1]*SP[p3, q1]*
    SP[p3, q2] + 32*d*t*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 
   512*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 224*d*me^2*SP[p2, q2]*
    SP[p3, q1]*SP[p3, q2] + 16*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
   64*mm^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 32*d*mm^2*SP[p2, q2]*SP[p3, q1]*
    SP[p3, q2] + 224*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 
   96*d*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 8*d^2*s*SP[p2, q2]*SP[p3, q1]*
    SP[p3, q2] - 64*t*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
   32*d*t*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 256*me^2*SP[p3, q1]^2*
    SP[p3, q2] + 128*d*me^2*SP[p3, q1]^2*SP[p3, q2] - 
   128*s*SP[p3, q1]^2*SP[p3, q2] + 64*d*s*SP[p3, q1]^2*SP[p3, q2] - 
   64*me^2*mm^2*SP[p3, q2]^2 + 32*d*me^2*mm^2*SP[p3, q2]^2 - 
   16*d^2*me^2*mm^2*SP[p3, q2]^2 - 32*mm^2*s*SP[p3, q2]^2 + 
   16*d*mm^2*s*SP[p3, q2]^2 - 8*d^2*mm^2*s*SP[p3, q2]^2 - 
   256*me^2*SP[p2, q1]*SP[p3, q2]^2 + 96*d*me^2*SP[p2, q1]*SP[p3, q2]^2 - 
   16*d^2*me^2*SP[p2, q1]*SP[p3, q2]^2 - 128*s*SP[p2, q1]*SP[p3, q2]^2 + 
   48*d*s*SP[p2, q1]*SP[p3, q2]^2 - 8*d^2*s*SP[p2, q1]*SP[p3, q2]^2 - 
   128*me^2*SP[p3, q1]*SP[p3, q2]^2 + 64*d*me^2*SP[p3, q1]*SP[p3, q2]^2 - 
   64*s*SP[p3, q1]*SP[p3, q2]^2 + 32*d*s*SP[p3, q1]*SP[p3, q2]^2 + 
   16*d*me^2*mm^4*SP[q1, q1] + 8*d*mm^6*SP[q1, q1] - 
   128*me^2*mm^2*s*SP[q1, q1] + 88*d*me^2*mm^2*s*SP[q1, q1] - 
   12*d^2*me^2*mm^2*s*SP[q1, q1] - 32*mm^4*s*SP[q1, q1] + 
   8*d*mm^4*s*SP[q1, q1] + 32*me^2*s^2*SP[q1, q1] - 
   24*d*me^2*s^2*SP[q1, q1] + 4*d^2*me^2*s^2*SP[q1, q1] - 
   64*mm^2*s^2*SP[q1, q1] + 44*d*mm^2*s^2*SP[q1, q1] - 
   6*d^2*mm^2*s^2*SP[q1, q1] + 16*s^3*SP[q1, q1] - 12*d*s^3*SP[q1, q1] + 
   2*d^2*s^3*SP[q1, q1] - 16*d*mm^4*t*SP[q1, q1] + 64*mm^2*s*t*SP[q1, q1] - 
   8*d*mm^2*s*t*SP[q1, q1] - 32*s^2*t*SP[q1, q1] + 8*d*s^2*t*SP[q1, q1] + 
   8*d*mm^2*t^2*SP[q1, q1] - 32*s*t^2*SP[q1, q1] + 8*d*s*t^2*SP[q1, q1] + 
   32*me^2*mm^2*SP[p2, q1]*SP[q1, q1] - 32*d*me^2*mm^2*SP[p2, q1]*
    SP[q1, q1] + 8*d^2*me^2*mm^2*SP[p2, q1]*SP[q1, q1] - 
   16*mm^4*SP[p2, q1]*SP[q1, q1] + 16*d*mm^4*SP[p2, q1]*SP[q1, q1] + 
   32*mm^2*s*SP[p2, q1]*SP[q1, q1] - 28*d*mm^2*s*SP[p2, q1]*SP[q1, q1] + 
   4*d^2*mm^2*s*SP[p2, q1]*SP[q1, q1] + 16*mm^2*t*SP[p2, q1]*SP[q1, q1] - 
   24*d*mm^2*t*SP[p2, q1]*SP[q1, q1] + 16*s*t*SP[p2, q1]*SP[q1, q1] + 
   4*d*s*t*SP[p2, q1]*SP[q1, q1] + 8*d*t^2*SP[p2, q1]*SP[q1, q1] - 
   288*me^2*mm^2*SP[p2, q2]*SP[q1, q1] + 32*d*me^2*mm^2*SP[p2, q2]*
    SP[q1, q1] + 24*d^2*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 
   4*d^3*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 144*mm^4*SP[p2, q2]*SP[q1, q1] + 
   72*d*mm^4*SP[p2, q2]*SP[q1, q1] - 8*d^2*mm^4*SP[p2, q2]*SP[q1, q1] + 
   384*me^2*s*SP[p2, q2]*SP[q1, q1] - 256*d*me^2*s*SP[p2, q2]*SP[q1, q1] + 
   56*d^2*me^2*s*SP[p2, q2]*SP[q1, q1] - 4*d^3*me^2*s*SP[p2, q2]*SP[q1, q1] + 
   80*mm^2*s*SP[p2, q2]*SP[q1, q1] - 84*d*mm^2*s*SP[p2, q2]*SP[q1, q1] + 
   22*d^2*mm^2*s*SP[p2, q2]*SP[q1, q1] - 2*d^3*mm^2*s*SP[p2, q2]*SP[q1, q1] + 
   192*s^2*SP[p2, q2]*SP[q1, q1] - 128*d*s^2*SP[p2, q2]*SP[q1, q1] + 
   28*d^2*s^2*SP[p2, q2]*SP[q1, q1] - 2*d^3*s^2*SP[p2, q2]*SP[q1, q1] + 
   240*mm^2*t*SP[p2, q2]*SP[q1, q1] - 112*d*mm^2*t*SP[p2, q2]*SP[q1, q1] + 
   12*d^2*mm^2*t*SP[p2, q2]*SP[q1, q1] - 176*s*t*SP[p2, q2]*SP[q1, q1] + 
   68*d*s*t*SP[p2, q2]*SP[q1, q1] - 6*d^2*s*t*SP[p2, q2]*SP[q1, q1] - 
   96*t^2*SP[p2, q2]*SP[q1, q1] + 40*d*t^2*SP[p2, q2]*SP[q1, q1] - 
   4*d^2*t^2*SP[p2, q2]*SP[q1, q1] + 32*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   24*d*mm^2*SP[p2, q2]^2*SP[q1, q1] + 4*d^2*mm^2*SP[p2, q2]^2*SP[q1, q1] - 
   32*t*SP[p2, q2]^2*SP[q1, q1] + 24*d*t*SP[p2, q2]^2*SP[q1, q1] - 
   4*d^2*t*SP[p2, q2]^2*SP[q1, q1] + 96*me^2*mm^2*SP[p3, q1]*SP[q1, q1] - 
   48*d*me^2*mm^2*SP[p3, q1]*SP[q1, q1] + 32*mm^4*SP[p3, q1]*SP[q1, q1] - 
   16*d*mm^4*SP[p3, q1]*SP[q1, q1] + 16*mm^2*s*SP[p3, q1]*SP[q1, q1] - 
   8*d*mm^2*s*SP[p3, q1]*SP[q1, q1] + 16*s^2*SP[p3, q1]*SP[q1, q1] - 
   4*d*s^2*SP[p3, q1]*SP[q1, q1] - 64*mm^2*t*SP[p3, q1]*SP[q1, q1] + 
   32*d*mm^2*t*SP[p3, q1]*SP[q1, q1] + 32*s*t*SP[p3, q1]*SP[q1, q1] - 
   16*d*s*t*SP[p3, q1]*SP[q1, q1] + 32*t^2*SP[p3, q1]*SP[q1, q1] - 
   16*d*t^2*SP[p3, q1]*SP[q1, q1] - 192*me^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q1] + 176*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] - 
   48*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] + 
   4*d^3*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] + 
   32*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] - 24*d*mm^2*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q1] + 4*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] - 
   160*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] + 120*d*s*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q1] - 28*d^2*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] + 
   2*d^3*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] - 32*t*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q1] + 24*d*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] - 
   4*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q1] + 96*me^2*mm^2*SP[p3, q2]*
    SP[q1, q1] - 64*d*me^2*mm^2*SP[p3, q2]*SP[q1, q1] + 
   8*d^2*me^2*mm^2*SP[p3, q2]*SP[q1, q1] - 448*me^2*s*SP[p3, q2]*SP[q1, q1] + 
   304*d*me^2*s*SP[p3, q2]*SP[q1, q1] - 64*d^2*me^2*s*SP[p3, q2]*SP[q1, q1] + 
   4*d^3*me^2*s*SP[p3, q2]*SP[q1, q1] + 48*mm^2*s*SP[p3, q2]*SP[q1, q1] - 
   32*d*mm^2*s*SP[p3, q2]*SP[q1, q1] + 4*d^2*mm^2*s*SP[p3, q2]*SP[q1, q1] - 
   304*s^2*SP[p3, q2]*SP[q1, q1] + 180*d*s^2*SP[p3, q2]*SP[q1, q1] - 
   34*d^2*s^2*SP[p3, q2]*SP[q1, q1] + 2*d^3*s^2*SP[p3, q2]*SP[q1, q1] + 
   192*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 176*d*me^2*SP[p2, q1]*
    SP[p3, q2]*SP[q1, q1] + 48*d^2*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 
   4*d^3*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 
   32*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] + 24*d*mm^2*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q1] - 4*d^2*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] + 
   160*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 120*d*s*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q1] + 28*d^2*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 
   2*d^3*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] + 32*t*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q1] - 24*d*t*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] + 
   4*d^2*t*SP[p2, q1]*SP[p3, q2]*SP[q1, q1] - 128*me^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 96*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   16*d^2*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   64*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 48*d*mm^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] - 8*d^2*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
   32*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 24*d*s*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] - 4*d^2*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   64*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 48*d*t*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q1] + 8*d^2*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
   128*me^2*SP[p3, q2]^2*SP[q1, q1] - 96*d*me^2*SP[p3, q2]^2*SP[q1, q1] + 
   16*d^2*me^2*SP[p3, q2]^2*SP[q1, q1] + 64*s*SP[p3, q2]^2*SP[q1, q1] - 
   48*d*s*SP[p3, q2]^2*SP[q1, q1] + 8*d^2*s*SP[p3, q2]^2*SP[q1, q1] - 
   128*me^2*mm^4*SP[q1, q2] + 112*d*me^2*mm^4*SP[q1, q2] - 
   8*d^2*me^2*mm^4*SP[q1, q2] - 64*mm^6*SP[q1, q2] + 56*d*mm^6*SP[q1, q2] - 
   4*d^2*mm^6*SP[q1, q2] - 128*me^2*mm^2*s*SP[q1, q2] + 
   72*d*me^2*mm^2*s*SP[q1, q2] - 2*d^3*me^2*mm^2*s*SP[q1, q2] - 
   32*mm^4*s*SP[q1, q2] + 8*d*mm^4*s*SP[q1, q2] + 32*me^2*s^2*SP[q1, q2] - 
   24*d*me^2*s^2*SP[q1, q2] + 4*d^2*me^2*s^2*SP[q1, q2] - 
   88*mm^2*s^2*SP[q1, q2] + 44*d*mm^2*s^2*SP[q1, q2] - 
   d^3*mm^2*s^2*SP[q1, q2] + 16*s^3*SP[q1, q2] - 12*d*s^3*SP[q1, q2] + 
   2*d^2*s^3*SP[q1, q2] + 128*mm^4*t*SP[q1, q2] - 112*d*mm^4*t*SP[q1, q2] + 
   8*d^2*mm^4*t*SP[q1, q2] + 40*d*mm^2*s*t*SP[q1, q2] - 
   4*d^2*mm^2*s*t*SP[q1, q2] - 32*s^2*t*SP[q1, q2] + 8*d*s^2*t*SP[q1, q2] - 
   64*mm^2*t^2*SP[q1, q2] + 56*d*mm^2*t^2*SP[q1, q2] - 
   4*d^2*mm^2*t^2*SP[q1, q2] - 32*s*t^2*SP[q1, q2] + 8*d*s*t^2*SP[q1, q2] + 
   256*me^2*mm^2*SP[p2, q1]*SP[q1, q2] - 64*d*me^2*mm^2*SP[p2, q1]*
    SP[q1, q2] + 16*d^2*me^2*mm^2*SP[p2, q1]*SP[q1, q2] + 
   32*mm^4*SP[p2, q1]*SP[q1, q2] + 32*d*mm^4*SP[p2, q1]*SP[q1, q2] - 
   256*me^2*s*SP[p2, q1]*SP[q1, q2] + 112*d*me^2*s*SP[p2, q1]*SP[q1, q2] - 
   8*d^2*me^2*s*SP[p2, q1]*SP[q1, q2] + 64*mm^2*s*SP[p2, q1]*SP[q1, q2] - 
   48*d*mm^2*s*SP[p2, q1]*SP[q1, q2] + 8*d^2*mm^2*s*SP[p2, q1]*SP[q1, q2] - 
   128*s^2*SP[p2, q1]*SP[q1, q2] + 56*d*s^2*SP[p2, q1]*SP[q1, q2] - 
   4*d^2*s^2*SP[p2, q1]*SP[q1, q2] - 64*mm^2*t*SP[p2, q1]*SP[q1, q2] - 
   48*d*mm^2*t*SP[p2, q1]*SP[q1, q2] + 112*s*t*SP[p2, q1]*SP[q1, q2] + 
   32*t^2*SP[p2, q1]*SP[q1, q2] + 16*d*t^2*SP[p2, q1]*SP[q1, q2] - 
   32*mm^2*SP[p2, q1]^2*SP[q1, q2] + 16*d*mm^2*SP[p2, q1]^2*SP[q1, q2] + 
   32*t*SP[p2, q1]^2*SP[q1, q2] - 16*d*t*SP[p2, q1]^2*SP[q1, q2] - 
   384*me^2*mm^2*SP[p2, q2]*SP[q1, q2] + 64*d*me^2*mm^2*SP[p2, q2]*
    SP[q1, q2] + 48*d^2*me^2*mm^2*SP[p2, q2]*SP[q1, q2] - 
   8*d^3*me^2*mm^2*SP[p2, q2]*SP[q1, q2] - 224*mm^4*SP[p2, q2]*SP[q1, q2] + 
   144*d*mm^4*SP[p2, q2]*SP[q1, q2] - 16*d^2*mm^4*SP[p2, q2]*SP[q1, q2] + 
   64*me^2*s*SP[p2, q2]*SP[q1, q2] - 96*d*me^2*s*SP[p2, q2]*SP[q1, q2] + 
   40*d^2*me^2*s*SP[p2, q2]*SP[q1, q2] - 4*d^3*me^2*s*SP[p2, q2]*SP[q1, q2] - 
   104*d*mm^2*s*SP[p2, q2]*SP[q1, q2] + 40*d^2*mm^2*s*SP[p2, q2]*SP[q1, q2] - 
   4*d^3*mm^2*s*SP[p2, q2]*SP[q1, q2] + 32*s^2*SP[p2, q2]*SP[q1, q2] - 
   48*d*s^2*SP[p2, q2]*SP[q1, q2] + 20*d^2*s^2*SP[p2, q2]*SP[q1, q2] - 
   2*d^3*s^2*SP[p2, q2]*SP[q1, q2] + 384*mm^2*t*SP[p2, q2]*SP[q1, q2] - 
   224*d*mm^2*t*SP[p2, q2]*SP[q1, q2] + 24*d^2*mm^2*t*SP[p2, q2]*SP[q1, q2] - 
   112*s*t*SP[p2, q2]*SP[q1, q2] + 72*d*s*t*SP[p2, q2]*SP[q1, q2] - 
   8*d^2*s*t*SP[p2, q2]*SP[q1, q2] - 160*t^2*SP[p2, q2]*SP[q1, q2] + 
   80*d*t^2*SP[p2, q2]*SP[q1, q2] - 8*d^2*t^2*SP[p2, q2]*SP[q1, q2] - 
   128*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 80*d*mm^2*SP[p2, q1]*
    SP[p2, q2]*SP[q1, q2] - 8*d^2*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 
   128*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 80*d*t*SP[p2, q1]*SP[p2, q2]*
    SP[q1, q2] + 8*d^2*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 
   32*mm^2*SP[p2, q2]^2*SP[q1, q2] + 16*d*mm^2*SP[p2, q2]^2*SP[q1, q2] + 
   32*t*SP[p2, q2]^2*SP[q1, q2] - 16*d*t*SP[p2, q2]^2*SP[q1, q2] + 
   128*me^2*mm^2*SP[p3, q1]*SP[q1, q2] - 96*d*me^2*mm^2*SP[p3, q1]*
    SP[q1, q2] + 64*mm^4*SP[p3, q1]*SP[q1, q2] - 
   32*d*mm^4*SP[p3, q1]*SP[q1, q2] + 320*me^2*s*SP[p3, q1]*SP[q1, q2] - 
   160*d*me^2*s*SP[p3, q1]*SP[q1, q2] + 16*d^2*me^2*s*SP[p3, q1]*SP[q1, q2] - 
   16*d*mm^2*s*SP[p3, q1]*SP[q1, q2] + 240*s^2*SP[p3, q1]*SP[q1, q2] - 
   96*d*s^2*SP[p3, q1]*SP[q1, q2] + 8*d^2*s^2*SP[p3, q1]*SP[q1, q2] - 
   128*mm^2*t*SP[p3, q1]*SP[q1, q2] + 64*d*mm^2*t*SP[p3, q1]*SP[q1, q2] + 
   64*s*t*SP[p3, q1]*SP[q1, q2] - 32*d*s*t*SP[p3, q1]*SP[q1, q2] + 
   64*t^2*SP[p3, q1]*SP[q1, q2] - 32*d*t^2*SP[p3, q1]*SP[q1, q2] + 
   128*me^2*SP[p2, q1]*SP[p3, q1]*SP[q1, q2] - 64*d*me^2*SP[p2, q1]*
    SP[p3, q1]*SP[q1, q2] + 64*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q1, q2] - 
   32*d*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q1, q2] + 32*s*SP[p2, q1]*SP[p3, q1]*
    SP[q1, q2] - 16*d*s*SP[p2, q1]*SP[p3, q1]*SP[q1, q2] - 
   64*t*SP[p2, q1]*SP[p3, q1]*SP[q1, q2] + 32*d*t*SP[p2, q1]*SP[p3, q1]*
    SP[q1, q2] - 128*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   192*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   80*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   8*d^3*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   128*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 80*d*mm^2*SP[p2, q2]*
    SP[p3, q1]*SP[q1, q2] + 8*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   224*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 176*d*s*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] - 48*d^2*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 
   4*d^3*s*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 128*t*SP[p2, q2]*SP[p3, q1]*
    SP[q1, q2] + 80*d*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
   8*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 128*me^2*SP[p3, q1]^2*
    SP[q1, q2] + 64*d*me^2*SP[p3, q1]^2*SP[q1, q2] - 
   64*s*SP[p3, q1]^2*SP[q1, q2] + 32*d*s*SP[p3, q1]^2*SP[q1, q2] + 
   128*me^2*mm^2*SP[p3, q2]*SP[q1, q2] - 128*d*me^2*mm^2*SP[p3, q2]*
    SP[q1, q2] + 16*d^2*me^2*mm^2*SP[p3, q2]*SP[q1, q2] + 
   384*me^2*s*SP[p3, q2]*SP[q1, q2] - 208*d*me^2*s*SP[p3, q2]*SP[q1, q2] + 
   24*d^2*me^2*s*SP[p3, q2]*SP[q1, q2] + 64*mm^2*s*SP[p3, q2]*SP[q1, q2] - 
   64*d*mm^2*s*SP[p3, q2]*SP[q1, q2] + 8*d^2*mm^2*s*SP[p3, q2]*SP[q1, q2] + 
   240*s^2*SP[p3, q2]*SP[q1, q2] - 112*d*s^2*SP[p3, q2]*SP[q1, q2] + 
   12*d^2*s^2*SP[p3, q2]*SP[q1, q2] + 640*me^2*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] - 512*d*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 
   112*d^2*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   8*d^3*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 
   128*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 80*d*mm^2*SP[p2, q1]*
    SP[p3, q2]*SP[q1, q2] + 8*d^2*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 
   352*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 256*d*s*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] + 56*d^2*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   4*d^3*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 128*t*SP[p2, q1]*SP[p3, q2]*
    SP[q1, q2] + 80*d*t*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
   8*d^2*t*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 128*me^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q2] - 64*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 
   64*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] - 32*d*mm^2*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q2] + 32*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] - 
   16*d*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] - 64*t*SP[p2, q2]*SP[p3, q2]*
    SP[q1, q2] + 32*d*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] - 
   512*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 320*d*me^2*SP[p3, q1]*
    SP[p3, q2]*SP[q1, q2] - 32*d^2*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
   256*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 160*d*s*SP[p3, q1]*SP[p3, q2]*
    SP[q1, q2] - 16*d^2*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
   128*me^2*SP[p3, q2]^2*SP[q1, q2] + 64*d*me^2*SP[p3, q2]^2*SP[q1, q2] - 
   64*s*SP[p3, q2]^2*SP[q1, q2] + 32*d*s*SP[p3, q2]^2*SP[q1, q2] + 
   128*me^2*mm^2*SP[q1, q1]*SP[q1, q2] - 80*d*me^2*mm^2*SP[q1, q1]*
    SP[q1, q2] + 8*d^2*me^2*mm^2*SP[q1, q1]*SP[q1, q2] + 
   64*mm^4*SP[q1, q1]*SP[q1, q2] - 40*d*mm^4*SP[q1, q1]*SP[q1, q2] + 
   4*d^2*mm^4*SP[q1, q1]*SP[q1, q2] - 96*me^2*s*SP[q1, q1]*SP[q1, q2] + 
   88*d*me^2*s*SP[q1, q1]*SP[q1, q2] - 24*d^2*me^2*s*SP[q1, q1]*SP[q1, q2] + 
   2*d^3*me^2*s*SP[q1, q1]*SP[q1, q2] - 48*s^2*SP[q1, q1]*SP[q1, q2] + 
   44*d*s^2*SP[q1, q1]*SP[q1, q2] - 12*d^2*s^2*SP[q1, q1]*SP[q1, q2] + 
   d^3*s^2*SP[q1, q1]*SP[q1, q2] - 128*mm^2*t*SP[q1, q1]*SP[q1, q2] + 
   80*d*mm^2*t*SP[q1, q1]*SP[q1, q2] - 8*d^2*mm^2*t*SP[q1, q1]*SP[q1, q2] + 
   64*s*t*SP[q1, q1]*SP[q1, q2] - 40*d*s*t*SP[q1, q1]*SP[q1, q2] + 
   4*d^2*s*t*SP[q1, q1]*SP[q1, q2] + 64*t^2*SP[q1, q1]*SP[q1, q2] - 
   40*d*t^2*SP[q1, q1]*SP[q1, q2] + 4*d^2*t^2*SP[q1, q1]*SP[q1, q2] + 
   256*me^2*mm^2*SP[q1, q2]^2 - 160*d*me^2*mm^2*SP[q1, q2]^2 + 
   16*d^2*me^2*mm^2*SP[q1, q2]^2 + 128*mm^4*SP[q1, q2]^2 - 
   80*d*mm^4*SP[q1, q2]^2 + 8*d^2*mm^4*SP[q1, q2]^2 - 
   256*me^2*s*SP[q1, q2]^2 + 224*d*me^2*s*SP[q1, q2]^2 - 
   56*d^2*me^2*s*SP[q1, q2]^2 + 4*d^3*me^2*s*SP[q1, q2]^2 - 
   128*s^2*SP[q1, q2]^2 + 112*d*s^2*SP[q1, q2]^2 - 28*d^2*s^2*SP[q1, q2]^2 + 
   2*d^3*s^2*SP[q1, q2]^2 - 256*mm^2*t*SP[q1, q2]^2 + 
   160*d*mm^2*t*SP[q1, q2]^2 - 16*d^2*mm^2*t*SP[q1, q2]^2 + 
   128*s*t*SP[q1, q2]^2 - 80*d*s*t*SP[q1, q2]^2 + 8*d^2*s*t*SP[q1, q2]^2 + 
   128*t^2*SP[q1, q2]^2 - 80*d*t^2*SP[q1, q2]^2 + 8*d^2*t^2*SP[q1, q2]^2 + 
   4*SP[p1, q2]^2*(-64*me^2*mm^2 + 72*d*me^2*mm^2 - 24*d^2*me^2*mm^2 + 
     2*d^3*me^2*mm^2 - 4*mm^4 + 2*d*mm^4 + d^2*mm^4 - 36*mm^2*s + 
     38*d*mm^2*s - 13*d^2*mm^2*s + d^3*mm^2*s + 4*mm^2*t - 2*d*mm^2*t - 
     d^2*mm^2*t + 4*((-4 + 3*d)*mm^2 - 2*(-3 + d)*s + (10 - 3*d)*t)*
      SP[p2, q1] + (-2*(-64 + 56*d - 14*d^2 + d^3)*me^2 - 8*(-3 + d)*mm^2 + 
       56*s - 52*d*s + 14*d^2*s - d^3*s - 24*t + 8*d*t)*SP[p3, q1] - 
     8*mm^2*SP[q1, q1] + 6*d*mm^2*SP[q1, q1] - d^2*mm^2*SP[q1, q1] + 
     8*s*SP[q1, q1] - 6*d*s*SP[q1, q1] + d^2*s*SP[q1, q1] + 8*t*SP[q1, q1] - 
     6*d*t*SP[q1, q1] + d^2*t*SP[q1, q1] + 8*mm^2*SP[q1, q2] - 
     4*d*mm^2*SP[q1, q2] - 8*s*SP[q1, q2] + 4*d*s*SP[q1, q2] - 
     8*t*SP[q1, q2] + 4*d*t*SP[q1, q2]) + 16*d*me^2*mm^4*SP[q2, q2] + 
   8*d*mm^6*SP[q2, q2] + 208*me^2*mm^2*s*SP[q2, q2] - 
   200*d*me^2*mm^2*s*SP[q2, q2] + 52*d^2*me^2*mm^2*s*SP[q2, q2] - 
   4*d^3*me^2*mm^2*s*SP[q2, q2] + 152*mm^2*s^2*SP[q2, q2] - 
   120*d*mm^2*s^2*SP[q2, q2] + 28*d^2*mm^2*s^2*SP[q2, q2] - 
   2*d^3*mm^2*s^2*SP[q2, q2] - 16*d*mm^4*t*SP[q2, q2] + 
   8*d*mm^2*s*t*SP[q2, q2] + 8*d*mm^2*t^2*SP[q2, q2] + 
   384*me^2*mm^2*SP[p2, q1]*SP[q2, q2] - 160*d*me^2*mm^2*SP[p2, q1]*
    SP[q2, q2] + 24*d^2*me^2*mm^2*SP[p2, q1]*SP[q2, q2] + 
   144*mm^4*SP[p2, q1]*SP[q2, q2] - 72*d*mm^4*SP[p2, q1]*SP[q2, q2] + 
   12*d^2*mm^4*SP[p2, q1]*SP[q2, q2] + 64*me^2*s*SP[p2, q1]*SP[q2, q2] - 
   48*d*me^2*s*SP[p2, q1]*SP[q2, q2] + 8*d^2*me^2*s*SP[p2, q1]*SP[q2, q2] + 
   160*mm^2*s*SP[p2, q1]*SP[q2, q2] - 56*d*mm^2*s*SP[p2, q1]*SP[q2, q2] + 
   6*d^2*mm^2*s*SP[p2, q1]*SP[q2, q2] + 32*s^2*SP[p2, q1]*SP[q2, q2] - 
   24*d*s^2*SP[p2, q1]*SP[q2, q2] + 4*d^2*s^2*SP[p2, q1]*SP[q2, q2] - 
   240*mm^2*t*SP[p2, q1]*SP[q2, q2] + 104*d*mm^2*t*SP[p2, q1]*SP[q2, q2] - 
   16*d^2*mm^2*t*SP[p2, q1]*SP[q2, q2] + 32*s*t*SP[p2, q1]*SP[q2, q2] - 
   8*d*s*t*SP[p2, q1]*SP[q2, q2] + 2*d^2*s*t*SP[p2, q1]*SP[q2, q2] + 
   96*t^2*SP[p2, q1]*SP[q2, q2] - 32*d*t^2*SP[p2, q1]*SP[q2, q2] + 
   4*d^2*t^2*SP[p2, q1]*SP[q2, q2] + 32*mm^2*SP[p2, q1]^2*SP[q2, q2] - 
   24*d*mm^2*SP[p2, q1]^2*SP[q2, q2] + 4*d^2*mm^2*SP[p2, q1]^2*SP[q2, q2] - 
   32*t*SP[p2, q1]^2*SP[q2, q2] + 24*d*t*SP[p2, q1]^2*SP[q2, q2] - 
   4*d^2*t*SP[p2, q1]^2*SP[q2, q2] + 64*me^2*mm^2*SP[p2, q2]*SP[q2, q2] - 
   96*d*me^2*mm^2*SP[p2, q2]*SP[q2, q2] + 40*d^2*me^2*mm^2*SP[p2, q2]*
    SP[q2, q2] - 4*d^3*me^2*mm^2*SP[p2, q2]*SP[q2, q2] + 
   16*mm^4*SP[p2, q2]*SP[q2, q2] - 16*d*mm^4*SP[p2, q2]*SP[q2, q2] + 
   4*d^2*mm^4*SP[p2, q2]*SP[q2, q2] + 48*mm^2*s*SP[p2, q2]*SP[q2, q2] - 
   56*d*mm^2*s*SP[p2, q2]*SP[q2, q2] + 20*d^2*mm^2*s*SP[p2, q2]*SP[q2, q2] - 
   2*d^3*mm^2*s*SP[p2, q2]*SP[q2, q2] - 16*mm^2*t*SP[p2, q2]*SP[q2, q2] + 
   16*d*mm^2*t*SP[p2, q2]*SP[q2, q2] - 4*d^2*mm^2*t*SP[p2, q2]*SP[q2, q2] - 
   32*me^2*mm^2*SP[p3, q1]*SP[q2, q2] + 48*d*me^2*mm^2*SP[p3, q1]*
    SP[q2, q2] - 16*d^2*me^2*mm^2*SP[p3, q1]*SP[q2, q2] + 
   32*mm^4*SP[p3, q1]*SP[q2, q2] - 16*d*mm^4*SP[p3, q1]*SP[q2, q2] - 
   512*me^2*s*SP[p3, q1]*SP[q2, q2] + 352*d*me^2*s*SP[p3, q1]*SP[q2, q2] - 
   72*d^2*me^2*s*SP[p3, q1]*SP[q2, q2] + 4*d^3*me^2*s*SP[p3, q1]*SP[q2, q2] - 
   48*mm^2*s*SP[p3, q1]*SP[q2, q2] + 40*d*mm^2*s*SP[p3, q1]*SP[q2, q2] - 
   8*d^2*mm^2*s*SP[p3, q1]*SP[q2, q2] - 320*s^2*SP[p3, q1]*SP[q2, q2] + 
   200*d*s^2*SP[p3, q1]*SP[q2, q2] - 38*d^2*s^2*SP[p3, q1]*SP[q2, q2] + 
   2*d^3*s^2*SP[p3, q1]*SP[q2, q2] - 64*mm^2*t*SP[p3, q1]*SP[q2, q2] + 
   32*d*mm^2*t*SP[p3, q1]*SP[q2, q2] + 32*s*t*SP[p3, q1]*SP[q2, q2] - 
   16*d*s*t*SP[p3, q1]*SP[q2, q2] + 32*t^2*SP[p3, q1]*SP[q2, q2] - 
   16*d*t^2*SP[p3, q1]*SP[q2, q2] - 128*me^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] + 96*d*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   16*d^2*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   64*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 48*d*mm^2*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 8*d^2*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   32*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 24*d*s*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] - 4*d^2*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 
   64*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 48*d*t*SP[p2, q1]*SP[p3, q1]*
    SP[q2, q2] + 8*d^2*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
   192*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 176*d*me^2*SP[p2, q2]*
    SP[p3, q1]*SP[q2, q2] - 48*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
   4*d^3*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 
   32*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 24*d*mm^2*SP[p2, q2]*SP[p3, q1]*
    SP[q2, q2] - 4*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 
   128*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 96*d*s*SP[p2, q2]*SP[p3, q1]*
    SP[q2, q2] - 24*d^2*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
   2*d^3*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 32*t*SP[p2, q2]*SP[p3, q1]*
    SP[q2, q2] - 24*d*t*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
   4*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 128*me^2*SP[p3, q1]^2*
    SP[q2, q2] - 96*d*me^2*SP[p3, q1]^2*SP[q2, q2] + 
   16*d^2*me^2*SP[p3, q1]^2*SP[q2, q2] + 64*s*SP[p3, q1]^2*SP[q2, q2] - 
   48*d*s*SP[p3, q1]^2*SP[q2, q2] + 8*d^2*s*SP[p3, q1]^2*SP[q2, q2] - 
   32*me^2*mm^2*SP[p3, q2]*SP[q2, q2] + 32*d*me^2*mm^2*SP[p3, q2]*
    SP[q2, q2] - 8*d^2*me^2*mm^2*SP[p3, q2]*SP[q2, q2] - 
   16*mm^2*s*SP[p3, q2]*SP[q2, q2] + 16*d*mm^2*s*SP[p3, q2]*SP[q2, q2] - 
   4*d^2*mm^2*s*SP[p3, q2]*SP[q2, q2] + 192*me^2*SP[p2, q1]*SP[p3, q2]*
    SP[q2, q2] - 176*d*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
   48*d^2*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
   4*d^3*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
   32*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 24*d*mm^2*SP[p2, q1]*SP[p3, q2]*
    SP[q2, q2] + 4*d^2*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
   128*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 96*d*s*SP[p2, q1]*SP[p3, q2]*
    SP[q2, q2] + 24*d^2*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
   2*d^3*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 32*t*SP[p2, q1]*SP[p3, q2]*
    SP[q2, q2] + 24*d*t*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
   4*d^2*t*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 64*me^2*s*SP[q1, q1]*
    SP[q2, q2] - 48*d*me^2*s*SP[q1, q1]*SP[q2, q2] + 
   8*d^2*me^2*s*SP[q1, q1]*SP[q2, q2] + 32*s^2*SP[q1, q1]*SP[q2, q2] - 
   24*d*s^2*SP[q1, q1]*SP[q2, q2] + 4*d^2*s^2*SP[q1, q1]*SP[q2, q2] + 
   128*me^2*mm^2*SP[q1, q2]*SP[q2, q2] - 80*d*me^2*mm^2*SP[q1, q2]*
    SP[q2, q2] + 8*d^2*me^2*mm^2*SP[q1, q2]*SP[q2, q2] + 
   64*mm^4*SP[q1, q2]*SP[q2, q2] - 40*d*mm^4*SP[q1, q2]*SP[q2, q2] + 
   4*d^2*mm^4*SP[q1, q2]*SP[q2, q2] - 96*me^2*s*SP[q1, q2]*SP[q2, q2] + 
   88*d*me^2*s*SP[q1, q2]*SP[q2, q2] - 24*d^2*me^2*s*SP[q1, q2]*SP[q2, q2] + 
   2*d^3*me^2*s*SP[q1, q2]*SP[q2, q2] - 48*s^2*SP[q1, q2]*SP[q2, q2] + 
   44*d*s^2*SP[q1, q2]*SP[q2, q2] - 12*d^2*s^2*SP[q1, q2]*SP[q2, q2] + 
   d^3*s^2*SP[q1, q2]*SP[q2, q2] - 128*mm^2*t*SP[q1, q2]*SP[q2, q2] + 
   80*d*mm^2*t*SP[q1, q2]*SP[q2, q2] - 8*d^2*mm^2*t*SP[q1, q2]*SP[q2, q2] + 
   64*s*t*SP[q1, q2]*SP[q2, q2] - 40*d*s*t*SP[q1, q2]*SP[q2, q2] + 
   4*d^2*s*t*SP[q1, q2]*SP[q2, q2] + 64*t^2*SP[q1, q2]*SP[q2, q2] - 
   40*d*t^2*SP[q1, q2]*SP[q2, q2] + 4*d^2*t^2*SP[q1, q2]*SP[q2, q2] - 
   4*SP[p1, q1]^2*(-16*me^2*mm^2 + 16*d*me^2*mm^2 - 8*mm^4 - 4*d*mm^4 - 
     16*me^2*s + 8*d*me^2*s + 12*mm^2*s + 6*d*mm^2*s - 20*s^2 + 6*d*s^2 + 
     16*mm^2*t - 20*s*t + 6*d*s*t - 8*t^2 + 4*d*t^2 - 
     8*(-2 + d)*(mm^2 - s - t)*SP[p1, q2] - 4*(-2 + d)*(mm^2 - t)*
      SP[p2, q1] + 56*mm^2*SP[p2, q2] - 8*d*mm^2*SP[p2, q2] - 
     40*s*SP[p2, q2] + 8*d*s*SP[p2, q2] - 32*t*SP[p2, q2] + 
     8*d*t*SP[p2, q2] + 32*me^2*SP[p3, q1] - 16*d*me^2*SP[p3, q1] - 
     24*mm^2*SP[p3, q1] + 12*d*mm^2*SP[p3, q1] + 32*s*SP[p3, q1] - 
     16*d*s*SP[p3, q1] + 24*t*SP[p3, q1] - 12*d*t*SP[p3, q1] - 
     64*me^2*SP[p3, q2] + 24*d*me^2*SP[p3, q2] - 4*d^2*me^2*SP[p3, q2] + 
     4*d*mm^2*SP[p3, q2] - 24*s*SP[p3, q2] + 8*d*s*SP[p3, q2] - 
     2*d^2*s*SP[p3, q2] - 4*d*t*SP[p3, q2] - 8*mm^2*SP[q1, q2] + 
     4*d*mm^2*SP[q1, q2] + 8*s*SP[q1, q2] - 4*d*s*SP[q1, q2] + 
     8*t*SP[q1, q2] - 4*d*t*SP[q1, q2] + 8*mm^2*SP[q2, q2] - 
     6*d*mm^2*SP[q2, q2] + d^2*mm^2*SP[q2, q2] - 8*s*SP[q2, q2] + 
     6*d*s*SP[q2, q2] - d^2*s*SP[q2, q2] - 8*t*SP[q2, q2] + 
     6*d*t*SP[q2, q2] - d^2*t*SP[q2, q2]) - 
   2*SP[p1, q1]*(16*me^2*mm^4 - 16*d*me^2*mm^4 + 4*d^2*me^2*mm^4 + 8*mm^6 - 
     48*me^2*mm^2*s + 48*d*me^2*mm^2*s - 8*d^2*me^2*mm^2*s + 24*mm^4*s - 
     14*d*mm^4*s + 2*d^2*mm^4*s - 48*mm^2*s^2 + 30*d*mm^2*s^2 - 
     4*d^2*mm^2*s^2 - 8*mm^4*t - 4*d*mm^4*t - 8*mm^2*s*t + 6*d*mm^2*s*t + 
     4*d*mm^2*t^2 - 8*(-2 + d)*(mm^2 - s - t)*SP[p1, q2]^2 + 
     8*(-2 + d)*(mm^2 - s - t)*SP[p2, q1]^2 - 64*me^2*mm^2*SP[p2, q2] + 
     48*d*me^2*mm^2*SP[p2, q2] - 40*mm^4*SP[p2, q2] + 40*d*mm^4*SP[p2, q2] - 
     4*d^2*mm^4*SP[p2, q2] - 32*me^2*s*SP[p2, q2] + 16*d*me^2*s*SP[p2, q2] - 
     4*d*mm^2*s*SP[p2, q2] + 2*d^2*mm^2*s*SP[p2, q2] - 32*s^2*SP[p2, q2] + 
     12*d*s^2*SP[p2, q2] + 56*mm^2*t*SP[p2, q2] - 48*d*mm^2*t*SP[p2, q2] + 
     4*d^2*mm^2*t*SP[p2, q2] - 24*s*t*SP[p2, q2] + 12*d*s*t*SP[p2, q2] - 
     16*t^2*SP[p2, q2] + 8*d*t^2*SP[p2, q2] - 128*mm^2*SP[p2, q2]^2 + 
     24*d*mm^2*SP[p2, q2]^2 + 32*s*SP[p2, q2]^2 - 8*d*s*SP[p2, q2]^2 + 
     80*t*SP[p2, q2]^2 - 24*d*t*SP[p2, q2]^2 + 32*me^2*mm^2*SP[p3, q1] - 
     64*d*me^2*mm^2*SP[p3, q1] + 16*mm^4*SP[p3, q1] + 8*d*mm^4*SP[p3, q1] + 
     128*me^2*s*SP[p3, q1] - 80*d*me^2*s*SP[p3, q1] + 
     8*d^2*me^2*s*SP[p3, q1] - 24*mm^2*s*SP[p3, q1] - 
     28*d*mm^2*s*SP[p3, q1] + 112*s^2*SP[p3, q1] - 48*d*s^2*SP[p3, q1] + 
     4*d^2*s^2*SP[p3, q1] - 32*mm^2*t*SP[p3, q1] + 40*s*t*SP[p3, q1] - 
     12*d*s*t*SP[p3, q1] + 16*t^2*SP[p3, q1] - 8*d*t^2*SP[p3, q1] + 
     256*me^2*SP[p2, q2]*SP[p3, q1] - 112*d*me^2*SP[p2, q2]*SP[p3, q1] + 
     8*d^2*me^2*SP[p2, q2]*SP[p3, q1] - 64*mm^2*SP[p2, q2]*SP[p3, q1] + 
     8*d*mm^2*SP[p2, q2]*SP[p3, q1] + 192*s*SP[p2, q2]*SP[p3, q1] - 
     64*d*s*SP[p2, q2]*SP[p3, q1] + 4*d^2*s*SP[p2, q2]*SP[p3, q1] + 
     64*t*SP[p2, q2]*SP[p3, q1] - 8*d*t*SP[p2, q2]*SP[p3, q1] - 
     128*me^2*SP[p3, q1]^2 + 64*d*me^2*SP[p3, q1]^2 + 32*mm^2*SP[p3, q1]^2 - 
     16*d*mm^2*SP[p3, q1]^2 - 80*s*SP[p3, q1]^2 + 40*d*s*SP[p3, q1]^2 - 
     32*t*SP[p3, q1]^2 + 16*d*t*SP[p3, q1]^2 + 96*me^2*mm^2*SP[p3, q2] - 
     136*d*me^2*mm^2*SP[p3, q2] + 24*d^2*me^2*mm^2*SP[p3, q2] - 
     2*d^3*me^2*mm^2*SP[p3, q2] + 4*d*mm^4*SP[p3, q2] + 
     2*d^2*mm^4*SP[p3, q2] + 64*me^2*s*SP[p3, q2] - 40*d*me^2*s*SP[p3, q2] + 
     4*d^2*me^2*s*SP[p3, q2] + 56*mm^2*s*SP[p3, q2] - 
     76*d*mm^2*s*SP[p3, q2] + 12*d^2*mm^2*s*SP[p3, q2] - 
     d^3*mm^2*s*SP[p3, q2] + 56*s^2*SP[p3, q2] - 24*d*s^2*SP[p3, q2] + 
     2*d^2*s^2*SP[p3, q2] - 4*d*mm^2*t*SP[p3, q2] - 2*d^2*mm^2*t*SP[p3, q2] + 
     16*s*t*SP[p3, q2] - 4*d*s*t*SP[p3, q2] + 320*me^2*SP[p2, q2]*
      SP[p3, q2] - 256*d*me^2*SP[p2, q2]*SP[p3, q2] + 
     56*d^2*me^2*SP[p2, q2]*SP[p3, q2] - 4*d^3*me^2*SP[p2, q2]*SP[p3, q2] - 
     128*mm^2*SP[p2, q2]*SP[p3, q2] + 56*d*mm^2*SP[p2, q2]*SP[p3, q2] - 
     8*d^2*mm^2*SP[p2, q2]*SP[p3, q2] + 336*s*SP[p2, q2]*SP[p3, q2] - 
     200*d*s*SP[p2, q2]*SP[p3, q2] + 36*d^2*s*SP[p2, q2]*SP[p3, q2] - 
     2*d^3*s*SP[p2, q2]*SP[p3, q2] + 128*t*SP[p2, q2]*SP[p3, q2] - 
     56*d*t*SP[p2, q2]*SP[p3, q2] + 8*d^2*t*SP[p2, q2]*SP[p3, q2] - 
     64*me^2*SP[p3, q1]*SP[p3, q2] + 64*d*me^2*SP[p3, q1]*SP[p3, q2] + 
     32*mm^2*SP[p3, q1]*SP[p3, q2] - 16*d*mm^2*SP[p3, q1]*SP[p3, q2] - 
     48*s*SP[p3, q1]*SP[p3, q2] + 40*d*s*SP[p3, q1]*SP[p3, q2] - 
     32*t*SP[p3, q1]*SP[p3, q2] + 16*d*t*SP[p3, q1]*SP[p3, q2] + 
     128*me^2*SP[p3, q2]^2 - 48*d*me^2*SP[p3, q2]^2 + 
     8*d^2*me^2*SP[p3, q2]^2 + 64*s*SP[p3, q2]^2 - 24*d*s*SP[p3, q2]^2 + 
     4*d^2*s*SP[p3, q2]^2 - 16*me^2*mm^2*SP[q1, q1] + 
     16*d*me^2*mm^2*SP[q1, q1] - 4*d^2*me^2*mm^2*SP[q1, q1] - 
     8*mm^4*SP[q1, q1] - 24*mm^2*s*SP[q1, q1] + 14*d*mm^2*s*SP[q1, q1] - 
     2*d^2*mm^2*s*SP[q1, q1] + 8*s^2*SP[q1, q1] - 2*d*s^2*SP[q1, q1] + 
     8*mm^2*t*SP[q1, q1] + 4*d*mm^2*t*SP[q1, q1] + 8*s*t*SP[q1, q1] - 
     6*d*s*t*SP[q1, q1] - 4*d*t^2*SP[q1, q1] + 64*mm^2*SP[p2, q2]*
      SP[q1, q1] - 32*d*mm^2*SP[p2, q2]*SP[q1, q1] + 
     4*d^2*mm^2*SP[p2, q2]*SP[q1, q1] - 32*s*SP[p2, q2]*SP[q1, q1] + 
     16*d*s*SP[p2, q2]*SP[q1, q1] - 2*d^2*s*SP[p2, q2]*SP[q1, q1] - 
     64*t*SP[p2, q2]*SP[q1, q1] + 32*d*t*SP[p2, q2]*SP[q1, q1] - 
     4*d^2*t*SP[p2, q2]*SP[q1, q1] - 96*me^2*SP[p3, q2]*SP[q1, q1] + 
     88*d*me^2*SP[p3, q2]*SP[q1, q1] - 24*d^2*me^2*SP[p3, q2]*SP[q1, q1] + 
     2*d^3*me^2*SP[p3, q2]*SP[q1, q1] - 16*mm^2*SP[p3, q2]*SP[q1, q1] + 
     12*d*mm^2*SP[p3, q2]*SP[q1, q1] - 2*d^2*mm^2*SP[p3, q2]*SP[q1, q1] - 
     64*s*SP[p3, q2]*SP[q1, q1] + 48*d*s*SP[p3, q2]*SP[q1, q1] - 
     12*d^2*s*SP[p3, q2]*SP[q1, q1] + d^3*s*SP[p3, q2]*SP[q1, q1] + 
     16*t*SP[p3, q2]*SP[q1, q1] - 12*d*t*SP[p3, q2]*SP[q1, q1] + 
     2*d^2*t*SP[p3, q2]*SP[q1, q1] - 128*me^2*mm^2*SP[q1, q2] + 
     32*d*me^2*mm^2*SP[q1, q2] - 8*d^2*me^2*mm^2*SP[q1, q2] - 
     16*mm^4*SP[q1, q2] + 128*me^2*s*SP[q1, q2] - 56*d*me^2*s*SP[q1, q2] + 
     4*d^2*me^2*s*SP[q1, q2] - 112*mm^2*s*SP[q1, q2] + 
     32*d*mm^2*s*SP[q1, q2] - 4*d^2*mm^2*s*SP[q1, q2] + 104*s^2*SP[q1, q2] - 
     36*d*s^2*SP[q1, q2] + 2*d^2*s^2*SP[q1, q2] + 32*mm^2*t*SP[q1, q2] + 
     8*d*mm^2*t*SP[q1, q2] + 24*s*t*SP[q1, q2] - 16*d*s*t*SP[q1, q2] - 
     16*t^2*SP[q1, q2] - 8*d*t^2*SP[q1, q2] + 96*mm^2*SP[p2, q2]*SP[q1, q2] - 
     40*d*mm^2*SP[p2, q2]*SP[q1, q2] + 4*d^2*mm^2*SP[p2, q2]*SP[q1, q2] - 
     80*s*SP[p2, q2]*SP[q1, q2] + 40*d*s*SP[p2, q2]*SP[q1, q2] - 
     4*d^2*s*SP[p2, q2]*SP[q1, q2] - 96*t*SP[p2, q2]*SP[q1, q2] + 
     40*d*t*SP[p2, q2]*SP[q1, q2] - 4*d^2*t*SP[p2, q2]*SP[q1, q2] - 
     64*me^2*SP[p3, q1]*SP[q1, q2] + 32*d*me^2*SP[p3, q1]*SP[q1, q2] + 
     32*mm^2*SP[p3, q1]*SP[q1, q2] - 16*d*mm^2*SP[p3, q1]*SP[q1, q2] - 
     48*s*SP[p3, q1]*SP[q1, q2] + 24*d*s*SP[p3, q1]*SP[q1, q2] - 
     32*t*SP[p3, q1]*SP[q1, q2] + 16*d*t*SP[p3, q1]*SP[q1, q2] - 
     320*me^2*SP[p3, q2]*SP[q1, q2] + 256*d*me^2*SP[p3, q2]*SP[q1, q2] - 
     56*d^2*me^2*SP[p3, q2]*SP[q1, q2] + 4*d^3*me^2*SP[p3, q2]*SP[q1, q2] + 
     64*mm^2*SP[p3, q2]*SP[q1, q2] - 40*d*mm^2*SP[p3, q2]*SP[q1, q2] + 
     4*d^2*mm^2*SP[p3, q2]*SP[q1, q2] - 240*s*SP[p3, q2]*SP[q1, q2] + 
     168*d*s*SP[p3, q2]*SP[q1, q2] - 32*d^2*s*SP[p3, q2]*SP[q1, q2] + 
     2*d^3*s*SP[p3, q2]*SP[q1, q2] - 64*t*SP[p3, q2]*SP[q1, q2] + 
     40*d*t*SP[p3, q2]*SP[q1, q2] - 4*d^2*t*SP[p3, q2]*SP[q1, q2] + 
     2*SP[p1, q2]*(-32*me^2*mm^2 + 24*d*me^2*mm^2 + 4*mm^4 - 12*d*mm^4 - 
       16*me^2*s + 8*d*me^2*s + 14*d*mm^2*s - 20*s^2 + 6*d*s^2 + 4*mm^2*t + 
       8*d*mm^2*t - 20*s*t + 6*d*s*t - 8*t^2 + 4*d*t^2 - 
       8*(5*mm^2 + (-5 + d)*s - 2*t)*SP[p2, q1] + 
       8*((-1 + d)*mm^2 - (-3 + d)*s - (-4 + d)*t)*SP[p2, q2] + 
       128*me^2*SP[p3, q1] - 56*d*me^2*SP[p3, q1] + 4*d^2*me^2*SP[p3, q1] - 
       48*mm^2*SP[p3, q1] + 20*d*mm^2*SP[p3, q1] + 88*s*SP[p3, q1] - 
       40*d*s*SP[p3, q1] + 2*d^2*s*SP[p3, q1] + 48*t*SP[p3, q1] - 
       20*d*t*SP[p3, q1] + 160*me^2*SP[p3, q2] - 128*d*me^2*SP[p3, q2] + 
       28*d^2*me^2*SP[p3, q2] - 2*d^3*me^2*SP[p3, q2] + 4*d*mm^2*SP[p3, q2] + 
       88*s*SP[p3, q2] - 68*d*s*SP[p3, q2] + 14*d^2*s*SP[p3, q2] - 
       d^3*s*SP[p3, q2] - 4*d*t*SP[p3, q2] - 32*mm^2*SP[q1, q2] + 
       20*d*mm^2*SP[q1, q2] - 2*d^2*mm^2*SP[q1, q2] + 32*s*SP[q1, q2] - 
       20*d*s*SP[q1, q2] + 2*d^2*s*SP[q1, q2] + 32*t*SP[q1, q2] - 
       20*d*t*SP[q1, q2] + 2*d^2*t*SP[q1, q2]) - 192*me^2*mm^2*SP[q2, q2] + 
     80*d*me^2*mm^2*SP[q2, q2] - 12*d^2*me^2*mm^2*SP[q2, q2] - 
     24*mm^4*SP[q2, q2] - 4*d*mm^4*SP[q2, q2] + 2*d^2*mm^4*SP[q2, q2] - 
     32*me^2*s*SP[q2, q2] + 24*d*me^2*s*SP[q2, q2] - 
     4*d^2*me^2*s*SP[q2, q2] - 40*mm^2*s*SP[q2, q2] + 
     24*d*mm^2*s*SP[q2, q2] - 5*d^2*mm^2*s*SP[q2, q2] - 48*s^2*SP[q2, q2] + 
     24*d*s^2*SP[q2, q2] - 3*d^2*s^2*SP[q2, q2] + 72*mm^2*t*SP[q2, q2] - 
     12*d*mm^2*t*SP[q2, q2] - 80*s*t*SP[q2, q2] + 28*d*s*t*SP[q2, q2] - 
     3*d^2*s*t*SP[q2, q2] - 48*t^2*SP[q2, q2] + 16*d*t^2*SP[q2, q2] - 
     2*d^2*t^2*SP[q2, q2] + 32*mm^2*SP[p2, q2]*SP[q2, q2] - 
     8*d*mm^2*SP[p2, q2]*SP[q2, q2] - 16*s*SP[p2, q2]*SP[q2, q2] + 
     4*d*s*SP[p2, q2]*SP[q2, q2] - 32*t*SP[p2, q2]*SP[q2, q2] + 
     8*d*t*SP[p2, q2]*SP[q2, q2] + 64*me^2*SP[p3, q1]*SP[q2, q2] - 
     48*d*me^2*SP[p3, q1]*SP[q2, q2] + 8*d^2*me^2*SP[p3, q1]*SP[q2, q2] - 
     32*mm^2*SP[p3, q1]*SP[q2, q2] + 24*d*mm^2*SP[p3, q1]*SP[q2, q2] - 
     4*d^2*mm^2*SP[p3, q1]*SP[q2, q2] + 48*s*SP[p3, q1]*SP[q2, q2] - 
     36*d*s*SP[p3, q1]*SP[q2, q2] + 6*d^2*s*SP[p3, q1]*SP[q2, q2] + 
     32*t*SP[p3, q1]*SP[q2, q2] - 24*d*t*SP[p3, q1]*SP[q2, q2] + 
     4*d^2*t*SP[p3, q1]*SP[q2, q2] - 96*me^2*SP[p3, q2]*SP[q2, q2] + 
     88*d*me^2*SP[p3, q2]*SP[q2, q2] - 24*d^2*me^2*SP[p3, q2]*SP[q2, q2] + 
     2*d^3*me^2*SP[p3, q2]*SP[q2, q2] + 16*mm^2*SP[p3, q2]*SP[q2, q2] - 
     12*d*mm^2*SP[p3, q2]*SP[q2, q2] + 2*d^2*mm^2*SP[p3, q2]*SP[q2, q2] - 
     80*s*SP[p3, q2]*SP[q2, q2] + 60*d*s*SP[p3, q2]*SP[q2, q2] - 
     14*d^2*s*SP[p3, q2]*SP[q2, q2] + d^3*s*SP[p3, q2]*SP[q2, q2] - 
     16*t*SP[p3, q2]*SP[q2, q2] + 12*d*t*SP[p3, q2]*SP[q2, q2] - 
     2*d^2*t*SP[p3, q2]*SP[q2, q2] + 2*SP[p2, q1]*(-32*me^2*mm^2 + 
       32*d*me^2*mm^2 - 16*mm^4 + 8*d*mm^4 - 32*me^2*s + 16*d*me^2*s + 
       8*d*mm^2*s - 28*s^2 + 10*d*s^2 + 32*mm^2*t - 16*d*mm^2*t - 16*s*t + 
       8*d*s*t - 16*t^2 + 8*d*t^2 - 8*(mm^2 + (-3 + d)*s + 2*t)*SP[p2, q2] - 
       4*(-2 + d)*(8*me^2 + 3*s)*SP[p3, q1] - 128*me^2*SP[p3, q2] + 
       48*d*me^2*SP[p3, q2] - 8*d^2*me^2*SP[p3, q2] - 112*s*SP[p3, q2] + 
       36*d*s*SP[p3, q2] - 4*d^2*s*SP[p3, q2] - 8*s*SP[q1, q2] + 
       4*d*s*SP[q1, q2] + 8*s*SP[q2, q2] - 6*d*s*SP[q2, q2] + 
       d^2*s*SP[q2, q2])) + 2*SP[p1, q2]*(48*me^2*mm^4 - 16*d*me^2*mm^4 - 
     12*d^2*me^2*mm^4 + 2*d^3*me^2*mm^4 - 4*d*mm^6 - 64*me^2*mm^2*s + 
     64*d*me^2*mm^2*s - 20*d^2*me^2*mm^2*s + 2*d^3*me^2*mm^2*s + 28*mm^4*s - 
     2*d*mm^4*s - 7*d^2*mm^4*s + d^3*mm^4*s - 52*mm^2*s^2 + 42*d*mm^2*s^2 - 
     11*d^2*mm^2*s^2 + d^3*mm^2*s^2 - 24*mm^4*t + 24*d*mm^4*t - 
     2*d^2*mm^4*t - 4*mm^2*s*t - 6*d*mm^2*s*t + d^2*mm^2*s*t + 24*mm^2*t^2 - 
     20*d*mm^2*t^2 + 2*d^2*mm^2*t^2 - 16*((-1 + d)*mm^2 - s - (-4 + d)*t)*
      SP[p2, q1]^2 - 24*d*me^2*mm^2*SP[p3, q1] + 24*d^2*me^2*mm^2*
      SP[p3, q1] - 2*d^3*me^2*mm^2*SP[p3, q1] - 20*d*mm^4*SP[p3, q1] + 
     2*d^2*mm^4*SP[p3, q1] - 64*me^2*s*SP[p3, q1] + 40*d*me^2*s*SP[p3, q1] - 
     4*d^2*me^2*s*SP[p3, q1] + 40*mm^2*s*SP[p3, q1] - 
     16*d*mm^2*s*SP[p3, q1] + 12*d^2*mm^2*s*SP[p3, q1] - 
     d^3*mm^2*s*SP[p3, q1] - 56*s^2*SP[p3, q1] + 24*d*s^2*SP[p3, q1] - 
     2*d^2*s^2*SP[p3, q1] + 16*mm^2*t*SP[p3, q1] + 12*d*mm^2*t*SP[p3, q1] - 
     2*d^2*mm^2*t*SP[p3, q1] - 24*s*t*SP[p3, q1] + 8*d*s*t*SP[p3, q1] - 
     16*t^2*SP[p3, q1] + 8*d*t^2*SP[p3, q1] + 192*me^2*SP[p3, q1]^2 - 
     64*d*me^2*SP[p3, q1]^2 - 32*mm^2*SP[p3, q1]^2 + 16*d*mm^2*SP[p3, q1]^2 + 
     112*s*SP[p3, q1]^2 - 40*d*s*SP[p3, q1]^2 + 32*t*SP[p3, q1]^2 - 
     16*d*t*SP[p3, q1]^2 + 8*d^2*me^2*mm^2*SP[p3, q2] - 16*mm^4*SP[p3, q2] + 
     8*d*mm^4*SP[p3, q2] - 4*d^2*mm^4*SP[p3, q2] + 8*mm^2*s*SP[p3, q2] - 
     4*d*mm^2*s*SP[p3, q2] + 6*d^2*mm^2*s*SP[p3, q2] + 16*mm^2*t*SP[p3, q2] - 
     8*d*mm^2*t*SP[p3, q2] + 4*d^2*mm^2*t*SP[p3, q2] + 
     256*me^2*SP[p3, q1]*SP[p3, q2] - 112*d*me^2*SP[p3, q1]*SP[p3, q2] + 
     8*d^2*me^2*SP[p3, q1]*SP[p3, q2] - 32*mm^2*SP[p3, q1]*SP[p3, q2] + 
     16*d*mm^2*SP[p3, q1]*SP[p3, q2] + 144*s*SP[p3, q1]*SP[p3, q2] - 
     64*d*s*SP[p3, q1]*SP[p3, q2] + 4*d^2*s*SP[p3, q1]*SP[p3, q2] + 
     32*t*SP[p3, q1]*SP[p3, q2] - 16*d*t*SP[p3, q1]*SP[p3, q2] - 
     144*me^2*mm^2*SP[q1, q1] + 16*d*me^2*mm^2*SP[q1, q1] + 
     12*d^2*me^2*mm^2*SP[q1, q1] - 2*d^3*me^2*mm^2*SP[q1, q1] - 
     24*mm^4*SP[q1, q1] + 4*d*mm^4*SP[q1, q1] + 192*me^2*s*SP[q1, q1] - 
     128*d*me^2*s*SP[q1, q1] + 28*d^2*me^2*s*SP[q1, q1] - 
     2*d^3*me^2*s*SP[q1, q1] - 64*mm^2*s*SP[q1, q1] + 2*d*mm^2*s*SP[q1, q1] + 
     7*d^2*mm^2*s*SP[q1, q1] - d^3*mm^2*s*SP[q1, q1] + 136*s^2*SP[q1, q1] - 
     78*d*s^2*SP[q1, q1] + 15*d^2*s^2*SP[q1, q1] - d^3*s^2*SP[q1, q1] + 
     72*mm^2*t*SP[q1, q1] - 24*d*mm^2*t*SP[q1, q1] + 
     2*d^2*mm^2*t*SP[q1, q1] - 8*s*t*SP[q1, q1] + 6*d*s*t*SP[q1, q1] - 
     d^2*s*t*SP[q1, q1] - 48*t^2*SP[q1, q1] + 20*d*t^2*SP[q1, q1] - 
     2*d^2*t^2*SP[q1, q1] - 96*me^2*SP[p3, q1]*SP[q1, q1] + 
     88*d*me^2*SP[p3, q1]*SP[q1, q1] - 24*d^2*me^2*SP[p3, q1]*SP[q1, q1] + 
     2*d^3*me^2*SP[p3, q1]*SP[q1, q1] - 16*mm^2*SP[p3, q1]*SP[q1, q1] + 
     12*d*mm^2*SP[p3, q1]*SP[q1, q1] - 2*d^2*mm^2*SP[p3, q1]*SP[q1, q1] - 
     64*s*SP[p3, q1]*SP[q1, q1] + 48*d*s*SP[p3, q1]*SP[q1, q1] - 
     12*d^2*s*SP[p3, q1]*SP[q1, q1] + d^3*s*SP[p3, q1]*SP[q1, q1] + 
     16*t*SP[p3, q1]*SP[q1, q1] - 12*d*t*SP[p3, q1]*SP[q1, q1] + 
     2*d^2*t*SP[p3, q1]*SP[q1, q1] - 64*me^2*SP[p3, q2]*SP[q1, q1] + 
     48*d*me^2*SP[p3, q2]*SP[q1, q1] - 8*d^2*me^2*SP[p3, q2]*SP[q1, q1] + 
     32*mm^2*SP[p3, q2]*SP[q1, q1] - 24*d*mm^2*SP[p3, q2]*SP[q1, q1] + 
     4*d^2*mm^2*SP[p3, q2]*SP[q1, q1] - 48*s*SP[p3, q2]*SP[q1, q1] + 
     36*d*s*SP[p3, q2]*SP[q1, q1] - 6*d^2*s*SP[p3, q2]*SP[q1, q1] - 
     32*t*SP[p3, q2]*SP[q1, q1] + 24*d*t*SP[p3, q2]*SP[q1, q1] - 
     4*d^2*t*SP[p3, q2]*SP[q1, q1] - 192*me^2*mm^2*SP[q1, q2] + 
     32*d*me^2*mm^2*SP[q1, q2] + 24*d^2*me^2*mm^2*SP[q1, q2] - 
     4*d^3*me^2*mm^2*SP[q1, q2] - 48*mm^4*SP[q1, q2] + 8*d*mm^4*SP[q1, q2] + 
     32*me^2*s*SP[q1, q2] - 48*d*me^2*s*SP[q1, q2] + 
     20*d^2*me^2*s*SP[q1, q2] - 2*d^3*me^2*s*SP[q1, q2] + 
     16*mm^2*s*SP[q1, q2] - 28*d*mm^2*s*SP[q1, q2] + 
     16*d^2*mm^2*s*SP[q1, q2] - 2*d^3*mm^2*s*SP[q1, q2] - 8*s^2*SP[q1, q2] - 
     20*d*s^2*SP[q1, q2] + 10*d^2*s^2*SP[q1, q2] - d^3*s^2*SP[q1, q2] + 
     128*mm^2*t*SP[q1, q2] - 48*d*mm^2*t*SP[q1, q2] + 
     4*d^2*mm^2*t*SP[q1, q2] - 104*s*t*SP[q1, q2] + 44*d*s*t*SP[q1, q2] - 
     4*d^2*s*t*SP[q1, q2] - 80*t^2*SP[q1, q2] + 40*d*t^2*SP[q1, q2] - 
     4*d^2*t^2*SP[q1, q2] - 64*me^2*SP[p3, q1]*SP[q1, q2] + 
     96*d*me^2*SP[p3, q1]*SP[q1, q2] - 40*d^2*me^2*SP[p3, q1]*SP[q1, q2] + 
     4*d^3*me^2*SP[p3, q1]*SP[q1, q2] - 64*mm^2*SP[p3, q1]*SP[q1, q2] + 
     40*d*mm^2*SP[p3, q1]*SP[q1, q2] - 4*d^2*mm^2*SP[p3, q1]*SP[q1, q2] - 
     48*s*SP[p3, q1]*SP[q1, q2] + 48*d*s*SP[p3, q1]*SP[q1, q2] - 
     20*d^2*s*SP[p3, q1]*SP[q1, q2] + 2*d^3*s*SP[p3, q1]*SP[q1, q2] + 
     64*t*SP[p3, q1]*SP[q1, q2] - 40*d*t*SP[p3, q1]*SP[q1, q2] + 
     4*d^2*t*SP[p3, q1]*SP[q1, q2] + 64*me^2*SP[p3, q2]*SP[q1, q2] - 
     32*d*me^2*SP[p3, q2]*SP[q1, q2] - 32*mm^2*SP[p3, q2]*SP[q1, q2] + 
     16*d*mm^2*SP[p3, q2]*SP[q1, q2] + 48*s*SP[p3, q2]*SP[q1, q2] - 
     24*d*s*SP[p3, q2]*SP[q1, q2] + 32*t*SP[p3, q2]*SP[q1, q2] - 
     16*d*t*SP[p3, q2]*SP[q1, q2] + 2*SP[p2, q2]*(-128*me^2*mm^2 + 
       144*d*me^2*mm^2 - 48*d^2*me^2*mm^2 + 4*d^3*me^2*mm^2 - 132*mm^2*s + 
       106*d*mm^2*s - 27*d^2*mm^2*s + 2*d^3*mm^2*s - 
       2*(2*(-64 + 56*d - 14*d^2 + d^3)*me^2 + (-124 + 80*d - 16*d^2 + d^3)*
          s)*SP[p3, q1] - (8 - 6*d + d^2)*s*SP[q1, q1] + 8*s*SP[q1, q2] - 
       4*d*s*SP[q1, q2]) + 32*me^2*mm^2*SP[q2, q2] - 
     48*d*me^2*mm^2*SP[q2, q2] + 20*d^2*me^2*mm^2*SP[q2, q2] - 
     2*d^3*me^2*mm^2*SP[q2, q2] - 8*mm^4*SP[q2, q2] + 8*d*mm^4*SP[q2, q2] - 
     2*d^2*mm^4*SP[q2, q2] + 32*mm^2*s*SP[q2, q2] - 36*d*mm^2*s*SP[q2, q2] + 
     12*d^2*mm^2*s*SP[q2, q2] - d^3*mm^2*s*SP[q2, q2] + 8*mm^2*t*SP[q2, q2] - 
     8*d*mm^2*t*SP[q2, q2] + 2*d^2*mm^2*t*SP[q2, q2] - 
     96*me^2*SP[p3, q1]*SP[q2, q2] + 88*d*me^2*SP[p3, q1]*SP[q2, q2] - 
     24*d^2*me^2*SP[p3, q1]*SP[q2, q2] + 2*d^3*me^2*SP[p3, q1]*SP[q2, q2] + 
     16*mm^2*SP[p3, q1]*SP[q2, q2] - 12*d*mm^2*SP[p3, q1]*SP[q2, q2] + 
     2*d^2*mm^2*SP[p3, q1]*SP[q2, q2] - 80*s*SP[p3, q1]*SP[q2, q2] + 
     60*d*s*SP[p3, q1]*SP[q2, q2] - 14*d^2*s*SP[p3, q1]*SP[q2, q2] + 
     d^3*s*SP[p3, q1]*SP[q2, q2] - 16*t*SP[p3, q1]*SP[q2, q2] + 
     12*d*t*SP[p3, q1]*SP[q2, q2] - 2*d^2*t*SP[p3, q1]*SP[q2, q2] - 
     2*SP[p2, q1]*(-32*me^2*mm^2 + 24*d*me^2*mm^2 + 4*mm^4 - 12*d*mm^4 + 
       2*d^2*mm^4 - 16*me^2*s + 8*d*me^2*s - 20*mm^2*s + 18*d*mm^2*s - 
       d^2*mm^2*s - 12*s^2 + 4*d*s^2 + 4*mm^2*t + 8*d*mm^2*t - 2*d^2*mm^2*t - 
       4*s*t + 2*d*s*t - 8*t^2 + 4*d*t^2 - 8*((-7 + d)*mm^2 + s - (-4 + d)*t)*
        SP[p2, q2] + 2*(2*(32 - 14*d + d^2)*me^2 - 2*(-8 + d)*mm^2 + 32*s - 
         14*d*s + d^2*s - 16*t + 2*d*t)*SP[p3, q1] + 160*me^2*SP[p3, q2] - 
       128*d*me^2*SP[p3, q2] + 28*d^2*me^2*SP[p3, q2] - 
       2*d^3*me^2*SP[p3, q2] + 64*mm^2*SP[p3, q2] - 28*d*mm^2*SP[p3, q2] + 
       4*d^2*mm^2*SP[p3, q2] + 104*s*SP[p3, q2] - 72*d*s*SP[p3, q2] + 
       14*d^2*s*SP[p3, q2] - d^3*s*SP[p3, q2] - 64*t*SP[p3, q2] + 
       28*d*t*SP[p3, q2] - 4*d^2*t*SP[p3, q2] - 32*mm^2*SP[q1, q1] + 
       16*d*mm^2*SP[q1, q1] - 2*d^2*mm^2*SP[q1, q1] + 16*s*SP[q1, q1] - 
       8*d*s*SP[q1, q1] + d^2*s*SP[q1, q1] + 32*t*SP[q1, q1] - 
       16*d*t*SP[q1, q1] + 2*d^2*t*SP[q1, q1] - 48*mm^2*SP[q1, q2] + 
       20*d*mm^2*SP[q1, q2] - 2*d^2*mm^2*SP[q1, q2] + 8*s*SP[q1, q2] + 
       48*t*SP[q1, q2] - 20*d*t*SP[q1, q2] + 2*d^2*t*SP[q1, q2] - 
       16*mm^2*SP[q2, q2] + 4*d*mm^2*SP[q2, q2] + 8*s*SP[q2, q2] - 
       2*d*s*SP[q2, q2] + 16*t*SP[q2, q2] - 4*d*t*SP[q2, q2]))))/
 (256*Pi^8*s^2)
