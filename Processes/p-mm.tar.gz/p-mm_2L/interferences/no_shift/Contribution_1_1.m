(* Created with the Wolfram Language : www.wolfram.com *)
-(EL^8*gAl^8*KiraPropagator[q1, mm]*KiraPropagator[-p3 + q1, 0]*
   KiraPropagator[q2, 0]*KiraPropagator[p3 + q2, mm]*
   KiraPropagator[-p1 - p2 + p3 + q2, mm]*KiraPropagator[q1 + q2, mm]*
   (64*me^2*mm^6 - 32*d*me^2*mm^6 + 32*mm^8 - 16*d*mm^8 - 64*me^2*mm^4*s + 
    48*d*me^2*mm^4*s - 8*d^2*me^2*mm^4*s - 16*mm^6*s + 8*d*mm^6*s + 
    16*me^2*mm^2*s^2 - 16*d*me^2*mm^2*s^2 + 4*d^2*me^2*mm^2*s^2 - 
    16*mm^4*s^2 + 16*d*mm^4*s^2 - 4*d^2*mm^4*s^2 + 8*mm^2*s^3 - 
    8*d*mm^2*s^3 + 2*d^2*mm^2*s^3 - 64*mm^6*t + 32*d*mm^6*t + 64*mm^4*s*t - 
    32*d*mm^4*s*t - 16*mm^2*s^2*t + 8*d*mm^2*s^2*t + 32*mm^4*t^2 - 
    16*d*mm^4*t^2 - 16*mm^2*s*t^2 + 8*d*mm^2*s*t^2 - 
    64*d*me^2*mm^4*SP[p2, q1] - 32*d*mm^6*SP[p2, q1] + 
    32*d*me^2*mm^2*s*SP[p2, q1] - 16*d^2*me^2*mm^2*s*SP[p2, q1] + 
    16*d*mm^2*s^2*SP[p2, q1] - 8*d^2*mm^2*s^2*SP[p2, q1] + 
    64*d*mm^4*t*SP[p2, q1] - 32*d*mm^2*s*t*SP[p2, q1] - 
    32*d*mm^2*t^2*SP[p2, q1] - 32*me^2*mm^4*SP[p2, q2] - 
    16*d*me^2*mm^4*SP[p2, q2] - 32*mm^6*SP[p2, q2] + 
    32*me^2*mm^2*s*SP[p2, q2] - 16*d*me^2*mm^2*s*SP[p2, q2] + 
    16*mm^4*s*SP[p2, q2] - 8*d*mm^4*s*SP[p2, q2] + 16*mm^2*s^2*SP[p2, q2] - 
    8*d*mm^2*s^2*SP[p2, q2] + 32*mm^4*t*SP[p2, q2] + 16*d*mm^4*t*SP[p2, q2] - 
    16*mm^2*s*t*SP[p2, q2] - 8*d*mm^2*s*t*SP[p2, q2] - 
    16*d*mm^2*t^2*SP[p2, q2] + 32*d*me^2*mm^2*SP[p2, q1]*SP[p2, q2] - 
    16*d^2*me^2*mm^2*SP[p2, q1]*SP[p2, q2] + 16*d*mm^4*SP[p2, q1]*
     SP[p2, q2] + 16*d*mm^2*s*SP[p2, q1]*SP[p2, q2] - 
    8*d^2*mm^2*s*SP[p2, q1]*SP[p2, q2] - 16*d*mm^2*t*SP[p2, q1]*SP[p2, q2] + 
    64*me^2*mm^2*SP[p2, q2]^2 - 32*d*me^2*mm^2*SP[p2, q2]^2 - 
    48*mm^4*SP[p2, q2]^2 + 40*d*mm^4*SP[p2, q2]^2 - 4*d^2*mm^4*SP[p2, q2]^2 + 
    32*mm^2*s*SP[p2, q2]^2 - 16*d*mm^2*s*SP[p2, q2]^2 + 
    48*mm^2*t*SP[p2, q2]^2 - 40*d*mm^2*t*SP[p2, q2]^2 + 
    4*d^2*mm^2*t*SP[p2, q2]^2 + 64*d*me^2*mm^4*SP[p3, q1] + 
    32*d*mm^6*SP[p3, q1] - 32*d*me^2*mm^2*s*SP[p3, q1] + 
    16*d^2*me^2*mm^2*s*SP[p3, q1] - 16*d*mm^2*s^2*SP[p3, q1] + 
    8*d^2*mm^2*s^2*SP[p3, q1] - 64*d*mm^4*t*SP[p3, q1] + 
    32*d*mm^2*s*t*SP[p3, q1] + 32*d*mm^2*t^2*SP[p3, q1] - 
    128*me^2*mm^2*SP[p2, q1]*SP[p3, q1] + 64*d*me^2*mm^2*SP[p2, q1]*
     SP[p3, q1] - 64*mm^4*SP[p2, q1]*SP[p3, q1] + 
    32*d*mm^4*SP[p2, q1]*SP[p3, q1] + 64*me^2*s*SP[p2, q1]*SP[p3, q1] - 
    64*d*me^2*s*SP[p2, q1]*SP[p3, q1] + 16*d^2*me^2*s*SP[p2, q1]*SP[p3, q1] + 
    32*s^2*SP[p2, q1]*SP[p3, q1] - 32*d*s^2*SP[p2, q1]*SP[p3, q1] + 
    8*d^2*s^2*SP[p2, q1]*SP[p3, q1] + 128*mm^2*t*SP[p2, q1]*SP[p3, q1] - 
    64*d*mm^2*t*SP[p2, q1]*SP[p3, q1] - 64*s*t*SP[p2, q1]*SP[p3, q1] + 
    32*d*s*t*SP[p2, q1]*SP[p3, q1] - 64*t^2*SP[p2, q1]*SP[p3, q1] + 
    32*d*t^2*SP[p2, q1]*SP[p3, q1] - 64*me^2*mm^2*SP[p2, q2]*SP[p3, q1] + 
    32*d*me^2*mm^2*SP[p2, q2]*SP[p3, q1] - 32*mm^4*SP[p2, q2]*SP[p3, q1] - 
    16*d*mm^4*SP[p2, q2]*SP[p3, q1] + 32*me^2*s*SP[p2, q2]*SP[p3, q1] - 
    32*d*me^2*s*SP[p2, q2]*SP[p3, q1] + 8*d^2*me^2*s*SP[p2, q2]*SP[p3, q1] + 
    16*d*mm^2*s*SP[p2, q2]*SP[p3, q1] + 16*s^2*SP[p2, q2]*SP[p3, q1] - 
    16*d*s^2*SP[p2, q2]*SP[p3, q1] + 4*d^2*s^2*SP[p2, q2]*SP[p3, q1] + 
    64*mm^2*t*SP[p2, q2]*SP[p3, q1] - 32*s*t*SP[p2, q2]*SP[p3, q1] + 
    16*d*s*t*SP[p2, q2]*SP[p3, q1] - 32*t^2*SP[p2, q2]*SP[p3, q1] + 
    16*d*t^2*SP[p2, q2]*SP[p3, q1] + 64*me^2*SP[p2, q1]*SP[p2, q2]*
     SP[p3, q1] - 64*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
    16*d^2*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
    32*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 16*d*mm^2*SP[p2, q1]*
     SP[p2, q2]*SP[p3, q1] + 32*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 
    32*d*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 8*d^2*s*SP[p2, q1]*SP[p2, q2]*
     SP[p3, q1] - 32*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] + 
    16*d*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q1] - 64*me^2*SP[p2, q2]^2*
     SP[p3, q1] + 32*d*me^2*SP[p2, q2]^2*SP[p3, q1] + 
    160*mm^2*SP[p2, q2]^2*SP[p3, q1] - 80*d*mm^2*SP[p2, q2]^2*SP[p3, q1] + 
    8*d^2*mm^2*SP[p2, q2]^2*SP[p3, q1] - 32*s*SP[p2, q2]^2*SP[p3, q1] + 
    16*d*s*SP[p2, q2]^2*SP[p3, q1] - 160*t*SP[p2, q2]^2*SP[p3, q1] + 
    80*d*t*SP[p2, q2]^2*SP[p3, q1] - 8*d^2*t*SP[p2, q2]^2*SP[p3, q1] + 
    128*me^2*mm^2*SP[p3, q1]^2 - 64*d*me^2*mm^2*SP[p3, q1]^2 + 
    64*mm^4*SP[p3, q1]^2 - 32*d*mm^4*SP[p3, q1]^2 - 64*me^2*s*SP[p3, q1]^2 + 
    64*d*me^2*s*SP[p3, q1]^2 - 16*d^2*me^2*s*SP[p3, q1]^2 - 
    32*s^2*SP[p3, q1]^2 + 32*d*s^2*SP[p3, q1]^2 - 8*d^2*s^2*SP[p3, q1]^2 - 
    128*mm^2*t*SP[p3, q1]^2 + 64*d*mm^2*t*SP[p3, q1]^2 + 
    64*s*t*SP[p3, q1]^2 - 32*d*s*t*SP[p3, q1]^2 + 64*t^2*SP[p3, q1]^2 - 
    32*d*t^2*SP[p3, q1]^2 - 64*mm^2*SP[p2, q2]*SP[p3, q1]^2 + 
    32*d*mm^2*SP[p2, q2]*SP[p3, q1]^2 + 32*s*SP[p2, q2]*SP[p3, q1]^2 - 
    16*d*s*SP[p2, q2]*SP[p3, q1]^2 + 64*t*SP[p2, q2]*SP[p3, q1]^2 - 
    32*d*t*SP[p2, q2]*SP[p3, q1]^2 + 64*me^2*mm^4*SP[p3, q2] + 
    16*d*mm^6*SP[p3, q2] - 64*me^2*mm^2*s*SP[p3, q2] + 
    48*d*me^2*mm^2*s*SP[p3, q2] - 8*d^2*me^2*mm^2*s*SP[p3, q2] + 
    32*mm^4*s*SP[p3, q2] - 16*d*mm^4*s*SP[p3, q2] - 48*mm^2*s^2*SP[p3, q2] + 
    32*d*mm^2*s^2*SP[p3, q2] - 4*d^2*mm^2*s^2*SP[p3, q2] - 
    32*d*mm^4*t*SP[p3, q2] + 16*d*mm^2*s*t*SP[p3, q2] + 
    16*d*mm^2*t^2*SP[p3, q2] - 64*me^2*mm^2*SP[p2, q1]*SP[p3, q2] - 
    32*d*me^2*mm^2*SP[p2, q1]*SP[p3, q2] + 16*d^2*me^2*mm^2*SP[p2, q1]*
     SP[p3, q2] - 32*mm^4*SP[p2, q1]*SP[p3, q2] + 
    32*d*mm^4*SP[p2, q1]*SP[p3, q2] + 32*me^2*s*SP[p2, q1]*SP[p3, q2] - 
    32*d*me^2*s*SP[p2, q1]*SP[p3, q2] + 8*d^2*me^2*s*SP[p2, q1]*SP[p3, q2] - 
    48*d*mm^2*s*SP[p2, q1]*SP[p3, q2] + 8*d^2*mm^2*s*SP[p2, q1]*SP[p3, q2] + 
    16*s^2*SP[p2, q1]*SP[p3, q2] - 16*d*s^2*SP[p2, q1]*SP[p3, q2] + 
    4*d^2*s^2*SP[p2, q1]*SP[p3, q2] + 64*mm^2*t*SP[p2, q1]*SP[p3, q2] - 
    48*d*mm^2*t*SP[p2, q1]*SP[p3, q2] - 32*s*t*SP[p2, q1]*SP[p3, q2] + 
    16*d*s*t*SP[p2, q1]*SP[p3, q2] - 32*t^2*SP[p2, q1]*SP[p3, q2] + 
    16*d*t^2*SP[p2, q1]*SP[p3, q2] - 64*me^2*SP[p2, q1]^2*SP[p3, q2] + 
    64*d*me^2*SP[p2, q1]^2*SP[p3, q2] - 16*d^2*me^2*SP[p2, q1]^2*SP[p3, q2] - 
    32*mm^2*SP[p2, q1]^2*SP[p3, q2] + 16*d*mm^2*SP[p2, q1]^2*SP[p3, q2] - 
    32*s*SP[p2, q1]^2*SP[p3, q2] + 32*d*s*SP[p2, q1]^2*SP[p3, q2] - 
    8*d^2*s*SP[p2, q1]^2*SP[p3, q2] + 32*t*SP[p2, q1]^2*SP[p3, q2] - 
    16*d*t*SP[p2, q1]^2*SP[p3, q2] + 192*me^2*mm^2*SP[p2, q2]*SP[p3, q2] - 
    256*d*me^2*mm^2*SP[p2, q2]*SP[p3, q2] + 80*d^2*me^2*mm^2*SP[p2, q2]*
     SP[p3, q2] - 8*d^3*me^2*mm^2*SP[p2, q2]*SP[p3, q2] - 
    16*d*mm^4*SP[p2, q2]*SP[p3, q2] + 144*mm^2*s*SP[p2, q2]*SP[p3, q2] - 
    152*d*mm^2*s*SP[p2, q2]*SP[p3, q2] + 44*d^2*mm^2*s*SP[p2, q2]*
     SP[p3, q2] - 4*d^3*mm^2*s*SP[p2, q2]*SP[p3, q2] + 
    16*d*mm^2*t*SP[p2, q2]*SP[p3, q2] + 64*me^2*SP[p2, q1]*SP[p2, q2]*
     SP[p3, q2] - 32*d*me^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 
    160*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 80*d*mm^2*SP[p2, q1]*
     SP[p2, q2]*SP[p3, q2] - 8*d^2*mm^2*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 
    32*s*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 16*d*s*SP[p2, q1]*SP[p2, q2]*
     SP[p3, q2] + 160*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] - 
    80*d*t*SP[p2, q1]*SP[p2, q2]*SP[p3, q2] + 8*d^2*t*SP[p2, q1]*SP[p2, q2]*
     SP[p3, q2] + 128*me^2*mm^2*SP[p3, q1]*SP[p3, q2] - 
    32*d*me^2*mm^2*SP[p3, q1]*SP[p3, q2] + 64*mm^4*SP[p3, q1]*SP[p3, q2] - 
    32*d*mm^4*SP[p3, q1]*SP[p3, q2] - 64*me^2*s*SP[p3, q1]*SP[p3, q2] + 
    64*d*me^2*s*SP[p3, q1]*SP[p3, q2] - 16*d^2*me^2*s*SP[p3, q1]*SP[p3, q2] + 
    16*d*mm^2*s*SP[p3, q1]*SP[p3, q2] - 32*s^2*SP[p3, q1]*SP[p3, q2] + 
    32*d*s^2*SP[p3, q1]*SP[p3, q2] - 8*d^2*s^2*SP[p3, q1]*SP[p3, q2] - 
    128*mm^2*t*SP[p3, q1]*SP[p3, q2] + 64*d*mm^2*t*SP[p3, q1]*SP[p3, q2] + 
    64*s*t*SP[p3, q1]*SP[p3, q2] - 32*d*s*t*SP[p3, q1]*SP[p3, q2] + 
    64*t^2*SP[p3, q1]*SP[p3, q2] - 32*d*t^2*SP[p3, q1]*SP[p3, q2] + 
    64*mm^2*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 32*d*mm^2*SP[p2, q1]*
     SP[p3, q1]*SP[p3, q2] - 32*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] + 
    16*d*s*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 64*t*SP[p2, q1]*SP[p3, q1]*
     SP[p3, q2] + 32*d*t*SP[p2, q1]*SP[p3, q1]*SP[p3, q2] - 
    768*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 512*d*me^2*SP[p2, q2]*
     SP[p3, q1]*SP[p3, q2] - 112*d^2*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
    8*d^3*me^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 
    128*mm^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 80*d*mm^2*SP[p2, q2]*
     SP[p3, q1]*SP[p3, q2] - 8*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] - 
    416*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 256*d*s*SP[p2, q2]*SP[p3, q1]*
     SP[p3, q2] - 56*d^2*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
    4*d^3*s*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 128*t*SP[p2, q2]*SP[p3, q1]*
     SP[p3, q2] - 80*d*t*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 
    8*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[p3, q2] + 32*d*me^2*mm^2*SP[p3, q2]^2 + 
    16*d*mm^2*s*SP[p3, q2]^2 + 768*me^2*SP[p2, q1]*SP[p3, q2]^2 - 
    512*d*me^2*SP[p2, q1]*SP[p3, q2]^2 + 112*d^2*me^2*SP[p2, q1]*
     SP[p3, q2]^2 - 8*d^3*me^2*SP[p2, q1]*SP[p3, q2]^2 + 
    128*mm^2*SP[p2, q1]*SP[p3, q2]^2 - 80*d*mm^2*SP[p2, q1]*SP[p3, q2]^2 + 
    8*d^2*mm^2*SP[p2, q1]*SP[p3, q2]^2 + 416*s*SP[p2, q1]*SP[p3, q2]^2 - 
    256*d*s*SP[p2, q1]*SP[p3, q2]^2 + 56*d^2*s*SP[p2, q1]*SP[p3, q2]^2 - 
    4*d^3*s*SP[p2, q1]*SP[p3, q2]^2 - 128*t*SP[p2, q1]*SP[p3, q2]^2 + 
    80*d*t*SP[p2, q1]*SP[p3, q2]^2 - 8*d^2*t*SP[p2, q1]*SP[p3, q2]^2 - 
    64*me^2*mm^4*SP[q1, q1] + 32*d*me^2*mm^4*SP[q1, q1] - 
    32*mm^6*SP[q1, q1] + 16*d*mm^6*SP[q1, q1] + 64*me^2*mm^2*s*SP[q1, q1] - 
    48*d*me^2*mm^2*s*SP[q1, q1] + 8*d^2*me^2*mm^2*s*SP[q1, q1] + 
    16*mm^4*s*SP[q1, q1] - 8*d*mm^4*s*SP[q1, q1] - 16*me^2*s^2*SP[q1, q1] + 
    16*d*me^2*s^2*SP[q1, q1] - 4*d^2*me^2*s^2*SP[q1, q1] + 
    16*mm^2*s^2*SP[q1, q1] - 16*d*mm^2*s^2*SP[q1, q1] + 
    4*d^2*mm^2*s^2*SP[q1, q1] - 8*s^3*SP[q1, q1] + 8*d*s^3*SP[q1, q1] - 
    2*d^2*s^3*SP[q1, q1] + 64*mm^4*t*SP[q1, q1] - 32*d*mm^4*t*SP[q1, q1] - 
    64*mm^2*s*t*SP[q1, q1] + 32*d*mm^2*s*t*SP[q1, q1] + 16*s^2*t*SP[q1, q1] - 
    8*d*s^2*t*SP[q1, q1] - 32*mm^2*t^2*SP[q1, q1] + 
    16*d*mm^2*t^2*SP[q1, q1] + 16*s*t^2*SP[q1, q1] - 8*d*s*t^2*SP[q1, q1] + 
    32*me^2*mm^2*SP[p2, q2]*SP[q1, q1] - 16*d*me^2*mm^2*SP[p2, q2]*
     SP[q1, q1] + 32*mm^4*SP[p2, q2]*SP[q1, q1] - 
    16*d*mm^4*SP[p2, q2]*SP[q1, q1] - 32*me^2*s*SP[p2, q2]*SP[q1, q1] + 
    32*d*me^2*s*SP[p2, q2]*SP[q1, q1] - 8*d^2*me^2*s*SP[p2, q2]*SP[q1, q1] - 
    16*mm^2*s*SP[p2, q2]*SP[q1, q1] + 8*d*mm^2*s*SP[p2, q2]*SP[q1, q1] - 
    16*s^2*SP[p2, q2]*SP[q1, q1] + 16*d*s^2*SP[p2, q2]*SP[q1, q1] - 
    4*d^2*s^2*SP[p2, q2]*SP[q1, q1] - 32*mm^2*t*SP[p2, q2]*SP[q1, q1] + 
    16*d*mm^2*t*SP[p2, q2]*SP[q1, q1] + 16*s*t*SP[p2, q2]*SP[q1, q1] - 
    8*d*s*t*SP[p2, q2]*SP[q1, q1] - 32*mm^2*SP[p2, q2]^2*SP[q1, q1] + 
    24*d*mm^2*SP[p2, q2]^2*SP[q1, q1] - 4*d^2*mm^2*SP[p2, q2]^2*SP[q1, q1] + 
    32*t*SP[p2, q2]^2*SP[q1, q1] - 24*d*t*SP[p2, q2]^2*SP[q1, q1] + 
    4*d^2*t*SP[p2, q2]^2*SP[q1, q1] - 64*me^2*mm^2*SP[p3, q2]*SP[q1, q1] + 
    32*d*me^2*mm^2*SP[p3, q2]*SP[q1, q1] + 64*me^2*s*SP[p3, q2]*SP[q1, q1] - 
    64*d*me^2*s*SP[p3, q2]*SP[q1, q1] + 16*d^2*me^2*s*SP[p3, q2]*SP[q1, q1] - 
    32*mm^2*s*SP[p3, q2]*SP[q1, q1] + 16*d*mm^2*s*SP[p3, q2]*SP[q1, q1] + 
    48*s^2*SP[p3, q2]*SP[q1, q1] - 40*d*s^2*SP[p3, q2]*SP[q1, q1] + 
    8*d^2*s^2*SP[p3, q2]*SP[q1, q1] + 128*me^2*SP[p2, q2]*SP[p3, q2]*
     SP[q1, q1] - 96*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
    16*d^2*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
    64*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 48*d*mm^2*SP[p2, q2]*
     SP[p3, q2]*SP[q1, q1] + 8*d^2*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 
    32*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 24*d*s*SP[p2, q2]*SP[p3, q2]*
     SP[q1, q1] + 4*d^2*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
    64*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] + 48*d*t*SP[p2, q2]*SP[p3, q2]*
     SP[q1, q1] - 8*d^2*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q1] - 
    128*me^2*SP[p3, q2]^2*SP[q1, q1] + 96*d*me^2*SP[p3, q2]^2*SP[q1, q1] - 
    16*d^2*me^2*SP[p3, q2]^2*SP[q1, q1] - 64*s*SP[p3, q2]^2*SP[q1, q1] + 
    48*d*s*SP[p3, q2]^2*SP[q1, q1] - 8*d^2*s*SP[p3, q2]^2*SP[q1, q1] - 
    64*me^2*mm^4*SP[q1, q2] + 64*d*me^2*mm^4*SP[q1, q2] - 
    32*mm^6*SP[q1, q2] + 32*d*mm^6*SP[q1, q2] + 64*me^2*mm^2*s*SP[q1, q2] - 
    64*d*me^2*mm^2*s*SP[q1, q2] + 16*d^2*me^2*mm^2*s*SP[q1, q2] + 
    16*mm^4*s*SP[q1, q2] - 8*d*mm^4*s*SP[q1, q2] - 16*me^2*s^2*SP[q1, q2] + 
    16*d*me^2*s^2*SP[q1, q2] - 4*d^2*me^2*s^2*SP[q1, q2] + 
    16*mm^2*s^2*SP[q1, q2] - 24*d*mm^2*s^2*SP[q1, q2] + 
    8*d^2*mm^2*s^2*SP[q1, q2] - 8*s^3*SP[q1, q2] + 8*d*s^3*SP[q1, q2] - 
    2*d^2*s^3*SP[q1, q2] + 64*mm^4*t*SP[q1, q2] - 64*d*mm^4*t*SP[q1, q2] - 
    64*mm^2*s*t*SP[q1, q2] + 48*d*mm^2*s*t*SP[q1, q2] + 16*s^2*t*SP[q1, q2] - 
    8*d*s^2*t*SP[q1, q2] - 32*mm^2*t^2*SP[q1, q2] + 
    32*d*mm^2*t^2*SP[q1, q2] + 16*s*t^2*SP[q1, q2] - 8*d*s*t^2*SP[q1, q2] - 
    64*me^2*mm^2*SP[p2, q1]*SP[q1, q2] + 32*d*me^2*mm^2*SP[p2, q1]*
     SP[q1, q2] - 32*mm^4*SP[p2, q1]*SP[q1, q2] + 
    16*d*mm^4*SP[p2, q1]*SP[q1, q2] + 32*me^2*s*SP[p2, q1]*SP[q1, q2] - 
    32*d*me^2*s*SP[p2, q1]*SP[q1, q2] + 8*d^2*me^2*s*SP[p2, q1]*SP[q1, q2] + 
    16*s^2*SP[p2, q1]*SP[q1, q2] - 16*d*s^2*SP[p2, q1]*SP[q1, q2] + 
    4*d^2*s^2*SP[p2, q1]*SP[q1, q2] + 64*mm^2*t*SP[p2, q1]*SP[q1, q2] - 
    32*d*mm^2*t*SP[p2, q1]*SP[q1, q2] - 32*s*t*SP[p2, q1]*SP[q1, q2] + 
    16*d*s*t*SP[p2, q1]*SP[q1, q2] - 32*t^2*SP[p2, q1]*SP[q1, q2] + 
    16*d*t^2*SP[p2, q1]*SP[q1, q2] + 192*me^2*mm^2*SP[p2, q2]*SP[q1, q2] - 
    32*d*me^2*mm^2*SP[p2, q2]*SP[q1, q2] + 64*mm^4*SP[p2, q2]*SP[q1, q2] - 
    32*d*mm^4*SP[p2, q2]*SP[q1, q2] + 32*me^2*s*SP[p2, q2]*SP[q1, q2] - 
    16*d*me^2*s*SP[p2, q2]*SP[q1, q2] + 80*mm^2*s*SP[p2, q2]*SP[q1, q2] + 
    16*s^2*SP[p2, q2]*SP[q1, q2] - 8*d*s^2*SP[p2, q2]*SP[q1, q2] - 
    96*mm^2*t*SP[p2, q2]*SP[q1, q2] + 32*d*mm^2*t*SP[p2, q2]*SP[q1, q2] + 
    32*t^2*SP[p2, q2]*SP[q1, q2] + 32*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 
    16*d*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] - 32*t*SP[p2, q1]*SP[p2, q2]*
     SP[q1, q2] + 16*d*t*SP[p2, q1]*SP[p2, q2]*SP[q1, q2] + 
    32*mm^2*SP[p2, q2]^2*SP[q1, q2] - 16*d*mm^2*SP[p2, q2]^2*SP[q1, q2] - 
    32*t*SP[p2, q2]^2*SP[q1, q2] + 16*d*t*SP[p2, q2]^2*SP[q1, q2] + 
    128*me^2*mm^2*SP[p3, q1]*SP[q1, q2] - 64*d*me^2*mm^2*SP[p3, q1]*
     SP[q1, q2] + 64*mm^4*SP[p3, q1]*SP[q1, q2] - 
    32*d*mm^4*SP[p3, q1]*SP[q1, q2] - 64*me^2*s*SP[p3, q1]*SP[q1, q2] + 
    64*d*me^2*s*SP[p3, q1]*SP[q1, q2] - 16*d^2*me^2*s*SP[p3, q1]*SP[q1, q2] - 
    32*s^2*SP[p3, q1]*SP[q1, q2] + 32*d*s^2*SP[p3, q1]*SP[q1, q2] - 
    8*d^2*s^2*SP[p3, q1]*SP[q1, q2] - 128*mm^2*t*SP[p3, q1]*SP[q1, q2] + 
    64*d*mm^2*t*SP[p3, q1]*SP[q1, q2] + 64*s*t*SP[p3, q1]*SP[q1, q2] - 
    32*d*s*t*SP[p3, q1]*SP[q1, q2] + 64*t^2*SP[p3, q1]*SP[q1, q2] - 
    32*d*t^2*SP[p3, q1]*SP[q1, q2] - 64*me^2*SP[p2, q2]*SP[p3, q1]*
     SP[q1, q2] + 32*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
    64*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 32*d*mm^2*SP[p2, q2]*
     SP[p3, q1]*SP[q1, q2] + 64*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] - 
    32*d*t*SP[p2, q2]*SP[p3, q1]*SP[q1, q2] + 192*me^2*mm^2*SP[p3, q2]*
     SP[q1, q2] - 96*d*me^2*mm^2*SP[p3, q2]*SP[q1, q2] + 
    16*d^2*me^2*mm^2*SP[p3, q2]*SP[q1, q2] + 128*mm^4*SP[p3, q2]*SP[q1, q2] - 
    80*d*mm^4*SP[p3, q2]*SP[q1, q2] + 8*d^2*mm^4*SP[p3, q2]*SP[q1, q2] - 
    448*me^2*s*SP[p3, q2]*SP[q1, q2] + 288*d*me^2*s*SP[p3, q2]*SP[q1, q2] - 
    56*d^2*me^2*s*SP[p3, q2]*SP[q1, q2] + 4*d^3*me^2*s*SP[p3, q2]*
     SP[q1, q2] - 32*mm^2*s*SP[p3, q2]*SP[q1, q2] + 
    32*d*mm^2*s*SP[p3, q2]*SP[q1, q2] - 256*s^2*SP[p3, q2]*SP[q1, q2] + 
    144*d*s^2*SP[p3, q2]*SP[q1, q2] - 28*d^2*s^2*SP[p3, q2]*SP[q1, q2] + 
    2*d^3*s^2*SP[p3, q2]*SP[q1, q2] - 256*mm^2*t*SP[p3, q2]*SP[q1, q2] + 
    160*d*mm^2*t*SP[p3, q2]*SP[q1, q2] - 16*d^2*mm^2*t*SP[p3, q2]*
     SP[q1, q2] + 128*s*t*SP[p3, q2]*SP[q1, q2] - 
    80*d*s*t*SP[p3, q2]*SP[q1, q2] + 8*d^2*s*t*SP[p3, q2]*SP[q1, q2] + 
    128*t^2*SP[p3, q2]*SP[q1, q2] - 80*d*t^2*SP[p3, q2]*SP[q1, q2] + 
    8*d^2*t^2*SP[p3, q2]*SP[q1, q2] - 64*me^2*SP[p2, q1]*SP[p3, q2]*
     SP[q1, q2] + 32*d*me^2*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] - 
    32*s*SP[p2, q1]*SP[p3, q2]*SP[q1, q2] + 16*d*s*SP[p2, q1]*SP[p3, q2]*
     SP[q1, q2] - 128*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 
    64*d*me^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] - 
    64*mm^2*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 32*d*mm^2*SP[p2, q2]*
     SP[p3, q2]*SP[q1, q2] - 32*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 
    16*d*s*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 64*t*SP[p2, q2]*SP[p3, q2]*
     SP[q1, q2] - 32*d*t*SP[p2, q2]*SP[p3, q2]*SP[q1, q2] + 
    128*me^2*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 64*d*me^2*SP[p3, q1]*
     SP[p3, q2]*SP[q1, q2] + 64*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] - 
    32*d*s*SP[p3, q1]*SP[p3, q2]*SP[q1, q2] + 128*me^2*SP[p3, q2]^2*
     SP[q1, q2] - 64*d*me^2*SP[p3, q2]^2*SP[q1, q2] + 
    64*s*SP[p3, q2]^2*SP[q1, q2] - 32*d*s*SP[p3, q2]^2*SP[q1, q2] + 
    32*me^2*s*SP[q1, q2]^2 - 16*d*me^2*s*SP[q1, q2]^2 + 16*s^2*SP[q1, q2]^2 - 
    8*d*s^2*SP[q1, q2]^2 - 4*SP[p1, q2]^2*(-16*me^2*mm^2 + 8*d*me^2*mm^2 - 
      12*mm^4 + 10*d*mm^4 - d^2*mm^4 + 4*mm^2*s - 6*d*mm^2*s + d^2*mm^2*s + 
      12*mm^2*t - 10*d*mm^2*t + d^2*mm^2*t + 24*mm^2*SP[p2, q1] - 
      2*(4*(-2 + d)*me^2 - (20 - 10*d + d^2)*mm^2 + 16*s - 8*d*s + d^2*s + 
        20*t - 10*d*t + d^2*t)*SP[p3, q1] - 8*mm^2*SP[q1, q1] + 
      6*d*mm^2*SP[q1, q1] - d^2*mm^2*SP[q1, q1] + 8*s*SP[q1, q1] - 
      6*d*s*SP[q1, q1] + d^2*s*SP[q1, q1] + 8*t*SP[q1, q1] - 
      6*d*t*SP[q1, q1] + d^2*t*SP[q1, q1] + 8*mm^2*SP[q1, q2] - 
      4*d*mm^2*SP[q1, q2] - 8*s*SP[q1, q2] + 4*d*s*SP[q1, q2] - 
      8*t*SP[q1, q2] + 4*d*t*SP[q1, q2]) + 32*me^2*mm^4*SP[q2, q2] - 
    32*d*me^2*mm^4*SP[q2, q2] + 8*d^2*me^2*mm^4*SP[q2, q2] + 
    16*mm^6*SP[q2, q2] - 16*d*mm^6*SP[q2, q2] + 4*d^2*mm^6*SP[q2, q2] - 
    160*me^2*mm^2*s*SP[q2, q2] + 144*d*me^2*mm^2*s*SP[q2, q2] - 
    32*d^2*me^2*mm^2*s*SP[q2, q2] + 2*d^3*me^2*mm^2*s*SP[q2, q2] - 
    112*mm^2*s^2*SP[q2, q2] + 80*d*mm^2*s^2*SP[q2, q2] - 
    16*d^2*mm^2*s^2*SP[q2, q2] + d^3*mm^2*s^2*SP[q2, q2] - 
    32*mm^4*t*SP[q2, q2] + 32*d*mm^4*t*SP[q2, q2] - 8*d^2*mm^4*t*SP[q2, q2] + 
    16*mm^2*s*t*SP[q2, q2] - 16*d*mm^2*s*t*SP[q2, q2] + 
    4*d^2*mm^2*s*t*SP[q2, q2] + 16*mm^2*t^2*SP[q2, q2] - 
    16*d*mm^2*t^2*SP[q2, q2] + 4*d^2*mm^2*t^2*SP[q2, q2] - 
    224*me^2*mm^2*SP[p2, q1]*SP[q2, q2] + 32*d*me^2*mm^2*SP[p2, q1]*
     SP[q2, q2] + 8*d^2*me^2*mm^2*SP[p2, q1]*SP[q2, q2] - 
    64*mm^4*SP[p2, q1]*SP[q2, q2] + 24*d*mm^4*SP[p2, q1]*SP[q2, q2] - 
    32*me^2*s*SP[p2, q1]*SP[q2, q2] + 16*d*me^2*s*SP[p2, q1]*SP[q2, q2] - 
    96*mm^2*s*SP[p2, q1]*SP[q2, q2] + 4*d^2*mm^2*s*SP[p2, q1]*SP[q2, q2] - 
    16*s^2*SP[p2, q1]*SP[q2, q2] + 8*d*s^2*SP[p2, q1]*SP[q2, q2] + 
    128*mm^2*t*SP[p2, q1]*SP[q2, q2] - 40*d*mm^2*t*SP[p2, q1]*SP[q2, q2] - 
    16*s*t*SP[p2, q1]*SP[q2, q2] + 8*d*s*t*SP[p2, q1]*SP[q2, q2] - 
    64*t^2*SP[p2, q1]*SP[q2, q2] + 16*d*t^2*SP[p2, q1]*SP[q2, q2] - 
    16*mm^2*SP[p2, q1]^2*SP[q2, q2] + 8*d*mm^2*SP[p2, q1]^2*SP[q2, q2] + 
    16*t*SP[p2, q1]^2*SP[q2, q2] - 8*d*t*SP[p2, q1]^2*SP[q2, q2] + 
    32*me^2*mm^2*SP[p2, q2]*SP[q2, q2] - 64*d*me^2*mm^2*SP[p2, q2]*
     SP[q2, q2] + 32*d^2*me^2*mm^2*SP[p2, q2]*SP[q2, q2] - 
    4*d^3*me^2*mm^2*SP[p2, q2]*SP[q2, q2] - 16*mm^4*SP[p2, q2]*SP[q2, q2] + 
    16*d*mm^4*SP[p2, q2]*SP[q2, q2] - 4*d^2*mm^4*SP[p2, q2]*SP[q2, q2] + 
    48*mm^2*s*SP[p2, q2]*SP[q2, q2] - 56*d*mm^2*s*SP[p2, q2]*SP[q2, q2] + 
    20*d^2*mm^2*s*SP[p2, q2]*SP[q2, q2] - 2*d^3*mm^2*s*SP[p2, q2]*
     SP[q2, q2] + 16*mm^2*t*SP[p2, q2]*SP[q2, q2] - 
    16*d*mm^2*t*SP[p2, q2]*SP[q2, q2] + 4*d^2*mm^2*t*SP[p2, q2]*SP[q2, q2] - 
    48*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q2, q2] + 32*d*mm^2*SP[p2, q1]*
     SP[p2, q2]*SP[q2, q2] - 4*d^2*mm^2*SP[p2, q1]*SP[p2, q2]*SP[q2, q2] + 
    48*t*SP[p2, q1]*SP[p2, q2]*SP[q2, q2] - 32*d*t*SP[p2, q1]*SP[p2, q2]*
     SP[q2, q2] + 4*d^2*t*SP[p2, q1]*SP[p2, q2]*SP[q2, q2] - 
    128*me^2*mm^2*SP[p3, q1]*SP[q2, q2] + 80*d*me^2*mm^2*SP[p3, q1]*
     SP[q2, q2] - 16*d^2*me^2*mm^2*SP[p3, q1]*SP[q2, q2] - 
    64*mm^4*SP[p3, q1]*SP[q2, q2] + 48*d*mm^4*SP[p3, q1]*SP[q2, q2] - 
    8*d^2*mm^4*SP[p3, q1]*SP[q2, q2] + 448*me^2*s*SP[p3, q1]*SP[q2, q2] - 
    288*d*me^2*s*SP[p3, q1]*SP[q2, q2] + 56*d^2*me^2*s*SP[p3, q1]*
     SP[q2, q2] - 4*d^3*me^2*s*SP[p3, q1]*SP[q2, q2] - 
    8*d*mm^2*s*SP[p3, q1]*SP[q2, q2] + 272*s^2*SP[p3, q1]*SP[q2, q2] - 
    152*d*s^2*SP[p3, q1]*SP[q2, q2] + 28*d^2*s^2*SP[p3, q1]*SP[q2, q2] - 
    2*d^3*s^2*SP[p3, q1]*SP[q2, q2] + 128*mm^2*t*SP[p3, q1]*SP[q2, q2] - 
    96*d*mm^2*t*SP[p3, q1]*SP[q2, q2] + 16*d^2*mm^2*t*SP[p3, q1]*SP[q2, q2] - 
    64*s*t*SP[p3, q1]*SP[q2, q2] + 48*d*s*t*SP[p3, q1]*SP[q2, q2] - 
    8*d^2*s*t*SP[p3, q1]*SP[q2, q2] - 64*t^2*SP[p3, q1]*SP[q2, q2] + 
    48*d*t^2*SP[p3, q1]*SP[q2, q2] - 8*d^2*t^2*SP[p3, q1]*SP[q2, q2] + 
    64*me^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 32*d*me^2*SP[p2, q1]*
     SP[p3, q1]*SP[q2, q2] + 32*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
    16*d*mm^2*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 16*s*SP[p2, q1]*SP[p3, q1]*
     SP[q2, q2] - 8*d*s*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] - 
    32*t*SP[p2, q1]*SP[p3, q1]*SP[q2, q2] + 16*d*t*SP[p2, q1]*SP[p3, q1]*
     SP[q2, q2] - 96*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
    112*d*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 40*d^2*me^2*SP[p2, q2]*
     SP[p3, q1]*SP[q2, q2] + 4*d^3*me^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
    32*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 24*d*mm^2*SP[p2, q2]*
     SP[p3, q1]*SP[q2, q2] + 4*d^2*mm^2*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 
    112*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 88*d*s*SP[p2, q2]*SP[p3, q1]*
     SP[q2, q2] - 24*d^2*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] + 
    2*d^3*s*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 32*t*SP[p2, q2]*SP[p3, q1]*
     SP[q2, q2] + 24*d*t*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 
    4*d^2*t*SP[p2, q2]*SP[p3, q1]*SP[q2, q2] - 64*me^2*SP[p3, q1]^2*
     SP[q2, q2] + 32*d*me^2*SP[p3, q1]^2*SP[q2, q2] - 
    32*s*SP[p3, q1]^2*SP[q2, q2] + 16*d*s*SP[p3, q1]^2*SP[q2, q2] + 
    32*me^2*mm^2*SP[p3, q2]*SP[q2, q2] - 32*d*me^2*mm^2*SP[p3, q2]*
     SP[q2, q2] + 8*d^2*me^2*mm^2*SP[p3, q2]*SP[q2, q2] + 
    16*mm^2*s*SP[p3, q2]*SP[q2, q2] - 16*d*mm^2*s*SP[p3, q2]*SP[q2, q2] + 
    4*d^2*mm^2*s*SP[p3, q2]*SP[q2, q2] + 288*me^2*SP[p2, q1]*SP[p3, q2]*
     SP[q2, q2] - 240*d*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
    56*d^2*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
    4*d^3*me^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
    64*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 40*d*mm^2*SP[p2, q1]*
     SP[p3, q2]*SP[q2, q2] + 4*d^2*mm^2*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] + 
    160*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 120*d*s*SP[p2, q1]*SP[p3, q2]*
     SP[q2, q2] + 28*d^2*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
    2*d^3*s*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 64*t*SP[p2, q1]*SP[p3, q2]*
     SP[q2, q2] + 40*d*t*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 
    4*d^2*t*SP[p2, q1]*SP[p3, q2]*SP[q2, q2] - 192*me^2*SP[p3, q1]*SP[p3, q2]*
     SP[q2, q2] + 128*d*me^2*SP[p3, q1]*SP[p3, q2]*SP[q2, q2] - 
    16*d^2*me^2*SP[p3, q1]*SP[p3, q2]*SP[q2, q2] - 
    96*s*SP[p3, q1]*SP[p3, q2]*SP[q2, q2] + 64*d*s*SP[p3, q1]*SP[p3, q2]*
     SP[q2, q2] - 8*d^2*s*SP[p3, q1]*SP[p3, q2]*SP[q2, q2] + 
    64*me^2*mm^2*SP[q1, q1]*SP[q2, q2] - 48*d*me^2*mm^2*SP[q1, q1]*
     SP[q2, q2] + 8*d^2*me^2*mm^2*SP[q1, q1]*SP[q2, q2] + 
    32*mm^4*SP[q1, q1]*SP[q2, q2] - 24*d*mm^4*SP[q1, q1]*SP[q2, q2] + 
    4*d^2*mm^4*SP[q1, q1]*SP[q2, q2] - 80*me^2*s*SP[q1, q1]*SP[q2, q2] + 
    72*d*me^2*s*SP[q1, q1]*SP[q2, q2] - 20*d^2*me^2*s*SP[q1, q1]*SP[q2, q2] + 
    2*d^3*me^2*s*SP[q1, q1]*SP[q2, q2] - 40*s^2*SP[q1, q1]*SP[q2, q2] + 
    36*d*s^2*SP[q1, q1]*SP[q2, q2] - 10*d^2*s^2*SP[q1, q1]*SP[q2, q2] + 
    d^3*s^2*SP[q1, q1]*SP[q2, q2] - 64*mm^2*t*SP[q1, q1]*SP[q2, q2] + 
    48*d*mm^2*t*SP[q1, q1]*SP[q2, q2] - 8*d^2*mm^2*t*SP[q1, q1]*SP[q2, q2] + 
    32*s*t*SP[q1, q1]*SP[q2, q2] - 24*d*s*t*SP[q1, q1]*SP[q2, q2] + 
    4*d^2*s*t*SP[q1, q1]*SP[q2, q2] + 32*t^2*SP[q1, q1]*SP[q2, q2] - 
    24*d*t^2*SP[q1, q1]*SP[q2, q2] + 4*d^2*t^2*SP[q1, q1]*SP[q2, q2] + 
    64*me^2*mm^2*SP[q1, q2]*SP[q2, q2] - 48*d*me^2*mm^2*SP[q1, q2]*
     SP[q2, q2] + 8*d^2*me^2*mm^2*SP[q1, q2]*SP[q2, q2] + 
    32*mm^4*SP[q1, q2]*SP[q2, q2] - 24*d*mm^4*SP[q1, q2]*SP[q2, q2] + 
    4*d^2*mm^4*SP[q1, q2]*SP[q2, q2] - 48*me^2*s*SP[q1, q2]*SP[q2, q2] + 
    56*d*me^2*s*SP[q1, q2]*SP[q2, q2] - 20*d^2*me^2*s*SP[q1, q2]*SP[q2, q2] + 
    2*d^3*me^2*s*SP[q1, q2]*SP[q2, q2] - 24*s^2*SP[q1, q2]*SP[q2, q2] + 
    28*d*s^2*SP[q1, q2]*SP[q2, q2] - 10*d^2*s^2*SP[q1, q2]*SP[q2, q2] + 
    d^3*s^2*SP[q1, q2]*SP[q2, q2] - 64*mm^2*t*SP[q1, q2]*SP[q2, q2] + 
    48*d*mm^2*t*SP[q1, q2]*SP[q2, q2] - 8*d^2*mm^2*t*SP[q1, q2]*SP[q2, q2] + 
    32*s*t*SP[q1, q2]*SP[q2, q2] - 24*d*s*t*SP[q1, q2]*SP[q2, q2] + 
    4*d^2*s*t*SP[q1, q2]*SP[q2, q2] + 32*t^2*SP[q1, q2]*SP[q2, q2] - 
    24*d*t^2*SP[q1, q2]*SP[q2, q2] + 4*d^2*t^2*SP[q1, q2]*SP[q2, q2] - 
    8*(-2 + d)*SP[p1, q1]^2*((2*(-2 + d)*me^2 + 2*mm^2 - 4*s + d*s - 2*t)*
       SP[p3, q2] + (mm^2 - s - t)*SP[q2, q2]) - 
    2*SP[p1, q1]*(32*d*me^2*mm^4 + 16*d*mm^6 - 16*d*me^2*mm^2*s + 
      8*d^2*me^2*mm^2*s - 8*d*mm^2*s^2 + 4*d^2*mm^2*s^2 - 32*d*mm^4*t + 
      16*d*mm^2*s*t + 16*d*mm^2*t^2 + 48*mm^2*SP[p2, q2]^2 + 
      64*me^2*mm^2*SP[p3, q1] - 32*d*me^2*mm^2*SP[p3, q1] + 
      32*mm^4*SP[p3, q1] - 16*d*mm^4*SP[p3, q1] - 32*me^2*s*SP[p3, q1] + 
      32*d*me^2*s*SP[p3, q1] - 8*d^2*me^2*s*SP[p3, q1] - 16*s^2*SP[p3, q1] + 
      16*d*s^2*SP[p3, q1] - 4*d^2*s^2*SP[p3, q1] - 64*mm^2*t*SP[p3, q1] + 
      32*d*mm^2*t*SP[p3, q1] + 32*s*t*SP[p3, q1] - 16*d*s*t*SP[p3, q1] + 
      32*t^2*SP[p3, q1] - 16*d*t^2*SP[p3, q1] + 32*me^2*mm^2*SP[p3, q2] + 
      16*d*me^2*mm^2*SP[p3, q2] - 8*d^2*me^2*mm^2*SP[p3, q2] + 
      16*mm^4*SP[p3, q2] - 16*me^2*s*SP[p3, q2] + 16*d*me^2*s*SP[p3, q2] - 
      4*d^2*me^2*s*SP[p3, q2] + 16*d*mm^2*s*SP[p3, q2] - 
      4*d^2*mm^2*s*SP[p3, q2] - 8*s^2*SP[p3, q2] + 8*d*s^2*SP[p3, q2] - 
      2*d^2*s^2*SP[p3, q2] - 32*mm^2*t*SP[p3, q2] + 8*d*mm^2*t*SP[p3, q2] + 
      16*s*t*SP[p3, q2] - 8*d*s*t*SP[p3, q2] + 16*t^2*SP[p3, q2] - 
      8*d*t^2*SP[p3, q2] + 64*me^2*SP[p2, q1]*SP[p3, q2] - 
      64*d*me^2*SP[p2, q1]*SP[p3, q2] + 16*d^2*me^2*SP[p2, q1]*SP[p3, q2] + 
      48*s*SP[p2, q1]*SP[p3, q2] - 40*d*s*SP[p2, q1]*SP[p3, q2] + 
      8*d^2*s*SP[p2, q1]*SP[p3, q2] + 32*mm^2*SP[p3, q1]*SP[p3, q2] - 
      16*d*mm^2*SP[p3, q1]*SP[p3, q2] - 16*s*SP[p3, q1]*SP[p3, q2] + 
      8*d*s*SP[p3, q1]*SP[p3, q2] - 32*t*SP[p3, q1]*SP[p3, q2] + 
      16*d*t*SP[p3, q1]*SP[p3, q2] - 384*me^2*SP[p3, q2]^2 + 
      256*d*me^2*SP[p3, q2]^2 - 56*d^2*me^2*SP[p3, q2]^2 + 
      4*d^3*me^2*SP[p3, q2]^2 + 64*mm^2*SP[p3, q2]^2 - 
      40*d*mm^2*SP[p3, q2]^2 + 4*d^2*mm^2*SP[p3, q2]^2 - 272*s*SP[p3, q2]^2 + 
      168*d*s*SP[p3, q2]^2 - 32*d^2*s*SP[p3, q2]^2 + 2*d^3*s*SP[p3, q2]^2 - 
      64*t*SP[p3, q2]^2 + 40*d*t*SP[p3, q2]^2 - 4*d^2*t*SP[p3, q2]^2 + 
      32*me^2*mm^2*SP[q1, q2] - 16*d*me^2*mm^2*SP[q1, q2] + 
      16*mm^4*SP[q1, q2] - 8*d*mm^4*SP[q1, q2] - 16*me^2*s*SP[q1, q2] + 
      16*d*me^2*s*SP[q1, q2] - 4*d^2*me^2*s*SP[q1, q2] - 8*s^2*SP[q1, q2] + 
      8*d*s^2*SP[q1, q2] - 2*d^2*s^2*SP[q1, q2] - 32*mm^2*t*SP[q1, q2] + 
      16*d*mm^2*t*SP[q1, q2] + 16*s*t*SP[q1, q2] - 8*d*s*t*SP[q1, q2] + 
      16*t^2*SP[q1, q2] - 8*d*t^2*SP[q1, q2] + 32*me^2*SP[p3, q2]*
       SP[q1, q2] - 16*d*me^2*SP[p3, q2]*SP[q1, q2] + 
      16*s*SP[p3, q2]*SP[q1, q2] - 8*d*s*SP[p3, q2]*SP[q1, q2] + 
      112*me^2*mm^2*SP[q2, q2] - 16*d*me^2*mm^2*SP[q2, q2] - 
      4*d^2*me^2*mm^2*SP[q2, q2] + 32*mm^4*SP[q2, q2] - 4*d*mm^4*SP[q2, q2] + 
      16*me^2*s*SP[q2, q2] - 8*d*me^2*s*SP[q2, q2] + 4*d*mm^2*s*SP[q2, q2] - 
      2*d^2*mm^2*s*SP[q2, q2] + 32*s^2*SP[q2, q2] - 8*d*s^2*SP[q2, q2] - 
      64*mm^2*t*SP[q2, q2] + 12*d*mm^2*t*SP[q2, q2] + 56*s*t*SP[q2, q2] - 
      12*d*s*t*SP[q2, q2] + 32*t^2*SP[q2, q2] - 8*d*t^2*SP[q2, q2] - 
      8*s*SP[p2, q1]*SP[q2, q2] + 4*d*s*SP[p2, q1]*SP[q2, q2] - 
      32*me^2*SP[p3, q1]*SP[q2, q2] + 16*d*me^2*SP[p3, q1]*SP[q2, q2] + 
      16*mm^2*SP[p3, q1]*SP[q2, q2] - 8*d*mm^2*SP[p3, q1]*SP[q2, q2] - 
      24*s*SP[p3, q1]*SP[q2, q2] + 12*d*s*SP[p3, q1]*SP[q2, q2] - 
      16*t*SP[p3, q1]*SP[q2, q2] + 8*d*t*SP[p3, q1]*SP[q2, q2] - 
      144*me^2*SP[p3, q2]*SP[q2, q2] + 120*d*me^2*SP[p3, q2]*SP[q2, q2] - 
      28*d^2*me^2*SP[p3, q2]*SP[q2, q2] + 2*d^3*me^2*SP[p3, q2]*SP[q2, q2] + 
      32*mm^2*SP[p3, q2]*SP[q2, q2] - 20*d*mm^2*SP[p3, q2]*SP[q2, q2] + 
      2*d^2*mm^2*SP[p3, q2]*SP[q2, q2] - 112*s*SP[p3, q2]*SP[q2, q2] + 
      80*d*s*SP[p3, q2]*SP[q2, q2] - 16*d^2*s*SP[p3, q2]*SP[q2, q2] + 
      d^3*s*SP[p3, q2]*SP[q2, q2] - 32*t*SP[p3, q2]*SP[q2, q2] + 
      20*d*t*SP[p3, q2]*SP[q2, q2] - 2*d^2*t*SP[p3, q2]*SP[q2, q2] + 
      2*SP[p2, q2]*(-8*d*me^2*mm^2 + 4*d^2*me^2*mm^2 - 12*d*mm^4 + 
        2*d^2*mm^2*s + 12*d*mm^2*t - 2*(-2 + d)*(2*(-2 + d)*me^2 - 6*mm^2 + 
          d*s + 6*t)*SP[p3, q1] + 2*(4*(-2 + d)*me^2 + (36 - 10*d + d^2)*
           mm^2 - 36*s + 12*d*s - d^2*s - 36*t + 10*d*t - d^2*t)*SP[p3, q2] - 
        8*mm^2*SP[q1, q2] + 4*d*mm^2*SP[q1, q2] + 8*s*SP[q1, q2] - 
        4*d*s*SP[q1, q2] + 8*t*SP[q1, q2] - 4*d*t*SP[q1, q2] + 
        20*mm^2*SP[q2, q2] - 8*d*mm^2*SP[q2, q2] + d^2*mm^2*SP[q2, q2] - 
        16*s*SP[q2, q2] + 8*d*s*SP[q2, q2] - d^2*s*SP[q2, q2] - 
        20*t*SP[q2, q2] + 8*d*t*SP[q2, q2] - d^2*t*SP[q2, q2]) + 
      2*SP[p1, q2]*(-8*d*me^2*mm^2 + 4*d^2*me^2*mm^2 + 4*d*mm^4 - 
        8*d*mm^2*s + 2*d^2*mm^2*s - 4*d*mm^2*t - 24*mm^2*SP[p2, q2] - 
        2*(-2 + d)*(2*(-2 + d)*me^2 + 2*mm^2 - 4*s + d*s - 2*t)*SP[p3, q1] - 
        16*me^2*SP[p3, q2] + 8*d*me^2*SP[p3, q2] - 40*mm^2*SP[p3, q2] + 
        20*d*mm^2*SP[p3, q2] - 2*d^2*mm^2*SP[p3, q2] + 32*s*SP[p3, q2] - 
        16*d*s*SP[p3, q2] + 2*d^2*s*SP[p3, q2] + 40*t*SP[p3, q2] - 
        20*d*t*SP[p3, q2] + 2*d^2*t*SP[p3, q2] + 8*mm^2*SP[q1, q2] - 
        4*d*mm^2*SP[q1, q2] - 8*s*SP[q1, q2] + 4*d*s*SP[q1, q2] - 
        8*t*SP[q1, q2] + 4*d*t*SP[q1, q2] - 12*mm^2*SP[q2, q2] + 
        8*d*mm^2*SP[q2, q2] - d^2*mm^2*SP[q2, q2] + 12*s*SP[q2, q2] - 
        8*d*s*SP[q2, q2] + d^2*s*SP[q2, q2] + 12*t*SP[q2, q2] - 
        8*d*t*SP[q2, q2] + d^2*t*SP[q2, q2])) - 
    2*SP[p1, q2]*(16*me^2*mm^4 + 8*d*me^2*mm^4 - 16*mm^6 + 16*d*mm^6 - 
      16*me^2*mm^2*s + 8*d*me^2*mm^2*s + 24*mm^4*s - 12*d*mm^4*s - 
      16*mm^2*s^2 + 8*d*mm^2*s^2 + 16*mm^4*t - 24*d*mm^4*t - 8*mm^2*s*t + 
      12*d*mm^2*s*t + 8*d*mm^2*t^2 + 32*me^2*mm^2*SP[p3, q1] - 
      16*d*me^2*mm^2*SP[p3, q1] + 16*mm^4*SP[p3, q1] - 24*d*mm^4*SP[p3, q1] - 
      16*me^2*s*SP[p3, q1] + 16*d*me^2*s*SP[p3, q1] - 
      4*d^2*me^2*s*SP[p3, q1] + 8*d*mm^2*s*SP[p3, q1] - 8*s^2*SP[p3, q1] + 
      8*d*s^2*SP[p3, q1] - 2*d^2*s^2*SP[p3, q1] - 32*mm^2*t*SP[p3, q1] + 
      32*d*mm^2*t*SP[p3, q1] + 16*s*t*SP[p3, q1] - 8*d*s*t*SP[p3, q1] + 
      16*t^2*SP[p3, q1] - 8*d*t^2*SP[p3, q1] - 32*mm^2*SP[p3, q1]^2 + 
      16*d*mm^2*SP[p3, q1]^2 + 16*s*SP[p3, q1]^2 - 8*d*s*SP[p3, q1]^2 + 
      32*t*SP[p3, q1]^2 - 16*d*t*SP[p3, q1]^2 - 96*me^2*mm^2*SP[p3, q2] + 
      128*d*me^2*mm^2*SP[p3, q2] - 40*d^2*me^2*mm^2*SP[p3, q2] + 
      4*d^3*me^2*mm^2*SP[p3, q2] - 8*d*mm^4*SP[p3, q2] - 
      72*mm^2*s*SP[p3, q2] + 84*d*mm^2*s*SP[p3, q2] - 
      22*d^2*mm^2*s*SP[p3, q2] + 2*d^3*mm^2*s*SP[p3, q2] + 
      8*d*mm^2*t*SP[p3, q2] + 384*me^2*SP[p3, q1]*SP[p3, q2] - 
      256*d*me^2*SP[p3, q1]*SP[p3, q2] + 56*d^2*me^2*SP[p3, q1]*SP[p3, q2] - 
      4*d^3*me^2*SP[p3, q1]*SP[p3, q2] - 64*mm^2*SP[p3, q1]*SP[p3, q2] + 
      40*d*mm^2*SP[p3, q1]*SP[p3, q2] - 4*d^2*mm^2*SP[p3, q1]*SP[p3, q2] + 
      272*s*SP[p3, q1]*SP[p3, q2] - 168*d*s*SP[p3, q1]*SP[p3, q2] + 
      32*d^2*s*SP[p3, q1]*SP[p3, q2] - 2*d^3*s*SP[p3, q1]*SP[p3, q2] + 
      64*t*SP[p3, q1]*SP[p3, q2] - 40*d*t*SP[p3, q1]*SP[p3, q2] + 
      4*d^2*t*SP[p3, q1]*SP[p3, q2] - 16*me^2*mm^2*SP[q1, q1] + 
      8*d*me^2*mm^2*SP[q1, q1] + 16*mm^4*SP[q1, q1] - 8*d*mm^4*SP[q1, q1] + 
      16*me^2*s*SP[q1, q1] - 16*d*me^2*s*SP[q1, q1] + 
      4*d^2*me^2*s*SP[q1, q1] - 24*mm^2*s*SP[q1, q1] + 
      12*d*mm^2*s*SP[q1, q1] + 16*s^2*SP[q1, q1] - 12*d*s^2*SP[q1, q1] + 
      2*d^2*s^2*SP[q1, q1] - 16*mm^2*t*SP[q1, q1] + 8*d*mm^2*t*SP[q1, q1] + 
      8*s*t*SP[q1, q1] - 4*d*s*t*SP[q1, q1] - 64*me^2*SP[p3, q2]*SP[q1, q1] + 
      48*d*me^2*SP[p3, q2]*SP[q1, q1] - 8*d^2*me^2*SP[p3, q2]*SP[q1, q1] + 
      32*mm^2*SP[p3, q2]*SP[q1, q1] - 24*d*mm^2*SP[p3, q2]*SP[q1, q1] + 
      4*d^2*mm^2*SP[p3, q2]*SP[q1, q1] - 48*s*SP[p3, q2]*SP[q1, q1] + 
      36*d*s*SP[p3, q2]*SP[q1, q1] - 6*d^2*s*SP[p3, q2]*SP[q1, q1] - 
      32*t*SP[p3, q2]*SP[q1, q1] + 24*d*t*SP[p3, q2]*SP[q1, q1] - 
      4*d^2*t*SP[p3, q2]*SP[q1, q1] - 96*me^2*mm^2*SP[q1, q2] + 
      16*d*me^2*mm^2*SP[q1, q2] - 16*d*mm^4*SP[q1, q2] - 
      16*me^2*s*SP[q1, q2] + 8*d*me^2*s*SP[q1, q2] - 24*mm^2*s*SP[q1, q2] + 
      16*d*mm^2*s*SP[q1, q2] - 24*s^2*SP[q1, q2] + 4*d*s^2*SP[q1, q2] + 
      16*mm^2*t*SP[q1, q2] + 16*d*mm^2*t*SP[q1, q2] - 32*s*t*SP[q1, q2] - 
      16*t^2*SP[q1, q2] + 32*me^2*SP[p3, q1]*SP[q1, q2] - 
      16*d*me^2*SP[p3, q1]*SP[q1, q2] - 32*mm^2*SP[p3, q1]*SP[q1, q2] + 
      16*d*mm^2*SP[p3, q1]*SP[q1, q2] + 32*s*SP[p3, q1]*SP[q1, q2] - 
      16*d*s*SP[p3, q1]*SP[q1, q2] + 32*t*SP[p3, q1]*SP[q1, q2] - 
      16*d*t*SP[p3, q1]*SP[q1, q2] + 64*me^2*SP[p3, q2]*SP[q1, q2] - 
      32*d*me^2*SP[p3, q2]*SP[q1, q2] - 32*mm^2*SP[p3, q2]*SP[q1, q2] + 
      16*d*mm^2*SP[p3, q2]*SP[q1, q2] + 48*s*SP[p3, q2]*SP[q1, q2] - 
      24*d*s*SP[p3, q2]*SP[q1, q2] + 32*t*SP[p3, q2]*SP[q1, q2] - 
      16*d*t*SP[p3, q2]*SP[q1, q2] + 2*SP[p2, q2]*(-32*me^2*mm^2 + 
        16*d*me^2*mm^2 - 44*mm^2*s + 18*d*mm^2*s - d^2*mm^2*s + 
        2*(-8*(-2 + d)*me^2 + (36 - 14*d + d^2)*s)*SP[p3, q1] - 
        (8 - 6*d + d^2)*s*SP[q1, q1] + 8*s*SP[q1, q2] - 4*d*s*SP[q1, q2]) - 
      16*me^2*mm^2*SP[q2, q2] + 32*d*me^2*mm^2*SP[q2, q2] - 
      16*d^2*me^2*mm^2*SP[q2, q2] + 2*d^3*me^2*mm^2*SP[q2, q2] - 
      8*mm^4*SP[q2, q2] + 8*d*mm^4*SP[q2, q2] - 2*d^2*mm^4*SP[q2, q2] - 
      16*mm^2*s*SP[q2, q2] + 20*d*mm^2*s*SP[q2, q2] - 
      8*d^2*mm^2*s*SP[q2, q2] + d^3*mm^2*s*SP[q2, q2] + 8*mm^2*t*SP[q2, q2] - 
      8*d*mm^2*t*SP[q2, q2] + 2*d^2*mm^2*t*SP[q2, q2] + 
      48*me^2*SP[p3, q1]*SP[q2, q2] - 56*d*me^2*SP[p3, q1]*SP[q2, q2] + 
      20*d^2*me^2*SP[p3, q1]*SP[q2, q2] - 2*d^3*me^2*SP[p3, q1]*SP[q2, q2] + 
      16*mm^2*SP[p3, q1]*SP[q2, q2] - 12*d*mm^2*SP[p3, q1]*SP[q2, q2] + 
      2*d^2*mm^2*SP[p3, q1]*SP[q2, q2] + 40*s*SP[p3, q1]*SP[q2, q2] - 
      32*d*s*SP[p3, q1]*SP[q2, q2] + 10*d^2*s*SP[p3, q1]*SP[q2, q2] - 
      d^3*s*SP[p3, q1]*SP[q2, q2] - 16*t*SP[p3, q1]*SP[q2, q2] + 
      12*d*t*SP[p3, q1]*SP[q2, q2] - 2*d^2*t*SP[p3, q1]*SP[q2, q2] + 
      2*SP[p2, q1]*(-8*d*me^2*mm^2 + 4*d^2*me^2*mm^2 + 12*d*mm^4 - 
        12*d*mm^2*s + 2*d^2*mm^2*s - 12*d*mm^2*t - 24*mm^2*SP[p2, q2] - 
        2*(-2 + d)*(2*(-2 + d)*me^2 + 6*mm^2 - 6*s + d*s - 6*t)*SP[p3, q1] - 
        16*me^2*SP[p3, q2] + 8*d*me^2*SP[p3, q2] - 72*mm^2*SP[p3, q2] + 
        20*d*mm^2*SP[p3, q2] - 2*d^2*mm^2*SP[p3, q2] + 4*d*s*SP[p3, q2] + 
        72*t*SP[p3, q2] - 20*d*t*SP[p3, q2] + 2*d^2*t*SP[p3, q2] + 
        8*mm^2*SP[q1, q2] - 4*d*mm^2*SP[q1, q2] - 8*t*SP[q1, q2] + 
        4*d*t*SP[q1, q2] - 20*mm^2*SP[q2, q2] + 8*d*mm^2*SP[q2, q2] - 
        d^2*mm^2*SP[q2, q2] + 4*s*SP[q2, q2] + 20*t*SP[q2, q2] - 
        8*d*t*SP[q2, q2] + d^2*t*SP[q2, q2]))))/(256*Pi^8*s^2)
